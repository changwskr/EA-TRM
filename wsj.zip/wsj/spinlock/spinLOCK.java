package wsj.spinlock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import   java.util.*;

public final class spinLOCK
{

  public interface Condition
  {	boolean satisfied();
  }

  public synchronized void acquire( Condition condition, long timeout )
      throws	Semaphore.Timed_out, InterruptedException
  {
    long expiration = System.currentTimeMillis() + timeout;			//#here
    while( !condition.satisfied() )
    {
      timeout = expiration - System.currentTimeMillis();
      if( timeout <= 0 )
        throw new Semaphore.Timed_out("Spin lock timed out.");
      wait( timeout );											//#there
    }
  }

  public synchronized void release()
  {
    notify();
  }

  public static final class Test
  {
    public static void main( String[] args ) throws Exception
    {
      final Stack stack	 =	new Stack();
      final spinLOCK lock =	new spinLOCK();
      new Thread()
      {
        public void run()
        {
          try
          {
            lock.acquire(new spinLOCK.Condition()
            {
              public boolean satisfied()
              {
                return !stack.isEmpty();
              }
            }, 4000  );

            System.out.println( stack.pop().toString() );
          }
          catch(Exception e){}
        }
        }.start();

      Thread.currentThread().sleep(500); // give the thread a
      // chance to get started.
      stack.push("hello world5");
      lock.release();
      stack.push("hello world1");
      lock.release();
      stack.push("hello world2");
      lock.release();
      stack.push("hello world3");
      lock.release();
      stack.push("hello world4");
      lock.release();
    }
  }
}