package wsj.rmiserver;

import java.rmi.*;
import java.rmi.server.*;

public class EchoImpl implements Echo
{
  public EchoImpl()
      throws RemoteException
  {}

  public void sayEcho(String name) {
    Logger.trace("EchoImpl.sayEcho()","start - "+name);
    try {
      Logger.trace("EchoImpl.sayEcho()","30�ʵ��� �����.......");
      Thread.sleep(1000*30);
      Logger.trace("EchoImpl.sayEcho()","30�ʵ��� �������.......");
    } catch(Exception e) {
      e.printStackTrace();
    }
    Logger.trace("EchoImpl.sayEcho()","end - "+name);
  }

  public String say(String name) {
    Logger.trace("EchoImpl.say()","start - "+name);
    try {
      Thread.sleep(1000*30);
    } catch(Exception e) {
      e.printStackTrace();
    }
    Logger.trace("EchoImpl.say()","end - "+name);
    return name;
  }
}