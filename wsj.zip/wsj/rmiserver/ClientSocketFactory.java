package wsj.rmiserver;

import java.io.*;
import java.net.*;
import java.util.*;
import java.rmi.server.*;

public class ClientSocketFactory
    implements RMIClientSocketFactory, Serializable {
  private InetAddress[] svrAddrs;

  public void init() throws UnknownHostException,IOException
  {
    String hostname = InetAddress.getLocalHost().getHostName();
    svrAddrs = InetAddress.getAllByName(hostname);
  }

  public Socket createSocket(String ip, int port)
      throws IOException
  {
    Logger.trace("ClientSocketFactory.createSocket()","connect - "+ip+":"+port);
    Socket sck = null;
    try {
      sck = new Socket(ip,port);
    } catch(IOException e) {
      Logger.trace("ClientSocketFactory.createSocket()",e.toString());
      for(int i=0;i<svrAddrs.length;i++) {
        if(!svrAddrs[i].getHostAddress().equals(ip)) {
          try {
            Logger.trace(
            "ClientSocketFactory.createSocket()",
            "connect - "+svrAddrs[i].getHostAddress()+":"+port
            );
            sck = new Socket(svrAddrs[i],port);
            } catch(Exception ex) {	}
        }
      }
    }
    if(sck==null) throw new IOException("Unkwon Host...");
    sck.setSoTimeout(5000);
    Logger.trace("ClientSocketFactory.createSocket()","create a Socket - "+sck);
    return sck;
  }
}


