package wsj.rmiserver;

import java.rmi.*;

public interface Echo extends Remote
{
	public void sayEcho(String name) throws RemoteException;
	public String say(String name) throws RemoteException;
}