package wsj.rmiserver;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class IBizDelegation {

  public IBizDelegation() {
  }
  public static void main(String[] args) {
    IBizDelegation IBizDelegation1 = new IBizDelegation();
  }
}