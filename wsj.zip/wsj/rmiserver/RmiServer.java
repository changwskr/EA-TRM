package wsj.rmiserver;

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class RmiServer
{
  public static void main(String args[]) throws Exception
  {
    String hostname = System.getProperty("java.rmi.server.hostname");
    Logger.trace("Server.main()","hostname : "+hostname);
    LocateRegistry.createRegistry(1100);

    Echo e = new EchoImpl();
    ServerSocketFactory ssf = new ServerSocketFactory();
    ClientSocketFactory csf = new ClientSocketFactory();
    csf.init();

    Echo stub = (Echo)UnicastRemoteObject.exportObject(e, 0, csf, ssf);
    Naming.rebind("rmi://"+hostname+":1100/MyEcho",stub);

    Logger.trace("Server.main()","The server is started...");
  }
}

