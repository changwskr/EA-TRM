package wsj.rmiserver;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DOCUMENT {

/*----------------------------------------------------------------------------*
1] Server.bat
   echo "%1"
   java -Djava.security.policy=rmi.policy -Djava.rmi.server.hostname=%1 specular.rmi.Server
2] Client.bat
   echo "%1"
   java -Djava.security.policy=rmi.policy specular.rmi.Client %1
3] rmic
   rmic wsj.rmiserver.EchoImpl
4] compile
   javac -d . *.java
*-----------------------------------------------------------------------------*/
}