package wsj.time;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.sql.*;
import wsj.util.*;

public class MILLISECONDtime2date {

  public static String CURRENTmilisecond2date(long l)
  {
    Timestamp today = new Timestamp(l);
    return wsj.util.date.DateUtil.makeDateFormat(today,"yyyyMMdd");
  }

  public static String CURRENTmilisecond2time(long l)
  {
    Timestamp today = new Timestamp(l);
    return wsj.util.date.DateUtil.makeDateFormat(today,"HH��mm��ss��SSS�и���");
  }

  public static void main(String[] args) {
    long l = System.currentTimeMillis();

    System.out.println(MILLISECONDtime2date.CURRENTmilisecond2date(l));
    System.out.println(MILLISECONDtime2date.CURRENTmilisecond2time(l));

  }
}