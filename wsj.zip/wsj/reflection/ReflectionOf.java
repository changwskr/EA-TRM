package wsj.reflection;

/*
(c) Copyright IBM Corp. 1999 All rights reserved.

This sample program is owned by International Business Machines Corporation or
one of its subsidiaries ("IBM") and is copyrighted and licensed, not sold.

You may copy, modify, and distribute this sample program in any form without
payment to IBM, for any purpose including developing, using, marketing or
distributing programs that include or are derivative works of the sample program.

The sample program is provided to you on an "AS IS" basis, without warranty of
any kind. IBM HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES, EITHER
EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE. Some jurisdictions do not allow for the exclusion or limitation of
implied warranties, so the above limitations or exclusions may not apply to you.
IBM shall not be liable for any damages you suffer as a result of using, modifying
or distributing the sample program or its derivatives.

Each copy of any portion of this sample program or any derivative work, must
include the above copyright notice and disclaimer of warranty.
*/

import java.lang.reflect.*;
/*
 * USAGE: java ReflectionOf <fully qualified classname>
 *
 * This class accepts an argument (class) and uses reflection to aquire:
 * the super class, modifiers, methods and constructors with their individual
 * parameter types and fields of the given class, including private ones.
 *
 * @version 1.0
 * @author Inocencio Richiez
 *
 */
public class ReflectionOf {
  static final String usage = "\tPlease try again..\n" +
                              "\tUSAGE: java ReflectionOf <fully qualified class name>\n" +
                              "\tExample: java ReflectionOf java.lang.Math\n";
  public static void main(String[] args) {
    if(args.length < 1) {
      System.out.println(usage);
      System.exit(0);
    }
    try {
      // Return the Class object associated with class given (args[0]).
      Class c = Class.forName(args[0]);
      // retrieve all declared methods from the Class object
      Method methods[] = c.getDeclaredMethods();
      // retrieve all declared constructors from the Class object
      Constructor constructors[] = c.getDeclaredConstructors();
      // retrieve all declared fields from the Class object
      Field fields[] = c.getDeclaredFields();
      // print the super class associated with the Class object
      if(c.getSuperclass() != null)
          System.out.println("\n[SUPERCLASS]\n" + '\t'+
                             c.getSuperclass().getName());
      // print each modifier associated with each method
      System.out.println("\n[METHODS]");
      for (int i = 0; i < methods.length; i++){
        Class params[] = methods[i].getParameterTypes();
        System.out.print('\t'+ Modifier.toString(methods[i].getModifiers())+
                         " " + methods[i].getReturnType().getName()+ " " +
                         methods[i].getName()+ "(");
        try{
          System.out.print(params[0].getName());
          }catch(ArrayIndexOutOfBoundsException e){}
          for (int j = 1; j<params.length; j++){
            System.out.print(", " + params[j].getName());
          }
          System.out.println(")");
      }
      System.out.println("\n[CONSTRUCTORS]");
      for (int i = 0; i < constructors.length; i++){
        Class params[] = constructors[i].getParameterTypes();
        System.out.print('\t'+ Modifier.toString(constructors[i].getModifiers())+
                           " "+ constructors[i].getName()+ "(");
        try{
          System.out.print(params[0].getName());
          }catch(ArrayIndexOutOfBoundsException e){}
          for (int j = 1; j<params.length; j++){
            System.out.print(", " + params[j].getName());
          }
          System.out.println(")");
      }
      System.out.println("\n[FIELDS]");
      for (int i = 0; i < fields.length; i++)
        System.out.println('\t'+ Modifier.toString(fields[i].getModifiers())+
                           " " + fields[i].getName());



      } catch (ClassNotFoundException e) {
        System.out.println("\tNot a fully qualified class: "+"<"+e+">"+"."+'\n'+
                           "\tTry full qualified name or check for spelling...\n"+
                           "\tExample: java ReflectionOf java.lang.Math\n");
      }
   }
}




