package wsj.database;

import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;

public class ConnectAccess {

  public ConnectAccess() {
  }

  public void connect(){
    try {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); // Sun ���� �����ϴ� JDBC-ODBC �긴�� �ε�
      Connection conn = DriverManager.getConnection("jdbc:odbc:MS Access Database");
      String sql = "select * from friends";
      PreparedStatement ps = conn.prepareStatement(sql);
      ps.execute();
      ResultSet rs = ps.getResultSet();
      while ( rs.next() ){
        System.out.println ("Name : " + rs.getString(1) + ", Phone : " + rs.getString(2) + ", Age : " + rs.getInt(3) );
      }
    }
    catch (Exception e){
      e.printStackTrace();
    }

  }

  public static void main(String[] args) {
    ConnectAccess connectAccess1 = new ConnectAccess();
    connectAccess1.connect();
  }
}