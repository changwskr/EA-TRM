package wsj.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;

public class AddBatch {

  public AddBatch() {
    Connection conn = null;
    PreparedStatement ps = null;

    try {
      String sql = "insert into friends values (?,?,?)";

      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR", "system", "manage");
      ps = conn.prepareStatement(sql);

      ps.setString(1, "Song");
      ps.setString(2,"02-1111-2222");
      ps.setInt(3, 20);
      ps.addBatch();

      ps.setString(1, "Lee");
      ps.setString(2,"02-3333-4444");
      ps.setInt(3, 21);
      ps.addBatch();

      ps.setString(1, "Park");
      ps.setString(2,"02-5555-4444");
      ps.setInt(3, 27);
      ps.addBatch();

      ps.executeBatch();
    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally{
      try {
        ps.close();
      }
      catch (Exception ex){
      }
      try {
        conn.close();
      }
      catch (Exception ex){
      }
    }
  }

  public static void main(String[] args) {
    AddBatch addBatch = new AddBatch();
  }
}