package wsj.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.io.ByteArrayInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class UseBlob {
  public UseBlob() {
    Connection conn = null;
    PreparedStatement ps = null;
    Statement st = null;
    String mesg = "Hello, This is a Test Program";
    ResultSet rs = null;

    try {
      String isql = "insert into friends values (?,?,?,?)";
      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR","system", "manage");

      ByteArrayInputStream bais = new ByteArrayInputStream( mesg.getBytes() );

      ps = conn.prepareStatement(isql);

      ps.setString(1,"Yu");
      ps.setString(2,"02-999-8888");
      ps.setInt(3,100);

      ps.setBinaryStream(4, bais, mesg.getBytes().length);
      ps.execute();
      ps.close();
    }
    catch (Exception e){
      e.printStackTrace();
    }

    try {
      String ssql = "select * from friends";
      st = conn.createStatement();
      if ( st.execute(ssql) ){

        rs = st.getResultSet();

        BufferedReader br = null;
        String line = null;

        if (rs != null){
          while(rs.next()){
            br = new BufferedReader( new InputStreamReader(rs.getBinaryStream(4) ) );

            System.out.print(rs.getString(1) + " : ");
            while( (line = br.readLine()) != null){
              System.out.println (line);
            }
          }
        }
      }

    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally{

      try {
        st.close();
      }
      catch (Exception ex){}

      try {
        conn.close();
      }
      catch (Exception ex){}
    }
  }

  public static void main(String[] args) {
    UseBlob useBlob = new UseBlob();
  }
}