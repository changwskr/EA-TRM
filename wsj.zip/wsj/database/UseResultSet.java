package wsj.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;

public class UseResultSet {

public UseResultSet() {
    Connection conn = null;
    ResultSet rs = null;
    Statement st = null;

    try {
      String sql = "select * from friends";

      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR","system", "manage");
      st = conn.createStatement();
      if ( st.execute(sql) ){
        rs = st.getResultSet();

        while(rs.next()){
          // �ڷ����� ���� getString, getInt �޼ҵ带 ȣ���ϰ� �Ķ���ʹ� �÷��̸�
          System.out.println ( "Name : " + rs.getString("name") + ", Phone : " + rs.getString("phone") + ", Age : " + rs.getInt("age") );

        }
      }
    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally{
      try {
        rs.close();
      }
      catch (Exception ex){}

      try {
        st.close();
      }
      catch (Exception ex){}

      try {
        conn.close();
      }
      catch (Exception ex){}
    }
  }
  public static void main(String[] args) {
    UseResultSet useResultSet1 = new UseResultSet();
  }
}
