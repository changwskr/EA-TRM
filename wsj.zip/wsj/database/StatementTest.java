package wsj.database;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;

public class StatementTest {

  public StatementTest() {
  }
  public static void main(String[] args) {
    Connection conn = null;
    Statement st = null;
    String sql1 = "insert into friends values ('Song','02-1111-2222',20)";
    String sql2 = "insert into friends values ('Lee' ,'02-3333-4444',21)";
    String sql3 = "insert into friends values ('Park','02-5555-4444',28)";

    try {
      // JDBC ����̹� �ε�
      Class.forName("oracle.jdbc.driver.OracleDriver");

      // Connection ��������
      conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR","system", "manage");

      st = conn.createStatement();
      st.execute(sql1);
      st.execute(sql2);
      st.execute(sql3);

      st.close();
      conn.close();
    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally {
      try {
        conn.close();
      }
      catch (Exception ex){
      }
    }
  }
}