package wsj.database;

import java.sql.*;

public class ArrayResult {

  public ArrayResult() {
  }
  public static void main(String[] args) {
    Connection conn = null;
    ResultSet rs = null;
    Statement st = null;

    try {
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
}