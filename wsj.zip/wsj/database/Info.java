package wsj.database;

import java.sql.SQLData;
import java.sql.SQLInput;
import java.sql.SQLException;
import java.sql.SQLOutput;

public class Info implements SQLData{
  public String name;
  public String phone;
  public int age;

  private String sql_type;

  public String getSQLTypeName(){
    return sql_type;
  }

  public void readSQL(SQLInput stream, String type) throws SQLException {
    sql_type = type;
    name = stream.readString();
    phone = stream.readString();
    age = stream.readInt();
  }

  public void writeSQL(SQLOutput stream) throws SQLException {
    stream.writeString(name);
    stream.writeString(phone);
    stream.writeInt(age);
  }
}
