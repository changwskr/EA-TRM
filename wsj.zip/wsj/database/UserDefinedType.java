package wsj.database;

import java.util.Dictionary;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.DriverManager;

public class UserDefinedType {

  public UserDefinedType() {
  }

  public static void main(String[] args) {
    OracleConnection conn = null;
    OracleResultSet rs = null;
    Statement st = null;
    PreparedStatement pst = null;

    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = (OracleConnection)DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR","system", "manage");

      // ���� ���ӿ� ���� Type Map�� �����´�.
      Dictionary map = (Dictionary)conn.getTypeMap();

      // INFO��� Ÿ�Կ� ���� Ŭ������ Info Ŭ������ �����ϵ��� �Ѵ�.
      map.put("INFO", Class.forName("example.database.Info"));

      st = conn.createStatement();

      st.execute("insert into friends2 values (INFO('David','222-444-xxx',30),69)");

      rs = (OracleResultSet)st.executeQuery("select * from friends2");

      Info info = null;
      while (rs.next()){
        // Object�� �����ͼ� Info�� ĳ�����Ѵ�.
        info = (Info)rs.getObject(1);
        System.out.println("Name:" + info.name + " Phone:" + info.phone + " Age:" + info.age);
        System.out.println("Score:" + rs.getInt(2));
      }
      rs.close();

    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
}
