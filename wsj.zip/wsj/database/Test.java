package wsj.database;


public class Test {
  static StringBuffer sb = new StringBuffer();
  public Test() {
    sb.append("asdf");

    sb = new StringBuffer();
  }
  public static void main(String[] args) {
    Test test1 = new Test();
  }
}