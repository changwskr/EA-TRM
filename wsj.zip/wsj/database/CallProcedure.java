package wsj.database;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.DriverManager;

public class CallProcedure {

  public CallProcedure() {
    Connection conn = null;
    Statement st = null;
    CallableStatement cs = null;

    try {
      String plsql = "{call addage}";

      Class.forName("oracle.jdbc.driver.OracleDriver");
      conn = DriverManager.getConnection("jdbc:oracle:thin:@pismute:1521:java300", "system", "asdf");
      cs = conn.prepareCall(plsql);

      cs.execute();
    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally{
      try {
        cs.close();
      }
      catch (Exception ex){}

      try {
        conn.close();
      }
      catch (Exception ex){}
    }
  }
  public static void main(String[] args) {
    CallProcedure callProcedure = new CallProcedure();
  }
}