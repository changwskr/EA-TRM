/*@lineinfo:filename=SQLJTest*//*@lineinfo:user-code*//*@lineinfo:1^1*/package
 wsj.database;

import sqlj.runtime.*;
import sqlj.runtime.ref.*;
import java.sql.*;

/*@lineinfo:generated-code*//*@lineinfo:7^1*/

//  ************************************************************
//  SQLJ iterator declaration:
//  ************************************************************

class Iter
extends sqlj.runtime.ref.ResultSetIterImpl
implements sqlj.runtime.NamedIterator
{
  public Iter(sqlj.runtime.profile.RTResultSet resultSet)
    throws java.sql.SQLException
  {
    super(resultSet);
    nameNdx = findColumn("name");
    phoneNdx = findColumn("phone");
    ageNdx = findColumn("age");
  }
  public String name()
    throws java.sql.SQLException
  {
    return resultSet.getString(nameNdx);
  }
  private int nameNdx;
  public String phone()
    throws java.sql.SQLException
  {
    return resultSet.getString(phoneNdx);
  }
  private int phoneNdx;
  public int age()
    throws java.sql.SQLException
  {
    return resultSet.getIntNoNull(ageNdx);
  }
  private int ageNdx;
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:7^55*/


public class SQLJTest{

	public static void main (String args[])
	{
		try {
			// Mysql JDBC ����̹��� �ε��Ѵ�.
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			// Connection�� �����´�.
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/test");
			conn.createStatement();

			// Connection ��ü�� DefaultContext�� �����Ѵ�.
			DefaultContext context = new DefaultContext(conn);
			DefaultContext.setDefaultContext(context);

			/*@lineinfo:generated-code*//*@lineinfo:26^4*/

//  ************************************************************
//  #sql { insert into friends (name, phone, age)
//  				values ('David Kim', 'xxx-sss-ffff', 25)  };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, SQLJTest_SJProfileKeys.getKey(0), 0);
    try
    {
      __sJT_execCtx.executeUpdate();
    }
    finally
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:27^46*/
				Iter iter;

			/*@lineinfo:generated-code*//*@lineinfo:30^4*/

//  ************************************************************
//  #sql iter = { select name, phone, age from friends  };
//  ************************************************************

{
  sqlj.runtime.ConnectionContext __sJT_connCtx = sqlj.runtime.ref.DefaultContext.getDefaultContext();
  if (__sJT_connCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_CONN_CTX();
  sqlj.runtime.ExecutionContext __sJT_execCtx = __sJT_connCtx.getExecutionContext();
  if (__sJT_execCtx == null) sqlj.runtime.error.RuntimeRefErrors.raise_NULL_EXEC_CTX();
  synchronized (__sJT_execCtx) {
    sqlj.runtime.profile.RTStatement __sJT_stmt = __sJT_execCtx.registerStatement(__sJT_connCtx, SQLJTest_SJProfileKeys.getKey(0), 1);
    try
    {
      sqlj.runtime.profile.RTResultSet __sJT_result = __sJT_execCtx.executeQuery();
      iter = new Iter(__sJT_result);
    }
    finally
    {
      __sJT_execCtx.releaseStatement();
    }
  }
}


//  ************************************************************

/*@lineinfo:user-code*//*@lineinfo:30^53*/

			while (iter.next()) {
				System.out.println
				(iter.name()+" "+iter.phone()+" "+iter.age());
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
}/*@lineinfo:generated-code*/class SQLJTest_SJProfileKeys
{
  private static SQLJTest_SJProfileKeys inst = null;
  public static java.lang.Object getKey(int keyNum)
    throws java.sql.SQLException
  {
    if (inst == null)
    {
      inst = new SQLJTest_SJProfileKeys();
    }
    return inst.keys[keyNum];
  }
  private final sqlj.runtime.profile.Loader loader = sqlj.runtime.RuntimeContext.getRuntime().getLoaderForClass(getClass());
  private java.lang.Object[] keys;
  private SQLJTest_SJProfileKeys()
    throws java.sql.SQLException
  {
    keys = new java.lang.Object[1];
    keys[0] = sqlj.runtime.ref.DefaultContext.getProfileKey(loader, "example.database.SQLJTest_SJProfile0");
  }
}
