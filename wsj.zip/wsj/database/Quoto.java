package wsj.database;

public class Quoto {
  public Quoto() {
  }

  public static String escape(String input){
    String output = input;
    char ch;

    if (input.indexOf("'") != -1) {
      StringBuffer sb = new StringBuffer();
      for (int i = 0; i < input.length(); i++) {
        if ( (ch = input.charAt(i)) == '\'')
          sb.append("''");
        else
          sb.append(ch);
      }
      output = sb.toString();
    }
    return output;
  }

  public static void main(String[] args) {
    String movie_name = "Harry Potter and the Sorcerer's Stone";
    long box_office = 317557891;
    String query = "insert into movie(name, box_office) values ('" + Quoto.escape(movie_name) + "', " + box_office + ")";
    System.out.println ("Escaped Query : " + query);
  }
}