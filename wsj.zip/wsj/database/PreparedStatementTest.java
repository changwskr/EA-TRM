package wsj.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;

public class PreparedStatementTest {

  public PreparedStatementTest() {
  }

  public static void main(String[] args) {
    Connection conn = null;
    String sql = "insert into friends values (?,?,?)";
    PreparedStatement ps = null;

    try {
      // JDBC ����̹� �ε�
      Class.forName("oracle.jdbc.driver.OracleDriver");

      // Connection ��������
      conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.117.44:1521:LOTEMKR","system", "manage");

      ps = conn.prepareStatement(sql);
      ps.setString(1, "Song");
      ps.setString(2,"02-1111-2222");
      ps.setInt(3, 20);
      ps.execute();

      ps.setString(1, "Lee");
      ps.setString(2,"02-3333-4444");
      ps.setInt(3, 21);
      ps.execute();

      ps.setString(1, "Park");
      ps.setString(2,"02-5555-4444");
      ps.setInt(3, 27);
      ps.execute();

      ps.close();
      conn.close();
    }
    catch (Exception e){
      e.printStackTrace();
    }
    finally {
      try {
        conn.close();
      }
      catch (Exception ex){
      }
    }
  }
}