
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class EPLRMIserver {
  private String RMIHOSTname;
  private int RMIport;
  private int TIMEOUT;
  private ServerSocketFactory ssf;
  private TIMEClientSocketFactory csf;
  private String bindingName;

  public void INITproperty(String hostname,String rmi_registry_port,String timeout){
    try {
      RMIHOSTname = hostname;
      TIMEOUT = Integer.valueOf(timeout).intValue();
      RMIport = Integer.valueOf(rmi_registry_port).intValue();
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public void STARTup(String[] bindingName)
  {
    try {
      //////////////////////////////////////////////////////////////////////////
      // Registry Server �⵿
      // -Ư�� PORT�� �⵿�ȴ�.
      // -Ŭ���̾�Ʈ���ϻ����� timeout���� �����ؾ� �ȴ�.
      //////////////////////////////////////////////////////////////////////////
      Registry reg = LocateRegistry.createRegistry(RMIport);
      ssf = new ServerSocketFactory();
      csf = new TIMEClientSocketFactory();
      csf.init(TIMEOUT);
      /////////////////////////////////////////////////////////////////////////
      // ������ RMIserver�� ����Ѵ�.
      //////////////////////////////////////////////////////////////////////////
      for( int i=0;i<bindingName.length;i++ )
      {
        System.out.println("bindingName["+i+"]-"+bindingName[i]);
        OFACBINDstup(bindingName[i]);
      }
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public void OFACBINDstup(String BINDINGname)
  {
    try {
      OFACmethod e = new OFACmethodImpl();
      OFACmethod stub = (OFACmethod)UnicastRemoteObject.exportObject(e, 0, csf, ssf);
      System.out.println("RMI-"+"rmi://"+RMIHOSTname+":"+RMIport+"/"+BINDINGname);
      Naming.rebind("rmi://"+RMIHOSTname+":"+RMIport+"/"+BINDINGname,stub);
    }
    catch(Exception e){
      e.printStackTrace();
    }
  }

  public EPLRMIserver() {
  }

  public static void main(String args[]) throws Exception
  {
    try
    {
      if( args.length  < 1 ){
        System.out.println("USAGE : java -Djava.security.policy=rmi.policy -Djava.rmi.server.hostname=wsjang com.chb.coses.itf.rmiserver.EPLRMIserver port#");
        System.out.println(" wsjang[hostname] is needed");
        System.exit(0);
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
    }

    String hostname = System.getProperty("java.rmi.server.hostname");
    String[] bindingName = new String[1];
    bindingName[0]="OFAC";

    EPLRMIserver ers = new EPLRMIserver();
    ers.INITproperty(hostname,args[0],"31000");
    ers.STARTup(bindingName);
    Logger.trace("Server.main()","The server is started...");
  }


}



