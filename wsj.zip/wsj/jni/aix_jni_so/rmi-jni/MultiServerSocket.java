
import java.io.*;
import java.net.*;
import java.util.*;

public class MultiServerSocket extends ServerSocket
{

  public MultiServerSocket(int port)
      throws IOException
  {
    super(port);
    try {
      InetAddress local = InetAddress.getLocalHost();
      InetAddress[] ia = InetAddress.getAllByName(local.getHostName());

      for(int i=0;i<ia.length;i++) {
        System.out.println(ia[i].getHostAddress());
      }
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
}
