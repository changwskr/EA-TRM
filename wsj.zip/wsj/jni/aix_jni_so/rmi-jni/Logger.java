
public class Logger
{
  public static void trace(String msg)
  {
    System.out.println(msg);
  }

  public static void trace(String cname,String msg)
  {
    System.out.println(cname+" ] "+msg);
  }
}
