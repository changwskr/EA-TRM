
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.rmi.*;

public class OFACexecute
{
  public static void main(String args[]) throws Exception
  {

    String rmiURL="rmi://localhost:30000/OFAC";
    if(args.length!=1) {
      System.out.println("java wsj.rmiserver.eplton.test.OFACexecute sendmessage");
      System.exit(0);
    }

    /*--------------------------------------------------------------------------
     * �̺κп� ���� ���� �����ؾ� �� �κ��̴�.
     *
    if (System.getSecurityManager() == null) {
      System.setSecurityManager(new SecurityManager());
    }
    */

    System.out.println("OFACexecute lookup start"+"--------------------------------------");
    System.out.println("url : " + rmiURL);

    OFACmethod e = (OFACmethod)Naming.lookup(rmiURL);
    for(int i=0;i<300;i++){
      //e.sayEcho("woosung");
      String result = e.say(args[0]);
      System.out.println("OFACexecute.main() "+"result - "+result);
      System.out.println("----------------------------------------------------");
    }



  }
}


