
import java.io.*;
import java.net.*;
import java.rmi.server.*;

public class ServerSocketFactory implements RMIServerSocketFactory {

  public ServerSocket createServerSocket(int port)
      throws IOException
  {
    ServerSocket ss = new ServerSocket(port);
    Logger.trace(
        "ServerSocketFactory.createServerSocket()",
        "create ServerSocket"
        );
    return ss;
  }
}

