
#if !defined(__BRIDGERTRACKERDLL_H__INCLUDED_)
#define __BRIDGERTRACKERDLL_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 

#ifdef __UNIX__

#define __declspec(dllexport)
#define _stdcall 


#define	VARIANT_BOOL	bool
#define  VARIANT_TRUE	true
#define  VARIANT_FALSE	false
#endif


typedef enum
{
	COUNTER_ALTERNATE				= 1,
	COUNTER_COMPARE_ADDRESS		= 2,
	COUNTER_COMPARE_NAME			= 3,
	COUNTER_FILE					= 4,
	COUNTER_FILE_NAMES			= 5,
	COUNTER_NAME					= 6,
	COUNTER_WIRE					= 7,
	COUNTER_WIRE_FILE				= 8,
	COUNTER_WIRE_FILE_NAMES		= 9
} enumBridgerTrackerCounter;


typedef enum
{
	BRIDGER_TRACKER_NO_ERROR						= 0x00000000,
	BRIDGER_TRACKER_ACCESS_DENIED					= 0xFFFFFFFF,
	BRIDGER_TRACKER_CIF_ERROR						= 0xFFFFFFFE,
	BRIDGER_TRACKER_DATA_FILE_ERROR				= 0xFFFFFFFD,
	BRIDGER_TRACKER_DATA_TRUNCATED				= 0xFFFFFFFC,
	BRIDGER_TRACKER_FILE_NOT_FOUND				= 0xFFFFFFFB,
	BRIDGER_TRACKER_FILE_NOT_OPEN					= 0xFFFFFFFA,
	BRIDGER_TRACKER_FORMAT_NOT_FOUND				= 0xFFFFFFF9,
	BRIDGER_TRACKER_FORMAT_NOT_LOADED			= 0xFFFFFFF8,
	BRIDGER_TRACKER_INVALID_DATE					= 0xFFFFFFF7,
	BRIDGER_TRACKER_INVALID_FILE					= 0xFFFFFFF6,
	BRIDGER_TRACKER_INVALID_HANDLE				= 0xFFFFFFF5,
	BRIDGER_TRACKER_INVALID_INTERFACE			= 0xFFFFFFF4,
	BRIDGER_TRACKER_INVALID_PARAMETER			= 0xFFFFFFF3,
	BRIDGER_TRACKER_INVALID_PATH					= 0xFFFFFFF2,
	BRIDGER_TRACKER_INVALID_POINTER				= 0xFFFFFFF1,
	BRIDGER_TRACKER_INVALID_PRODUCT_CODE		= 0xFFFFFFF0,
	BRIDGER_TRACKER_INVALID_RESULTS_HANDLER	= 0xFFFFFFEF,
	BRIDGER_TRACKER_INVALID_SIZE					= 0xFFFFFFEE,
	BRIDGER_TRACKER_NO_CUSTOM_FORMATS			= 0xFFFFFFED,
	BRIDGER_TRACKER_NO_DATA_FILES					= 0xFFFFFFEC,
	BRIDGER_TRACKER_NO_DFM							= 0xFFFFFFEB,
	BRIDGER_TRACKER_NO_RESULTS_HANDLER			= 0xFFFFFFEA,
	BRIDGER_TRACKER_NO_SEARCH_OPTIONS			= 0xFFFFFFE9,
	BRIDGER_TRACKER_NO_WRITE_ACCESS				= 0xFFFFFFE8,
	BRIDGER_TRACKER_NOT_FILE_ERROR				= 0xFFFFFFE7,
	BRIDGER_TRACKER_OPEN_FAILED					= 0xFFFFFFE6,
	BRIDGER_TRACKER_ORBIT_DATA_SOURCE_ERROR	= 0xFFFFFFE5,
	BRIDGER_TRACKER_ORBIT_DB_READ_FAILED		= 0xFFFFFFE4,
	BRIDGER_TRACKER_ORBIT_DB_WRITE_FAILED		= 0xFFFFFFE3,
	BRIDGER_TRACKER_ORBIT_DSN_UNAVAILABLE		= 0xFFFFFFE2,
	BRIDGER_TRACKER_ORBIT_GET_FIELD_FAILED		= 0xFFFFFFE1,
	BRIDGER_TRACKER_ORBIT_OPEN_DBM_FAILED		= 0xFFFFFFE0,
	BRIDGER_TRACKER_ORBIT_READ_DBM_FAILED		= 0xFFFFFFDF,
	BRIDGER_TRACKER_ORBIT_REINDEX_FAILED		= 0xFFFFFFDE,
	BRIDGER_TRACKER_ORBIT_SERVER_UNAVAILABLE	= 0xFFFFFFDD,
	BRIDGER_TRACKER_ORBIT_SET_FIELD_FAILED		= 0xFFFFFFDC,
	BRIDGER_TRACKER_ORBIT_WRITE_DBM_FAILED		= 0xFFFFFFDB,
	BRIDGER_TRACKER_OUT_OF_MEMORY					= 0xFFFFFFDA,
	BRIDGER_TRACKER_PARAMETER_TOO_LONG			= 0xFFFFFFD9,
	BRIDGER_TRACKER_PRODUCT_ACCESS_DENIED		= 0xFFFFFFD8,
	BRIDGER_TRACKER_PRODUCT_TRIAL_EXPIRED		= 0xFFFFFFD7,
	BRIDGER_TRACKER_READ_FAILED					= 0xFFFFFFD6,
	BRIDGER_TRACKER_SAME_FILE						= 0xFFFFFFD5,
	BRIDGER_TRACKER_SEEK_FAILED					= 0xFFFFFFD4,
	BRIDGER_TRACKER_TOO_MANY_FILES				= 0xFFFFFFD3,
	BRIDGER_TRACKER_TOO_MANY_NAMES				= 0xFFFFFFD2,
	BRIDGER_TRACKER_TRANSLATE_FAILED				= 0xFFFFFFD1,
	BRIDGER_TRACKER_WRITE_FAILED					= 0xFFFFFFD0
} enumBridgerTrackerErrors;


typedef enum
{
	FORMAT_CRLF	= 1,
	FORMAT_HTML	= 2,
	FORMAT_XML	= 3
} enumBridgerTrackerFormat;


typedef enum
{
	OPTION_DISPLAY_ALL_RESULTS			= 1,
	OPTION_GENERATE_NAMES_FILE			= 2,
	OPTION_GENERATE_OUTPUT_FILE		= 3,
	OPTION_IGNORE_VESSEL					= 4,
	OPTION_IGNORE_DIFFERENT_COUNTRY	= 5,
	OPTION_SCAN_ADDRESS					= 6,
	OPTION_SCAN_NAME						= 7,
	OPTION_WRITE_TO_REPORTS				= 8
} enumBridgerTrackerOptions;


typedef enum
{
	OPTION_ERROR			= -1,
	OPTION_OFF				=  0,
	OPTION_ON				=  1
} enumBridgerTrackerOptionValues;



extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall CheckAccess();

extern "C" __declspec(dllexport) enumBridgerTrackerErrors _stdcall DLLGetLastError();

extern "C" __declspec(dllexport) const char * _stdcall GetLastErrorMessage();

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetLastErrorMessageBSTR();

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetDataSourceName(const char *pcDataSourceName);
#endif

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetPath(const char *pcPath);



#ifndef __UNIX__
extern "C" __declspec(dllexport) const char * _stdcall GetFormatDescription(int iIndex);

extern "C" __declspec(dllexport) BSTR _stdcall GetFormatDescriptionBSTR(int iIndex);

extern "C" __declspec(dllexport) const char * _stdcall GetFormatFileName(int iIndex);

extern "C" __declspec(dllexport) BSTR _stdcall GetFormatFileNameBSTR(int iIndex);

extern "C" __declspec(dllexport) const char * _stdcall GetListFileName();

extern "C" __declspec(dllexport) BSTR _stdcall GetListFileNameBSTR();

extern "C" __declspec(dllexport) int _stdcall GetNumFormats();

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall ReadCustomFormatList(const char *pcPathAndFileName);
#endif



extern "C" __declspec(dllexport) const char * _stdcall GetResultBestName(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultBestNameBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultDenyReason(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultDenyReasonBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultEntityName(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultEntityNameBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultFileDate(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultFileDateBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultFileName(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultFileNameBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultListing(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultListingBSTR(int iIndex);

extern "C" __declspec(dllexport) int _stdcall GetResultNumFound();

extern "C" __declspec(dllexport) int _stdcall GetResultNumSearched();
#endif

extern "C" __declspec(dllexport) int _stdcall GetResultScore(int iIndex);

extern "C" __declspec(dllexport) const char * _stdcall GetResultsText(enumBridgerTrackerFormat iFormat);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultsTextBSTR(enumBridgerTrackerFormat iFormat);
#endif

extern "C" __declspec(dllexport) const char * _stdcall GetResultWireContext(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetResultWireContextBSTR(int iIndex);
#endif



extern "C" __declspec(dllexport) int _stdcall AlternateSearch(const char *pcAlternate, const char *pcCheckedBy, const char *pcDivision);

extern "C" __declspec(dllexport) int _stdcall CheckName(const char *pcName, const char *pcCheckedBy, const char *pcDivision);

extern "C" __declspec(dllexport) int _stdcall CheckNameAddress(const char *pcName, const char *pcAddress, const char *pcCity, const char *pcState, const char *pcCountry, const char *pcCheckedBy, const char *pcDivision);

extern "C" __declspec(dllexport) int _stdcall CheckWire(const char *pcWire, const char *pcCheckedBy, const char *pcDivision);

extern "C" __declspec(dllexport) int _stdcall CompareAddresses(const char *pcAddress1, const char *pcAddress2);

extern "C" __declspec(dllexport) int _stdcall CompareNames(const char *pcName1, const char *pcName2);

#ifndef __UNIX__
extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall ScanFile(const char *pcInputFileName, const char *pcInputFormat, const char *pcOutputFileName, const char *pcCheckedBy, const char *pcDivision);

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall ScanWireFile(const char *pcInputFileName, const char *pcOutputFileName, const char *pcCheckedBy, const char *pcDivision);
#endif



extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall AddFile(const char *pcDataFilePathAndName);

extern "C" __declspec(dllexport) int _stdcall AddFiles(const char *pcPath);

extern "C" __declspec(dllexport) const char * _stdcall GetDataFile(int iIndex);

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetDataFileBSTR(int iIndex);
#endif

extern "C" __declspec(dllexport) int _stdcall GetMinScore();

extern "C" __declspec(dllexport) int _stdcall GetNumFiles();

extern "C" __declspec(dllexport) const char * _stdcall GetOutputPath();

#ifndef __UNIX__
extern "C" __declspec(dllexport) BSTR _stdcall GetOutputPathBSTR();

extern "C" __declspec(dllexport) const char * _stdcall GetReportsPath();

extern "C" __declspec(dllexport) BSTR _stdcall GetReportsPathBSTR();
#endif

extern "C" __declspec(dllexport) enumBridgerTrackerOptionValues _stdcall GetSearchOption(int iOption);

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall RemoveAllFiles();

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall RemoveFile(const char *pcDataFilePathAndName);

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetMinScore(int iScore);

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetOutputPath(const char *pcOutputPath);

#ifndef __UNIX__
extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetReportsPath(const char *pcReportsPath);
#endif

extern "C" __declspec(dllexport) VARIANT_BOOL _stdcall SetSearchOption(int iOption, enumBridgerTrackerOptionValues iValue);



extern "C" __declspec(dllexport) int _stdcall GetSearchCount(enumBridgerTrackerCounter iOption, const char *pcBeginDate, const char *pcEndDate);


#endif 
