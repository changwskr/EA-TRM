import java.rmi.*;

public class Client
{
  public static void main(String args[]) throws Exception
  {

    String rmiURL="rmi://localhost:1100/MyEcho";
    if(args.length==1) {
      rmiURL = "rmi://"+args[0]+":1100/MyEcho";
    }
    if (System.getSecurityManager() == null) {
      System.setSecurityManager(new SecurityManager());
    }
    Logger.trace("Client.main()","url : "+rmiURL);

    Echo e = (Echo)Naming.lookup(rmiURL);

    Logger.trace("Client.main()",e.toString());
    e.sayEcho("woosung");
    String result = e.say("specular");
    Logger.trace("Client.main()","result - "+result);

  }
}

