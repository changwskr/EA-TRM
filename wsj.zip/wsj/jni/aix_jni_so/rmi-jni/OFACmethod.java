
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed * @version 1.0
 */

import java.rmi.*;

public interface OFACmethod extends Remote{
  public void sayEcho(String name) throws RemoteException;
  public String say(String name) throws RemoteException;
}
