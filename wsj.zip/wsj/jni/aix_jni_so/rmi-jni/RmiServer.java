
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;

public class RmiServer
{
  public static void main(String args[]) throws Exception
  {
    try {
      if( args.length  < 1 ){
        System.out.println("USAGE : java java -Djava.security.policy=rmi.policy -Djava.rmi.server.hostname=wsjang wsj.rmiserver.RmiServer ");
        System.out.println(" wsjang[hostname] is needed");
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
    }

    String hostname = System.getProperty("java.rmi.server.hostname");
    Logger.trace("Server.main()","hostname : "+hostname);
    LocateRegistry.createRegistry(1100);

    Echo e = new EchoImpl();
    ServerSocketFactory ssf = new ServerSocketFactory();
    ClientSocketFactory csf = new ClientSocketFactory();
    csf.init();

    Echo stub = (Echo)UnicastRemoteObject.exportObject(e, 0, csf, ssf);
    Naming.rebind("rmi://"+hostname+":1100/MyEcho",stub);

    Logger.trace("Server.main()","The server is started...");
  }
}

