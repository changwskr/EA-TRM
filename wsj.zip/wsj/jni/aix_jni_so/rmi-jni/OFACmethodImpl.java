
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.rmi.*;
import java.rmi.server.*;

public class OFACmethodImpl implements OFACmethod
{
  public OFACmethodImpl()
      throws RemoteException
  {

  }
  public void sayEcho(String name)
  {
 
	  MessageType h = new MessageType();
	  System.out.println("-------------------------------------------------");
	  System.out.println("pass arg message : " + "[" + "ppppppp" + "]");
	  System.out.println("retn val message : " + "[" + h.printMessage("ppppppp") + "]");

    System.out.println("OFACmethodImpl.sayEcho()]"+"--------------------------------------");
    System.out.println("OFACmethodImpl.sayEcho()]"+"start - "+name);
    try {
      System.out.println("OFACmethodImpl.sayEcho()]"+"30�ʵ��� �����.......");
      //Thread.sleep(1);
      System.out.println("OFACmethodImpl.sayEcho()]"+"30�ʵ��� �������.......");
    } catch(Exception e) {
      e.printStackTrace();
    }
    System.out.println("OFACmethodImpl.sayEcho()]"+"end - "+name);
    System.out.println("OFACmethodImpl.sayEcho()]"+"--------------------------------------");
  }

  public String say(String name)
  {
    try {
	  MessageType h = new MessageType();
	  System.out.println("-------------------------------------------------");
	  System.out.println("pass arg message : " + "[" + "ppppppp" + "]");
	  System.out.println("retn val message : " + "[" + h.printMessage("ppppppp") + "]");
      //Thread.sleep(1);
    } catch(Exception e) {
      e.printStackTrace();
    }
    System.out.println("RECV["+ name+"]");
    return name;
  }

}
