#include <jni.h>

#include "MessageType.h"

#include <stdio.h>

JNIEXPORT jstring JNICALL Java_MessageType_printMessage(JNIEnv* env, jobject obj, jstring msg) {

   char buf[128];

   const char *str = (*env)->GetStringUTFChars(env, msg, 0);

   printf("\ncpp-recv[%s]", str);

   (*env)->ReleaseStringUTFChars(env, msg, str);

   sprintf(buf,"%s", "jni_call_success");

   return (*env)->NewStringUTF(env, buf);

}

