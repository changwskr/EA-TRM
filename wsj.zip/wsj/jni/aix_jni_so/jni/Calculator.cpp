#include <jni.h>
#include "Calculator.h"
#include <stdio.h>

JNIEXPORT jint JNICALL Java_Calculator_add(JNIEnv *env, jobject obj, jint a, jint b) {

	jint sum;

	printf("a + b =");

	sum = a + b;

	return sum;
}
