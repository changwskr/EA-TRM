public class MessageType {

   static {

     System.loadLibrary("message");

   }

   public native String printMessage(String str);   

   public static void main(String[] args)  throws Exception {

       MessageType h = new MessageType();

       System.out.println(h.printMessage("Type anything? : "));

   }

}

