#include <jni.h>
#include "HelloWorld.h"
#include <stdio.h>

JNIEXPORT void JNICALL Java_HelloWorld_printHelloWorld(JNIEnv *env, jobject obj) 
{

	printf("Hello World!!\n");
	return;
}

JNIEXPORT jstring JNICALL Java_HelloWorld_printHelloWorld_str_arg(JNIEnv *env, jobject obj, jstring msg)
{

   char buf[128];
   const char *str = (*env)->GetStringUTFChars(env, msg, 0);

   printf("jni_recv[%s]", str);
   (*env)->ReleaseStringUTFChars(env, msg, str);

   sprintf(buf,"[%s]","cpp--");
   return (*env)->NewStringUTF(env, buf);
}


void aaa()
{
        printf("------aaaa---");
	return;
}


