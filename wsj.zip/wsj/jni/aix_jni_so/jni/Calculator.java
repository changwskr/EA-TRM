public class Calculator {

	static {
		System.loadLibrary("calculator");
		System.out.println("===> load Library!!");
	}

	public native int add(int a, int b);

	public static void main(String[] args) throws Exception {
	
		Calculator c = new Calculator();

		int result = c.add(10, 5);

		System.out.println(result);
	}
}
