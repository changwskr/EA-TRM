public class FieldControl {

	int int_a = 10;

	double double_b = -1.2345;

	static {

		System.loadLibrary("control");
	}

	public native double add();

	public static void main(String[] args) {

		double c = new FieldControl().add();

		System.out.println("final result==> a + b = " + c);

	}
}
