#include <jni.h>
#include "FieldControl.h"
#include <stdio.h>

JNIEXPORT jdouble JNICALL Java_FieldControl_add(JNIEnv *env, jobject obj) {

	double c;

	jclass class_fieldcontrol = (*env)->GetObjectClass(env, obj);

	jfieldID id_a = (*env)->GetFieldID(env, class_fieldcontrol, "int_a", "I");

	jint a = (*env)->GetIntField(env, obj, id_a);

	jfieldID id_b = (*env)->GetFieldID(env, class_fieldcontrol, "double_b", "D");

	jdouble b = (*env)->GetDoubleField(env, obj, id_b);

	printf("a : %d \n", a);

	printf("b : %f \n", b);

	c = a+b;

	printf("before ==> a + b = %f \n", a+b);

	a += 5;

	(*env)->SetIntField(env, obj, id_a, a);

	b+=2.123;

	(*env)->SetDoubleField(env, obj, id_b, b);

	c = a + b;

	printf("after ==> a + b = %f \n", a+b);

	return c;
}
