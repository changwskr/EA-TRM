#include <stdio.h>

void aa()
{
	printf("call a\n");
}


