
#include <stdio.h>

main()
{
	aa();

}
