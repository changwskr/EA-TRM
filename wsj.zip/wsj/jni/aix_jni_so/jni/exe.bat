java -classpath . HelloWorld
