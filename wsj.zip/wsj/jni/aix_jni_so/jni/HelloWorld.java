public class HelloWorld {

	static {
		System.loadLibrary("helloworld");
		
		System.out.println("===>> lib was loaded!!");
	}

	//public native void printHelloWorld();
	public native String printHelloWorld_str_arg(String ps);

	public static void main(String[] args) throws Exception {
		
		//new HelloWorld().printHelloWorld();
		String ps="send-------------";
		String kkk=new HelloWorld().printHelloWorld_str_arg(ps);

		System.out.println("["+kkk+"]");
	
	}
}
