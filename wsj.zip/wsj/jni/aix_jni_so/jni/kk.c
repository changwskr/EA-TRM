

#include <stdio.h>

void aaa();

main()
{
	aaa();

}
