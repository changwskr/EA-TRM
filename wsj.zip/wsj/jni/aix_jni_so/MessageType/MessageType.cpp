#include <jni.h>
#include "MessageType.h"
#include <stdio.h>

//----------------------------------------------------------------------------------------------
#include <stdlib.h>
#include <memory.h>
#include <dlfcn.h>
#include <string.h>
#include "errno.h"
#include "BridgerTrackerDLL.h"

#define LINE_SIZE               4096
#define FILE_SCAN_LEVEL         75
#define DYNAMIC_LINK
	
//*****************************************************************
//	OFAC Library definitions for defining function interface.
//*****************************************************************

#ifdef DYNAMIC_LINK

void	*g_hBridgerTrackerSO;
typedef bool (*SET_PATH) ( const char * );
typedef bool (*CHECK_ACCESS) ();
typedef const char *	(*GET_LAST_ERROR_MESSAGE) ();
typedef enumBridgerTrackerErrors (*DLL_GET_LAST_ERROR) ();
typedef bool (*ADD_FILE) ( const char * );
typedef int (*ADD_FILES) ( const char * );
typedef int (*GET_NUM_FILES) ();
typedef const char * (*GET_DATA_FILE) (int);
typedef bool (*REMOVE_FILE) ( const char * );
typedef void (*REMOVE_ALL_FILES) ();
typedef int (*GET_MIN_SCORE) ();
typedef bool (*SET_MIN_SCORE) ( int );
typedef enumBridgerTrackerOptionValues (*GET_SEARCH_OPTION) ( int );
typedef bool (*SET_SEARCH_OPTION) ( int, enumBridgerTrackerOptionValues );
typedef const char * (*GET_OUTPUT_PATH) ();
typedef bool (*SET_OUTPUT_PATH) (const char *);
typedef int (*CHECK_NAME) ( const char *, const char *, const char * );
typedef int (*CHECK_NAME_ADDRESS) ( const char *, const char *, const char *, const char *, const char *, const char *, const char * );
typedef int (*CHECK_WIRE) ( const char *, const char *, const char * );
typedef int (*ALTERNATE_SEARCH) (const char *, const char *, const char * );
typedef const char * (*GET_RESULTS_TEXT) ( enumBridgerTrackerFormat );
typedef int (*GET_RESULT_SCORE) ( int );
typedef const char * (*GET_RESULT_FILE_NAME) ( int );
typedef const char * (*GET_RESULT_FILE_DATE) ( int );
typedef const char * (*GET_RESULT_WIRE_CONTEXT) ( int );
typedef const char * (*GET_RESULT_ENTITY_NAME) ( int );
typedef const char * (*GET_RESULT_BEST_NAME) ( int );
typedef const char * (*GET_RESULT_LISTING) ( int );
typedef const char * (*GET_RESULT_DENY_REASON) ( int );
typedef int (*COMPARE_NAMES) ( const char *, const char * );
typedef int (*COMPARE_ADDRESSES) ( const char *, const char * );
typedef int (*GET_SEARCH_COUNT) ( enumBridgerTrackerCounter, const char *, const char * );

SET_PATH pSetPath	= NULL;
CHECK_ACCESS		pCheckAccess				= NULL;
GET_LAST_ERROR_MESSAGE	pGetLastErrorMessage		= NULL;
DLL_GET_LAST_ERROR	pDLLGetLastError			= NULL;
ADD_FILE		pAddFile						= NULL;
ADD_FILES		pAddFiles					= NULL;
GET_NUM_FILES		pGetNumFiles				= NULL;
GET_DATA_FILE		pGetDataFile				= NULL;
REMOVE_FILE		pRemoveFile					= NULL;
REMOVE_ALL_FILES	pRemoveAllFiles			= NULL;
GET_MIN_SCORE		pGetMinScore				= NULL;
SET_MIN_SCORE		pSetMinScore				= NULL;
GET_SEARCH_OPTION	pGetSearchOption			= NULL;
SET_SEARCH_OPTION	pSetSearchOption			= NULL;
GET_OUTPUT_PATH		pGetOutputPath				= NULL;
SET_OUTPUT_PATH		pSetOutputPath				= NULL;
CHECK_NAME		pCheckName					= NULL;
CHECK_NAME_ADDRESS	pCheckNameAddress			= NULL;
CHECK_WIRE		pCheckWire					= NULL;
ALTERNATE_SEARCH	pAlternateSearch			= NULL;
GET_RESULTS_TEXT	pGetResultsText			= NULL;
GET_RESULT_SCORE	pGetResultScore			= NULL;
GET_RESULT_FILE_NAME	pGetResultFileName		= NULL;
GET_RESULT_FILE_DATE	pGetResultFileDate		= NULL;
GET_RESULT_WIRE_CONTEXT	pGetResultWireContext	= NULL;
GET_RESULT_ENTITY_NAME	pGetResultEntityName		= NULL;
GET_RESULT_BEST_NAME	pGetResultBestName		= NULL;
GET_RESULT_LISTING	pGetResultListing			= NULL;
GET_RESULT_DENY_REASON	pGetResultDenyReason		= NULL;
COMPARE_NAMES		pCompareNames				= NULL;
COMPARE_ADDRESSES	pCompareAddresses			= NULL;
GET_SEARCH_COUNT	pGetSearchCount			= NULL;

#else

// Change the variable names used for dynamic linking to the
// actual function name for automatic linking with the
// shared object.
#define	pSetPath		SetPath
#define	pCheckAccess		CheckAccess
#define	pGetLastErrorMessage	GetLastErrorMessage
#define	pDLLGetLastError	DLLGetLastError
#define	pAddFile		AddFile
#define	pAddFiles		AddFiles
#define	pGetNumFiles		GetNumFiles
#define	pGetDataFile		GetDataFile
#define	pRemoveFile		RemoveFile
#define	pRemoveAllFiles		RemoveAllFiles
#define	pGetMinScore		GetMinScore
#define	pSetMinScore		SetMinScore
#define	pGetSearchOption	GetSearchOption
#define	pSetSearchOption	SetSearchOption
#define 	pGetOutputPath				GetOutputPath
#define	pSetOutputPath				SetOutputPath
#define	pCheckName					CheckName
#define	pCheckNameAddress			CheckNameAddress
#define	pCheckWire					CheckWire
#define	pAlternateSearch			AlternateSearch
#define	pGetResultsText			GetResultsText
#define	pGetResultScore			GetResultScore
#define 	pGetResultFileName		GetResultFileName
#define 	pGetResultFileDate		GetResultFileDate
#define	pGetResultWireContext	GetResultWireContext
#define	pGetResultEntityName		GetResultEntityName
#define	pGetResultBestName		GetResultBestName
#define	pGetResultListing			GetResultListing
#define	pGetResultDenyReason		GetResultDenyReason
#define	pCompareNames				CompareNames
#define	pCompareAddresses			CompareAddresses
#define	pGetSearchCount			GetSearchCount
#endif  // DYNAMIC_LINK

//*****************************************************************
// LoadSO
//*****************************************************************
// Description:
//  This function creates a connection to the OFAC SO by loading
//  the shared object into memory and attaching function pointers
//  to all of its interface functions.
//
// Parameters:
//  stInterface - A SO_INTERFACE structure in which to return the
//                shared object information.
//
// Returns:
//  true - The SO was loaded successfully.
//  false - An error has occured.
//
// Created By:		Matthew Aznoe
// Created:			6-May-2002
//
//*****************************************************************
#ifdef DYNAMIC_LINK
bool LoadSO()
{
//	g_hBridgerTrackerSO = dlopen(  "/opt/dev/OFAC/OFAC47/Data/tmp/libofac.so", RTLD_NOW );
printf("[%s][%d]\n",__FILE__,__LINE__);
	g_hBridgerTrackerSO = dlopen(  "libofac.so", RTLD_NOW );
	if( g_hBridgerTrackerSO == NULL )
		g_hBridgerTrackerSO = dlopen(  "./libbridgertracker.so", RTLD_NOW );
		if( g_hBridgerTrackerSO == NULL )
			return false;
	
	pSetPath			= (SET_PATH) dlsym( g_hBridgerTrackerSO, "SetPath" );
	pCheckAccess			= (CHECK_ACCESS) dlsym( g_hBridgerTrackerSO, "CheckAccess" );	
	pGetLastErrorMessage		= (GET_LAST_ERROR_MESSAGE) dlsym( g_hBridgerTrackerSO, "GetLastErrorMessage" );
	pDLLGetLastError		= (DLL_GET_LAST_ERROR) dlsym( g_hBridgerTrackerSO, "DLLGetLastError" );
	pAddFile			= (ADD_FILE) dlsym( g_hBridgerTrackerSO, "AddFile" );
	pAddFiles			= (ADD_FILES) dlsym( g_hBridgerTrackerSO, "AddFiles" );
	pGetNumFiles			= (GET_NUM_FILES) dlsym( g_hBridgerTrackerSO, "GetNumFiles" );
	pGetDataFile			= (GET_DATA_FILE) dlsym( g_hBridgerTrackerSO, "GetDataFile" );
	pRemoveFile			= (REMOVE_FILE) dlsym( g_hBridgerTrackerSO, "RemoveFile" );
	pRemoveAllFiles			= (REMOVE_ALL_FILES) dlsym( g_hBridgerTrackerSO, "RemoveAllFiles" );
	pGetMinScore			= (GET_MIN_SCORE) dlsym( g_hBridgerTrackerSO, "GetMinScore" );
	pSetMinScore			= (SET_MIN_SCORE) dlsym( g_hBridgerTrackerSO, "SetMinScore" );
	pGetSearchOption		= (GET_SEARCH_OPTION) dlsym( g_hBridgerTrackerSO, "GetSearchOption" );
	pSetSearchOption		= (SET_SEARCH_OPTION) dlsym( g_hBridgerTrackerSO, "SetSearchOption" );
	pGetOutputPath			= (GET_OUTPUT_PATH) dlsym( g_hBridgerTrackerSO, "GetOutputPath" );
	pSetOutputPath			= (SET_OUTPUT_PATH) dlsym( g_hBridgerTrackerSO, "SetOutputPath" );
	pCheckName			= (CHECK_NAME) dlsym( g_hBridgerTrackerSO, "CheckName" );
	pCheckNameAddress 		= (CHECK_NAME_ADDRESS) dlsym( g_hBridgerTrackerSO, "CheckNameAddress" );
	pCheckWire			= (CHECK_WIRE) dlsym( g_hBridgerTrackerSO, "CheckWire" );
	pAlternateSearch		= (ALTERNATE_SEARCH) dlsym( g_hBridgerTrackerSO, "AlternateSearch" );
	pGetResultsText			= (GET_RESULTS_TEXT) dlsym( g_hBridgerTrackerSO, "GetResultsText" );
	pGetResultScore			= (GET_RESULT_SCORE) dlsym( g_hBridgerTrackerSO, "GetResultScore" );
	pGetResultFileName		= (GET_RESULT_FILE_NAME) dlsym( g_hBridgerTrackerSO, "GetResultFileName" );
	pGetResultFileDate		= (GET_RESULT_FILE_DATE) dlsym( g_hBridgerTrackerSO, "GetResultFileDate" );
	pGetResultWireContext	= (GET_RESULT_WIRE_CONTEXT) dlsym( g_hBridgerTrackerSO, "GetResultWireContext" );
	pGetResultEntityName		= (GET_RESULT_ENTITY_NAME) dlsym( g_hBridgerTrackerSO, "GetResultEntityName" );
	pGetResultBestName		= (GET_RESULT_BEST_NAME) dlsym( g_hBridgerTrackerSO, "GetResultBestName" );
	pGetResultListing		= (GET_RESULT_LISTING) dlsym( g_hBridgerTrackerSO, "GetResultListing" );
	pGetResultDenyReason		= (GET_RESULT_DENY_REASON) dlsym( g_hBridgerTrackerSO, "GetResultDenyReason" );
	pCompareNames			= (COMPARE_NAMES) dlsym( g_hBridgerTrackerSO, "CompareNames" );
	pCompareAddresses		= (COMPARE_ADDRESSES) dlsym( g_hBridgerTrackerSO, "CompareAddresses" );
	pGetSearchCount			= (GET_SEARCH_COUNT) dlsym( g_hBridgerTrackerSO, "GetSearchCount" );

	
	return true;
} // LoadSO
#endif //DYNAMIC_LINK




//*****************************************************************
// UnLoadSO
//*****************************************************************
// Description:
//	 Disconnects the shared object from the application.
//
// Parameters:
//  g_stInterface - A SO_INTERFACE structure containing connection
//                information about the shared object.
//
// Returns:
//  true - The SO was unloaded successfully.
//  false - An error has occured.
//
// Created By:		Matthew Aznoe
// Created:			6-May-2002
//
//*****************************************************************
#ifdef DYNAMIC_LINK
bool UnLoadSO()
{
	printf("[%s][%d]\n",__FILE__,__LINE__);
	if( g_hBridgerTrackerSO )
	{
		dlclose( g_hBridgerTrackerSO );
		pSetPath 					= NULL;
		pCheckAccess 				= NULL;
		pGetLastErrorMessage		= NULL;
		pDLLGetLastError			= NULL;
		pAddFile						= NULL;
		pAddFiles					= NULL;
		pGetNumFiles				= NULL;
		pGetDataFile				= NULL;
		pRemoveFile					= NULL;
		pRemoveAllFiles			= NULL;
		pGetMinScore				= NULL;
		pSetMinScore				= NULL;
		pGetSearchOption			= NULL;
		pSetSearchOption			= NULL;
		pGetOutputPath				= NULL;
		pSetOutputPath				= NULL;
		pCheckName					= NULL;
		pCheckNameAddress			= NULL;
		pCheckWire					= NULL;
		pAlternateSearch			= NULL;
		pGetResultsText			= NULL;
		pGetResultScore			= NULL;
		pGetResultFileName		= NULL;
		pGetResultFileDate		= NULL;
		pGetResultWireContext	= NULL;
		pGetResultEntityName		= NULL;
		pGetResultBestName		= NULL;
		pGetResultListing			= NULL;
		pGetResultDenyReason		= NULL;
		pCompareNames				= NULL;
		pCompareAddresses			= NULL;
		pGetSearchCount			= NULL;
	}
	return true;
} // UnLoadSO

#endif // DYNAMIC_LINK

#define TEST_SCRIPT_TYPE	1
#define NAME_SCRIPT_TYPE	2

char * tcf(char *psdata);

//----------------------------------------------------------------------------------------------

JNIEXPORT jstring JNICALL Java_MessageType_printMessage(JNIEnv* env, jobject obj, jstring msg) {

   char buf[128];
   const char *str = (env)->GetStringUTFChars( msg, 0);

	printf("[%s][%d]\n",__FILE__,__LINE__);
  /////////////////////////////////////////////////////////////////////////////////////////////
  #ifdef DYNAMIC_LINK
	// Load the shared object into memory		
	if( ! LoadSO() )
	{
		printf("[%s][%d]\n",__FILE__,__LINE__);
		printf( "Error Loading SO\r\n" );
		printf( "%s\r\n", dlerror() );
		exit(1);
	}
	#endif // DYNAMIC_LINK
	//////////////////////////////////////////////////////////////////////////////////////////
   
   
   printf("cpp-recv[%s]\n", str);

   (env)->ReleaseStringUTFChars( msg, str);
   sprintf(buf,"%s", "jni_call_success");
   

  ///////////////////////////////////////////////////////////////////////////////////
  #ifdef DYNAMIC_LINK
  printf("[%s][%d]\n",__FILE__,__LINE__);
	UnLoadSO();
	printf("[%s][%d]\n",__FILE__,__LINE__);
	#endif // DYNAMIC_LINK
	///////////////////////////////////////////////////////////////////////////////////

   return (env)->NewStringUTF( buf);

}

