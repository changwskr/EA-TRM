package wsj.charset;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.nio.charset.*;
import java.nio.channels.*;
import java.nio.*;
import java.io.*;

public class TESTcharset {
  public static void main(String[] args) {
    if (args.length != 2) {
      System.out.println("[���] java TESTcharset ĳ���ͼ� ���� - EUC-KR ����");
      //java TESTcharset UTF-16 �ѱ۰�Alphabet������
      //C:\jws\WSJJDK14\test>type temp.tmp
      //    ?? ? A l p h a b e t???
      //C:\bea81\jdk141_02\bin\java wsj.charset.TESTcharset EUC-KR �ѱ�AB
      //C:\jws\WSJJDK14\test>type temp.tmp
      //�ѱ�AB

      System.exit(0);
    }

    FileChannel channel = null;

    try {
      Charset charset = Charset.forName(args[0]);
      ByteBuffer buff = charset.encode(args[1]);

      FileOutputStream out = new FileOutputStream("temp.tmp");
      channel = out.getChannel();
      channel.write(buff);
    } catch(IllegalCharsetNameException ex) {
      System.out.println("�߸��� ĳ���ͼ� �̸�: " + args[0]);
    } catch(UnsupportedCharsetException ex) {

      System.out.println("�������� �ʴ� ĳ���ͼ�: " + args[0]);
    } catch(IOException ex) {
      System.out.println("����� ����: " + ex.getMessage());
    } finally {
      if (channel != null) try { channel.close(); } catch(IOException ex) {}
    }
  }
}