package wsj.charset.international;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.sql.*;

class Execute {
    public static void main(String[] args)
        throws ClassNotFoundException, SQLException, IOException {
        if (args.length < 2) {
            System.out.println("����: java Execute driver db_url"
                                + " [user] [passwd] [-encoding encoding]");
            System.exit(-1);
        }

        Class.forName(args[0]);

        java.util.Properties props = new java.util.Properties();
        if (args.length > 2 && ! args[2].equals("-encoding")) {
            props.put("user", args[2]);      // �ʿ��ϸ� �����Ѵ�.
            if (args.length > 3 && ! args[3].equals("-encoding"))
                props.put("password", args[3]);  // �ʿ��ϸ� �����Ѵ�.
        }
        if (args.length > 3 && args[args.length-2].equals("-encoding"))
            props.put("charSet", args[args.length-1]);

        //DriverManager.setLogStream(System.out);
        Connection con = DriverManager.getConnection(args[1], props);
        Statement stmt = con.createStatement();

        BufferedReader stdin
            = new BufferedReader(new InputStreamReader(System.in));

        for (String line; (line = stdin.readLine()) != null;) {
            // �ϳ��� SQL ������ ���������� �̾������� ���� '\'�� �Է��Ѵ�.
            String sql = "";
            while (line.endsWith("\\")) {
                sql += line.substring(0, line.length()-1);
                line = stdin.readLine();
            }
            sql += line;

            boolean isResultSet = stmt.execute(sql);

            while(true) {
                if(isResultSet) {
                    ResultSet rs = stmt.getResultSet();
                    printResultSet(rs);
                } else {
                    int updateCount = stmt.getUpdateCount();
                    if (updateCount == -1)
                        break;
                    System.out.println(updateCount + "���� ���� ����Ǿ���");
                }
                // isResultSet = stmt.getMoreResults();
                // getMoreResults()�� ���� ����̹��� ����� �������� �����Ƿ�
                // ��� ������ �ߴܽ�Ų��.
                break;
            }
        }

        stmt.close();
        con.close();
    }

    private static void printResultSet(ResultSet rs)
        throws SQLException {
        // ��� ���̺������� ���� ���� ���� ���
        ResultSetMetaData rsmd = rs.getMetaData();
        int numCols = rsmd.getColumnCount();
        String[] colNames = new String[numCols];
        int[] colDisplaySizes = new int[numCols];
        int totalDisplaySize = 1;
        for (int i = 0; i < numCols; i++) {
            colNames[i] = rsmd.getColumnName(i+1);
            colDisplaySizes[i] = Math.max(rsmd.getColumnDisplaySize(i+1),
                                          colNames[i].getBytes().length);
            totalDisplaySize += colDisplaySizes[i] + 3;
        }

        // ��� ���̺��� ��� ���
        System.out.println(getLine('-', totalDisplaySize));
        System.out.print("|");
        for(int i = 0; i < numCols; i++) {
            System.out.print(" ");
            print(colNames[i], colDisplaySizes[i]);
            System.out.print(" |");
        }
        System.out.println();
        System.out.println(getLine('-', totalDisplaySize));

        // ��� ���̺��� ����Ÿ ����
        while (rs.next()) {
            System.out.print("|");
            for (int i = 0; i < numCols; i++) {
                System.out.print(" ");
                print(rs.getString(i+1), colDisplaySizes[i]);
                System.out.print(" |");
            }
            System.out.println();
        }
        System.out.println(getLine('-', totalDisplaySize));
    }


    private static String getLine(char ch, int size) {
        char[] line = new char[size];
        for(int i = 0; i < size; ++i)
            line[i] = ch;
        return new String(line);
    }

    private static void print(String str, int size) {
        if (str == null)
            str = "NULL";
        System.out.print(str);
        int strSize = str.getBytes().length;
        int padSize = size - strSize;
        if (padSize < 0)
            padSize = 0;
        System.out.print(getLine(' ', padSize));
    }
}
