package wsj.pipestream.datainputstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;

public class PipedInputOutputStreamTest {
        public static void main(String args[]) {
                PipedInputThread  pin  = new PipedInputThread();
                PipedOutputThread pout =  new PipedOutputThread();
                pin.connection(pout.getPipedOutput());
                pin.start();
                pout.start();
        }
}
