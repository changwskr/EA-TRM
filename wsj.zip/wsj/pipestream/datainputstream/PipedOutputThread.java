package wsj.pipestream.datainputstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
class PipedOutputThread extends Thread {
  private PipedOutputStream  pout = null;
  public PipedOutputThread() {
    pout  = new PipedOutputStream();
  }
  public PipedOutputStream getPipedOutput() {
    return(pout);
  }
  public void run() {
    try {
      System.out.print("���� �Է��ϼ��� : ");
      int ch;
      int iicnt=0;
      while(true){
        if( iicnt>10) break;
        iicnt++;
        Thread.currentThread().sleep(1000);
        String tmp = "��������";
        DataOutputStream dos = new DataOutputStream( pout );
        dos.writeUTF(tmp);
        System.out.println("sendmsg:"+"["+tmp+"]��(��) ����");
      }
      pout.close();
      System.out.println();
    } catch(Exception e) {
      System.out.println(toString() + ": "+e);
    }
  }


}

