package wsj.pipestream.inputstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class PipedInputThread extends Thread {
        private PipedInputStream  pin = null;
        public PipedInputThread() {
                pin  = new PipedInputStream();
        }
        public void connection(PipedOutputStream pout) {
                try {
                        pin.connect(pout);
                } catch(IOException e) {
                        System.out.println(toString() + ": "+e);
                }
        }
        public void run() {
                try {
                        int ch;
                        while((ch=pin.read()) != -1) {
                                System.out.println(toString() + ": "+(char)ch);
                        }
                        System.out.println();
                } catch(IOException e) {
                        System.out.println(toString() + ": "+e);
                }
        }
}

