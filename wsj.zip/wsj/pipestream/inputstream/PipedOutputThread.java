package wsj.pipestream.inputstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
public class PipedOutputThread extends Thread {
        private PipedOutputStream  pout = null;
        public PipedOutputThread() {
                pout  = new PipedOutputStream();
        }
        public PipedOutputStream getPipedOutput() {
                return(pout);
        }
        public void run() {
                try {
                        System.out.print("���� �Է��ϼ��� : ");
                        int ch;
                        while((ch=System.in.read()) != 13) {
                                pout.write(ch);
                                System.out.println(toString() +": "+(char)ch +" ��(��)  �Է��ϼ̽��ϴ�.");
                        }
                        pout.close();
                        System.out.println();
                } catch(IOException e) {
                        System.out.println(toString() + ": "+e);
                }
        }
}
