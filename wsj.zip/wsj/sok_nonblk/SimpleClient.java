package wsj.sok_nonblk;

import java.net.Socket;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.InputStreamReader;

public class SimpleClient {

  public SimpleClient() {
  }
  public static void main(String[] args) {
    int port = 7979;
    Socket socket = null;
    String hostname = "localhost";
    BufferedReader br = null;
    String line = null;
    OutputStream os = null;
    System.out.println ("Echo Client Start !");
    try {
      br = new BufferedReader(new InputStreamReader(System.in));
      socket = new Socket(hostname, port);
      os = socket.getOutputStream();

      while(true){
        line = br.readLine();
        os.write(line.getBytes());
        os.write('\n');
      }
    }
    catch (Exception ex){
      System.out.println ("Error : " + ex.toString());
    }
    finally {
      try {
        socket.close();
      }
      catch (Exception e){}
    }
    System.out.println ("Echo Client End !");
  }
}