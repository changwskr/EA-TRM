package wsj.sok_nonblk;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SimpleServer {

  public SimpleServer() {
  }
  public static void main(String[] args) {
    int port = 7979;
    ServerSocket ss = null;
    Socket client_socket = null;
    BufferedReader br = null;
    String line = null;

    System.out.println ("Echo Server Start !");
    try {
      ss = new ServerSocket(port);
      ss.setReuseAddress(true);
      client_socket = ss.accept();
      br = new BufferedReader(new InputStreamReader(client_socket.getInputStream()));
      while(true){
        line = br.readLine();
        if (line != null)
          System.out.println ("READ : " + line );
        else
          break;
      }
    }
    catch (Exception ex){
      System.out.println ("Error : " + ex.toString());
    }
    finally {
      try {
        client_socket.close();
      }
      catch (Exception e){}
      try {
        ss.close();
      }
      catch (Exception e){}
    }
    System.out.println ("Echo Server End !");
  }
}