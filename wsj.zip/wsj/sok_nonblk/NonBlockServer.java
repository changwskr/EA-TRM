package wsj.sok_nonblk;

import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.util.Set;
import java.util.Iterator;
import java.nio.channels.SocketChannel;

public class NonBlockServer {

  int port = 7979;
  int BUFF_SIZE = 4096;

  public NonBlockServer() {
  }

  public void start(){
    Selector selector = null;
    ServerSocketChannel channel = null;
    InetAddress ia = null;
    int numofkey;
    ByteBuffer bytebuff = ByteBuffer.allocate(1024);
    int readbyte;

    try {
      ia = InetAddress.getByName("127.0.0.1");
      System.out.println ("Server " + ia.toString());
      selector = Selector.open();
      channel = ServerSocketChannel.open();
      channel.configureBlocking(false);
      channel.socket().bind(new InetSocketAddress(ia,port));

      SelectionKey acceptKey = channel.register(selector, SelectionKey.OP_ACCEPT);

      while (( numofkey = selector.select() ) > 0 ){
        Set keys = selector.selectedKeys();
        Iterator i = keys.iterator();
        while (i.hasNext()){
          SelectionKey key = (SelectionKey)i.next();

          if ( key.isAcceptable() ){   // Accept�� �Ǵ� SelectionKey�� �ִ��� Ȯ��
            ServerSocketChannel ssc = (ServerSocketChannel)key.channel();

// ���ο� SocketChannel �� �Ҵ� ����
            SocketChannel sc = ssc.accept();

// nonblocking ���� �����Ѵ�.
            sc.configureBlocking(false);

// ���ο� SocketChannel�� selector�� ��� �Ѵ�.
            SelectionKey sk = sc.register(selector, SelectionKey.OP_READ);
            System.out.println ("new Client accepted");
          }
          else if (key.isReadable()){    // Read ������ SelectionKey�� �ִ��� Ȯ��

            SocketChannel sc = (SocketChannel)key.channel();
            readbyte = sc.read(bytebuff);

            if (readbyte > -1 ){   // ���� ������ ���� readbyte�� -1 �� ������ ����� ���� �ʴ´�.
              bytebuff.flip();

              System.out.println ("READ " + new String(bytebuff.array(),0, readbyte));
              bytebuff.clear();
            }
            else {                    // ������ �������Ƿ� key�� �����Ѵ�.
              key.cancel();
              System.out.println ("Client closed");
            }
          }
          i.remove();
        }
      }
    }
    catch (Exception e){
      System.out.println ("Server Error");
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    NonBlockServer nonBlockServer = new NonBlockServer();
    nonBlockServer.start();
  }
}