package wsj.password;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;

public class FILEpasswd {
  public static void main(String [] args) throws FileNotFoundException, IOException {
    System.out.println("���� input.txt���Ͽ� ��ȣȭ�� �ؽ�Ʈ�� ���κ��� �־� ������ ������");
    LineNumberReader rd = new LineNumberReader(new FileReader("input.txt"));
    Password p1 = new Password();
    String line;
    FileOutputStream fos = new FileOutputStream("output.txt");
    while((line = rd.readLine()) != null) {
      String p2 = p1.StringAlphaToPass(line);
      char tmp;
      for(int i = 0; i < p2.length(); i++) {
        tmp = p2.charAt(i);
        fos.write(tmp);
      }
      fos.write('\n');
    }
    fos.close();
    LineNumberReader rd2 = new LineNumberReader(new FileReader("output.txt"));
    String line2;
    FileOutputStream fos2 = new FileOutputStream("output2.txt");
    while((line2 = rd2.readLine()) != null) {
      String p3 = p1.StringPassToAlpha(line2);
      char tmp2;
      for(int i = 0; i < p3.length(); i++) {
        tmp2 = p3.charAt(i);
        fos2.write(tmp2);
      }
      fos2.write('\n');
    }
  }
}