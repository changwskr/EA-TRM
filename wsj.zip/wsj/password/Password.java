package wsj.password;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Password {
  // �������� ���� ���� ��
  private int ByToBy = 9;
  // �� ĭ�� �� ����
  private char Alphabet[][] = {{'a', 'b', 'c', 'd', 'e', '5', '!', '_', '/'},
  {'f', 'g', 'h', 'i', 'j', '6', '@', '=', '~'},
  {'k', 'l', 'm', 'n', 'o', '7', '#', '|', '`'},
  {'p', 'q', 'r', 's', 't', '8', '$', '{', '?'},
  {'u', 'v', 'w', 'x', 'y', '9', '%', '}', '/'},
  {'z', '1', '2', '3', '4', '0', '^', '[', '\t'},
  {'&', '*', '(', ')', '-', '+', '\\', ']', ' '},
      {';', '\'', ':', '\"', '<', '>', ',', '.', ' '},
      {' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' '}};
  // ��ȯ�� �н�����
  private char Password[] = {'A', 'C', 'H', 'L', 'X', 'Z', 'P', 'Q', 'G'};

  // ���ڸ� �н������ ��ȯ
  public String AlphaToPass(char Alpha) {
    int IntAlpha = (int)Alpha;
    StringBuffer dest = new StringBuffer(2);
    if (IntAlpha >= (int)'A' && IntAlpha <= (int)'Z') {
      IntAlpha += 32;
      Alpha = (char)IntAlpha;
    }
    int i = 0, j = 0;
    for (i = 0; i < ByToBy; i++) {
      int c = 0;
      for (j = 0; j < ByToBy; j++) {
        if (Alpha == Alphabet[i][j]) {
          c = 1;
          break;
        }
      }
      if (c == 1) break;
    }
    dest.append(Password[j]);
    dest.append(Password[i]);

    return dest.toString();
  }

  // �н����带 ���ڷ� ��ȯ
  public char PassToAlpha(String Pass) {
    char post, last;
    post = Pass.charAt(0);
    last = Pass.charAt(1);
    int i = 0, j = 0;
    for (i = 0; i < ByToBy ; i++) {
      if (Password[i] == post) break;
    }
    for (j = 0; j < ByToBy; j++) {
      if (Password[j] == last) break;
    }
    return Alphabet[j][i];
  }

  // ���ڿ��� �н����忭�� ��ȯ
  public String StringAlphaToPass(String StringAlpha) {
    char tmp;
    String Ans = "";
    for (int i = 0; i < StringAlpha.length(); i++) {
      tmp = StringAlpha.charAt(i);
      Ans = Ans + this.AlphaToPass(tmp);
    }
    return Ans;
  }

  // �н����忭�� ���ڿ��� ��ȯ
  public String StringPassToAlpha(String pass) {
    StringBuffer pass1 = new StringBuffer(2);
    String Ans = "";
    for (int i = 0; i < pass.length(); i = i + 2) {
      pass1.insert(0, pass.charAt(i));
      pass1.insert(1, pass.charAt(i+1));
      char tmp = this.PassToAlpha(pass1.toString());
      Ans = Ans + tmp;
    }
    return Ans;
  }

  public static void main(String args[]){
    Password pw = new Password();
    String str=args[0];
    String desc = pw.StringAlphaToPass(str);
    String val=pw.StringPassToAlpha(desc);
    System.out.println(str+":"+desc+":"+val);

  }
}