package wsj.udp;

import java.net.DatagramSocket;
import java.net.DatagramPacket;

public class DatagramServer {
  public DatagramServer() {
  }
  public static void main(String[] args) {
    int buffsize = 18;
    int port = 9999;

    byte[] rbuff = new byte[buffsize];
    byte[] sbuff = new byte[buffsize];

    try {
      // DatagramSocket �� �����Ѵ�.
      DatagramSocket socket = new DatagramSocket(port);

      // �޾Ƶ��� DatagramPacket�� �����Ѵ�.
      DatagramPacket rcv_packet = new DatagramPacket(rbuff, buffsize);

      // �����͸� �д´�.
      socket.receive(rcv_packet);

      System.arraycopy(rcv_packet.getData(),0,sbuff,0,buffsize);

      System.out.println ( "[����] ���� ������ : " + new String( rcv_packet.getData(), "euc-kr") );

      socket.close();
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
}