package wsj.soksrv.typestr.client;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;
import wsj.util.system.*;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;

class CLIdemo extends Thread {

  private Socket csocket;
  private OutputStream os;
  private InputStream is;
  private int txcnt=0;

  public static void main(String args[]) throws IOException {
    System.out.println("usage CLIdemo ip port txcnt senddata");

    new CLIdemo(args[2]).sendrecv(args[0],args[1],args[3]);

  }

  public CLIdemo(String txcnt) throws IOException {
    try{
      this.txcnt = String2Number.Str2Int(txcnt);
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }
  }

  public void sendrecv(String ip,String port,String senddata){
    String srttime = GetSystime.GetSysTime();
    String recvdata = null;
    int cnt=0;

    try{
      csocket = SOCKETapi.SOCKETopen(ip,String2Number.Str2Int(port));
      is = csocket.getInputStream();
      os = csocket.getOutputStream();
    }
    catch(Exception ex){
      ex.printStackTrace();
      return ;
    }

    while(true){
      try{
        csocket.setSoTimeout(10000);
        cnt++;
        String snd=senddata+cnt;
        SOCKETapi.write_data(os ,snd);
        recvdata = SOCKETapi.read_data(is);

        System.out.print("-S["+snd +"]");
        System.out.println("-R["+recvdata+"]" );

        if( cnt==txcnt ){
          break;
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
        break;
      }
    }

    try{
      csocket.close();
      is.close();
      os.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
}

