package wsj.soksrv.typestr;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;

public class SOCKETserver extends Thread {
  private Vector QUEUE_socketFD = new Vector(); //������ ������ ��������Ÿ����
  private ServerSocket serverSocket;
  private Socket u_srv_sok;
  private int PORT;
  private int MAX_THR_CNT;

  public SOCKETserver(int MAX_THR_CNT,int PORT) throws IOException {
    this.MAX_THR_CNT=MAX_THR_CNT;
    this.PORT = PORT;

    try{
      for( int ii=0 ; ii<MAX_THR_CNT ; ii++ ){
        new SOCKETserverHandler(QUEUE_socketFD,"T:["+String2Number.Int2Str(ii)+"]");
      }
      serverSocket = SOCKETapi.SERVERopen(PORT);
      new Thread(this,"TM").start();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }
  }

  public void run() {
    for( ; ; ){
      try{
        u_srv_sok = SOCKETapi.SOKaccept(serverSocket);
        QUEUE_socketFD.add(u_srv_sok);
        synchronized (QUEUE_socketFD) {
          QUEUE_socketFD.notifyAll();
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
        return;
      }
    }
  }

  public static void main(String[] args) throws Exception {
    try {
       new SOCKETserver(String2Number.Str2Int(args[0]),String2Number.Str2Int(args[1]));
    }
    catch(Exception ex){}
  }
}

