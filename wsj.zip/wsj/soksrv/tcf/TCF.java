package wsj.soksrv.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class TCF {
  public String packet;
  public Object opacket;
  public TCF() {
  }
  public boolean execute(String pvtmp)
  {
    this.packet = pvtmp;
    return true;
  }
  public boolean execute(Object pvtmp)
  {
    this.opacket = pvtmp;
    return true;
  }

  public static void main(String[] args) {
    TCF TCF1 = new TCF();
  }
}