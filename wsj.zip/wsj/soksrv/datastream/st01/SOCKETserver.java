package wsj.soksrv.datastream.st01;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

class SOCKETserver extends Thread {
  private ServerSocket serversocket;
  private Socket srvsocket;
  private DataInputStream sdis;
  private DataOutputStream sdos;
  private int port;

  public static void main(String args[]) throws IOException{
    new SOCKETserver(String2Number.Str2Int(args[0]));
  }

  public SOCKETserver(int port) throws IOException{
    this.port = port;
    try{
      this.serversocket =new ServerSocket(this.port);
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    System.out.println("ServerSocket open success");
    return;
  }

  public void run() {
    while(true){
      try{
        this.srvsocket=this.serversocket.accept();
        try{
          new SOCKETserverhandler(this.srvsocket);
        }
        catch(Exception ioe){
          System.out.println(this.srvsocket.getInetAddress().getHostAddress()+":: ����Ǿ����ϴ�");
          continue;
        }
      }
      catch(Exception ex){
        System.out.println("ServerSocket���� accept�ÿ� Exception�� �߻�");
        System.out.println("ServerSocket ����");
        ex.printStackTrace();
        break;
      }
    }
    try{
      this.serversocket.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("�������� ����");
  }
}
//::~ endof SOCKETserver


