package wsj.soksrv.datastream.st01;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;


class SOCKETserverhandler extends Thread{
  private Socket srvsocket;
  private DataInputStream sdis;
  private DataOutputStream sdos;
  private int port;


  public SOCKETserverhandler(Socket srvsocket) throws IOException {
    try{
      this.srvsocket=srvsocket;
      this.sdis = new DataInputStream ( this.srvsocket.getInputStream());
      this.sdos = new DataOutputStream( this.srvsocket.getOutputStream());
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    System.out.println("ServerSocket open success");
    new Thread(this,"SOCKETserverhandler-thr-0").start();
  }
  public void run(){
    while(true){
      try{
        System.out.println("-------------------------------------->>>>>>");
        String tmp =  SOCKETapi.read_data(this.sdis );
        //System.out.println(tmp);
        SOCKETapi.write_data(this.sdos ,tmp);
      }
      catch(Exception ex){
        ex.printStackTrace();
        System.out.println("SOCKETserverhandler exception �߻�--"
            +this.srvsocket.getInetAddress().getHostAddress()
            +":: ����Ǿ����ϴ�");
        break;
      }
    }

    try{

      this.srvsocket.close();
      this.sdis.close();
      this.sdos.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("����SOCKETserverhandler ����");
  }
}


