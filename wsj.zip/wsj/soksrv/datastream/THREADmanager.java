package wsj.soksrv.datastream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;


public class THREADmanager {
  Thread thr;
  String stime;
  String tname;
  String sdate;
  int    cnt;
  String dump;

  public THREADmanager(Thread thr){
    this.thr=thr;
    this.sdate="20020719";
    this.stime="1010111";
    this.cnt=0;
    this.tname=thr.currentThread().getName();
  }

  public synchronized static void addThread(Hashtable thrmanage,String key) throws Exception{
    thrmanage.put(key,new THREADmanager(Thread.currentThread()));
  }

  public synchronized static THREADmanager getThrInfo(String tname,Hashtable thrmanage){
    return( (THREADmanager)thrmanage.get(tname) );
  }

  public static boolean �׾�����ٽü���(String mkey,Hashtable thrmanage,Thread thr) throws Exception {
    if( thrmanage.containsKey(mkey) && !(((THREADmanager)thrmanage.get(mkey)).thr.isAlive()) ){
      ((THREADmanager)thrmanage.get(mkey)).thr = thr;
      ((THREADmanager)thrmanage.get(mkey)).sdate="22222222";
      ((THREADmanager)thrmanage.get(mkey)).stime="22222222";
      ((THREADmanager)thrmanage.get(mkey)).cnt++;
      return true;
    }
    return false;
  }

  public synchronized static boolean isExist(Hashtable thrmanage,String mkey) throws Exception {
    if( thrmanage.containsKey(mkey) )
      return true;
    else
      return false;
  }

  public synchronized static void removeThread(Hashtable thrmanage,String mkey) throws Exception {
    thrmanage.remove(mkey);
  }

  public static ArrayList getIsStopThr(Hashtable thrmanage) throws Exception {
    ArrayList vthr = new ArrayList();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      if ( !ti.thr.isAlive() ){
        vthr.add(ti);
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }

  public static ArrayList getIsAliveThr(Hashtable thrmanage) throws Exception {
    ArrayList vthr = new ArrayList();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      if ( ti.thr.isAlive() ){
        vthr.add(ti);
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }

  public static Vector getIsStopThrv(Hashtable thrmanage) throws Exception {
    Vector vthr = new Vector();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      if ( !ti.thr.isAlive() ){
        vthr.addElement(ti) ;
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }

  public static Vector getIsAliveThrv(Hashtable thrmanage) throws Exception {
    Vector vthr = new Vector();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      if ( ti.thr.isAlive() ){
        vthr.addElement(ti) ;
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }

  public static void prntKilledthr(Vector vinfo) {
    for(int ii=0;ii<vinfo.size();ii++){
      THREADmanager thr = (THREADmanager)vinfo.elementAt(ii);
      System.out.println(thr.tname+"::"+thr.stime+"::"+thr.sdate);
    }
  }

  public static void prntThrInfo(Hashtable thrmanage){
    for( Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      System.out.println(ti.tname+"::"+ti.stime+"::"+ti.sdate);
    }
  }

  public synchronized static void removeKilledThr(Hashtable thrmanage){
    for( Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THREADmanager ti = (THREADmanager)thrmanage.get(thrname);
      if( !ti.thr.isAlive() )
              thrmanage.remove(thrname);
      //System.out.println(ti.tname+"::"+ti.stime+"::"+ti.sdate);
    }
  }
}



