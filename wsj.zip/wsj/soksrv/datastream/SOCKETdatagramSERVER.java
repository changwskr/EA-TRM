package wsj.soksrv.datastream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

public class SOCKETdatagramSERVER extends Thread{
  private Socket srvsocket;
  private DataInputStream sdis;
  private DataOutputStream sdos;
  private int port;
  private Hashtable thrmanage;

  public SOCKETdatagramSERVER(Socket srvsocket,Hashtable thrmanage) throws IOException {
    try{
      this.srvsocket=srvsocket;
      this.thrmanage = thrmanage;
      this.sdis = new DataInputStream ( this.srvsocket.getInputStream());
      this.sdos = new DataOutputStream( this.srvsocket.getOutputStream());
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    System.out.println("ServerSocket open success");
    new Thread(this,"SOCKETdatagramSERVER-thr-0").start();
  }
  public void run(){
    thrmanage.put(Thread.currentThread().getName(),new THREADmanager(Thread.currentThread()));
    while(true){
      try{
        System.out.println("-------------------------------------->>>>>>");
        String tmp =  SOCKETapi.read_data(this.sdis );
        //System.out.println(tmp);
        SOCKETapi.write_data(this.sdos ,tmp);
      }
      catch(Exception ex){
        ex.printStackTrace();
        System.out.println("SOCKETdatagramSERVER exception �߻�--"
            +this.srvsocket.getInetAddress().getHostAddress()
            +":: ����Ǿ����ϴ�");
        break;
      }
    }

    try{
      THREADmanager.removeThread(thrmanage,Thread.currentThread().getName());
      this.srvsocket.close();
      this.sdis.close();
      this.sdos.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("����SOCKETdatagramSERVER ����");
  }
}

