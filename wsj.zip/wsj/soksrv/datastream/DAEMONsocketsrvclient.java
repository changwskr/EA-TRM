package wsj.soksrv.datastream;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.util.*;

public class DAEMONsocketsrvclient extends Thread {

  /**-------------------------------------------------------------------------
   * <p>Title: �⵿�� �����带 ���� </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: </p>
   * @author unascribed
   * @version 1.0
   */
  public String IP = "21.101.1.252";
  public int port = 35555;

  public DAEMONsocketsrvclient(char type) {
    try {
      switch( type ){
        case 's':
          new SOCKETserver(this.port).start();
          break;
        case 'c':
          new SOCKETclient(this.IP,this.port).start();
          break;
      }
    }
    catch(IOException ex){
      ex.printStackTrace();
      System.out.println("DAEMONsocketsrvclient ex::"+ex.getMessage());
      System.exit(1);
    }
    System.out.println("DAEMONsocketsrvclient �� ������::");
  }

  public void run() {
    while(true){
      try{

      }
      catch(Exception ex){
      }
    }
  }

  public static void main(String[] args)throws Exception{
    DAEMONsocketsrvclient set = new DAEMONsocketsrvclient(args[0].charAt(0));
  }

  /**-------------------------------------------------------------------------
   * <p>Title: Ŭ���̾�Ʈ ����</p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: </p>
   * @author unascribed
   * @version 1.0
   */

  class SOCKETclient extends Thread {
    private Socket csocket;
    private DataOutputStream cdos;
    private DataInputStream cdis;
    private int port;
    private String hostip;
    private String hostname;

    public SOCKETclient (String IP,int port) throws IOException {
      try {
        this.port = port;
        this.hostip = IP;
        this.csocket = new Socket(this.hostip ,this.port);
        this.hostname = this.csocket.getInetAddress().getHostAddress();
        this.cdis = new DataInputStream ( this.csocket.getInputStream());
        this.cdos = new DataOutputStream( this.csocket.getOutputStream());
      }
      catch(IOException ex){
        ex.printStackTrace();
        throw new IOException(ex.getMessage());
      }
    }

    public void run(){
      while(true){
        try{
          Thread.currentThread().sleep(3000);
          String tmp = "1234567890abcdefg���ھ� ����";
          write_data(this.cdos ,tmp);
          System.out.println(read_data(this.cdis));
        }
        catch(Exception ex){
          ex.printStackTrace();
          break;
        }
      }
      try{
        this.csocket.close();
        this.cdis.close();
        this.cdos.close();
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
      System.out.println("Ŭ���̾�Ʈ ����");
    }
  }
  //::~ endof SOCKETclient

  /**------------------------------------------------------------------------*
   * <p>Title: </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: </p>
   * @author unascribed
   * @version 1.0
   */
  private ServerSocket serversocket;

  class SOCKETserver extends Thread {
    private ServerSocket serversocket;
    private Socket srvsocket;
    private DataInputStream sdis;
    private DataOutputStream sdos;
    private int port;

    public SOCKETserver(int port) throws IOException{
      this.port = port;
      try{
        this.serversocket =new ServerSocket(35555);
      }
      catch(IOException ex){
        ex.printStackTrace();
        throw new IOException(ex.getMessage());
      }
      System.out.println("ServerSocket open success");
      return;
    }

    public void run() {
      while(true){
        try{
          this.srvsocket=this.serversocket.accept();
          try{
            new SOCKETsvrthr(this.srvsocket);
          }
          catch(Exception ioe){
            System.out.println(this.srvsocket.getInetAddress().getHostAddress()+":: ����Ǿ����ϴ�");
            continue;
          }
        }
        catch(Exception ex){
          System.out.println("ServerSocket���� accept�ÿ� Exception�� �߻�");
          System.out.println("ServerSocket ����");
          ex.printStackTrace();
          break;
        }
      }
      try{
        this.serversocket.close();
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
      System.out.println("�������� ����");
    }
  }
  //::~ endof SOCKETserver


  /**----------------------------------------------------------------------*
   * <p>Title: </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: </p>
   * @author unascribed
   * @version 1.0
   */

  class SOCKETsvrthr extends Thread{
    private Socket srvsocket;
    private DataInputStream sdis;
    private DataOutputStream sdos;
    private int port;

    public SOCKETsvrthr(Socket srvsocket) throws IOException {
      try{
        this.srvsocket=srvsocket;
        this.sdis = new DataInputStream ( this.srvsocket.getInputStream());
        this.sdos = new DataOutputStream( this.srvsocket.getOutputStream());
      }
      catch(IOException ex){
        ex.printStackTrace();
        throw new IOException(ex.getMessage());
      }
      System.out.println("ServerSocket open success");
      new Thread(this,"SOCKETsvrthr").start();
    }
    public void run(){
      while(true){
        try{
          String tmp =  read_data(this.sdis );
          System.out.println(tmp);
          write_data(this.sdos ,tmp);
        }
        catch(Exception ex){
          ex.printStackTrace();
          System.out.println("SOCKETsvrthr exception �߻�--"
              +this.srvsocket.getInetAddress().getHostAddress()
              +":: ����Ǿ����ϴ�");
          break;
        }
      }

      try{
        this.srvsocket.close();
        this.sdis.close();
        this.sdos.close();
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
      System.out.println("����SOCKETsvrthr ����");
    }
  }

  public static final String read_data(DataInputStream  dis)
      throws IOException {
    byte[] b;
    byte[] bytebuff ;
    long size;
    int div;
    int slice;
    int rest;
    long st=0;
    long et=0;

    try {
      size=dis.readLong();
      bytebuff = new byte[(int)size];
      div=dis.readInt();
      rest=(int)(size%div);
      slice=(int)((size-rest)/div);

      st=System.currentTimeMillis();

      int i=0;
      int sp=0;
      if(slice!=0)
        for(i=0;i<div;i++){
          b=new byte[slice];
          dis.read(b);
          System.arraycopy(b,0,bytebuff,sp,slice);
          sp = sp+slice;
        }

      //���ҵ� ������ ũ���� �迭
      b=new byte[rest];
      //������ ������ ����
      dis.read(b);
      System.arraycopy(b,0,bytebuff,sp,rest);

      //���� ���� �ð�
      et=System.currentTimeMillis();
      //���� �� �ҿ�ð�
      System.out.println("---------------------------------------------------");
      System.out.println("size:"+size+",div:"+div+",slice:"+slice +",rest:"+rest);
      System.out.println((et-st)+"/milliseconds,readlen/"+bytebuff.length
                         +" readdata[" + new String(bytebuff)+"]");
      if( bytebuff.length != size ){
        throw new IOException("read_data ex::data length not match");
      }
    }catch(IOException ioe){
      ioe.printStackTrace();
      throw new IOException("read_data ex::"+ioe.getMessage());
    }
    return (new String(bytebuff));
  }

  public static final void write_data(DataOutputStream dos,String senddata)
      throws IOException {
    long size;
    int  div;
    int  slice;
    int  rest;
    long st=0;
    long et=0;
    byte[] bytebuffer=null;
    byte[] b;

    try{
      bytebuffer = senddata.getBytes();
      size=bytebuffer.length;
      div=100;
      rest=(int)(size%div);
      slice=(int)((size-rest)/div);

      int sp=0;
      int ep=0;
      int ii=0;
      dos.writeLong(size);
      dos.writeInt(div);
      st=System.currentTimeMillis();

      if( slice!=0)
        for(ii=0;ii<div;ii++){
          b=new byte[slice];
          System.arraycopy(bytebuffer,sp,b,0,slice);
          sp += slice;
          dos.write(b);
        }
        b=new byte[rest];
        System.arraycopy(bytebuffer,sp,b,0,rest);
        dos.write(b);
        dos.flush();

        et=System.currentTimeMillis();

        System.out.println("-------------------------------------------------");
        System.out.println("size:"+size+",div:"+div+",slice:"+slice +",rest:"+rest);
        System.out.println((et-st)+"/milliseconds,sendlen/"
                           +bytebuffer.length+" senddata["
                           + new String(bytebuffer)+"]");

    }catch(IOException ioe){
      ioe.printStackTrace();
      throw new IOException("write_data ex::"+ioe.getMessage());
    }
    return;
  }

}



