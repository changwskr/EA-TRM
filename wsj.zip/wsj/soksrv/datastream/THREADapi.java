package wsj.soksrv.datastream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class THREADapi {
  public static final void THREADstart() throws Exception {
    Thread zipThread = new Thread( new Runnable() {
        public void run()
        {
          while(!Thread.currentThread().isInterrupted() ){
            try
            {
              Thread.currentThread().sleep(1000);
              System.out.println("THREAD start");
            }
            catch( Exception e )
            {
              e.printStackTrace();
            }
          }
        }
    });
    zipThread.start();
  }
}

