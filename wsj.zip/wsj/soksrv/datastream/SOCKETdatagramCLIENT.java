package wsj.soksrv.datastream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

public class SOCKETdatagramCLIENT extends Thread {
  private Socket csocket;
  private DataOutputStream cdos;
  private DataInputStream cdis;
  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  public SOCKETdatagramCLIENT (String IP,int port,Hashtable thrmanage) throws IOException {
    try {
      this.port = port;
      this.hostip = IP;
      this.thrmanage=thrmanage;
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = new DataInputStream ( this.csocket.getInputStream());
      this.cdos = new DataOutputStream( this.csocket.getOutputStream());
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
  }

  public void run(){
    thrmanage.put(Thread.currentThread().getName(),new THREADmanager(Thread.currentThread()));
    while(true){
      try{
        Thread.currentThread().sleep(1000);
        String tmp = "1234567890abcdefg���ھ� ����";
        System.out.println("-------------------------------------->>>>>>");
        SOCKETapi.write_data(this.cdos ,tmp);
        SOCKETapi.read_data(this.cdis);
      }
      catch(Exception ex){
        ex.printStackTrace();
        break;
      }
    }
    try{
      this.csocket.close();
      this.cdis.close();
      this.cdos.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("Ŭ���̾�Ʈ ����");
  }


}
//::~ endof SOCKETdatagramCLIENT

