package wsj.soksrv.datastream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;

public class SOCKETdatastreamSRV extends Thread {

  /**-------------------------------------------------------------------------
   * <p>Title: �⵿�� �����带 ���� </p>
   * <p>Description: </p>
   * <p>Copyright: Copyright (c) 2002</p>
   * <p>Company: </p>
   * @author unascribed
   * @version 1.0
   */
  public static Hashtable hashinfo = new Hashtable();
  public String IP = "21.101.1.252";
  public int port = 35555;
  private Hashtable thrmanage = new Hashtable();
  private ServerSocket serversocket;


  public SOCKETdatastreamSRV(char type) {
    try {
      switch( type ){
        case 's':
          new Thread(new SOCKETdatagramSERVER(this.port,thrmanage),
                     "SOCKETdatagramSERVER-thr-0").start();
          new Thread(this,"SOCKETdatastreamSRV-0").start();
          break;
        case 'c':
          new Thread(new SOCKETdatagramCLIENT(this.IP,this.port,thrmanage),
                     "SOCKETdatagramCLIENT-thr-0").start();
          break;
      }
    }
    catch(IOException ex){
      ex.printStackTrace();
      System.out.println("SOCKETdatastreamSRV ex::"+ex.getMessage());
      System.exit(1);
    }
    System.out.println("SOCKETdatastreamSRV �� ������::");
  }


  public void run() {
    thrmanage.put(Thread.currentThread().getName(),new THREADmanager(Thread.currentThread()));
    while(true){
      try{
        Thread.currentThread().sleep(3000) ;
        THREADmanager.removeKilledThr(thrmanage);
        System.out.println("Current Thr Size::"+(thrmanage.size()) );
        THREADmanager.prntThrInfo(thrmanage);
      }
      catch(Exception ex){
      }
    }
  }

  public static void main(String[] args)throws Exception{
    SOCKETdatastreamSRV set = new SOCKETdatastreamSRV(args[0].charAt(0));
  }

}



class SOCKETenv {
  private final int PORT = 35530;
  private final String HOST = "21.101.1.252";
}





