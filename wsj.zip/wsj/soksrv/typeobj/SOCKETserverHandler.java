package wsj.soksrv.typeobj;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

public class SOCKETserverHandler extends Thread {

  private Vector QUEUE_socketFD;
  private Socket SOKfd;
  private ObjectInputStream objinpstream;
  private ObjectOutputStream objoutpstream;

  public SOCKETserverHandler(Vector QUEUE_socketFD,String handlerName) throws IOException {
    try{
      this.QUEUE_socketFD = QUEUE_socketFD;
      new Thread(this,handlerName).start();
    }
    catch(Exception ex){
      ex.printStackTrace();
      throw new IOException();
    }
  }

  public void run() {
    for (; ; ) {
      synchronized (QUEUE_socketFD) {
        while (QUEUE_socketFD.isEmpty()) {
          try {
            QUEUE_socketFD.wait();
          }
          catch (InterruptedException ex) {
          }
        }
        try{
          Object o = QUEUE_socketFD.remove(0);
          SOKfd=(Socket)o;
          objinpstream = SOCKETapi.SOKgetstrois(SOKfd);
          objoutpstream = SOCKETapi.SOKgetstroos(SOKfd);
        }
        catch(Exception ex){
          try{
            objinpstream.close();
            objoutpstream.close();
            SOKfd.close();
          }
          catch(Exception ex2){}
          continue;
        }
      }

      for( ; ; ){
        try{
          Object RECVdata = SOCKETapi.read_data(objinpstream );

          //////////////////////////////////////////////////////////////////
          // Ʈ����� ������ �����Ѵ�.
          //////////////////////////////////////////////////////////////////
            System.out.println("=========================================TCF ST");
            TCF tcf = new TCF();
            tcf.execute(RECVdata);
            System.out.println("=========================================TCF END");
          //////////////////////////////////////////////////////////////////
          SOCKETapi.write_data(objoutpstream,RECVdata);
          System.out.println("==�۽ŵ���Ÿ:["+RECVdata+"]");
        }
        catch(Exception ex3){
          ex3.printStackTrace();
          break;
        }
      }

      try{
        SOKfd.close();
        objinpstream.close();
        objoutpstream.close();
      }
      catch(Exception ex4){
        ex4.printStackTrace();
      }
    }
  }
}
