package wsj.soksrv.typeobj.client;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;
import wsj.util.system.*;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;

class CLIdemo {

  private Socket csocket;
  private ObjectOutputStream os;
  private ObjectInputStream is;

  public static void main(String args[]) throws IOException {
    packet senddata = new packet();
    System.out.println("usage CLIdemo ip port ");

    new CLIdemo().sendrecv(args[0],args[1],(Object)senddata);

  }


  public Object sendrecv(String ip,String port,Object senddata){
    packet recvdata = null;

    try{
      System.out.println("--1");
      csocket = SOCKETapi.SOCKETopen(ip,String2Number.Str2Int(port));
      System.out.println("--2["+this.csocket.getLocalAddress().getHostName()  );

      is = SOCKETapi.SOKgetstrois(csocket);
      System.out.println("--2");
      os = SOCKETapi.SOKgetstroos(csocket);

      System.out.println("--3");
      System.out.println("--4");
      csocket.setSoTimeout(30000);
      System.out.println("--5");
      SOCKETapi.write_data(this.os ,senddata);
      System.out.println("--6");
      recvdata = (packet)SOCKETapi.read_data(is);

      System.out.print(": S["+ ((packet)senddata).p1 +"]-");
      System.out.println("-R["+((packet)recvdata).p1+"]" );
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    try{
      this.csocket.close();
      this.is.close();
      this.os.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    return (Object)recvdata;
  }
}

class packet implements Serializable {
  public String p1="1";
  public String p2="2";
}
