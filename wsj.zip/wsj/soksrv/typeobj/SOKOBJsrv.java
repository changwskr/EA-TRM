package wsj.soksrv.typeobj;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.net.*;
import java.util.*;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

public class SOKOBJsrv {

  private static void printUsage() {
    System.out.println("usage: java SOKOBJsrv port");
  }

  public static void main(String[] args) {
    if (args.length < 1) {
      printUsage();
      return;
    }
    int port;
    try {
      port = Integer.parseInt(args[0]);
    }
    catch (NumberFormatException e) {
      printUsage();
      return;
    }

    try {
      ServerSocket ss = new ServerSocket(port);
      while (true) {
              System.out.println("--sv");
        Socket request = ss.accept();
        new HandlerThread(request).start();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

class HandlerThread extends Thread {

  Socket s;

  public HandlerThread(Socket s) {
    this.s = s;
  }

  public void run() {
    try {
      System.out.println("--1");
      ObjectInputStream in = new ObjectInputStream(s.getInputStream());
      ObjectOutputStream out = new ObjectOutputStream(s.getOutputStream());

      for( ; ; ){
        try{
          System.out.println("--*");
          Object RECVdata = SOCKETapi.read_data(in);

          //////////////////////////////////////////////////////////////////
          // Ʈ����� ������ �����Ѵ�.
          //////////////////////////////////////////////////////////////////
            System.out.println("=========================================TCF ST");
            TCF tcf = new TCF();
            tcf.execute(RECVdata);
            System.out.println("=========================================TCF END");
          //////////////////////////////////////////////////////////////////
          SOCKETapi.write_data(out,RECVdata);
          System.out.println("==�۽ŵ���Ÿ:["+RECVdata.toString()+"]");
        }
        catch(Exception ex3){
          ex3.printStackTrace();
          break;
        }
      }
      try{
        in.close();
        out.close();
        s.close();
      }
      catch(Exception ex4){
        ex4.printStackTrace();
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

