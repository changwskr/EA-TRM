package wsj.soksrv.inoutstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;

public class DEMOclient extends Thread {
  private Socket csocket;
  private InputStream cis;
  private OutputStream cos;
  private int port;
  private String hostip;
  private String hostname;

  public DEMOclient (String IP,int port) throws IOException {
    try {
      this.port = port;
      this.hostip = IP;
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cis = this.csocket.getInputStream();
      this.cos = this.csocket.getOutputStream();
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    new Thread(this,"DEMOclient").start();
  }
  public static void main(String args[]) throws IOException{
    new DEMOclient("21.101.1.252",35555);
  }

  public void run(){
    while(true){
      try{
        Thread.currentThread().sleep(100);
        String tmp = "1234567890abcdefg���ھ� ����";
        System.out.println("-------------------------------------->>>>>>");
        SOCKETapi.write_data(this.cos ,tmp);
        System.out.println("senddata:["+tmp+"]"+tmp.length());
        String tmp2 = SOCKETapi.read_data(this.cis);
        System.out.println("readdata:["+tmp2+"]"+tmp2.length());
      }
      catch(Exception ex){
        ex.printStackTrace();
        break;
      }
    }
    try{
      this.csocket.close();
      this.cis.close();
      this.cos.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("Ŭ���̾�Ʈ ����");
  }
}
//::~ endof DEMOclient
