package wsj.soksrv.inoutstream;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;
import wsj.soksrv.tcf.TCF;


public class DEMOserver extends Thread {
  private ServerSocket serversocket;
  private Socket srvsocket;
  public static Socket pssocket;
  private int port;

  public DEMOserver(int port) throws IOException{
    this.port = port;
    try{
      this.serversocket =new ServerSocket(this.port);
    }
    catch(IOException ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    System.out.println("ServerSocket open success");
    new Thread(this,"DEMOserver").start();
    return;
  }

  public static void main(String args[]) throws IOException{
    new DEMOserver(35555);
  }

  public void run() {
    while(true){
      try{
        this.srvsocket=this.serversocket.accept();
        this.pssocket = this.srvsocket;
        try{
          //=================================================================||
          Thread DEMOsrvthr = new Thread( new Runnable() {
            //--------------------------------------------
            public void run(){
              InputStream sis;
              OutputStream sos;
              Socket srvsocket = DEMOserver.pssocket;
              try{
                sis = srvsocket.getInputStream();
                sos = srvsocket.getOutputStream();
              }
              catch(IOException ex){
                ex.printStackTrace();
                try{ srvsocket.close(); }catch(Exception ex2){}
                return;
              }
              System.out.println("ServerSocket open success");
              while(!Thread.currentThread().isInterrupted()){
                try{
                  String tmp =  SOCKETapi.read_data(sis );
                  System.out.println("readdata:["+tmp+"]"+tmp.length());
                  SOCKETapi.write_data(sos ,tmp);
                  System.out.println("senddata:["+tmp+"]"+tmp.length());
                }
                catch(Exception ex){
                  ex.printStackTrace();
                  System.out.println("SOCKETsvrthr exception �߻�--"
                      +srvsocket.getInetAddress().getHostAddress()
                      +":: ����Ǿ����ϴ�");
                  break;
                }
              }
              try{
                srvsocket.close();
                sis.close();
                sos.close();
              }
              catch(Exception ex){
                ex.printStackTrace();
              }
              System.out.println("����SOCKETsvrthr ����");
            }
            //------------------------------------------
          });
          DEMOsrvthr.start();
          //=================================================================||
        }
        catch(Exception ioe){
          System.out.println(this.srvsocket.getInetAddress().getHostAddress()+":: ����Ǿ����ϴ�");
          continue;
        }
      }
      catch(Exception ex){
        System.out.println("ServerSocket���� accept�ÿ� Exception�� �߻�");
        System.out.println("ServerSocket ����");
        ex.printStackTrace();
        break;
      }
    }
    try{
      this.serversocket.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    System.out.println("�������� ����");
  }
}
//::~ endof DEMOserver
