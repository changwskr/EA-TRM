package wsj.soksrv.client;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;
import wsj.util.system.*;
import wsj.util.socket.SOCKETapi;
import wsj.util.string.String2Number;

class CLIdemo extends Thread {

  private Socket csocket;
  private OutputStream os;
  private InputStream is;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;
  private long [] stime = new long [500];
  private long [] etime = new long [500];
  private int sindex=0;
  private int eindex=0;
  private int txcnt=0;

  public synchronized void sindex(){
    sindex++;
  }
  public synchronized void eindex(){
    eindex++;
  }

  public static void main(String args[]) throws IOException {
    System.out.println("USAGE:: Thr���� Tx�Ǽ�");
    int txcnt = Integer.valueOf(args[1]).intValue();
    for(int i=1; i<=Integer.valueOf(args[0]).intValue() ; i++){
      if( i<=9 ){
        Thread thr = new Thread(new CLIdemo(txcnt),"Thr0"+i);
        thr.start();
      }
      else if( i>=10 && i<=99){
        Thread thr = new Thread(new CLIdemo(txcnt),"Thr"+i);
        thr.start();
      }
    }
  }

  public CLIdemo(int txcnt) throws IOException {
    try{

      for(int iicnt=0; iicnt<stime.length ;iicnt++){
        stime[iicnt]=99999999;
        etime[iicnt]=99999999;
      }
      this.txcnt = txcnt;

      this.csocket = SOCKETapi.SOCKETopen("21.101.3.47",33456);
      this.is = this.csocket.getInputStream();
      this.os = this.csocket.getOutputStream();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }
  }

  public void run(){
    String srttime = GetSystime.GetSysTime();
    String recvdata = null;
    int cnt=0;

    while(true){
      try{
        Thread.currentThread().sleep(100);
        String senddata = GetSystime.GetSysTime();
        csocket.setSoTimeout(10000);
        SOCKETapi.write_data(this.os ,Thread.currentThread().getName()+senddata);
        cnt++;
        recvdata = SOCKETapi.read_data(this.is);

        System.out.print(Thread.currentThread().getName()+": S["+Thread.currentThread().getName()+ senddata +"]-");
        System.out.println(cnt + "-R["+recvdata+"]" );

        if( cnt==txcnt ){
          System.out.print(Thread.currentThread().getName()+": S["+Thread.currentThread().getName()+ senddata +"]-");
          System.out.println(cnt + "-R["+recvdata+"] P:"+csocket.getPort()+" ITV:"+GetSystime.GetSysTime().substring(0,6)+":");
          break;
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
        //break;
        continue;
      }
    }

    try{
      this.csocket.close();
      this.is.close();
      this.os.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
}

