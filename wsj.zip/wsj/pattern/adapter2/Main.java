package wsj.pattern.adapter2;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

abstract class Print {
  public abstract void printWeak();
  public abstract void printStrong();
}

//���߻���� �ȵȴ�. �ڹٴ� [ C++���� ]
class PrintBanner extends Print {
  private Banner banner;
  public PrintBanner(String str){
    this.banner = new Banner(str);
  }
  public void printWeak(){
    banner.showWithParen();

  }
  public void printStrong(){
    banner.showWithAster();
  }
}

class Banner {
  private String string;
  public Banner(String string){
    this.string = string;
  }
  public void showWithParen(){
    System.out.println(string);
  }
  public void showWithAster(){
    System.out.println("*"+string+"*");
  }
}

public class Main {
  public static void main(String [] args) {
    PrintBanner p = new PrintBanner("Hello");
    p.printWeak();
    p.printStrong();
    //p.super.showWithAster();
    //p.super.showWithParen();
  }
}