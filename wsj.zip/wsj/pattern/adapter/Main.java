package wsj.pattern.adapter;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

interface Print {
  public abstract void printWeak();
  public abstract void printStrong();
}

class Banner {
  private String string;
  public Banner(String string){
    this.string = string;
  }
  public void showWithParen(){
    System.out.println(string);
  }
  public void showWithAster(){
    System.out.println("*"+string+"*");
  }
}

//PrintBanner�� Prnint�� �����ؾߵǰ�,Banner�� ��ӹ޴´�.
class PrintBanner extends Banner implements Print {
  public PrintBanner(String str){
    super(str);
  }
  public void printWeak(){
    showWithParen();
  }
  public void printStrong(){
    showWithAster();
  }
}

public class Main {
  public static void main(String [] args) {
    Print p = new PrintBanner("Hello");
    p.printWeak();
    p.printStrong();
    //p.super.showWithAster();
    //p.super.showWithParen();
  }
}