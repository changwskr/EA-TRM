package wsj.pattern.factory;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.util.*;

abstract class Factory {
        public final Product create(String owner){
                Product p = createProduct(owner);
                registerProduct(p);
                return p;
        }
        protected abstract Product createProduct(String owner);
        protected abstract void registerProduct(Product product);
}

class IDCardFactory extends Factory {
        private Vector owners = new Vector();
        //Factory�� ��ӹ޾����Ƿ� createProduct�� �����ؾ� �ȴ�.
        public Product createProduct(String owner){
                return new IDCard(owner);
        }
        //Factory�� ��ӹ޾����Ƿ� registerProduct�� �����ؾ� �ȴ�.
        public void registerProduct(Product product){
                owners.add(((IDCard)product).getOwner());
        }
        Vector getOwner(){
                return owners;
        }
}

abstract class Product {
        public abstract void use();
}

class IDCard extends Product {
        private String owner;
        IDCard(String owner){
                this.owner=owner;
                System.out.println(this.owner + " ����ڰ� ī�带 ����ϴ�");
        }
        //Product�� ��ӹ޾� use()�� �����Ѵ�.
        public void use(){
                System.out.println(this.owner + " ����ڰ� ����ϰ� �ֽ��ϴ�");
        }
        public String getOwner(){
                return this.owner;
        }
}


public class Main {
        public static void main(String[] args) {
                Factory factory = new IDCardFactory();
                Product card1 = factory.create("HHH");
                Product card2 = factory.create("MMM");
                Product card3 = factory.create("FFF");
                card1.use();
                card2.use();
                card3.use();
        }
}
