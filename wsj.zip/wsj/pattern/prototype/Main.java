package wsj.pattern.prototype;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.util.*;

interface Product extends Cloneable {
  public abstract void use(String s);
  public abstract Product createClone();
}

class Manager {
  private Hashtable showcase = new Hashtable();
  public void register(String name,Product proto){
    showcase.put(name,proto);
  }
  public Product create(String protoname){
    Product p = (Product)showcase.get(protoname);
    return p.createClone();
  }
}

class MessageBox implements Product {
  private char decochar;
  public MessageBox(char decochar){
    this.decochar = decochar;
  }
  public void use(String s){
    int length=s.getBytes().length;
    for(int i=0;i<length+4;i++){
      System.out.print(decochar);
    }
    System.out.println();
  }
  public Product createClone(){
    Product p = null;
    try{
      p = (Product)clone();
    }
    catch(CloneNotSupportedException e){
      e.printStackTrace();
    }
    return p;
  }
}

class UnderlinePen implements Product {
  private char decochar;
  public UnderlinePen(char decochar){
    this.decochar = decochar;
  }
  public void use(String s){
    int length=s.getBytes().length;
    System.out.println("\""+s + "\"");
    System.out.print(" ");
    for(int i=0;i<length+4;i++){
      System.out.print(decochar);
    }
    System.out.println();
  }
  public Product createClone(){
    Product p = null;
    try{
      p = (Product)clone();
    }
    catch(CloneNotSupportedException e){
      e.printStackTrace();
    }
    return p;
  }
}



public class Main {
  public static void main(String[] args) {
    Manager manager = new Manager();
    UnderlinePen upen = new UnderlinePen('-');
    System.out.println("-----------------1");
    MessageBox mbox = new MessageBox('*');
    System.out.println("-----------------2");
    MessageBox sbox = new MessageBox('/');
    System.out.println("-----------------3");
    manager.register("kkkkkkkkkkkkkkkkkkkkkkk",upen);
    System.out.println("-----------------4");
    manager.register("kkkkkkkkkkkkkkkkkkk222",mbox);
    manager.register("kkkkkkkkkkkkkkkkkkkk33",sbox);

    System.out.println("-----------------5");
    Product p1 = manager.create("kkkkkkkkkkkkkkkkkkk");
    p1.use("hello, world");
    Product p2 = manager.create("kkkkk222kkkkkkkkkkkkkk");
    p2.use("hello, world");
    Product p3 = manager.create("kkkk333kkkkkkkkkkkkkkk");
    p3.use("hello, world");


  }
}