package wsj.pattern.iterator.test;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Main {
  public static void main(String[] args) {
    FileInfoListDTO fil = new FileInfoListDTO(20);
    fil.appendFileInfo(new FileInfo("�μ���"));
    Iterator it = fil.iterator();
    while( it.hasNext() ){
      FileInfo fi = (FileInfo)it.next();
      System.out.println(" "+fi.getName());

    }


  }
}
