package wsj.pattern.iterator.test;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FileInfoListDTO implements AggregateIterator{
  private FileInfo[] fileinfo;
  private int last=0;

  public FileInfoListDTO(int maxlistsize){
    this.fileinfo = new FileInfo[maxlistsize];
  }

  public FileInfo getFileInfoAt(int index){
    return fileinfo[index];
  }

  public void appendFileInfo(FileInfo fi){
    this.fileinfo[last]=fi;
    last++;
  }

  public int getLength(){
    return last;
  }

  public Iterator iterator(){
    return new FileInfoListDTOIterator(this);
  }
}

