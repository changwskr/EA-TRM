package wsj.pattern.iterator.test;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public interface Iterator {
  public abstract boolean hasNext();
  public abstract Object next();
}