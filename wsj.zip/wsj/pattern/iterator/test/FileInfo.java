package wsj.pattern.iterator.test;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FileInfo {
  public String name;

  public FileInfo(String name) {
    this.name = name;
  }

  public String getName(){
    return this.name;
  }
}