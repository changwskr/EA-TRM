package wsj.pattern.iterator.test;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FileInfoListDTOIterator implements Iterator {
  private FileInfoListDTO fileinfolist;
  private int index;
  public FileInfoListDTOIterator(FileInfoListDTO fileinfolist){
    this.fileinfolist = fileinfolist;
    this.index = 0;
  }
  public boolean hasNext(){
    if( index < fileinfolist.getLength() ){
      return true;
    }
    else
    {
      return false;
    }

  }
  public Object next(){
    FileInfo fi = fileinfolist.getFileInfoAt(index);
    index++;
    return fi;
  }
}
