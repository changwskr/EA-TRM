package wsj.pattern.iterator;

public interface Aggregate {
	public abstract Iterator iterator();
}

