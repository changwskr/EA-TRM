package wsj.pattern.iterator;

public class Main {
	public static void main(String[] args) {
		BookShelf bookShelf = new BookShelf(4);
		bookShelf.appendBook( new Book("Book 1"));
		bookShelf.appendBook( new Book("Book 2"));
		bookShelf.appendBook( new Book("Book 3"));
		bookShelf.appendBook( new Book("Book 4"));

		Iterator it = bookShelf.iterator();
		while(it.hasNext()){
			Book book = (Book)it.next();
			System.out.println(" "+book.getName());
		}

                //------------------------------------------------------------
                BookShelf bs = new BookShelf(10); //10���� å�� ������ ������ �����.
                bs.appendBook(new Book("1b")); //å�� �����Ѵ�
                bs.appendBook(new Book("2b")); //å�� �����Ѵ�
                bs.appendBook(new Book("3b")); //å�� �����Ѵ�
                bs.appendBook(new Book("4b")); //å�� �����Ѵ�
                System.out.println("--1");
                Iterator lit = bs.iterator();
                while( lit.hasNext() ){
                  Book book = (Book)lit.next();
                  System.out.println(" "+book.getName());
                }


	}
}

