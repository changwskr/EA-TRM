package wsj.pattern.sigleton;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Main {

  public Main() {
  }

  public static void main(String[] args) {
    System.out.println("start.");
    Singleton obj1 = Singleton.getInstance();
    Singleton obj2 = Singleton.getInstance();
    if( obj1 == obj2 ){
      System.out.println("����");
    }
    else{
      System.out.println("Ʋ����");
    }

  }
}


class Singleton {
  private static Singleton singleton = new Singleton();
  private Singleton() {
    System.out.println("�ν��Ͻ��� �����߽��ϴ�");
  }
  public static Singleton getInstance() {
    return singleton;
  }
}

