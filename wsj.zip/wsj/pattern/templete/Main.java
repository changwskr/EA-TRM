package wsj.pattern.templete;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

abstract class AbstractDisplay {
  public abstract void open();
  public abstract void print();
  public abstract void close();

  //�������⼭ open�� ��ӹ��� �ӿ��� �����ǰ� ������ ���� display���� ȣ���ϴ� Ÿ���̴�.
  public final void display(){
    open();
    for(int i=0;i<5;i++){
      print();
    }
    close();
  }
}

class CharDisplay extends AbstractDisplay {
  private char ch;
  CharDisplay(char ch){
    this.ch=ch;
  }
  public void open(){
    System.out.print("<<");
  }
  public void print(){
    System.out.print(ch);
  }
  public void close(){
    System.out.print(">>");
  }
}

class StringDisplay extends AbstractDisplay {
  private String str;
  private int width;
  public StringDisplay(String str){
    this.str = str;
    this.width = str.getBytes().length;
  }
  public void open(){
    printLine();
  }
  public void print(){
    System.out.println("|" + str + "|");
  }
  public void close(){
    printLine();
  }
  public void printLine(){
    System.out.print("+");
    for(int i=0;i<width;i++){
      System.out.print("-");
    }
    System.out.println("+");
  }
}

public class Main {
  public static void main(String[] args){
    AbstractDisplay d1 = new CharDisplay('H');
    d1.display();
    AbstractDisplay d2 = new StringDisplay("Hello world");
    d2.display();
  }

}