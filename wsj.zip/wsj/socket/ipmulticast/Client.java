package wsj.socket.ipmulticast;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.InputStreamReader;

public class Client
{
  public static void main(String [] arstring)
  {
    try
    {
      // Create a datagram package and send it to the multicast
      // group at 230.0.0.1, port 7777.
      byte [] arb = new byte [] {'h','e','l','l','o'};
      InetAddress inetAddress = InetAddress.getByName("230.0.0.1");
      DatagramPacket datagramPacket = new DatagramPacket(arb, arb.length, inetAddress, 7777);
      MulticastSocket multicastSocket = new MulticastSocket();
      multicastSocket.send(datagramPacket);
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }
}