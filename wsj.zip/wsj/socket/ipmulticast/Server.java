package wsj.socket.ipmulticast;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.io.InputStreamReader;

public class Server
{
  public static void main(String [] arstring)
  {
    try
    {
      // Create a multicast datagram socket for receiving IP
      // multicast packets. Join the multicast group at
      // 230.0.0.1, port 7777.
      MulticastSocket multicastSocket = new MulticastSocket(7777);
      InetAddress inetAddress = InetAddress.getByName("230.0.0.1");
      multicastSocket.joinGroup(inetAddress);
      // Loop forever and receive messages from clients. Print
      // the received messages.
      while (true)
      {
        byte [] arb = new byte [100];
        DatagramPacket datagramPacket = new DatagramPacket(arb, arb.length);
        multicastSocket.receive(datagramPacket);
        System.out.println("recv msg:"+new String(arb));
      }
    }
    catch (Exception exception)
    {
      exception.printStackTrace();
    }
  }
}