package wsj.socket.datagram;

//
// **********************************************************************
// *                                                                    *
// * (c) Copyright IBM Corp. 1997  All rights reserved.                 *
// *                                                                    *
// * This sample program is owned by International Business Machines    *
// * Corporation or one of its subsidiaries ("IBM") and is copyrighted  *
// * and licensed, not sold.                                            *
// *                                                                    *
// * You may copy, modify, and distribute this sample program in any    *
// * form without payment to IBM,  for any purpose including developing,*
// * using, marketing or distributing programs that include or are      *
// * derivative works of the sample program.                            *
// *                                                                    *
// * The sample program is provided to you on an "AS IS" basis, without *
// * warranty of any kind.  IBM HEREBY  EXPRESSLY DISCLAIMS ALL         *
// * WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED  *
// * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A    *
// * PARTICULAR PURPOSE.                                                *
// *                                                                    *
// * Some jurisdictions do not allow for the exclusion or limitation of *
// * implied warranties, so the above limitations or exclusions may not *
// * apply to you.  IBM shall not be liable for any damages you suffer  *
// * as a result of using, modifying or distributing the sample program *
// * or its derivatives.                                                *
// *                                                                    *
// * Each copy of any portion of this sample program or any derivative  *
// * work,  must include a the above copyright notice and disclaimer of *
// * warranty.                                                          *
// *                                                                    *
// **********************************************************************
//
//
// This code sample demonstrates a very simple client/server application.
// input are entered at the server window and client window will display
// the input text.
// This example illustrates the uses of DatagramPacket class to send a packet of
// data from the server to the client through a DatagramSocket.
// DatagramPacket can be created with this constructor
// DatagramPacket(byte msgBytes[], int size, InetAddress,int port)
// This program should be run on the local machine.


import java.net.*;
class ClientServer {
  public static DatagramPacket dp;
  public static DatagramSocket ds;
  public static int bsize = 256;
  public static byte msgBytes[] = new byte[bsize];
  public static int port_server = 5021;
  public static int port_client = 5025;


  public static void ServerApp()  {
    int size=0;
    while (true) {
      try {
      int ch = System.in.read();    // reads char from standard input
      switch (ch) {
        case '\r':
          break;
        case '\n':
           dp = new DatagramPacket(msgBytes,size,
                                  InetAddress.getLocalHost(),port_client);
           ds.send(dp);
           size=0;
           break;

        case -1:
           System.out.println("Server finishes..");
           return;
        default:
           msgBytes[size++] = (byte) ch;

        }
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
  }

  public static void ClientApp() {
    while(true) {
    try {
     DatagramPacket p = new DatagramPacket(msgBytes, msgBytes.length);
     ds.receive(p);
     System.out.println("receive  " + p.getLength() + " bytes.  They are :  ");
     String msg=new String(p.getData());
     System.out.println(msg);
        } catch (Exception e) {
                e.printStackTrace();
        }
    }
  }

  public static void main(String args[]) throws Exception {
    System.out.println("�������� Ŭ���̾�Ʈ�� ĳ����");
    System.out.println("for server - java wsj.socket.datagram.ClientServer server");
    System.out.println("for client - java wsj.socket.datagram.ClientServer");
    if(args.length == 1) {
      ds = new DatagramSocket(port_server);
      ServerApp();
    } else {
      ds = new DatagramSocket(port_client);
      ClientApp();
    }
  }
}





