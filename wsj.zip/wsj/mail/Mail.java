package wsj.mail;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.mail.Transport;

public class Mail {

  String to = "foo@bar.com";
  String from = "bar@foo.com";
  String subject = "�׽�Ʈ ���� �Դϴ�";
  String content = "�׽�Ʈ ���� �Դϴ�";

  public Mail() {
  }

  public void sendMail(){
    Properties prop = System.getProperties();
    prop.put("mail.smtp.host", "mail.foo.bar");

    Session session = Session.getDefaultInstance(prop);
    MimeMessage mm = new MimeMessage(session);

    try {
      // setHeader�� ���� ����� �����Ѵ�.
      mm.setHeader("From", from);
      mm.setHeader("To", to);
      mm.setSubject(subject, "euc-kr");
      mm.setText(content, "euc-kr");
      Transport.send(mm);
    }
    catch (Exception e){
      System.out.println ("Message Sending Error");
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    Mail mail = new Mail();
    mail.sendMail();
  }
}