package wsj.mail;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;


public class SendMail
{
  String from,to,subject,content;
  String smtpHost="mail.kcnet5.com";


  public SendMail(String from,String to,String subject,String content)throws Exception
  {
    Properties properties = System.getProperties();
    properties.put("mail.smtp.host", smtpHost);

    Session session=Session.getInstance(properties,null);
    MimeMessage message=new MimeMessage(session);

    this.from=from;
    this.to=to;
    this.subject=subject;
    this.content=content;

    message.setFrom(new InternetAddress(from));
    message.setRecipient(Message.RecipientType.TO,new InternetAddress(to));
    message.setSubject(subject);
    message.setContent(content,"text/plain; charset=euc-kr");

    Transport.send(message);

    message.saveChanges();
    message.writeTo(System.out);

  }



  public static void main(String args[])throws Exception
  {
    SendMail sm=new SendMail("indeday@hanmail.net","indeday@orgio.net","Hi~","�ѱ��� ������ �����");
  }
}