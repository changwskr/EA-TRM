package wsj.netmessanger;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;

public class NetMessanagerClone  {

  String ip_datafile_name = "C:\\ePlaton\\jars\\NetSend.IP";

  public NetMessanagerClone() {
  }

  public void run(String message)
  {
    int linecnt = 0;
    int total_line=50;
    String line = message;

    try {

      BufferedReader ipin = new BufferedReader( new FileReader(ip_datafile_name) );
      linecnt++;System.out.println(" ");
      int i = 1;

      for( String ipline; (ipline = ipin.readLine()) != null ; ){
        if( ipline.equals("")){
          continue;
        }
        if( ipline.substring(0,1).equals("#") ){
          linecnt++;System.out.println("    " + ipline );
          continue;
        }
        Thread.currentThread().sleep(100);
        if( NetMessanagerClone(ipline,line) ){
          linecnt++;System.out.println("    *" + ipline + " | " + line + " (SUCC)-"+i);
        }
        else{
          linecnt++;System.out.println("    *" + ipline + " | " + line + " (FAIL)-"+i);
        }
        i++;
      }

      System.out.println("END>\n");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public boolean NetMessanagerClone(String ip,String msg){
    try{
      Runtime runtime = Runtime.getRuntime();
      runtime.exec("net send " + ip +  "  " + msg);
    }
    catch(IOException ex){
      return false;
    }
    return true;
  }
  public static String GetHostName()
  {
    InetAddress Address=null ;
    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }

  public static String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }

  public static String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }

  public static void main(String[] args) {
    try {
      new NetMessanagerClone().run("messge");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }


}
