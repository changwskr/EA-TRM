package wsj.tunelling.ejb;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.transfer.*;
import com.chb.coses.cosesFramework.transfer.*;
import com.chb.coses.cosesFramework.business.delegate.*;
import javax.rmi.PortableRemoteObject;
import com.chb.coses.user.business.facade.IUserManagement;
import com.chb.coses.user.business.facade.UserManagementSBHome;
import com.chb.coses.user.business.facade.UserManagementSB;
import wsj.tunelling.packet.*;


public class TCPCallEJB {
  private static TCPCallEJB instance;
  public static CosesBizDelegateHome bizHome = null;
  public static CosesBizDelegate remote = null;
  public int isUse = 0;

  private Context ctx;
  public String url = "t3://localhost:7001";
  public String initial_context = "weblogic.jndi.WLInitialContextFactory";
  public CosesCommonDTO cosescommon;
  public CosesEvent event;
  public IEvent result ;

  public static synchronized TCPCallEJB getInstance(String ip,String port)
  {
    if (instance == null) {
      try{
        instance = new TCPCallEJB(ip,port);
      }
      catch(Exception igex)
      {
        System.out.println(igex);
        return null;
      }
    }
    return instance;
  }

  public TCPCallEJB(String ip,String port) throws Exception
  {
    try{
      this.url = "t3://"+ip+":"+port;
      System.out.println("TCPCallEJB URL : "+ url );
      this.ctx = this.getInitialContext();
      this.event = new CosesEvent();
    }catch(Exception ex){
      ex.printStackTrace();
      throw ex;
    }
  }

  public Context getInitialContext()throws NamingException
  {
    if (ctx == null) {
      try {
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,initial_context);
        p.put(Context.PROVIDER_URL, this.url);
        ctx = new InitialContext(p);
      } catch (NamingException ne) {
        System.out.println(ne);
        throw ne;
      }
    }
    return ctx;
  }

  public Object getHome() throws NamingException
  {
    if(this.bizHome==null) {
      Object obj = ctx.lookup(CosesBizDelegateHome.class.getName());
      bizHome = (CosesBizDelegateHome)PortableRemoteObject.narrow(
          obj,CosesBizDelegateHome.class
          );
      return bizHome;
    }
    else
      return this.bizHome;
  }

  public boolean getHome2()
  {
    try{
      Object obj = ctx.lookup(CosesBizDelegateHome.class.getName());
      bizHome = (CosesBizDelegateHome)PortableRemoteObject.narrow( obj,CosesBizDelegateHome.class );
      return true;
    }
    catch(Exception ex){
      return false;
    }
  }

  public Object getRemote() throws Exception
  {
    if(this.remote==null) {
      this.remote = this.bizHome.create();
      return this.remote ;
    }
    else
      return this.remote;
  }

  public synchronized Object callEJB2(String callBizAction,CosesCommonDTO cdto,Object obj)
      throws IOException
  {
    BoundArea inbound = new BoundArea(BoundArea.CMD_INITIAL);
    try {
      this.isUse = 1;
      System.out.println(("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
      inbound.setParameter(obj);
      inbound.cdto = cdto;

      Object tmp = inbound.getParameter();
      if(!(tmp instanceof IDTO) ) {
        inbound.errcode = "EI0033";
        inbound.errmsg = "EI0033 error crack";
        this.isUse = 0;
        System.out.println(("EJBCall (1):"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return inbound;
      }

      inbound.setBizAction(callBizAction);
      inbound.setCommand(BoundArea.CALL_BATCH_EJB);
      inbound.errcode = "IZZ000";

      // ������� ���� ����
      this.cosescommon = inbound.cdto;
      this.cosescommon.setTimeZone("GMT+09:00");
      this.cosescommon.setFxRateCount(1);

      this.event.setCommon(this.cosescommon);
      this.event.setAction(inbound.getBizAction());
      this.event.setRequest((IDTO)inbound.getParameter());

      this.bizHome = (CosesBizDelegateHome) this.getHome();
      this.remote = (CosesBizDelegate) this.getRemote();

      this.result = this.remote.execute(event);
      if( result.getResponse() == null )
      {
        inbound.errcode = "EI0034";
        inbound.setParameter((Object)"void");
        inbound.errmsg = "EI0034 error crack";
        this.isUse = 0;
        System.out.println(("EJBCall (2):"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return (Object)inbound;
      }
      else{
        inbound.errcode = "IZZ000";
        inbound.setParameter((Object)result.getResponse());
        this.isUse = 0;
        System.out.println(("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return (Object)inbound;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        System.out.println("BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        System.out.println(e);
        inbound.errcode = "EI0035";
        inbound.errmsg = "Call Coses Exception-BizActionException";
      }
      else if(e instanceof RemoteException)
      {
        //System.out.println("RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        System.out.println(e);
        inbound.errcode = "EI0036";
        inbound.errmsg = "Call Coses Exception-RemoteException";
      }
      else if(e instanceof CosesAppException)
      {
        System.out.println(e);
        inbound.errcode = "EI0037";
        inbound.errmsg = "Call Coses Exception-CosesAppException";
      }
      else if(e instanceof BizDelegateException)
      {
        //System.out.println(getClass()+"------------BizDelegaeException");
        System.out.println(e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = "*";
        String exceptionMsg = "*";
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        inbound.errcode = "EC" + exceptionCode;
        inbound.errmsg= exceptionMsg;
        //System.out.println("---------------------BizDelegaeException:["+inbound.errcode+"]");
      }
      else
      {
        System.out.println(e);
        inbound.errcode = "EI0038";
        inbound.errmsg= "Call Coses Exception-Other";
      }

      inbound.setParameter((Object)"void");
      this.isUse = 0;
      System.out.println(("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
      return (Object)inbound;
    }
  }

  public synchronized boolean checkisUsingBizDelegate () {
    if( this.isUse == 1 )
      return true;
    else
      return false;
  }


  public synchronized BoundArea Login(BoundArea inbound) throws IOException
  {
    String bankCode = inbound.cdto.getBankCode();
    String tellerId = inbound.tellerId;
    String passwd = inbound.passwd;

    UserManagementSBHome home = null;
    UserManagementSB remote = null;

    try {
      Object obj = this.ctx.lookup(UserManagementSBHome.class.getName());
      home = (UserManagementSBHome)PortableRemoteObject.narrow(obj,UserManagementSBHome.class );
      if(home!=null){
        System.out.println("[TCPCallEJB : home --> "+home.toString()+"]");
      }else{
        System.out.println("[TCPCallEJB : home --> home is null...]");
        inbound.errcode ="EI0039";
        return inbound;
      }

      remote = home.create();
      if(remote!=null){
        System.out.println("[TCPCallEJB : remote --> "+remote.toString()+"]");
      }else{
        System.out.println("[TCPCallEJB : home --> remote is null...]");
        inbound.errcode ="EI0040";
        return inbound;
      }
    } catch(NamingException e) {
      System.out.println(e);
      inbound.errcode ="EI0041";
      System.out.println("fail.ejbLookup.UserManagementSBHome");
      return inbound;
    } catch(CreateException e) {
      System.out.println("fail.create.UserManagementSB");
      System.out.println(e);
      inbound.errcode ="EI0042";
      return inbound;
    } catch(RemoteException e) {
      System.out.println("fail.callEjb");
      System.out.println(e);
      inbound.errcode ="EI0043";
      return inbound;
    } catch(Exception e) {
      System.out.println("fail.callEjb");
      System.out.println(e);
      inbound.errcode ="EI0044";
      return inbound;
    }

    CosesCommonDTO cosescommon = null;
    try {
      cosescommon = remote.login(bankCode,tellerId,passwd);
      System.out.println("[TCPCallEJB : cosescommon --> "+ cosescommon.toString()+"]");
    } catch(RemoteException e) {
      System.out.println("fail.callEjb");
      e.printStackTrace();
      System.out.println(e);
      inbound.errcode ="EI0045";
      return inbound;
    } catch(Exception e) {
      System.out.println("fail.callEjb."+e.getMessage());
      e.printStackTrace();
      System.out.println(e);
      inbound.errcode ="EI0046";
      return inbound;
    }

    inbound.errcode = "IZZ000";
    this.cosescommon = cosescommon;
    inbound.cdto = cosescommon;
    return inbound;
  }

}
