package wsj.tunelling.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.sql.*;



public class IOBoundHead implements Serializable{
  public String	sDTimer="*****";		   /* Host ó�� Max Time �ܸ��¾�*/
  public String	sDSysDate="********";  /* Real ���� �ܸ��¾� */
  public String sDInTime="********";   /* �ܸ��¾� */

  public String	sBBrnSeq="*****************";		/* ������ ���� Seq ��ȣ */
  public String	sBSysDate="********";	    /* Real ���� */
  public String	sBInTime="********";		/* Host Input Time */
  public String	sBOutTime="********";	    /* Host Output Time */
  public String sBErrCode="******";

  public String sMsg="**************************************************";

  public String sDLoginOffSet="*";
  public String sDSijaeOpenOffset="*";
  public String sBEodOffset="*";
  public String sDSijaeClosOffset="*";
  public String sDMode="*";

  public int head_len = 66 + this.sMsg.length();


  public IOBoundHead() {

  }

  public void initial(){
    this.sDTimer="*****";		   /* Host ó�� Max Time �ܸ��¾�*/
    this.sDSysDate="********";  /* Real ���� �ܸ��¾� */
    this.sDInTime="********";   /* �ܸ��¾� */

    this.sBBrnSeq="*****************";		/* ������ ���� Seq ��ȣ */
    this.sBSysDate="********";	    /* Real ���� */
    this.sBInTime="********";		/* Host Input Time */
    this.sBOutTime="********";	    /* Host Output Time */
    this.sBErrCode="******";

    this.sMsg="**************************************************";

    this.sDLoginOffSet="*";
    this.sDSijaeOpenOffset="*";
    this.sBEodOffset="*";
    this.sDSijaeClosOffset="*";
    this.sDMode="*";

  }


  /*
  conn retail/samtron

  DROP SEQUENCE SQ_COSIFHT_HOSTSEQ
  ;
  CREATE SEQUENCE SQ_COSIFHT_HOSTSEQ
  INCREMENT BY 1
  START WITH   1
  MAXVALUE     9999999
  CYCLE
  ORDER
  ;
  grant select on SQ_COSIFHT_HOSTSEQ to eplaton;

  conn eplaton/eplaton
  create synonym SQ_COSIFHT_HOSTSEQ for retail.SQ_COSIFHT_HOSTSEQ;
  */


  /*
  public String GetTxSeq() throws IOException{
    String tx_seq=null;
    try{
      tx_seq = ComUtil.GetSysDate()+ComUtil.GetSysTime();
      if( tx_seq.length() != 17 ){
        IOException ex = new IOException("IOBoundHead.GetTxSeq Exception");
        JLO.getInstance().eprintf(10,ex);
        throw ex;
      }
    }
    catch(Exception ex){
      throw new IOException("TJBLprocess ����:"+ex.getMessage());
    }
    return tx_seq;
  }
  */

  public String toString(char ch){
    return( sDTimer + ch +
            sDSysDate + ch +
            sDInTime + ch +
            sBBrnSeq + ch +
            sBSysDate + ch +
            sBInTime + ch +
            sBOutTime + ch +
            sBErrCode + ch +
            sMsg + ch +
            this.sDLoginOffSet+ ch +
            this.sDSijaeOpenOffset+ ch +
            this.sBEodOffset+ ch +
            this.sDSijaeClosOffset+ ch +
            this.sDMode
            );
  }

  public String toString(){
    return( sDTimer  +
            sDSysDate  +
            sDInTime  +
            sBBrnSeq  +
            sBSysDate  +
            sBInTime  +
            sBOutTime  +
            sBErrCode  +
            sMsg +
            this.sDLoginOffSet +
            this.sDSijaeOpenOffset +
            this.sBEodOffset +
            this.sDSijaeClosOffset +
            this.sDMode
            );
  }


  public synchronized boolean setBBrnSeq(){
    try{
      System.out.println("setBBrnSeq() �������� ä������");
      this.sBBrnSeq=this.GetTxSeq();
      if( this.sBBrnSeq == null ){
        System.out.println("setBBrnSeq() �������� ä���� NULL �߻�");
        return false;
      }
      System.out.println("setBBrnSeq() �������� ä������:["+this.sBBrnSeq+"]");
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println("setBBrnSeq ���� ���ܰ� �߻��߽��ϴ�");
      return false;
    }
    return true;
  }

  public void setBSysDate(){
    this.sBSysDate = ComUtil.GetSysDate();
  }

  public void setBInTime(){
    this.sBInTime = ComUtil.GetSysTime().substring(0,8) ;
  }

  public void setBOutTime(){
    this.sBOutTime = ComUtil.GetSysTime().substring(0,8) ;
  }

  public void setBErrCode(String errcode,IOBoundArea out){
    this.sBErrCode = errcode;
    out.iohead.sBErrCode = errcode;
  }

  public void setBErrCode(String errcode){
    this.sBErrCode = errcode;
  }

  public void setMsg(String msg){
    if( msg.length()== IOBoundProtoType.sMsg_LEN ){
      this.sMsg = msg;
    }
    else{
      String tmp = ComUtil.PSpaceToStr(msg,IOBoundProtoType.sMsg_LEN);
      this.sMsg = tmp;
      //System.out.println("["+tmp+"]"+tmp.length());
    }
  }

  public void setMsg(String msg,IOBoundArea out){
    if( msg.length()== IOBoundProtoType.sMsg_LEN ){
      this.sMsg = msg;
    }
    else{
      String tmp = ComUtil.PSpaceToStr(msg,IOBoundProtoType.sMsg_LEN);
      this.sMsg = tmp;
      out.iohead.setMsg(this.sMsg);
      //System.out.println("["+tmp+"]"+tmp.length());
    }
  }

  public IOBoundHead getIOBoundHead(){
    return this;
  }
}