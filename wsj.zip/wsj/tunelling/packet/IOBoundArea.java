package wsj.tunelling.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import java.io.Serializable;

public class IOBoundArea implements Serializable,Cloneable {
  public String sLength="*****";
  public IOBoundHead iohead;
  public IOBoundCDTO cdto; //165����Ʈ (�ѹ��ڴ�1����Ʈ���)
  public IOBoundData iodata;

  /////////////////////////////////////////////////////////
  // IOBoundArea ��������
  /////////////////////////////////////////////////////////
  private String packetinfo;
  public IOBoundArea() throws IOException,NotBoundException{
    this.iohead = new IOBoundHead();
    this.cdto = new IOBoundCDTO();
    this.iodata = new IOBoundData();
  }
  public void initial(){
    this.sLength = "*****";
    this.iohead.initial();
  }
  public IOBoundArea(String packetinfo) throws IOException,NotBoundException{
    this.packetinfo = packetinfo;
    this.iohead = new IOBoundHead();
    this.cdto = new IOBoundCDTO();
    this.iodata = new IOBoundData();
    this.setInParsing();
  }
  /////////////////////////////////////////////////////////////////////////////

  public String toString() {

    return (
        this.sLength +
        //���������
        this.iohead.toString() +
        //CDTO�������
        this.toStringCdto() +
        //������Ÿ����
        this.iodata.sBoundData );
  }

  public String toStringCdto(){
    return(
        this.cdto.getBankCode() +
        this.cdto.getBranchCode() +
        this.cdto.getGIPostBrCode() +
        this.cdto.getChannelType() +
        this.cdto.getUserId() +
        this.cdto.getTerminalId() +
        this.cdto.getTerminalType() +
        this.cdto.getEventNo() +
        this.cdto.getNationCode() +
        this.cdto.getRegionCode() +
        this.cdto.getTimeZone() +
        this.cdto.getFxRateSeq() +
        this.cdto.getXmlSeq() +
        this.cdto.getReqName() +
        this.cdto.getTrxDate() +
        this.cdto.getBizDate() +
        this.cdto.getTrxInTime() +
        this.cdto.getTrxOutTime() +
        this.cdto.getTrxNumber() +
        this.cdto.getVoucherNum() +
        this.cdto.getRefNum() +
        this.cdto.getCifNum() +
        this.cdto.getBaseCurrency() +
        this.cdto.getAtmSeqNo()
        );
  }

  /////////////////////////////////////////////////////////////////////////////
  public String toString(char ch) {
    return (
        //������Ÿ���� ����
            this.sLength + ch +
            //���������
            this.iohead.toString(ch) + ch +
            //CDTO�������
            this.toStringCdto(ch) + ch +
            //������Ÿ����
            this.iodata.sBoundData );
  }

  public String toStringCdto(char ch){
    return(
        this.cdto.getBankCode() + ch +
        this.cdto.getBranchCode() + ch +
        this.cdto.getGIPostBrCode() + ch +
        this.cdto.getChannelType() + ch +
        this.cdto.getUserId() + ch +
        this.cdto.getTerminalId() + ch +
        this.cdto.getTerminalType() + ch +
        this.cdto.getEventNo() + ch +
        this.cdto.getNationCode() + ch +
        this.cdto.getRegionCode() + ch +
        this.cdto.getTimeZone() + ch +
        this.cdto.getFxRateSeq() + ch +
        this.cdto.getXmlSeq() + ch +
        this.cdto.getReqName() + ch +
        this.cdto.getTrxDate() + ch +
        this.cdto.getBizDate() + ch +
        this.cdto.getTrxInTime() + ch +
        this.cdto.getTrxOutTime() + ch +
        this.cdto.getTrxNumber() + ch +
        this.cdto.getVoucherNum() + ch +
        this.cdto.getRefNum() + ch +
        this.cdto.getCifNum() + ch +
        this.cdto.getBaseCurrency() + ch +
        this.cdto.getAtmSeqNo()
        );
  }
  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }

  public void setCDTO(){
    /*
    IOBoundCDTO commonDTO = new IOBoundCDTO();
    commonDTO.setBankCode("bank01");
    commonDTO.setBranchCode("branch01");
    */
  }

  public boolean setInParsing(){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = this.sLength
              = packetinfo.substring(curp,IOBoundProtoType.sLength_LEN);
      //JLO.getInstance().printf(1,"LEN(5):["+dumytmp+"]"+"-"+IOBoundProtoType.sLength_LEN+"-"+IOBoundProtoType.sDTimer_LEN);

      curp += IOBoundProtoType.sLength_LEN;
      dumytmp = this.iohead.sDTimer
              = packetinfo.substring(curp,(curp+IOBoundProtoType.sDTimer_LEN));

      curp += IOBoundProtoType.sDTimer_LEN;
      dumytmp = this.iohead.sDSysDate
              = packetinfo.substring(curp,(curp+IOBoundProtoType.sDSysDate_LEN));
      //JLO.getInstance().printf(1,"DSysdate(8):["+dumytmp+"]");

      curp += IOBoundProtoType.sDSysDate_LEN;
      dumytmp = this.iohead.sDInTime
              = packetinfo.substring(curp,(curp+IOBoundProtoType.sDInTime_LEN));
      //JLO.getInstance().printf(1,dumytmp);

      curp += IOBoundProtoType.sDInTime_LEN;
      dumytmp=this.iohead.sBBrnSeq
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBBrnSeq_LEN));
      //JLO.getInstance().printf(1,"sBBrnSeq:["+dumytmp+"]");

      curp += IOBoundProtoType.sBBrnSeq_LEN;
      dumytmp=this.iohead.sBSysDate
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBSysDate_LEN));
      //JLO.getInstance().printf(1,"sBSysDate:["+dumytmp+"]");

      curp += IOBoundProtoType.sBSysDate_LEN;
      dumytmp=this.iohead.sBInTime
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBInTime_LEN));
      //JLO.getInstance().printf(1,"sBInTime:["+dumytmp+"]");

      curp += IOBoundProtoType.sBInTime_LEN;
      dumytmp=this.iohead.sBOutTime
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBOutTime_LEN));
      //JLO.getInstance().printf(1,"sBOutTime:["+dumytmp+"]");

      curp += IOBoundProtoType.sBOutTime_LEN;
      dumytmp=this.iohead.sBErrCode
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBErrCode_LEN));
      //JLO.getInstance().printf(1,"sBErrCode:["+dumytmp+"]");

      curp += IOBoundProtoType.sBErrCode_LEN;
      dumytmp=this.iohead.sMsg
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sMsg_LEN));
      //JLO.getInstance().printf(1,"sMsg:["+dumytmp+"]");

      //-------------------------------------------------------
      // 1��24�� �߰���
      //-------------------------------------------------------
      curp += IOBoundProtoType.sMsg_LEN;
      dumytmp=this.iohead.sDLoginOffSet
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDLoginOffSet_LEN));
      //JLO.getInstance().printf(1,"LoginOffSet:["+dumytmp+"]");

      curp += IOBoundProtoType.sDLoginOffSet_LEN;
      dumytmp=this.iohead.sDSijaeOpenOffset
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDSijaeOpenOffset_LEN));
      //JLO.getInstance().printf(1,"SijaeOpenOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sDSijaeOpenOffset_LEN;
      dumytmp=this.iohead.sBEodOffset
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBEodOffset_LEN));
      //JLO.getInstance().printf(1,"sBEodOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sBEodOffset_LEN;
      dumytmp=this.iohead.sDSijaeClosOffset
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDSijaeClosOffset_LEN));
      //JLO.getInstance().printf(1,"DSijaeClosOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sDSijaeClosOffset_LEN;
      dumytmp=this.iohead.sDMode
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDMode_LEN));
      //JLO.getInstance().printf(1,"DMode:["+dumytmp+"]");

      //-------------------------------------------------------
      // CDTO
      curp += IOBoundProtoType.sDMode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.bankCode_LEN));
      this.cdto.setBankCode(dumytmp);
      //JLO.getInstance().printf(1,"bankcode:["+dumytmp+"]");

      curp += IOBoundProtoType.bankCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.branchCode_LEN));
      this.cdto.setBranchCode(dumytmp);
      //JLO.getInstance().printf(1,"branchcode:["+dumytmp+"]");

      curp += IOBoundProtoType.branchCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.gIPostBrCode_LEN));
      this.cdto.setGIPostBrCode(dumytmp);
      //JLO.getInstance().printf(1,"glpostcode:["+dumytmp+"]");

      curp += IOBoundProtoType.gIPostBrCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.channelType_LEN));
      this.cdto.setChannelType(dumytmp);
      //JLO.getInstance().printf(1,"channeltype:["+dumytmp+"]");

      curp += IOBoundProtoType.channelType_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.userId_LEN));
      this.cdto.setUserId(dumytmp);
      //JLO.getInstance().printf(1,"userid:["+dumytmp+"]");

      curp += IOBoundProtoType.userId_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.terminalId_LEN));
      this.cdto.setTerminalId(dumytmp);
      //JLO.getInstance().printf(1,"terminalid:["+dumytmp+"]");

      curp += IOBoundProtoType.terminalId_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.terminalType_LEN));
      this.cdto.setTerminalType(dumytmp);
      //JLO.getInstance().printf(1,"terminaltype:["+dumytmp+"]");

      curp += IOBoundProtoType.terminalType_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.eventNo_LEN));
      this.cdto.setEventNo(dumytmp);
      //JLO.getInstance().printf(1,"trxcode:["+dumytmp+"]");

      curp += IOBoundProtoType.eventNo_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.nationCode_LEN));
      this.cdto.setNationCode(dumytmp);
      //JLO.getInstance().printf(1,"nationcode:["+dumytmp+"]");

      curp += IOBoundProtoType.nationCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.regionCode_LEN));
      this.cdto.setRegionCode(dumytmp);
      //JLO.getInstance().printf(1,"regioncode:["+dumytmp+"]");

      curp += IOBoundProtoType.regionCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.timeZone_LEN));
      this.cdto.setTimeZone(dumytmp);
      //JLO.getInstance().printf(1,"timezone:["+dumytmp+"]");

      curp += IOBoundProtoType.timeZone_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.fxRateSeq_LEN));
      this.cdto.setFxRateSeq(dumytmp);
      //JLO.getInstance().printf(1,"fxrate:["+dumytmp+"]");

      curp += IOBoundProtoType.fxRateSeq_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.xmlSeq_LEN));
      this.cdto.setXmlSeq(dumytmp);
      //JLO.getInstance().printf(1,"xmlseq:["+dumytmp+"]");

      curp += IOBoundProtoType.xmlSeq_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.reqName_LEN));
      this.cdto.setReqName(dumytmp);
      //JLO.getInstance().printf(1,"reqname:["+dumytmp+"]");

      curp += IOBoundProtoType.reqName_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxDate_LEN));
      this.cdto.setTrxDate(dumytmp);
      //JLO.getInstance().printf(1,"trxdate:["+dumytmp+"]");

      curp += IOBoundProtoType.trxDate_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.bizDate_LEN));
      this.cdto.setBizDate(dumytmp);
      //JLO.getInstance().printf(1,"bizdate:["+dumytmp+"]");

      curp += IOBoundProtoType.bizDate_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxInTime_LEN));
      this.cdto.setTrxInTime(dumytmp);
      //JLO.getInstance().printf(1,"trxintime:["+dumytmp+"]");

      curp += IOBoundProtoType.trxInTime_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxOutTime_LEN));
      this.cdto.setTrxOutTime(dumytmp);
      //JLO.getInstance().printf(1,"trxouttime:["+dumytmp+"]");

      curp += IOBoundProtoType.trxOutTime_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxNumber_LEN));
      this.cdto.setTrxNumber(dumytmp);
      //JLO.getInstance().printf(1,"trxnumber:["+dumytmp+"]");


      curp += IOBoundProtoType.trxNumber_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.voucherNum_LEN));
      this.cdto.setVoucherNum(dumytmp);
      //JLO.getInstance().printf(1,"vouchernum:["+dumytmp+"]");

      curp += IOBoundProtoType.voucherNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.refNum_LEN));
      this.cdto.setRefNum(dumytmp);
      //JLO.getInstance().printf(1,"refnum:["+dumytmp+"]");

      curp += IOBoundProtoType.refNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.cifNum_LEN));
      this.cdto.setCifNum(dumytmp);
      //JLO.getInstance().printf(1,"cifnum:["+dumytmp+"]");

      curp += IOBoundProtoType.cifNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.baseCurrency_LEN));
      this.cdto.setBaseCurrency(dumytmp);
      //JLO.getInstance().printf(1,"basecurrency:["+dumytmp+"]");

      curp += IOBoundProtoType.baseCurrency_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.atmSeqNo_LEN));
      this.cdto.setAtmSeqNo(dumytmp);
      //JLO.getInstance().printf(1,"atmseqNo:["+dumytmp+"]");

      //iodata
      curp += IOBoundProtoType.atmSeqNo_LEN;
      dumytmp=this.iodata.sBoundData
             =packetinfo.substring(curp,(curp+ComUtil.Str2Int(this.sLength)));
      //JLO.getInstance().printf(1,"ioboundata:["+dumytmp+"]");
    }
    catch( Exception ex ){
      ex.printStackTrace();
      this.iohead.setBErrCode("EI0001");
      this.iohead.setMsg("Application Exception[IOBoundArea.setInParsing]");
      return false;
    }
    return true;
  }

  public void setLength(){
    this.sLength = this.iodata.sLength;
  }
  public static void main(String args[]) {
    try{
      IOBoundArea in = new IOBoundArea(
//"000050032002100709192789*************************************************************************************************************WXX0000001******************12345************************************************************************************************************************AAAAA");
    "00005TIMsys date1010101120021007101010111SYS DATE1010111110101111ERRCODMSG----------*****----------------------------------MSG*****************************************************************************************************************************************************************RETCAAAAA");
/*
      in.sLength = "lengt";
      in.iohead.sDTimer="TIM";
      in.iohead.sDSysDate="sys date";
      in.iohead.sDInTime="10101011";
      in.iohead.sBBrnSeq="20021007101010111";
      in.iohead.sBSysDate="SYS DATE";
      in.iohead.sBInTime="10101111";
      in.iohead.sBOutTime="10101111";
      in.iohead.sBErrCode="ERRCOD";
      in.iohead.sMsg="MSG--------------------------------------------MSG";

      in.cdto.setBaseCurrency("RETC");
      in.iodata.sBoundData = "AAAAA";
*/
      in.setInParsing();

      //JLO.getInstance().printf(1,"in.iohead.sBBrnSeq:"+in.iohead.sBBrnSeq );
      //JLO.getInstance().printf(1,in.iohead.sDTimer);
      //JLO.getInstance().printf(1,in.iodata.sBoundData);
      //JLO.getInstance().printf(1,in.sLength );
      //JLO.getInstance().printf(1,in.cdto.getUserId());
      //JLO.getInstance().printf(1,in.toString());


      //-----------------------------------------------
      in.sLength="Lengt";

      // IOHEAD
      in.iohead.sDTimer="Timer";		   /* Host ó�� Max Time �ܸ��¾�*/
      in.iohead.sDSysDate="Sys-date";  /* Real ���� �ܸ��¾� */
      in.iohead.sDInTime="Sys-time";   /* �ܸ��¾� */
      in.iohead.sBBrnSeq="*****************";		/* ������ ���� Seq ��ȣ */
      in.iohead.sBSysDate="Sys-date";	    /* Real ���� */
      in.iohead.sBInTime="Sysitime";		/* Host Input Time */
      in.iohead.sBOutTime="Sysotime";	    /* Host Output Time */
      in.iohead.sBErrCode="Errcod";
      in.iohead.sMsg="**************************************************";

      in.cdto.bankCode ="Bc";
      in.cdto.branchCode = "Brcd";
      in.cdto.gIPostBrCode = "Gpbc";
      in.cdto.channelType = "Ct";
      in.cdto.userId = "User    Id";
      in.cdto.terminalId = "Terminal  ID";
      in.cdto.terminalType = "Tmityp";
      in.cdto.eventNo = "Eventn";
      in.cdto.nationCode = "Nc";
      in.cdto.regionCode = "Rc";
      in.cdto.timeZone = "Tz";
      in.cdto.fxRateSeq = "Fr";
      in.cdto.xmlSeq = "Xl";
      in.cdto.reqName = "Requstname";
      in.cdto.trxDate = "T***d**e";
      in.cdto.bizDate = "B***d**e";
      in.cdto.trxInTime = "T**i***e";
      in.cdto.trxOutTime = "T*o****e";
      in.cdto.trxNumber = "TrxNumber*******";
      in.cdto.voucherNum = "VoucherNum******";
      in.cdto.refNum = "RefNum**********";
      in.cdto.cifNum = "CifNum**********";
      in.cdto.baseCurrency = "Rtd";

      in.iodata.sBoundData =  "qqqqqqqqqqqqqqqqqqq";

    }
    catch(Exception ex){
      System.exit(0);
    }
  }

  public static void getPacketInfo(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = packetinfo.substring(curp,IOBoundProtoType.sLength_LEN);
      JLO.getInstance().print(1,"LEN(5):["+dumytmp+"]"+"-"+IOBoundProtoType.sLength_LEN+"-"+IOBoundProtoType.sDTimer_LEN);

      curp += IOBoundProtoType.sLength_LEN;
      dumytmp = packetinfo.substring(curp,(curp+IOBoundProtoType.sDTimer_LEN));

      curp += IOBoundProtoType.sDTimer_LEN;
      dumytmp = packetinfo.substring(curp,(curp+IOBoundProtoType.sDSysDate_LEN));
      JLO.getInstance().print(1,"DSysdate(8):["+dumytmp+"]");

      curp += IOBoundProtoType.sDSysDate_LEN;
      dumytmp = packetinfo.substring(curp,(curp+IOBoundProtoType.sDInTime_LEN));
      JLO.getInstance().print(1,dumytmp);

      curp += IOBoundProtoType.sDInTime_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBBrnSeq_LEN));
      JLO.getInstance().print(1,"sBBrnSeq:["+dumytmp+"]");

      curp += IOBoundProtoType.sBBrnSeq_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBSysDate_LEN));
      JLO.getInstance().print(1,"sBSysDate:["+dumytmp+"]");

      curp += IOBoundProtoType.sBSysDate_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBInTime_LEN));
      JLO.getInstance().print(1,"sBInTime:["+dumytmp+"]");

      curp += IOBoundProtoType.sBInTime_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBOutTime_LEN));
      JLO.getInstance().print(1,"sBOutTime:["+dumytmp+"]");

      curp += IOBoundProtoType.sBOutTime_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBErrCode_LEN));
      JLO.getInstance().print(1,"sBErrCode:["+dumytmp+"]");

      curp += IOBoundProtoType.sBErrCode_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sMsg_LEN));
      JLO.getInstance().print(1,"sMsg:["+dumytmp+"]");

      //-------------------------------------------------------
      // 1��24�� �߰���
      //-------------------------------------------------------
      curp += IOBoundProtoType.sMsg_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDLoginOffSet_LEN));
      JLO.getInstance().print(1,"sDLoginOffSet:["+dumytmp+"]");

      curp += IOBoundProtoType.sDLoginOffSet_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDSijaeOpenOffset_LEN));
      JLO.getInstance().print(1,"sDSijaeOpenOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sDSijaeOpenOffset_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sBEodOffset_LEN));
      JLO.getInstance().print(1,"sBEodOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sBEodOffset_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDSijaeClosOffset_LEN));
      JLO.getInstance().print(1,"sDSijaeClosOffset:["+dumytmp+"]");

      curp += IOBoundProtoType.sDSijaeClosOffset_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+IOBoundProtoType.sDMode_LEN));
      JLO.getInstance().print(1,"sDMode:["+dumytmp+"]");

      //-------------------------------------------------------
      // CDTO
      curp += IOBoundProtoType.sDMode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.bankCode_LEN));
      JLO.getInstance().print(1,"bankcode:["+dumytmp+"]");

      curp += IOBoundProtoType.bankCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.branchCode_LEN));
      JLO.getInstance().print(1,"branchcode:["+dumytmp+"]");

      curp += IOBoundProtoType.branchCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.gIPostBrCode_LEN));
      JLO.getInstance().print(1,"glpostcode:["+dumytmp+"]");

      curp += IOBoundProtoType.gIPostBrCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.channelType_LEN));
      JLO.getInstance().print(1,"channeltype:["+dumytmp+"]");

      curp += IOBoundProtoType.channelType_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.userId_LEN));
      JLO.getInstance().print(1,"userid:["+dumytmp+"]");

      curp += IOBoundProtoType.userId_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.terminalId_LEN));
      JLO.getInstance().print(1,"terminalid:["+dumytmp+"]");

      curp += IOBoundProtoType.terminalId_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.terminalType_LEN));
      JLO.getInstance().print(1,"terminaltype:["+dumytmp+"]");

      curp += IOBoundProtoType.terminalType_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.eventNo_LEN));
      JLO.getInstance().print(1,"trxcode:["+dumytmp+"]");

      curp += IOBoundProtoType.eventNo_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.nationCode_LEN));
      JLO.getInstance().print(1,"nationcode:["+dumytmp+"]");

      curp += IOBoundProtoType.nationCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.regionCode_LEN));
      JLO.getInstance().print(1,"regioncode:["+dumytmp+"]");

      curp += IOBoundProtoType.regionCode_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.timeZone_LEN));
      JLO.getInstance().print(1,"timezone:["+dumytmp+"]");

      curp += IOBoundProtoType.timeZone_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.fxRateSeq_LEN));
      JLO.getInstance().print(1,"fxrate:["+dumytmp+"]");

      curp += IOBoundProtoType.fxRateSeq_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.xmlSeq_LEN));
      JLO.getInstance().print(1,"xmlseq:["+dumytmp+"]");

      curp += IOBoundProtoType.xmlSeq_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.reqName_LEN));
      JLO.getInstance().print(1,"reqname:["+dumytmp+"]");

      curp += IOBoundProtoType.reqName_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxDate_LEN));
      JLO.getInstance().print(1,"trxdate:["+dumytmp+"]");

      curp += IOBoundProtoType.trxDate_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.bizDate_LEN));
      JLO.getInstance().print(1,"bizdate:["+dumytmp+"]");

      curp += IOBoundProtoType.bizDate_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxInTime_LEN));
      JLO.getInstance().print(1,"trxintime:["+dumytmp+"]");

      curp += IOBoundProtoType.trxInTime_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxOutTime_LEN));
      JLO.getInstance().print(1,"trxouttime:["+dumytmp+"]");

      curp += IOBoundProtoType.trxOutTime_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.trxNumber_LEN));
      JLO.getInstance().print(1,"trxnumber:["+dumytmp+"]");


      curp += IOBoundProtoType.trxNumber_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.voucherNum_LEN));
      JLO.getInstance().print(1,"vouchernum:["+dumytmp+"]");

      curp += IOBoundProtoType.voucherNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.refNum_LEN));
      JLO.getInstance().print(1,"refnum:["+dumytmp+"]");

      curp += IOBoundProtoType.refNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.cifNum_LEN));
      JLO.getInstance().print(1,"cifnum:["+dumytmp+"]");

      curp += IOBoundProtoType.cifNum_LEN;
      dumytmp=packetinfo.substring(curp,(curp+IOBoundProtoType.baseCurrency_LEN));
      JLO.getInstance().print(1,"basecurrency:["+dumytmp+"]");

      //iodata
      curp += IOBoundProtoType.baseCurrency_LEN;
      dumytmp
             =packetinfo.substring(curp,(curp+ComUtil.Str2Int(packetinfo.substring(curp,IOBoundProtoType.sLength_LEN))));
      JLO.getInstance().print(1,"ioboundata:["+dumytmp+"]");
    }
    catch( Exception ex ){
    }
  }

  public static synchronized boolean printLog(IOBoundArea in,char type) {
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      JEN jen = new JEN();
      // ����ð��� �����Ѵ�.
      in.iohead.setBOutTime();

      LOGFILENAME = jen.BIZLOGFILENAME + ComUtil.GetHostName() + "." +
                    Thread.currentThread().getName() + "." + in.cdto.getUserId() + "." +
                    "log" + "." +
                    ComUtil.GetSysDate();

      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      if( type == 'o' ){
        ps.println("-----------------------------------------------------");
      }

      ps.println(in.toString('^') );
      ps.flush();
      ps.close();
      fos.close();

    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("STF_SPcommonLog() ���� Exception");
        return false;
    }
    return true;
  }

  public IOBoundArea getIOBoundArea(){
    this.iohead = this.iohead.getIOBoundHead();
    this.cdto = this.cdto.getIOBoundCDTO();
    return this;
  }
}