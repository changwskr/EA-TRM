package wsj.tunelling.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class IOBoundProtoType {

    public static int INHEADLEN = 66 + 5;
    public static int CDTOLEN = 164;
    public static int BASELEN;
    public static int TRCLASS_POC=5;

    ///////////////////////////////////////////////////////////////////
    // IN/OUTLEN
    ///////////////////////////////////////////////////////////////////
    public static int	sLength_LEN = 5;

    ///////////////////////////////////////////////////////////////////
    // IN/OUTHEAD
    ///////////////////////////////////////////////////////////////////
    public static int sDTimer_LEN = 5;
    public static int sDSysDate_LEN = 8;
    public static int sDInTime_LEN = 8;
    public static int sBBrnSeq_LEN = 17;
    public static int sBSysDate_LEN = 8;
    public static int sBInTime_LEN = 8;
    public static int sBOutTime_LEN = 8;
    public static int sBErrCode_LEN = 6;
    public static int sMsg_LEN=50;

    public static int  sDLoginOffSet_LEN = "*".length();
    public static int  sDSijaeOpenOffset_LEN = "*".length();
    public static int  sBEodOffset_LEN = "*".length();
    public static int  sDSijaeClosOffset_LEN = "*".length();
    public static int  sDMode_LEN = "*".length();

    ///////////////////////////////////////////////////////////////////
    // CDTO
    ///////////////////////////////////////////////////////////////////
    public static int bankCode_LEN = 2;
    public static int branchCode_LEN = 4;
    public static int gIPostBrCode_LEN = 4;
    public static int channelType_LEN = 2;
    public static int userId_LEN = 10;
    public static int terminalId_LEN = 12;
    public static int terminalType_LEN = 6;
    public static int eventNo_LEN = 5;
    public static int nationCode_LEN = 2;
    public static int regionCode_LEN = 2;
    public static int timeZone_LEN = 2;
    public static int fxRateSeq_LEN = 2;
    public static int xmlSeq_LEN = 2;
    public static int reqName_LEN = 10;
    public static int trxDate_LEN = 8;
    public static int bizDate_LEN = 8;
    public static int trxInTime_LEN = 8;
    public static int trxOutTime_LEN = 8;
    public static int trxNumber_LEN = 16;
    public static int voucherNum_LEN = 16;
    public static int refNum_LEN = 16;
    public static int cifNum_LEN = 16;
    public static int baseCurrency_LEN = 3;
    public static int atmSeqNo_LEN = 20;

    //////////////////////////////////////////////////////////////////////
    public IOBoundProtoType() {
      this.BASELEN = 5 + this.CDTOLEN + this.INHEADLEN ;
    }
}