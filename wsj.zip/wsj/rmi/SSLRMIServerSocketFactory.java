package wsj.rmi;

import java.net.Socket;
import java.rmi.server.RMIServerSocketFactory;
import java.net.ServerSocket;
import java.security.KeyStore;
import java.io.Serializable;
import java.io.IOException;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.KeyManagerFactory;
import java.io.FileInputStream;

public class SSLRMIServerSocketFactory implements RMIServerSocketFactory, Serializable{
  public SSLRMIServerSocketFactory() {
  }

  public ServerSocket createServerSocket(int port) throws IOException{

    SSLServerSocketFactory factory = null;
    char[] password = "thisistest".toCharArray();

    try {
      // SSLContext�� �����´�.
      SSLContext context = SSLContext.getInstance("SSL");

      // KeyManagerFactory�� �����´�.
      KeyManagerFactory keymanager = KeyManagerFactory.getInstance("SunX509");

      // ���Ϸ� ���� KeyStore�� �����´�.
      KeyStore ks = KeyStore.getInstance("JKS");
      ks.load(new FileInputStream("C:\\Documents and Settings\\Administrator\\.keystore"),password);

      // KeyManagerFactory�� �ʱ�ȭ �Ѵ�.
      keymanager.init(ks, "my_cert_pass".toCharArray());

      // SSLContext�� �ʱ�ȭ �Ѵ�.
      context.init(keymanager.getKeyManagers(), null, null);

      // SSLContext�κ��� SSLServerSocketFactory�� �����´�.
      factory = context.getServerSocketFactory();
    }
    catch (Exception e){
      e.printStackTrace();
    }

    // �ش� ��Ʈ�� ���Ͽ� ServerSocket�� ����� �����Ѵ�.
    return factory.createServerSocket(port);
  }
}