package wsj.rmi;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

// �̸� �����ص� interface�� implementation �Ѵ�.
public class SSLCalculatorImpl extends UnicastRemoteObject implements Calculator{

  public int add(int a, int b) throws RemoteException{
    return a+b;
  }

  public int multiply (int a, int b) throws RemoteException{
    return a*b;
  }

  public SSLCalculatorImpl() throws RemoteException{
    // SSL Socket Factory���� ������ �ʱ�ȭ �Ѵ�.
    super(0, new SSLRMIClientSocketFactory(), new SSLRMIServerSocketFactory());
  }
}
