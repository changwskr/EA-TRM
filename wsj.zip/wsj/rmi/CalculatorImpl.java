package wsj.rmi;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

// �̸� �����ص� interface�� implementation �Ѵ�.
public class CalculatorImpl extends UnicastRemoteObject implements Calculator{

  public int add(int a, int b) throws RemoteException{
    return a+b;
  }

  public int multiply (int a, int b) throws RemoteException{
    return a*b;
  }

  public CalculatorImpl() throws RemoteException{
    super();
  }

}