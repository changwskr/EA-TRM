package wsj.rmi;

import java.security.SecureRandom;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import java.rmi.server.RMIClientSocketFactory;
import java.io.Serializable;
import java.net.Socket;
import java.io.IOException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.SSLSocketFactory;

// X590TrustManager�� �����. ������ ��� Certificate�� �� �����ϴٰ� �ϱ�� �Ѵ�.
class MyTrustManager implements X509TrustManager {
  public X509Certificate[] getAcceptedIssuers(){
    return null;
  }
  public void checkClientTrusted(X509Certificate[] chain, String authType){
  }
  public void checkServerTrusted(X509Certificate[] chain, String authType) {
  }
}

public class SSLRMIClientSocketFactory implements RMIClientSocketFactory, Serializable {

  public SSLRMIClientSocketFactory() {
  }

  public Socket createSocket(String host, int port) throws IOException{
    SSLSocket socket = null;

    try {
      X509TrustManager tm = new MyTrustManager();

      // SSLContext�� �����Ѵ�. �̶� SSLv3 ���������� �̿��ϱ�� �Ѵ�.
      SSLContext context = SSLContext.getInstance("SSL");

      // TrustManager�� array�� �����Ѵ�.
      TrustManager[] tms = {
          tm};

      // context�� �ʱ�ȭ �Ѵ�.
      context.init(null, tms, new SecureRandom());

      SSLSocketFactory factory = context.getSocketFactory();
      socket = (SSLSocket)factory.createSocket(host, port);
    }
    catch (Exception e){
      e.printStackTrace();
    }

    return socket;
  }

}