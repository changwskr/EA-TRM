package wsj.net.url;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class URLinfo {

  public URLinfo() {
  }
  public static void main(String[] args) {
    URLinfo URLinfo1 = new URLinfo();
  }
}