package wsj.url;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;

public class URLuploader {
  final static int BUFFER_SIZE = 2048;
  URL url = null;
  public URLuploader(String urlString) throws IOException {
    try{
      url = new URL(urlString.replace('\\','/'));
    }
    catch(MalformedURLException ex){
      ex.printStackTrace();
      throw ex;
    }
    catch(IOException e){
      e.printStackTrace();
      System.err.println("io err : " + e.getMessage() );
      throw e;
    }
  }
  public void upload(String filename) throws IOException
  {
    //������ url�κ��� �Է½�Ʈ���� �д´�.
    BufferedInputStream in = null;
    BufferedOutputStream out = null;

    try{
      URLConnection connection = url.openConnection();
      connection.setDoOutput(true);

      in = new BufferedInputStream(new FileInputStream(filename),this.BUFFER_SIZE);
      out = new BufferedOutputStream(connection.getOutputStream(),this.BUFFER_SIZE);

      byte[] buffer = new byte[this.BUFFER_SIZE];
      int nRead = 0, nWrote = 0;

      System.out.println(filename + " ������ ���ε��ϰ� �ֽ��ϴ�");

      //�Է��� -1�϶����� ����ؼ� �о ���Ϸ� ����.
      while( (nRead=in.read(buffer,0,1024)) >= 0 ){
        out.write(buffer,0,nRead);
        nWrote += nRead;
        System.out.println("#"); //ī�����ϰ�� �޽���
      }
      System.out.println();
      System.out.println(filename + " ���Ͽ� " + nWrote + " ����Ʈ�� ����ϴ�");
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    finally{
      if( in != null )
        in.close();
      if( out != null ){
        out.flush();
        out.close();
      }
    }
  }

  public static void main(String[] args) throws IOException{
    if( args.length < 2 ){
      System.out.println("java wsj.url.URLuploader http://21.101.3.47:7001 filename ");
      System.exit(0);
    }
    new URLuploader(args[0]).upload(args[1]);
  }
}