package wsj.url;

/**
 * URLDownload.java
 * Copyright (c) 1998 Yoon Kyung Koo. All rights reserved.
 *
 * First release date 1998/10/01
 *
 * @version 1.0 1998/10/01
 * @author <A HREF="mailto:yoonforh@moon.daewoo.co.kr">Yoon Kyung Koo</A>
 */

import java.net.*;
import java.io.*;

class URLDownload {
        public static void main(String args[]) {
                if (args.length<1) {
                        System.out.println("Usage : java URLDownload URL");
                        System.out.println("Ex : java URLDownload http://moon.daewoo.co.kr/~yoonforh/new.gif");
                        //coses�ý��ۿ���
                        //C:\jws\WSJJDK14\test>java wsj.url.URLDownload http://21.101.3.47:7001/kk
                        System.exit(1);
                }
                try {
                        URL url  = new  URL(args[0]);  // create URL object from args[0]
                        String filename=url.getFile().substring(url.getFile().lastIndexOf('/')+1);
                        System.out.println("Port      : "+url.getPort());
                        System.out.println("Protocol  : "+url.getProtocol());
                        System.out.println("Host      : "+url.getHost());
                        System.out.println("File      : "+url.getFile());
                        System.out.println("Ref       : "+url.getRef());
                        System.out.println("File Name : "+filename);
                        // open input stream from given URL
                        BufferedInputStream in = new BufferedInputStream(url.openStream(), 1024);

                        BufferedOutputStream out =
                                new BufferedOutputStream(new FileOutputStream(filename));

                        byte buf[]=new byte[1024];
                        int nRead=0, nWrote=0;
                        System.out.println("Start to download "+filename+".");
                        // write to file until read return -1(have no data to read)
                        while ((nRead = in.read(buf, 0, 1024)) >= 0) {
                                out.write(buf, 0, nRead);
                                nWrote+=nRead;
                                System.out.print("#"); // mark that it's under copying
                        }
                        System.out.println();
                        System.out.println("Wrote "+nWrote+" bytes in "+filename+".");
                        in.close();  // close input stream
                        out.flush();  // flush output.
                        out.close();  // close output.
                } catch (MalformedURLException mue) {
                        System.out.println("MalformedURLException: " + mue.getMessage());
                } catch (IOException ie) {
                        System.out.println("IOException: " + ie.getMessage());
                }
        }
}