package wsj.url;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;

public class URLdownloader {
  final static int BUFFER_SIZE = 2048;
  URL url = null;
  public URLdownloader(String urlString) throws IOException {
    try{
      url = new URL(urlString.replace('\\','/'));
      //HTTP ����ó��
      Authenticator.setDefault(
          new Authenticator(){
            public PasswordAuthentication getPasswordAuthentication(){
              BufferedReader in = null;
              try{
                in = new BufferedReader(new InputStreamReader(System.in));
                System.out.println();
                System.out.println("-- Authentication Required --");
                System.out.println("user name : ");
                String user = in.readLine();
                System.out.println("password  : ");
                String pass = in.readLine();
                return new PasswordAuthentication(user,pass.toCharArray());
              }
              catch(IOException e){
                e.printStackTrace();
                System.err.println("io err : " + e.getMessage() );
              }
              finally{
                if( in != null ){
                  try{
                    in.close();
                  }
                  catch(IOException e){
                    e.printStackTrace();
                    System.err.println("io err : " + e.getMessage() );
                  }
                }
              }
              return null;
            }
          });
    }
    catch(MalformedURLException ex){
      ex.printStackTrace();
      throw ex;
    }
    catch(IOException e){
      e.printStackTrace();
      System.err.println("io err : " + e.getMessage() );
      throw e;
    }
  }
  public void download() throws IOException
  {
    boolean saveFile = true;
    String filename = url.getPath();

    filename = filename.substring(filename.lastIndexOf('/')+1 );
    saveFile = (filename.length() > 0);

    //������ url�κ��� �Է½�Ʈ���� �д´�.
    BufferedInputStream in = null;
    BufferedOutputStream out = null;

    try{
      URLConnection connection = url.openConnection();
      in = new BufferedInputStream(connection.getInputStream(),this.BUFFER_SIZE);

      //�����̸��� ���� ��� ���丮�ϰ�� ���Ϸ� ��¾ʰ� �ܼ����
      if( saveFile ){
        out = new BufferedOutputStream(new FileOutputStream(filename),this.BUFFER_SIZE);
      }
      else{
        System.out.println("��������޽��� --");
        out = new BufferedOutputStream(System.out,this.BUFFER_SIZE );
      }

      byte[] buffer = new byte[this.BUFFER_SIZE];
      int nRead = 0, nWrote = 0;
      if( saveFile ){
        System.out.println(filename + " ������ �ٿ�ε��ϰ� �ֽ��ϴ�");
      }

      //�Է��� -1�϶����� ����ؼ� �о ���Ϸ� ����.
      while( (nRead=in.read(buffer,0,1024)) >= 0 ){
        out.write(buffer,0,nRead);
        nWrote += nRead;
        if( saveFile )
          System.out.println("#"); //ī�����ϰ�� �޽���
      }

      if( saveFile ) {
        System.out.println();
        System.out.println(filename + " ���Ͽ� " + nWrote + " ����Ʈ�� ����ϴ�");
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    finally{
      if( in != null )
        in.close();
      if( out != null ){
        out.flush();
        out.close();
      }
    }
  }

  public static void main(String[] args) throws IOException{
    if( args.length == 0 ){
      System.out.println("java wsj.url.URLdownloader http://21.101.3.47:7001/kk ");
      System.exit(0);
    }
    new URLdownloader(args[0]).download();
  }
}