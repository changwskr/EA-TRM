package wsj.queue;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class QueueNode {
  int data;
  QueueNode next=null;

  public QueueNode(int n)
  {
    this.data = n;
  }
}
