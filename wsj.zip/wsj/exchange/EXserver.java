package wsj.exchange;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class EXserver extends Thread{
  private ServerSocket ssk;
  private int port;
  private Socket sk;
  public static String path;

  public EXserver(String path,int port) {
    this.path=path;
    this.port=port;
    try{
        System.out.println("Ŭ���̾�Ʈ ���� ����� ");
        ssk=new ServerSocket(this.port);
    }
    catch(IOException ex){
        ex.printStackTrace();
        return;
    }
    this.start();
  }

  public void run(){
    while(true){
      try{
        sk=ssk.accept();
        System.out.println("*--------------------------------------------------*");
        System.out.println("* ����Ŭ���̾�Ʈ ����");
        System.out.println("*--------------------------------------------------*");
        System.out.println("* ����/�ð� : " + GetSysdate.GetSysDate() + " : " + GetSystime.GetSysTime().substring(0,6) );
        System.out.println("* ���� Ŭ���̾�Ʈ IP/PORT : " + sk.getLocalAddress() + " : " + sk.getLocalPort() );
        System.out.println("*--------------------------------------------------*");
        new EXEthr(sk,path);
      }catch(Exception ioe1){
        ioe1.printStackTrace();
        break;
      }
    }
    try{
        this.ssk.close();
    }
    catch(IOException ex){
        ex.printStackTrace();
        return;
    }
 }

  public static void main(String[] args) {
    System.out.println("********************************************************");
    System.out.println("* USAGE : ���������н� ��Ʈ                                *");
    System.out.println("********************************************************");
    System.out.println("* ���� ���� ���� :"+GetSystime.GetSysTime());
    System.out.println("********************************************************");
    EXserver exs = new EXserver(args[0],String2Number.Str2Int(args[1]));
    //EXserver exs = new EXserver("C:\\MYTEST\\INETCHB\\src\\JTM\\jtest\\recvfile",35530);
  }
}


