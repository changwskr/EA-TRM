package wsj.exchange.bizness;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.text.*;
import java.util.*;

public class PROC_EX01 {
  private static PROC_EX01 instance;
  private String packetinfo;
  private String recvdata;
  private String executedata;
  private String senddata;

  public static synchronized PROC_EX01 getInstance() {
    if (instance == null) {
      try{
        instance = new PROC_EX01();
        }catch(Exception igex){}
    }
    return instance;
  }

  public void doStart(String context) {
    this.recvdata = context;
    return;
  }

  public synchronized void execute() {
    this.executedata = this.recvdata;
    IOBoundExc10000CDTO cdto = new IOBoundExc10000CDTO();
    cdto.setIOBoundExc10000CDTOParsing(this.recvdata);
    return;
  }

  public void doEnd() {
    this.senddata = executedata;
    return;
  }

  public String getSenddata(){
    return this.senddata;
  }

}


