package wsj.exchange.bizness;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;

public class IOBoundExc10001CDTO {
  public String  key;
  public String  sysdate;
  public String  displayseq;
  public String  CurrencyCd;
  public String  TransferRate;
  public String  TransferImportRate;
  public String  TransferBaseRate;
  public String  TenonCost;
  public String  CashExportRate;
  public String  CashImportRate;
  public String  TCtransfer;
  public String  EExchangeRate;
  public String  CoinTransferExportRate;
  public String  CoinTransferImportRate;
  public String  USAexchangeRate;
  public String  PostDate;

  public static final int SysDate_LEN=8;
  public static final int DisplaySeq_LEN=2;

  public static final int CurrencyCd_LEN=5;
  public static final int TransferRate_LEN=10;
  public static final int TransferImportRate_LEN=10;
  public static final int TransferBaseRate_LEN=10;
  public static final int TenonCost_LEN=10;
  public static final int CashExportRate_LEN=10;
  public static final int CashImportRate_LEN=10;
  public static final int TCtransfer_LEN=10;
  public static final int EExchangeRate_LEN=10;
  public static final int CoinTransferExportRate_LEN=10;
  public static final int CoinTransferImportRate_LEN=10;
  public static final int USAexchangeRate_LEN=11;
  public static final int PostDate_LEN=5;

  public IOBoundExc10001CDTO() {
    this.key="not";
    StringFormatter.SpaceToStr(this.sysdate ,this.SysDate_LEN);
    StringFormatter.SpaceToStr(this.displayseq ,this.DisplaySeq_LEN);
    StringFormatter.SpaceToStr(this.CurrencyCd,this.CurrencyCd_LEN );
    StringFormatter.SpaceToStr(this.TransferRate,this.TransferRate_LEN );
    StringFormatter.SpaceToStr(this.TransferImportRate,this.TransferImportRate_LEN );
    StringFormatter.SpaceToStr(this.TransferBaseRate,this.TransferBaseRate_LEN );
    StringFormatter.SpaceToStr(this.TenonCost,this.TenonCost_LEN );
    StringFormatter.SpaceToStr(this.CashExportRate,this.CashExportRate_LEN );
    StringFormatter.SpaceToStr(this.CashImportRate,this.CashImportRate_LEN );
    StringFormatter.SpaceToStr(this.TCtransfer,this.TCtransfer_LEN );
    StringFormatter.SpaceToStr(this.EExchangeRate,this.EExchangeRate_LEN );
    StringFormatter.SpaceToStr(this.CoinTransferExportRate,this.CoinTransferExportRate_LEN );
    StringFormatter.SpaceToStr(this.CoinTransferImportRate,this.CoinTransferImportRate_LEN );
    StringFormatter.SpaceToStr(this.USAexchangeRate,this.USAexchangeRate_LEN );
    StringFormatter.SpaceToStr(this.PostDate,this.PostDate_LEN );
  }

  public String toString(){
    return this.sysdate
        + "," + this.displayseq
        + "," + this.CurrencyCd
        +","+ this.TransferRate
        +","+ this.TransferImportRate
        +","+ this.TransferBaseRate
        +","+ this.TenonCost
        +","+ this.CashExportRate
        +","+ this.CashImportRate
        +","+ this.TCtransfer
        +","+ this.EExchangeRate
        +","+ this.CoinTransferExportRate
        +","+ this.CoinTransferImportRate
        +","+ this.USAexchangeRate
        +","+ this.PostDate;
  }
  public void toReformat(){
    this.TransferRate = this.format(TransferRate,4);
    this.TransferImportRate = this.format(TransferImportRate,4);
    this.TransferBaseRate = this.format(TransferBaseRate,4);
    this.TenonCost = this.format(TenonCost,4);
    this.CashExportRate = this.format(CashExportRate,4);
    this.CashImportRate = this.format(CashImportRate,4);
    this.TCtransfer = this.format(TCtransfer,4);
    this.EExchangeRate = this.format(EExchangeRate,4);
    this.CoinTransferExportRate = this.format(CoinTransferExportRate,4);
    this.CoinTransferImportRate = this.format(CoinTransferImportRate,4);
    this.USAexchangeRate = this.format(USAexchangeRate,4);
  }

  public boolean setIOBoundExc10001CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {

      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = this.CurrencyCd
              = packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.CurrencyCd_LEN));
      System.out.println("currencycd:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.CurrencyCd_LEN;
      dumytmp = this.TransferRate
              = packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.TransferRate_LEN));
      System.out.println("TransferRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.TransferRate_LEN;
      dumytmp=this.TransferImportRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.TransferImportRate_LEN));
      System.out.println("TransferImportRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.TransferImportRate_LEN;
      dumytmp=this.TransferBaseRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.TransferBaseRate_LEN));
      System.out.println("TransferBaseRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.TransferBaseRate_LEN;
      dumytmp=this.TenonCost
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.TenonCost_LEN));
      System.out.println("TenonCost:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.TenonCost_LEN;
      dumytmp=this.CashExportRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.CashExportRate_LEN));
      System.out.println("CashExportRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.CashExportRate_LEN;
      dumytmp=this.CashImportRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.CashImportRate_LEN));
      System.out.println("CashImportRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.CashImportRate_LEN;
      dumytmp=this.TCtransfer
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.TCtransfer_LEN));
      System.out.println("TCtransfer:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.TCtransfer_LEN;
      dumytmp=this.EExchangeRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.EExchangeRate_LEN));
      System.out.println("EExchangeRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.EExchangeRate_LEN;
      dumytmp=this.CoinTransferExportRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.CoinTransferExportRate_LEN));
      System.out.println("CoinTransferExportRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.CoinTransferExportRate_LEN;
      dumytmp=this.CoinTransferImportRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.CoinTransferImportRate_LEN));
      System.out.println("CoinTransferImportRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.CoinTransferImportRate_LEN;
      dumytmp=this.USAexchangeRate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.USAexchangeRate_LEN));
      System.out.println("USAexchangeRate:["+dumytmp+"]");

      curp += IOBoundExc10001CDTO.USAexchangeRate_LEN;
      dumytmp=this.PostDate
             =packetinfo.substring(curp,(curp+IOBoundExc10001CDTO.PostDate_LEN));
      System.out.println("PostDate:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      System.out.println(ex);
      return false;
    }
    return true;
  }
  public String format(String str,int offset){
    StringBuffer tt = new StringBuffer();
    for( int i=0 ; i<str.length() ; i++)
    {
      tt.append(str.charAt(i) );
      if( i==offset ){
        tt.append('.');
      }
    }
    return tt.toString();
  }
}
