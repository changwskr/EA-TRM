package wsj.exchange.bizness;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;


public class IOBoundExc10000CDTO {
  public int exseqcnt=0;
  public static final int EX_PACK_LEN = 116 + 5;
  public static final int EX_PACK_CNT = 100;

  public String  SysDate;
  public String  DisplaySeq;
  public IOBoundExc10001CDTO Excd[] = new IOBoundExc10001CDTO[EX_PACK_CNT];

  public static final int SysDate_LEN=8;
  public static final int DisplaySeq_LEN=2;

  public IOBoundExc10000CDTO() {
    for( int i = 0 ; i< Excd.length ; i++ ){
      Excd[i] = new IOBoundExc10001CDTO();
    }
    StringFormatter.SpaceToStr(this.SysDate,this.SysDate_LEN );
    StringFormatter.SpaceToStr(this.DisplaySeq,this.DisplaySeq_LEN );
  }

  public String toString(){
    return StringFormatter.SpaceToStr(this.SysDate,this.SysDate_LEN )
        +","+ StringFormatter.SpaceToStr(this.DisplaySeq,this.DisplaySeq_LEN );
  }
  public boolean setIOBoundExc10000CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      int reallen = packetinfo.length() - 10;
      this.exseqcnt = (int) reallen / EX_PACK_LEN;
      System.out.println("readllen:"+reallen + " " +"exseqcnt :"+exseqcnt);

      /* ---------------------------------------------------------------------*
      curp = 0;
      dumytmp = this.SysDate
              = packetinfo.substring(curp,IOBoundExc10000CDTO.SysDate_LEN);
      System.out.println("SysDate:["+dumytmp+"]");

      curp += IOBoundExc10000CDTO.SysDate_LEN;
      dumytmp = this.DisplaySeq
              = packetinfo.substring(curp,(curp+IOBoundExc10000CDTO.DisplaySeq_LEN));
      System.out.println("ex seq:["+dumytmp+"]");

      String packdata = packetinfo.substring(curp+IOBoundExc10000CDTO.DisplaySeq_LEN);
      System.out.println("tt["+packdata+"]");
      ------------------------------------------------------------------------*/
      curp = 0;
      dumytmp = this.DisplaySeq
              = packetinfo.substring(curp,IOBoundExc10000CDTO.DisplaySeq_LEN);
      System.out.println("DisplaySeq:["+dumytmp+"]");

      curp += IOBoundExc10000CDTO.DisplaySeq_LEN;
      dumytmp = this.SysDate
              = packetinfo.substring(curp,(curp+IOBoundExc10000CDTO.SysDate_LEN));
      System.out.println("ex seq:["+dumytmp+"]");

      String packdata = packetinfo.substring(curp+IOBoundExc10000CDTO.SysDate_LEN);
      System.out.println("tt["+packdata+"]");

      String fname = "/home/cosif/atmppp/log/EX." + this.DisplaySeq + "." + GetSysdate.GetSysDate();
      if( FILEapi.FILEexist(fname) ){
        FILEapi.FILEdel(fname);
      }


	  curp=0;
      for( int i = 0; i < this.exseqcnt ; i++ ){
        dumytmp = packdata.substring(curp,(curp+this.EX_PACK_LEN));
        Excd[i].setIOBoundExc10001CDTOParsing(dumytmp);
		curp += this.EX_PACK_LEN;
        Excd[i].key="used";
        Excd[i].sysdate = this.SysDate;
        Excd[i].displayseq = this.DisplaySeq ;
        if( Excd[i].CurrencyCd.equals("00000")) break;
        Excd[i].toReformat();
        this.toFile("EX."+this.DisplaySeq,Excd[i].toString() );
      }
    }
    catch( Exception ex ){
      ex.printStackTrace();
      System.out.println(ex);
      return false;
    }
    return true;
  }

  public static boolean toFile(String fname,String contentToWrite) {
    boolean result=true;
    String LOGFILENAME = "/home/cosif/atmppp/log/"+fname+"."+ GetSysdate.GetSysDate();
    try {
      contentToWrite = contentToWrite + "\n";
      FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
      PrintStream ps = new PrintStream(fos);
      ps.print(contentToWrite);
      ps.close();
    }catch(Exception e){
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
      return false;
    }
    return true;
  }

}
