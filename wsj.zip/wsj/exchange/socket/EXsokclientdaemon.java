package wsj.exchange.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;


class EXsokclientdaemon extends Thread {
  Socket sok1;
  OutputStream os1;
  InputStream is1;
  String ip1="21.101.10.12";
  int port = 6001;

  Socket sok2;
  OutputStream os2;
  InputStream is2;
  String ip2="21.101.10.12";

  Socket sok3;
  OutputStream os3;
  InputStream is3;
  String ip3="21.101.10.12";

  public EXsokclientdaemon ()  {
    this.start();
  }

  public boolean opensession (Socket csocket,String IP,int port) {
    OutputStream cdos = null;
    InputStream cdis = null;
    String hostip = null;
    String hostname = null;

    try {
      String p1 = "9074####";
      int p2 = 32;
      String p3 = "TCP412  ";
      String p4 = "1234567890123456";
      String p5 = "OPEN";
      String p6 = "0000";

      hostip = IP;
      csocket = new Socket(hostip ,port);
      hostname = csocket.getInetAddress().getHostAddress();
      cdis = csocket.getInputStream();
      cdos = csocket.getOutputStream();
      /*
      SOCKETapi.write_byte(cdos,p1);
      SOCKETapi.write_data(cdos,p3+p4+p5+p6);
      */
      byte[] bytep1 = p1.getBytes();
      byte[] bytep2 = ByteUtil.int2byte(p2);
      byte[] bytep3 = (p3+p4+p5+p6).getBytes();
      byte[] sendbuff = new byte[bytep1.length+bytep2.length+bytep3.length] ;
      System.arraycopy(bytep1,0,sendbuff,0,bytep1.length);
      System.arraycopy(bytep2,0,sendbuff,0+bytep1.length,bytep2.length);
      System.arraycopy(bytep3,0,sendbuff,0+bytep1.length+bytep2.length,bytep3.length);
      System.out.println("-----byte len:"+sendbuff.length);
      SOCKETapi.write_byte(cdos,sendbuff);
      String tmp = SOCKETapi.jni_read_data3(cdis);
      System.out.println("����:["+tmp+"]");
    }
    catch(IOException ex){
      ex.printStackTrace();
      try{
        cdis.close();
        cdos.close();
        csocket.close();
      }
      catch(Exception ex2){
        ex2.printStackTrace();
      }
      return false;
    }
    try{
      cdis.close();
      cdos.close();
      csocket.close();
    }
    catch(Exception ex2){
      ex2.printStackTrace();
    }
    return true;
  }

  public static boolean opensession (String IP,int port) {
    Socket csocket = null;
    OutputStream cdos = null;
    InputStream cdis = null;
    String hostip = null;
    String hostname = null;

    try {
      String p1 = "9074####";
      int p2 = 32;
      String p3 = "TCP412  ";
      String p4 = "1234567890123456";
      String p5 = "OPEN";
      String p6 = "0000";

      hostip = IP;
      csocket = new Socket(hostip ,port);
      hostname = csocket.getInetAddress().getHostAddress();
      cdis = csocket.getInputStream();
      cdos = csocket.getOutputStream();

      byte[] bytep1 = p1.getBytes();
      byte[] bytep2 = ByteUtil.int2byte(p2);
      byte[] bytep3 = (p3+p4+p5+p6).getBytes();
      byte[] sendbuff = new byte[bytep1.length+bytep2.length+bytep3.length] ;
      System.arraycopy(bytep1,0,sendbuff,0,bytep1.length);
      System.arraycopy(bytep2,0,sendbuff,0+bytep1.length,bytep2.length);
      System.arraycopy(bytep3,0,sendbuff,0+bytep1.length+bytep2.length,bytep3.length);
      System.out.println("-----send byte len:"+sendbuff.length);
      SOCKETapi.write_byte(cdos,sendbuff);
      String tmp = SOCKETapi.jni_read_data3(cdis);
      System.out.println("-----����:["+tmp+"]");
    }
    catch(IOException ex){
      ex.printStackTrace();
      try{
        cdis.close();
        cdos.close();
        csocket.close();
      }
      catch(Exception ex2){
        ex2.printStackTrace();
      }
      return false;
    }
    return true;
  }


  public static boolean h1=false;
  //public static boolean h2=false;
  //public static boolean h3=false;

  public void run(){
    while(true){
      try{
        Thread.currentThread().sleep(30000);
        if( !h1 ){
          if( this.opensession(this.sok1,this.ip1,this.port) ){
            h1=true;
          }
        }
        System.out.println("*Open client ----- chking *");
        /*
        if( !h2 ){
          if( this.opensession(this.sok2,this.ip2,this.port) ){
            h2=true;
          }
        }
        if( !h3 ){
          if( this.opensession(this.sok1,this.ip3,this.port) ){
            h3=true;
          }
        }
        */
      }
      catch(Exception ex){
        ex.printStackTrace();
        break;
      }
    }
  }

}
//::~ endof EXsokclientdaemon
