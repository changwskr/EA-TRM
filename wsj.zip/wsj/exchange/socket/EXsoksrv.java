package wsj.exchange.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.number.Number2String;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;


public class EXsoksrv extends Thread {
  private Vector v_sok_fd_tbl = new Vector();
  private ServerSocket serverSocket;
  private Socket u_srv_sok;
  private int PORT;
  private int MAX_THR_CNT;
  private String svcname;
  public EXsokclientdaemon excd;
  public String targetPID;
  public String targetMHostIP;
  public int targetMHostPort;

  public EXsoksrv(int MAX_THR_CNT,int PORT,String targetPID,
                  String targetMHostIP,int targetMHostPort )
      throws IOException,NotBoundException
  {
    this.MAX_THR_CNT=MAX_THR_CNT;
    this.PORT = PORT;
    this.svcname = svcname;
    Thread.currentThread().setName("ATMM_TM");
    this.targetPID = targetPID;
    this.targetMHostIP = targetMHostIP;
    this.targetMHostPort = targetMHostPort;

    try{
      for( int ii=0 ; ii<MAX_THR_CNT ; ii++ ){
        if( ii <= 9 ){
          new EXsoksrvhandler(v_sok_fd_tbl,"ATMH_T0"+Number2String.Int2Str(ii),this);
        }
        else
          new EXsoksrvhandler(v_sok_fd_tbl,"ATMH_T"+Number2String.Int2Str(ii),this);
      }
      this.serverSocket = SOCKETapi.SERVERopen(this.PORT);
      new Thread(this,"ATMH_TM").start();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println(ex);
      System.out.println(ex);
      System.exit(0);
    }
  }

  public void run() {


    EXsokmanager exs = new EXsokmanager(targetPID,targetMHostIP,targetMHostPort);
    Thread thr = new Thread(exs);
    thr.start();

			//////////////////////////////////////////////
			for( ; ; ){
				try{
				if( !this.opensession() ){
					System.out.println("-SOKserv��������� �׾�����");
					Thread.currentThread().sleep(60000);
					continue;
				}
				else
					break;
				}
				catch(Exception ex){}
			}
			//////////////////////////////////////////////

    for( ; ; ){
      try{
        System.out.println("* OPEN ����� *");
        this.u_srv_sok = SOCKETapi.SOKaccept(this.serverSocket);
        v_sok_fd_tbl.add(this.u_srv_sok);
        synchronized (v_sok_fd_tbl) {
          v_sok_fd_tbl.notifyAll();
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
        System.out.println(ex);
        System.out.println(ex);
        return;
      }
    }
  }

  public boolean opensession () {
    Socket csocket = null;
    OutputStream cdos = null;
    InputStream cdis = null;
    String hostip = null;
    String hostname = null;

    try {
      String p1 = "9074####";
      int p2 = 32;
      String p3 = this.targetPID;
      String p4 = "1234567890123456";
      String p5 = "OPEN";
      String p6 = "0000";

      hostip = this.targetMHostIP;
      csocket = new Socket(hostip ,this.targetMHostPort);
      hostname = csocket.getInetAddress().getHostAddress();
      cdis = csocket.getInputStream();
      cdos = csocket.getOutputStream();

      byte[] bytep1 = p1.getBytes();
      byte[] bytep2 = ByteUtil.int2byte(p2);
      byte[] bytep3 = (p3+p4+p5+p6).getBytes();
      byte[] sendbuff = new byte[bytep1.length+bytep2.length+bytep3.length] ;
      System.arraycopy(bytep1,0,sendbuff,0,bytep1.length);
      System.arraycopy(bytep2,0,sendbuff,0+bytep1.length,bytep2.length);
      System.arraycopy(bytep3,0,sendbuff,0+bytep1.length+bytep2.length,bytep3.length);
      System.out.println("-----send byte len:"+sendbuff.length);
      SOCKETapi.write_byte(cdos,sendbuff);
      String tmp = SOCKETapi.jni_read_data3(cdis);
      System.out.println("-----����:["+tmp+"]");
    }
    catch(IOException ex){
      ex.printStackTrace();
      try{
        cdis.close();
        cdos.close();
        csocket.close();
      }
      catch(Exception ex2){
        ex2.printStackTrace();
      }
      return false;
    }
    try{
      cdis.close();
      cdos.close();
      csocket.close();
    }
    catch(Exception ex2){
      ex2.printStackTrace();
    }
    return true;
  }

  public static void main(String[] args) throws Exception {
    try {
        System.out.println("USAGE : Thr# ");
        System.out.println("          *-------------------------------------------------------*");
        System.out.println("          * ���� ���� ���� [EXsoksrv]                            *");
        System.out.println("          *-------------------------------------------------------*");
        System.out.println("          *  - svc stime: "+ GetSysdate.GetSysDate() + ":�� " + GetSystime.GetSysTime().substring(0,6) +":��" );
        System.out.println("          *-------------------------------------------------------*");
        new EXsoksrv(1,3623,"TCP412  ","21.101.10.12",6001);
        new EXsoksrv(1,3620,"TCP409  ","21.101.10.12",6001);
        new EXsoksrv(1,3622,"TCP413  ","21.101.10.12",6001);
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
}

class EXsokmanager extends Thread{
  public String targetPID;
  public String targetMHostIP;
  public int targetMHostPort;

  public EXsokmanager(String targetPID, String targetMHostIP, int targetMHostPort)
  {
    this.targetMHostIP = targetMHostIP;
    this.targetMHostPort = targetMHostPort ;
    this.targetPID = targetPID;
  }

  public void run() {
    while(true){
      try{
        Thread.currentThread().sleep(2000);
		/*
        if( !opensession() ){
          continue;
        }
		*/
        Thread.currentThread().sleep(60000);
      }
      catch(Exception ex){
        ex.printStackTrace();
        continue;
      }
    }
  }

  public boolean opensession () {
    Socket csocket = null;
    OutputStream cdos = null;
    InputStream cdis = null;
    String hostip = null;
    String hostname = null;

    try {
      String p1 = "9074####";
      int p2 = 32;
      String p3 = this.targetPID;
      String p4 = "1234567890123456";
      String p5 = "OPEN";
      String p6 = "0000";

      hostip = this.targetMHostIP;
      csocket = new Socket(hostip ,this.targetMHostPort);
      hostname = csocket.getInetAddress().getHostAddress();
      cdis = csocket.getInputStream();
      cdos = csocket.getOutputStream();

      byte[] bytep1 = p1.getBytes();
      byte[] bytep2 = ByteUtil.int2byte(p2);
      byte[] bytep3 = (p3+p4+p5+p6).getBytes();
      byte[] sendbuff = new byte[bytep1.length+bytep2.length+bytep3.length] ;
      System.arraycopy(bytep1,0,sendbuff,0,bytep1.length);
      System.arraycopy(bytep2,0,sendbuff,0+bytep1.length,bytep2.length);
      System.arraycopy(bytep3,0,sendbuff,0+bytep1.length+bytep2.length,bytep3.length);
      //System.out.println("-----send byte len:"+sendbuff.length);
      SOCKETapi.write_byte(cdos,sendbuff);
      String tmp = SOCKETapi.jni_read_data3(cdis);
      //System.out.println("-----����:["+tmp+"]");
    }
    catch(IOException ex){
      ex.printStackTrace();
      try{
        cdis.close();
        cdos.close();
        csocket.close();
      }
      catch(Exception ex2){
        ex2.printStackTrace();
      }
      return false;
    }
    try{
      cdis.close();
      cdos.close();
      csocket.close();
    }
    catch(Exception ex2){
      ex2.printStackTrace();
    }
    return true;
  }

}
