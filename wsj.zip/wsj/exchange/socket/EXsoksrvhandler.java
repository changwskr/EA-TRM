package wsj.exchange.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.number.Number2String;
import wsj.exchange.bizness.PROC_EX01;

public class EXsoksrvhandler extends Thread {
  private Vector v_sok_fd_tbl;
  public String name;
  public Thread CurThread;
  public boolean connectFlagOffSet=false;
  public static boolean connop=false;

  private Socket u_srv_sok=null;
  private InputStream is;
  private OutputStream os;
  private int PORT;
  private String mainhostip;

  private int atmserverlivecnt=0;
  public EXsoksrv exsrv;
  ////////////////////////////////////////////////////////////////////////////
  // �α��ΰŷ��ü� ������� BoundArea�� �����ϰ� �ִ´�.
  ////////////////////////////////////////////////////////////////////////////

  public EXsoksrvhandler(Vector v_sok_fd_tbl,String name,EXsoksrv exsrv) throws IOException {
    try{
      this.v_sok_fd_tbl = v_sok_fd_tbl;
      this.name = name;
      this.connectFlagOffSet=false;
      this.exsrv = exsrv;
      this.start();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println(ex);
      System.out.println(ex);
      throw new IOException();
    }
  }

  public Thread getCurrentThread() {
    return this.CurThread;
  }
  public void run() {
    Thread.currentThread().setName(this.name);
    this.CurThread=Thread.currentThread();
    for ( ; ; ) {
      connectFlagOffSet=false;
      synchronized (v_sok_fd_tbl) {
        while (v_sok_fd_tbl.isEmpty()) {
          try {
            v_sok_fd_tbl.wait();
          }
          catch (InterruptedException ex) {
          }
        }
        try{
          Object o = v_sok_fd_tbl.remove(0);
          this.u_srv_sok=(Socket)o;
          this.is = this.u_srv_sok.getInputStream();
          this.os = this.u_srv_sok.getOutputStream();
          this.mainhostip = this.u_srv_sok.getInetAddress().getHostAddress();
          System.out.println("::mainhostip-->"+this.mainhostip );
        }
        catch(Exception ex){
          this.opensession();
          System.out.println(ex);
          System.out.println(ex);
          try{
            this.is.close();
            this.os.close();
            this.u_srv_sok.close();
          }
          catch(Exception ex2){}
          continue;
        }
      }
      /////////////////////////////////////////////////////////////////
      // ����������� �����Ѵ�. ���� �ϳ��� Ŭ���̾�Ʈ connection�� ������Ų��
      /////////////////////////////////////////////////////////////////
      connectFlagOffSet=true;

      String senddata = null;
      String tmp = null;
      for( ; ; ){
        try{
          //tmp = SOCKETapi.read_data(this.is );
          tmp = SOCKETapi.jni_read_data2(this.is);
          System.out.println("\n\n\n");
          System.out.println("==���ŵ���Ÿ:["+tmp+"]");

          //////////////////////////////////////////////////////////////////
          // Ʈ����� ������ �����Ѵ�.
          //////////////////////////////////////////////////////////////////
          PROC_EX01.getInstance().doStart(tmp);
          PROC_EX01.getInstance().execute() ;
          PROC_EX01.getInstance().doEnd() ;
          //////////////////////////////////////////////////////////////////
          //SOCKETapi.write_data(this.os,senddata);
          //SOCKETapi.jni_write_data(this.os,senddata);
          //System.out.println("==�۽ŵ���Ÿ:["+senddata+"]");
        }
        catch(Exception ex3){
          connectFlagOffSet=false;
          ex3.printStackTrace();
          System.out.println(ex3);
          System.out.println(ex3);
          break;
        }
      }

      ////////////////////////////////////////////////////////////////////
      // connection count�� �ٿ��ش�.
      ////////////////////////////////////////////////////////////////////
      connectFlagOffSet=false;

      try{
        this.is.close();
        this.os.close();
        this.u_srv_sok.close();
      }
      catch(Exception ex4){
        ex4.printStackTrace();
        System.out.println(ex4);
      }
            //////////////////////////////////////////////
            for( ; ; ){
                try{
                if( !this.opensession() ){
                    System.out.println("-SOKETthreadhandler ��������� �׾�����");
                    Thread.currentThread().sleep(60000);
                    continue;
                }
                else
                    break;
                }
                catch(Exception ex){}
            }
          //////////////////////////////////////////////
    }
  }

  public String execute(String tmp){
    String senddata=tmp;

    try{
      //////////////////////////////////////////////////////////////////
      // Ʈ����� ������ �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      System.out.println("=========================================TCF ST");


    }
    catch(Exception ex){
      System.out.println(ex);
      System.out.println(ex);
    }
    return senddata;
  }

  public boolean opensession () {
    Socket csocket = null;
    OutputStream cdos = null;
    InputStream cdis = null;
    String hostip = null;
    String hostname = null;

    try {
      String p1 = "9074####";
      int p2 = 32;
      String p3 = this.exsrv.targetPID;
      String p4 = "1234567890123456";
      String p5 = "OPEN";
      String p6 = "0000";

      hostip = this.exsrv.targetMHostIP;
      csocket = new Socket(hostip ,this.exsrv.targetMHostPort);
      hostname = csocket.getInetAddress().getHostAddress();
      cdis = csocket.getInputStream();
      cdos = csocket.getOutputStream();

      byte[] bytep1 = p1.getBytes();
      byte[] bytep2 = ByteUtil.int2byte(p2);
      byte[] bytep3 = (p3+p4+p5+p6).getBytes();
      byte[] sendbuff = new byte[bytep1.length+bytep2.length+bytep3.length] ;
      System.arraycopy(bytep1,0,sendbuff,0,bytep1.length);
      System.arraycopy(bytep2,0,sendbuff,0+bytep1.length,bytep2.length);
      System.arraycopy(bytep3,0,sendbuff,0+bytep1.length+bytep2.length,bytep3.length);
      SOCKETapi.write_byte(cdos,sendbuff);
      String tmp = SOCKETapi.jni_read_data3(cdis);
      System.out.println("EXsoksrvhandler ���û���Ÿ޽���:"+sendbuff.length+":["+tmp+"]");
      //System.out.println("-----����:["+tmp+"]");
    }
    catch(IOException ex){
      ex.printStackTrace();
      try{
        cdis.close();
        cdos.close();
        csocket.close();
      }
      catch(Exception ex2){
        ex2.printStackTrace();
      }
      return false;
    }
    try{
      cdis.close();
      cdos.close();
      csocket.close();
    }
    catch(Exception ex2){
      ex2.printStackTrace();
    }
    return true;
  }

}

