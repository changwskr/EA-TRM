package wsj.exchange;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class THRmanager {
  Thread thr;
  String stime;
  String tname;
  String sdate;
  int    cnt;
  String dump;

  public THRmanager(Thread thr){
    this.thr=thr;
    this.sdate="20020719";
    this.stime="1010111";
    this.cnt=0;
    this.tname=thr.currentThread().getName();
  }
  public static void addThread(Hashtable thrmanage,String key) throws Exception{
    thrmanage.put(key,new THRmanager(Thread.currentThread()));
  }
  public static THRmanager getThrInfo(String tname,Hashtable thrmanage){
    return( (THRmanager)thrmanage.get(tname) );
  }
  public static boolean ifKilledReset(String mkey,Hashtable thrmanage,Thread thr) throws Exception {
    if( thrmanage.containsKey(mkey) && !(((THRmanager)thrmanage.get(mkey)).thr.isAlive()) ){
      ((THRmanager)thrmanage.get(mkey)).thr = thr;
      ((THRmanager)thrmanage.get(mkey)).sdate="22222222";
      ((THRmanager)thrmanage.get(mkey)).stime="22222222";
      ((THRmanager)thrmanage.get(mkey)).cnt++;
      return true;
    }
    return false;
  }
  public static boolean isExist(Hashtable thrmanage,String mkey) throws Exception {
    if( thrmanage.containsKey(mkey) )
      return true;
    else
      return false;
  }
  public static void removeThread(Hashtable thrmanage,String mkey) throws Exception {
    thrmanage.remove(mkey);
  }
  public static ArrayList getIsStopThr(Hashtable thrmanage) throws Exception {
    ArrayList vthr = new ArrayList();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      if ( !ti.thr.isAlive() ){
        vthr.add(ti);
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }
  public static ArrayList getIsAliveThr(Hashtable thrmanage) throws Exception {
    ArrayList vthr = new ArrayList();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      if ( ti.thr.isAlive() ){
        vthr.add(ti);
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }
  public static Vector getIsStopThrv(Hashtable thrmanage) throws Exception {
    Vector vthr = new Vector();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      if ( !ti.thr.isAlive() ){
        vthr.addElement(ti) ;
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }
  public static Vector getIsAliveThrv(Hashtable thrmanage) throws Exception {
    Vector vthr = new Vector();
    for(Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      if ( ti.thr.isAlive() ){
        vthr.addElement(ti) ;
        thrmanage.remove(thrname);
      }
    }
    return vthr;
  }
  public static void prntKilledthr(Vector vinfo) {
    for(int ii=0;ii<vinfo.size();ii++){
      THRmanager thr = (THRmanager)vinfo.elementAt(ii);
      System.out.println(thr.tname+"::"+thr.stime+"::"+thr.sdate);
    }
  }
  public static void prntThrInfo(Hashtable thrmanage){
    for( Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      System.out.println(ti.tname+"::"+ti.stime+"::"+ti.sdate);
    }
  }
  public static void removeKilledThr(Hashtable thrmanage){
    for( Enumeration eti=thrmanage.keys(); eti.hasMoreElements(); ){
      String thrname = eti.nextElement().toString();
      THRmanager ti = (THRmanager)thrmanage.get(thrname);
      if( !ti.thr.isAlive() )
          thrmanage.remove(thrname);
      //System.out.println(ti.tname+"::"+ti.stime+"::"+ti.sdate);
    }
  }

}

