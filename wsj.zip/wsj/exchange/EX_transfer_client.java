package wsj.exchange;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class EX_transfer_client
{
  private static EX_transfer_client instance;
  private Socket sk;
  private DataOutputStream dos;
  private FileInputStream fis;

  private File file;
  private byte[] b;
  private long size;
  private int div = 100;
  private int slice;
  private int rest;

  public static synchronized EX_transfer_client getInstance() throws Exception{
    if (instance == null) {
      try
      {
        instance = new EX_transfer_client();
      }
      catch(Exception igex)
      {
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public EX_transfer_client() {
  }

  public void execute (String server,int port,String fileName)
      throws IOException
  {
    try
    {
      //file base infomation set
      this.file=new File(fileName);
      this.size=file.length();
      this.rest=(int)(size%div);
      this.slice=(int)((size-rest)/div);
      //socket base information set
      this.sk=new Socket(server,port);
      this.dos=new DataOutputStream(this.sk.getOutputStream());
      this.fis=new FileInputStream(this.file);

      //execute
      this.run();

      //resource close
      this.fis.close();
      this.dos.close();
      this.sk.close();
    }
    catch(IOException ex){
      ex.printStackTrace();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
    finally{
      this.fis.close();
      this.dos.close();
      this.sk.close();
    }
  }

  public void run() throws IOException {
    long st=0;
    long et=0;
    try{
      this.dos.writeUTF(file.getName());
      this.dos.writeLong(size);
      this.dos.writeInt(div);

      st=System.currentTimeMillis();

      int i=0;
      for(i=0;i<div;i++){
        b=new byte[slice];
        fis.read(b);
        dos.write(b);
      }

      b=new byte[rest];
      this.fis.read(b);
      this.dos.write(b);
      this.dos.flush();


      et=System.currentTimeMillis();
      System.out.println((et-st)+" milliseconds");


      System.out.println("write complete");
    }catch(IOException ioe){
      ioe.printStackTrace();
      throw new IOException("EX_transfer_client ���ܹ߻�");
    }
  }

  public static void main(String[] args)throws Exception{
    System.out.println("********************************************************");
    System.out.println("* USAGE : �۽����ϸ� IP PORT                            *");
    System.out.println("********************************************************");
    System.out.println("* ���� ���� ���� :"+GetSystime.GetSysTime());
    System.out.println("********************************************************");
    EX_transfer_client.getInstance().execute(args[1],String2Number.Str2Int(args[2]),args[0]);
  }
}
