package wsj.exchange;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class EXclient extends Thread{

  private String fname;

  //fname:/home/mis/log/ȯ�����ϸ�.xxx
  public EXclient(String fname) throws IOException{
    this.fname = fname;
    this.start();
  }

  public void run ()
  {
    long ofilestat = 0;
    long nfilestat=0;

    // ȯ�������� ������ ���������� �����Ѵ�.
    ofilestat = FILEapi.FILElastmodified(this.fname);
    //property loading;
    //�ؽ�����

    while(true){
      try{
        Thread.currentThread().sleep(3000);
        nfilestat = FILEapi.FILElastmodified(this.fname); //1234567

        if( ofilestat != nfilestat ){
          System.out.println(
              "### ȯ�������� ���� : ~ "
                 + ofilestat
                     + "|" + nfilestat);
          try{
            //new EXfsnd("21.102.1.227",35530,this.fname).run();
            //new EXfsnd("21.102.1.227",35531,this.fname).run();
            //-- Ftp.FtpTransfer()
            //-- FILE.copy(adsfas,afdsadf)
            //- �ؽ� ������Ʈ
            //-- Property.������


          }
          catch(Exception ex){
            continue;
          }
          ofilestat = FILEapi.FILElastmodified(this.fname);
        }
        else
          System.out.println(
              "ȯ������ ���� ����: ~ "
                 + ofilestat
                     + "|" + nfilestat);

      }
      catch(Exception ex){
        ex.printStackTrace();
      }
    }
  }

  public static void main(String[] args)throws Exception{
    System.out.println("********************************************************");
    System.out.println("* USAGE : �۽����ϸ�                            *");
    System.out.println("********************************************************");
    System.out.println("* ���� ���� ���� :"+GetSystime.GetSysTime());
    System.out.println("********************************************************");
    //new EXclient(args[0]);
    new EXclient("C:\\MYTEST\\INETCHB\\src\\JTM\\jtest\\sendfile\\TCF.java");
  }
}

