package wsj.exchange;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.util.socket.SOCKETapi;
import wsj.util.bit.ByteUtil;
import wsj.util.string.String2Number;
import wsj.util.string.StringFormatter;
import wsj.util.number.Number2String;
import wsj.util.file.FILEapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class EXfsnd{

    private Socket sk;
    private DataOutputStream dos;
    private FileInputStream fis;

    private File file;
    private byte[] b;
    private long size;
    private int div;
    private int slice;
    private int rest;


    public EXfsnd(String server,int port,String fileName)throws IOException{
        int loop=0;
        while(true){
            loop++;
            if( loop > 10 ) {
                throw new IOException("Socket connect EX ::");
            }
            try{
                sk=new Socket(server,port);
                Thread.currentThread().sleep(500);
            }
            catch(InterruptedException ex){
                continue;
            }
            catch(IOException ex){
                continue;
            }
            break;
        }

        file=new File(fileName);
        size=file.length();
        div=100;
        rest=(int)(size%div);
        slice=(int)((size-rest)/div);
    }

    private String filetype;
    public EXfsnd(String server,int port,String fileName, String type)throws IOException{
        int loop=0;
        this.filetype = type;
        while(true){
            loop++;
            if( loop > 10 ) {
                throw new IOException("Socket connect EX ::");
            }
            try{
                sk=new Socket(server,port);
                Thread.currentThread().sleep(500);
            }
            catch(InterruptedException ex){
                continue;
            }
            catch(IOException ex){
                continue;
            }
            break;
        }

        file=new File(fileName);
        size=file.length();
        div=100;
        rest=(int)(size%div);
        slice=(int)((size-rest)/div);
    }

    public void run() throws IOException {
        long st=0;
        long et=0;
        try{
            dos=new DataOutputStream(sk.getOutputStream());
            fis=new FileInputStream(file);

            dos.writeUTF(file.getName());
            dos.writeLong(size);
            dos.writeInt(div);

            st=System.currentTimeMillis();

            int i=0;
            for(i=0;i<div;i++){
                b=new byte[slice];
                fis.read(b);
                dos.write(b);
                System.out.println(i+1+" : "+b.length);
            }
            b=new byte[rest];
            fis.read(b);
            dos.write(b);
            dos.flush();
            System.out.println(i+1+" : "+b.length);

            et=System.currentTimeMillis();
            System.out.println((et-st)+" milliseconds");

            fis.close();
            dos.close();
            sk.close();
            System.out.println("write complete");
        }catch(IOException ioe){
            ioe.printStackTrace();
            throw new IOException("EXfsnd ���ܹ߻�");
        }
    }

    public void execute() throws IOException {
        long st=0;
        long et=0;
        try{
            dos=new DataOutputStream(sk.getOutputStream());
            fis=new FileInputStream(file);

            dos.writeUTF(file.getName());
            dos.writeUTF(this.filetype);
            dos.writeLong(size);
            dos.writeInt(div);

            st=System.currentTimeMillis();

            int i=0;
            for(i=0;i<div;i++){
                b=new byte[slice];
                fis.read(b);
                dos.write(b);
                System.out.println(i+1+" : "+b.length);
            }
            b=new byte[rest];
            fis.read(b);
            dos.write(b);
            dos.flush();
            System.out.println(i+1+" : "+b.length);

            et=System.currentTimeMillis();
            System.out.println((et-st)+" milliseconds");

            fis.close();
            dos.close();
            sk.close();
            System.out.println("write complete");
        }catch(IOException ioe){
            ioe.printStackTrace();
            throw new IOException("EXfsnd ���ܹ߻�");
        }
    }

    public static void main(String[] args)throws Exception{
      System.out.println("********************************************************");
      System.out.println("* USAGE : �۽����ϸ� IP PORT                            *");
      System.out.println("********************************************************");
      System.out.println("* ���� ���� ���� :"+GetSystime.GetSysTime());
      System.out.println("********************************************************");
      new EXfsnd(args[1],String2Number.Str2Int(args[2]) ,args[0]).run();
    }
}