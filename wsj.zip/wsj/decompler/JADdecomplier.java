package wsj.decompler;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;
import wsj.util.date.CalendarUtil;
import wsj.util.file.*;

public class JADdecomplier {

  public boolean comparefileExt (java.io.File file, String fileExt)
  {
    String Ext = "";
    String fileName = "";
    fileName= file.getName();
    String comparefileExt = fileExt.toLowerCase();
    if ( fileName.length() >=3)
    {
      Ext = file.getName().substring(fileName.lastIndexOf(".") + 1 ,fileName.length()).toLowerCase();
      if (comparefileExt.equals("java"))
        comparefileExt = "java";
      if (comparefileExt.equals("class"))
        comparefileExt = "class";
    }
    return Ext.equals(comparefileExt);
  }

  /* Ȯ���ڰ� .class �ΰ��� ��ã�Ƽ� �������Ϸ� �Ѵ�
   * path�� ������ Ŭ�������� Ȯ���ϴ�.
  */

  public void execute(String path,String fileExt)
  {
    CalendarUtil calendarUtil  = new CalendarUtil();
    String fileDate ="";
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    Calendar calendar = Calendar.getInstance();
    DirectoryFinder dirFinder = new DirectoryFinder(path);

    while (dirFinder.hasNextDirectory()) {
      try{
        File dir = dirFinder.nextDirectory();
        String subpath = dir.getAbsolutePath();
        FileFinder fileFinder = new FileFinder(subpath, -1);
        while (fileFinder.hasNextFile()) {
          try{
            File file = fileFinder.nextFile();
            String filename = file.getAbsolutePath();
            calendar.setTime(new Date(file.lastModified())) ;
            fileDate = formatter.format(new Date(file.lastModified()));
            if ( file.isFile() && comparefileExt(file,fileExt) )
            {
              System.out.println("*--"+file.getName()+" "+file.getAbsolutePath()+" "+fileDate );
              System.out.println("--"+get_only_filename_except_ext(file.getName()));
              /*
              if( wsj.util.file.FILEapi.FILEexist("C:\\jws\\javaDecomplier\\class\\"+get_only_filename_except_ext(file.getName())+".java"))
              {
                wsj.util.file.FILEapi.FILEdel("C:\\jws\\javaDecomplier\\class\\"+get_only_filename_except_ext(file.getName())+".java");
              }
              */
              wsj.util.system.RuntimeCommand.runBuild("C:\\jws\\javaDecomplier\\jad -o -r -s .java " + file.getName() );

            }
          }
          catch(Exception ex){
            ex.printStackTrace();
          }
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
    }
    return ;
  }

  public String get_only_filename__except_ext_from_filepath(String path_filename)
  {
    return get_only_filename_except_ext(get_only_filename_from_filepath(path_filename));
  }

  public String get_only_filename_from_filepath(String path_filename)
  {
    String filename=null,directory=null;
    int lastSlash = path_filename.lastIndexOf('/');
    filename = path_filename.substring(lastSlash+1);
    directory = path_filename.substring(0, lastSlash);
    return filename;
  }

  public String get_only_filename_except_ext(String pfilename)
  {
    String filename=null,directory=null;
    int lastSlash = pfilename.lastIndexOf('.');
    //filename = pfilename.substring(lastSlash+1); - class
    //filename = pfilename.substring(lastSlash); - .class
    filename = pfilename.substring(0,lastSlash);
    return filename;
  }


  public static void main(String[] args) {
    JADdecomplier JADdecomplier1 = new JADdecomplier();
    JADdecomplier1.execute("C:\\jws\\javaDecomplier","class");
  }
}



class DirectoryFinder {
  private File root;
  private List dirs = new ArrayList();
  private FilenameFilter filter;
  private int currentIndex;

  public DirectoryFinder(String path) {
    this(path, null, 1);
  }

  public DirectoryFinder(String path, FilenameFilter filter) {
    this(path, filter, 1);
  }

  public DirectoryFinder(String path, int level) {
    this(path, null, level);
  }

  public DirectoryFinder(String path, FilenameFilter filter, int level) {
    this.root = new File(path);
    this.filter = filter;
    if (filter != null) {
      findDirectory(root, root.listFiles(filter), level);
    } else {
      findDirectory(root, root.listFiles(), level);
    }
  }

  private void findDirectory(File path, File[] list, int level) {
    if (list == null) {
      //System.out.println("'" + path.getAbsolutePath() + "' directory is not existed.");
      return;
    }
        --level;
        for (int i = 0; i < list.length; i++) {
          File file = list[i];
          if (file.isDirectory()) {
            dirs.add(file);
            if (level > 0) {
              findDirectory(file,
                            (filter == null)
                            ? file.listFiles() : file.listFiles(filter),
                            level);
            }
          }
        } // the end of for
  }

  public boolean hasNextDirectory() {
    if (currentIndex < dirs.size()) {
      return true;
    }
    return false;
  }

  public File nextDirectory() {
    File file = (File) dirs.get(currentIndex);
    ++currentIndex;
    return file;
  }

}

