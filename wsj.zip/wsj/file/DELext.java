package wsj.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.File;
import java.io.FilenameFilter;
import java.lang.*;


//Ư�� Ȯ���� ���� �����ϱ�
public class DELext {
  public static void main (String args[]) {
    System.out.println("hello");
    DELext td = new DELext();
    td.deleteFiles("c:/test/", ".gif");
  }

  public void deleteFiles( String d, String e ) {
    ExtensionFilter filter = new ExtensionFilter(e);
    File dir = new File(d);

    String[] list = dir.list(filter);
    File file;
    if (list.length == 0) return;

    for (int i = 0; i < list.length; i++) {
      file = new File(d + list[i]);
      boolean isdeleted = file.delete();
      System.out.print(file);
      System.out.println( " deleted " + isdeleted);
    }
  }

  class ExtensionFilter implements FilenameFilter {
    private String extension;
    public ExtensionFilter( String extension ) {
      this.extension = extension;
    }
    public boolean accept(File dir, String name) {
      return (name.endsWith(extension));
    }
  }
}