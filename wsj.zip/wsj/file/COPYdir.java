package wsj.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

// Directory�� �����ϴ� ���α׷��Դϴ�. (Sub ����)
// Swing�� �̿��� ����� �ɼǷ�ƾ �߰�
// author : youwant@lycos.co.kr 00/03/02

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class COPYdir {

  private int copySize = 0;

  public COPYdir(String srcDir, String desDir){

    File srcFile = new File(srcDir);
    File desFile = new File(desDir);

    if( !srcFile.exists() ) return;
    copyDir( srcFile.getAbsolutePath() , desFile.getAbsolutePath() );

    String infoString = copySize + " [ byte ] ���縦 ���ƽ��ϴ�.";

    JOptionPane.showMessageDialog(
        null, infoString , "�Ϸ�",
        JOptionPane.INFORMATION_MESSAGE ) ;
    System.exit(0);

  }

  private void copyDir( String srcPath , String desPath ){

    File srcDirFile = new File(srcPath);
    File desDirFile = new File(desPath);

    if( !desDirFile.exists() )desDirFile.mkdir();

    File[] srcListFile = srcDirFile.listFiles();
    File desListFile;
    String desFileName;
    for(int i =0 ; i < srcListFile.length; i++){

      desFileName = srcListFile[i].getName();
      desListFile = new File(desPath + File.separator + desFileName);

      if( srcListFile[i].isDirectory() )
        copyDir( srcListFile[i].getAbsolutePath() , desPath + File.separator + desFileName );

      else{
        if( desListFile.exists() ){
          int ret = JOptionPane.showConfirmDialog(
              null, desFileName+ "������ �����մϴ�. ������?", "����", JOptionPane.YES_NO_OPTION );

          if( ret == 0 )
            copyFile( srcListFile[i] , desListFile );
        }
        else
          copyFile( srcListFile[i] , desListFile );
      }
    }
  }

  private void copyFile(File srcFile , File desFile){

    try{

      InputStream in = new FileInputStream( srcFile );
      OutputStream out = new FileOutputStream( desFile );
      byte buf[] = new byte[1024];

      for( int cnt; (cnt = in.read(buf)) != -1; ){
        copySize += cnt;
        out.write( buf, 0, cnt );
      }
      in.close();
      out.close();
    }catch(Exception e){
      System.out.println(e);
    }
  }

  public static void main(String[] args){

    if(args.length < 2 ){

      JOptionPane.showMessageDialog(
          null, "java srcDir desDir", "����", JOptionPane.ERROR_MESSAGE );

      System.exit(0);
    }
    new COPYdir( args[0] , args[1]);
  }
}

