package wsj.tunnellingservlet;

import java.io.*;
import java.util.*;
import java.text.*;
import javax.rmi.*;
import java.rmi.*;
import javax.naming.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.ejb.*;

import wsj.atm.ejb.*;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.tcf.TCF;

/* -----------------------------------------------------------------------------
 * porting processing
 * -----------------------------------------------------------------------------
 * 1) C:\jws\ATMPPP\mkwartunnellingservlet
 * 2) ServletClient,TPMcalltunnellingservlet.java,TullellingServlet ����
 *    C:\jws\ATMPPP\mkwartunnellingservlet
 * 3) mkTunnelingWebApp.bat TunnellingWebApp
 * 4) %JAVA_HOME%/bin/java wsj.tunnellingservlet.client.ServletClient
* -----------------------------------------------------------------------------*/

public class TunellingServlet extends HttpServlet
{
  protected ServletContext context;
  public EJBPool atmejbpool;
  private IOBoundArea inbound;
  private IOBoundArea outbound;
  private TCPCallEJB ejbinstance;
  private InputStream in;
  private OutputStream out;

  public void init()
  {
    context = getServletContext();
    //getEJBPool(); //ATMXMLconfig.xml ����ȯ���� ���п� �°�����
  }
  public EJBPool getEJBPool()
  {
    if( atmejbpool == null ){
      this.atmejbpool = EJBPool.getInstance();
    }
    return this.atmejbpool;
  }
  public InputStream getInputStream(HttpServletRequest request) throws IOException
  {
    return request.getInputStream();
  }
  public ObjectInputStream getObjectInputStream() throws IOException
  {
    return new ObjectInputStream(this.in);
  }
  public OutputStream getOutputStream(HttpServletResponse response) throws IOException
  {
    return response.getOutputStream();
  }
  public ObjectOutputStream getObjectOutputStream() throws IOException
  {
    return new ObjectOutputStream(this.out);
  }
  public void dispatch(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
  {
    System.out.println(">"+ComUtil.GetSysTime());
    System.out.println(">"+"Connecting for request Service from Client");

    this.in = this.getInputStream(request);
    System.out.println(">"+this.getSystemDate()+"-"+this.getSystemTime());
    System.out.println(">"+"*------------------------------------------------------------------*");
    System.out.println(">"+"*                         Client Information                       *");
    System.out.println(">"+"*------------------------------------------------------------------*");
    System.out.println(">"+"Client.IP:"+request.getRemoteAddr());
    System.out.println(">"+"Client.Host:"+request.getRemoteHost());
    System.out.println(">"+"*------------------------------------------------------------------*");

    System.out.println(">"+"Get. Input/Output Stream");
    ObjectInputStream ois = null;
    this.out = this.getOutputStream(response);
    ObjectOutputStream oos = null;
    try
    {
      ois = this.getObjectInputStream();
      oos = this.getObjectOutputStream();

      System.out.println(">"+"Get. ObjectInput/ObjectOutput Stream");

      Object obj = ois.readObject();
      this.execute(obj);

      System.out.println(">"+"Send. ObjectOutput Stream");
      oos.writeObject(this.outbound);
    }
    catch(ClassNotFoundException e)
    {
      e.printStackTrace();
      throw new ServletException("ClassNotFoundException - "+ "IOBoundArea class");
    }

    finally
    {
      ois.close();
      oos.close();
      out.close();
    }
  }


  // foundation �̿� rmi server�� ���� �����´�.
  private String getSystemDate()
  {
    String dateFormat = "yyyyMMdd";
    Format df = new SimpleDateFormat(dateFormat);
    return df.format(new java.util.Date());
  }

  // foundation �̿� rmi server�� ���� �����´�.
  private String getSystemTime()
  {
    String timeFormat = "HHmmssSSS";
    Format tf = new SimpleDateFormat(timeFormat);
    Calendar c = Calendar.getInstance();
    int ms = c.get(Calendar.MILLISECOND)/10 * 10;
    c.set(Calendar.MILLISECOND, ms);
    java.util.Date today = c.getTime();
    String time = tf.format(today);
    return time.substring(0, time.length());
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
  {
    dispatch(request,response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException
  {
    dispatch(request,response);
  }

  public void destroy()
  {
  }
  public void setInIOBoundArea(IOBoundArea io){
    this.inbound = io;
  }
  public void setOutIOBoundArea(IOBoundArea io)  throws IOException,NotBoundException {
    if( this.outbound == null )
      this.outbound = new IOBoundArea();
    this.outbound = io;
  }
  public boolean execute(Object obj) throws ServletException{
    try{
      if(obj instanceof wsj.atm.packet.IOBoundArea){
        this.inbound = (IOBoundArea)obj;
        this.outbound = new IOBoundArea();
      }
      else {
        throw new ServletException("Invalid IOBoundArea. - "+obj.getClass().getName());
      }
      //////////////////////////////////////////////////////////////////
      // Ŭ���̾�Ʈ�� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////
      // ���� �������� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////
      // Ʈ����� ������ �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      System.out.println("recv data["+this.inbound.toString()+"]");
      System.out.println("=========================================TCF ST");

      //TCF tcf = new TCF();
      this.outbound.iodata.sBoundData = this.inbound.iodata.sBoundData;
      System.out.println("==Biz Method==outbound:["+this.outbound.toString()+"]");
      //tcf.execute(inbound.toString());

      System.out.println("=========================================TCF END");
      System.out.println("send data["+outbound.toString()+"]");
      //////////////////////////////////////////////////////////////////
      // Ŭ���̾�Ʈ�� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////
      // �������� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
    }
    catch(Exception ex){
      ex.printStackTrace();
      inbound.setInParsing();
      inbound.iohead.sBErrCode = "EI0999";
      this.outbound.iohead.sBErrCode = this.inbound.iohead.sBErrCode ;
      this.outbound.iohead.setMsg("TunnellingServlet-execute");
      this.outbound.iodata.sBoundData = this.inbound.iodata.sBoundData ;
      this.outbound.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outbound.iodata.sBoundData.length()),5);
      this.outbound.iodata.sLength = this.outbound.sLength;
      return false;
    }
    return true;
  }

/*
  private String getBusinessDate(IOBoundArea command)
      throws IOException
  {
    Context ctx = null;
    CommonManagementSBHome home = null;
    ICommonManagementSB remote = null;
    HashMap hm = new HashMap();

    try {
      System.out.println("------------------1");
      if(commonHome==null) {
        ctx = new InitialContext();
        System.out.println("------------------1-1");
        Object obj = ctx.lookup(CommonManagementSBHome.class.getName());
        System.out.println("------------------2");
        commonHome = (CommonManagementSBHome)PortableRemoteObject.narrow(
            obj,CommonManagementSBHome.class
            );
        System.out.println("------------------3");
      }
      remote = commonHome.create();
      System.out.println("------------------4");
      String businessDate = remote.getBusinessDate(command.getBankCode());
      System.out.println("------------------5");
      return businessDate;
    } catch(Exception e) {
      System.out.println("-----------getBusinessDate() -----");
      e.printStackTrace();
      throw new IOException(e.getMessage());
    }
  }
*/

}