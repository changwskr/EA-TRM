package wsj.tunnellingservlet.client;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.net.*;

import wsj.tunnellingservlet.tpm.TPMcalltunnellingservlet;
import wsj.atm.packet.*;

/**
 *	TPMcalltunnellingservlet�� �̿��� IOBoundArea ��ü�� TunellingServlet�� �����ϰ�, ����� ��ȯ�ϴ�
 *	Utility class�̴�.[TunellingServlet�� ȣ���ϴ� utility class]
 */
public class ServletClient
{
  /**
   *	Default Constructor
   */
  private ServletClient()
      {}

  /**
   *	IOBoundArea�� TPMcalltunnellingservlet ��ü�� �̿��ؼ� TunellingServlet�� �����ϰ�,
   *	������� �޾� ��ȯ�ϴ� �޼���
   *
   *	@param	inbound	IOBoundArea
   *	@return	result object
   *	@exception	BatchException
   */
  public static Object call(IOBoundArea inbound)
      throws Exception
  {
    String servletUrl ="http://localhost:10000/TunnellingWebApp/TunellingServlet";

    URL servlet = null;
    try
    {
      servlet = new URL(servletUrl);
    }
    catch(MalformedURLException e)
    {
      throw new Exception(e.getMessage());
    }

    TPMcalltunnellingservlet tcs = new TPMcalltunnellingservlet(servlet);
    InputStream in = null;
    ObjectInputStream ois = null;
    try {
      in = tcs.TUNLcall(inbound);
      ois = new ObjectInputStream(in);
      Object obj = ois.readObject();
      return obj;
    } catch(IOException e) {
      e.printStackTrace();
      throw new Exception(e.getMessage());
    } catch(ClassNotFoundException e) {
      e.printStackTrace();
      throw new Exception(e.getMessage());
    }
  }

  public static void main(String args[]) throws Exception
  {
    IOBoundArea inbound = new IOBoundArea();
    inbound.cdto.eventNo="80001";
    inbound.iodata.sBoundData="1234567890";

    for( int i = 0 ; i < 10 ; i ++){
      System.out.println("\n\n==Biz Method==inbound:["+inbound.toString()+"]");
      Object result = ServletClient.call(inbound);
      IOBoundArea outbound = (IOBoundArea) result;
      System.out.println("==Biz Method==outbound:["+outbound.toString()+"]");

    }

  }
}