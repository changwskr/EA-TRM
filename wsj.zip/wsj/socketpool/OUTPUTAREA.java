package wsj.socketpool;


/**---------------------------------------------------------------------------*
 # TITLE : OUTPUTAREA
 #                                                  Copyright @2001 03 20 W.S.J
 # ---------------------------------------------------------------------------*
 #
 # DESC  :
 #		(1)
 #		(2)
 **---------------------------------------------------------------------------*/




import java.io.*;


public class OUTPUTAREA implements Serializable
{
  public int    OutputDataLen;
  public String HostSeq;
  public String HostServ;
  public String HostProg;
  public String InTime;
  public String OutTime;
  public String CurDate;
  public int    TpFq;
  public String ErrCode;
  public int    Ivt;
  public String OutputData;

  public void set_OutputDataLen(int datalen)
  {
    this.OutputDataLen=datalen;
  }
  public void set_ErrCode(String ErrCode)
  {
    this.ErrCode=ErrCode;
  }
  public void set_CurDate(String CurDate)
  {
    this.CurDate=CurDate;
  }
  public void set_HostSeq(String HostSeq)
  {
    this.HostSeq=HostSeq;
  }
  public void set_HostServ(String HostServ)
  {
    this.HostServ=HostServ;
  }
  public void set_HostProg(String HostProg)
  {
    this.HostServ=HostProg;
  }
  public void set_InTime(String InTime)
  {
    this.InTime=InTime;
  }
  public void set_OutTime(String OutTime)
  {
    this.OutTime=OutTime;
  }
  public void set_TpFq(int tpfq)
  {
    this.TpFq=tpfq;
  }
  public void set_Ivt(int ivt)
  {
    this.Ivt=ivt;
  }
  public void set_OutputData(String outputdata)
  {
    this.OutputData=outputdata;
  }

}
