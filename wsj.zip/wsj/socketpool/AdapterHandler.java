package wsj.socketpool;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.util.*;

public class AdapterHandler implements Runnable {

  protected Socket s;
  protected DataInputStream i;
  protected DataOutputStream o;
  protected int id;
  protected static Vector handlers = new Vector ();

  public AdapterHandler (Socket s) throws IOException {
    this.s = s;
    i = new DataInputStream (new BufferedInputStream (s.getInputStream ()));
    o = new DataOutputStream (new BufferedOutputStream (s.getOutputStream ()));
  }

  public void SOK_timeout(int psMilliseconds) throws SocketException
  {
    this.s.setSoTimeout(psMilliseconds);
    return;
  }

  public void run () {

    try {

      handlers.addElement (this);

      while (true) {
        //----------------------------------------------------------------------
        String msg = SOK_recv();
        System.out.println(Thread.currentThread().getName() + ":R[" + msg +"]");
        //----------------------------------------------------------------------

        //prntVector();

        //----------------------------------------------------------------------
        SOK_send(msg);
        System.out.println(Thread.currentThread().getName() + ":S[" + msg +"]");
        //----------------------------------------------------------------------

      }
    } catch (IOException ex) {
      System.out.println(Thread.currentThread().getName()+ "[IOException ------");
      ex.printStackTrace ();
    } finally {
      handlers.removeElement (this);
      try {
        s.close ();
      } catch (IOException ex) {
        ex.printStackTrace();
      }
      System.out.println(Thread.currentThread().getName()+ "[�����带 �����մϴ�]");
    }
  }


  protected void SOK_send (AdapterHandler c,String message) throws IOException{
    try {
      synchronized (c.o) {
        c.o.writeUTF (message);
      }
      c.o.flush ();
    } catch (IOException ex) {

      throw new IOException();
      //c.stop ();
    }
  }

  protected void SOK_send (String message) throws IOException{
    try {

      o.writeUTF (message);
      o.flush ();

    } catch (IOException ex) {
      System.out.println(Thread.currentThread().getName() + "[SOK_send() error�߻�]");
      throw new IOException();

    }
  }


  protected String SOK_recv () throws IOException {
    String message;
    try {
      message =null;
      message=i.readUTF();
    } catch (IOException ex) {
      System.out.println(Thread.currentThread().getName() + "[SOK_recv() error�߻�]");
      throw new IOException();
    }
    return message;
  }

  protected String SOK_recv (AdapterHandler c) throws IOException {
    String message;
    try {
      synchronized (c.i) {
        message =null;
        System.out.println(c.id + " read waiting");
        message=c.i.readUTF ();
      }

    } catch (IOException ex) {
      //c.stop ();
      throw new IOException();
    }
    return message;
  }

  protected void broadcast (String message) {
    synchronized (handlers) {
      Enumeration e = handlers.elements ();
      while (e.hasMoreElements ()) {
        AdapterHandler c = (AdapterHandler) e.nextElement ();
        try {
          synchronized (c.o) {
            c.o.writeUTF (message);
          }
          c.o.flush ();
        } catch (IOException ex) {
          //c.stop ();

        }
      }
    }
  }

  protected void prntVector () throws IOException{
    synchronized (handlers) {
      Enumeration e = handlers.elements ();
      while (e.hasMoreElements ()) {
        AdapterHandler c = (AdapterHandler) e.nextElement ();
        //try {
        System.out.println("handler id:"+c.id);
        //} catch (IOException ex) {
        //c.stop ();
        //throw new IOException();
        //}
      }
    }
  }
}