package wsj.socketpool;

import java.net.*;
import java.io.*;
import java.util.*;
import java.text.*;

class InforArea {

	String _UserName;
	char   _IsAlive;
	String _ThreadNo;
	String _IPaddress;
	String _Port;

	Socket _Socket;
	String _TrCnt;
	String _StartDate;
	String _StartTime;
	String _EndTime;

	InforArea(Thread thr,String username,Socket s,String port)
	{
		setInforarea(thr,username,s,port);
	}

	public synchronized void setInforarea(Thread thr,String username,Socket s,String port)
	{
		set_Alive();
		set_Socket(s);
		set_Port(port);
		set_IPaddress();
		set_ThreadNo(thr);
		set_UserName(username);
		set_StartTime();
		set_EndTime();
	}

	public void set_Socket(Socket s)
	{
		_Socket = s;
	}
	public void set_Die()
	{
		this._IsAlive = '0';
	}

	public void set_Alive()
	{
		this._IsAlive = '1';
	}
	public void set_IPaddress()
	{
		_IPaddress=_Socket.getInetAddress().toString();
	}
	public void set_ThreadNo(Thread thr)
	{
		_ThreadNo = thr.currentThread().getName();
	}
	public void set_UserName(String username)
	{
		_UserName = username;
	}
	public void set_Port(String port)
	{
		_Port = port;
	}
	public void set_StartTime()
	{
		SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSS");
		_StartTime = fmt.format(new Date()).toString();
	}
	public void set_StartDate()
	{
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		_StartDate=fmt.format(fmt.format(new Date()).toString());
	}
	public void set_EndTime()
	{
		SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
		_StartDate=fmt.format(fmt.format(new Date()).toString());
	}
}
