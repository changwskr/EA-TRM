package wsj.socketpool;

public class TCF
{
  INPUTAREA  IN;
  OUTPUTAREA OUT;

  TCF(INPUTAREA IN,OUTPUTAREA OUT)
  {
    this.IN = IN;
    this.OUT = OUT;
  }

  public void TCF_MAIN()
  {
    STF();
    BIZ();
    ETF();
  }

  public void STF()
  {
  }

  public void ETF()
  {
  }


  public void BIZ()
  {
  }
}