package wsj.socketpool;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class TPThreadPoolTest
{
  private static TPThreadPool pool = new TPThreadPool( 10, 10 );

  public static void main( String[] args )
  {
    TPThreadPoolTest test_bed = new TPThreadPoolTest();
    test_bed.fire( "hello" );
    test_bed.fire( "world" );
    // Give the threads a chance to start before closing the pool
    try {
      Thread.currentThread().sleep(1500);
    } catch(InterruptedException e){
    }
    pool.close();
  }

  private void fire( final String id )
  {
    pool.execute (
        new Runnable() {
      public void run() {
        System.out.println("Starting " + id );
        try	{
          Thread.currentThread().sleep(500);
        } catch(InterruptedException e){
        }
        System.out.println("Stopping " + id );
      }
    }
    );
  }
}