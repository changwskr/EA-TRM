package wsj.bitutil;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.nio.*;

public class ByteCutTest {

  public static String truncateNicely(String s, int len, String tail)
  {
    if (s == null)
      return null;

    int srcLen = realLength(s);
    if (srcLen < len)
      return s;

    String tmpTail = tail;
    if (tail == null)
      tmpTail = "";

    int tailLen = realLength(tmpTail);
    if (tailLen > len)
      return "";

    char a;
    int i = 0;
    int realLen = 0;
    for (i = 0; i < len - tailLen && realLen < len - tailLen; i++) {
      a = s.charAt(i);
      if ((a & 0xFF00) == 0)
        realLen += 1;
      else
        realLen += 2;
    }

    while (realLength(s.substring(0, i)) > len - tailLen) {
      i--;
    }

    return s.substring(0, i) + tmpTail;
  }

  public static int realLength(String s) {
    return s.getBytes().length;
  }

  public static void main(String[] args) {
    String str = "�̰��� Hangul(�ѱ�)�Դϴ�.";
    System.out.println(str);
    System.out.println(" 2: " + truncateNicely(str, 2, "*"));
    System.out.println(" 3: " + truncateNicely(str, 3, "*"));
    System.out.println(" 9: " + truncateNicely(str, 9, "*"));
    System.out.println("10: " + truncateNicely(str, 10, "*"));
    System.out.println("11: " + truncateNicely(str, 11, "*"));
    System.out.println("12: " + truncateNicely(str, 12, "*"));
    System.out.println("13: " + truncateNicely(str, 13, "*"));
    System.out.println("14: " + truncateNicely(str, 14, "*"));
    System.out.println("15: " + truncateNicely(str, 15, "*"));
    System.out.println("16: " + truncateNicely(str, 16, "*"));



    System.out.println(" 2: " + truncateNicely(str, 2, "..."));
    System.out.println(" 3: " + truncateNicely(str, 3, "..."));
    System.out.println(" 9: " + truncateNicely(str, 9, "..."));
    System.out.println("10: " + truncateNicely(str, 10, "..."));
    System.out.println("11: " + truncateNicely(str, 11, "..."));
    System.out.println("12: " + truncateNicely(str, 12, "..."));
    System.out.println("13: " + truncateNicely(str, 13, "..."));
    System.out.println("14: " + truncateNicely(str, 14, "..."));
    System.out.println("15: " + truncateNicely(str, 15, "..."));
    System.out.println("16: " + truncateNicely(str, 16, "..."));



    System.out.println(" 2: " + truncateNicely(str, 2, ""));
    System.out.println(" 3: " + truncateNicely(str, 3, ""));
    System.out.println(" 9: " + truncateNicely(str, 9, ""));
    System.out.println("10: " + truncateNicely(str, 10, ""));
    System.out.println("11: " + truncateNicely(str, 11, ""));
    System.out.println("12: " + truncateNicely(str, 12, ""));
    System.out.println("13: " + truncateNicely(str, 13, ""));
    System.out.println("14: " + truncateNicely(str, 14, ""));
    System.out.println("15: " + truncateNicely(str, 15, ""));
    System.out.println("16: " + truncateNicely(str, 16, ""));


    System.out.println("16: " + truncateNicely(str, 16, null));



    String data = str;
    while (realLength(data) > 5) {
      String tmp = truncateNicely(data, 5, "");
      System.out.println(tmp);
      data = data.substring(tmp.length());
    }
    if (data.length() > 0)
      System.out.println(data);
  }
}
/*
���� ���:--------------------------
�̰��� Hangul(�ѱ�)�Դϴ�.
 2: *
 3: ��*
 9: �̰��� H*
10: �̰��� Ha*
11: �̰��� Han*
12: �̰��� Hang*
13: �̰��� Hangu*
14: �̰��� Hangul*
15: �̰��� Hangul(*
16: �̰��� Hangul(*
 2:
 3: ...
 9: �̰���...
10: �̰��� ...
11: �̰��� H...
12: �̰��� Ha...
13: �̰��� Han...
14: �̰��� Hang...
15: �̰��� Hangu...
16: �̰��� Hangul...
�̰�
�� Ha
ngul(
�ѱ�)
�Դ�
��.
*/