package wsj.os390.codeset;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;

public class EBCDICtoascii {

  public EBCDICtoascii(){}

  public static String process(String file)
  {
    StringBuffer buffer	= new StringBuffer();
    String line	= null;
    File f = new File(file);

    if(f.exists())
    {
      try
      {
        BufferedReader buff = new BufferedReader(new FileReader(f));

        while((line = buff.readLine()) != null)
        {
          byte[] ebcdic = ebcdicBytes(line);
          byte[] blines = line.getBytes();
          //System.out.println( "ebcdic bytes\n" + formedHexString(ebcdic, 0, ebcdic.length) ) ;
          //System.out.println( "\nfrom ebcdic\n" + unicodeString(ebcdic) ) ;
          //buffer.append(formedHexString(ebcdic, 0, ebcdic.length)+"\n");
          buffer.append("ebcdic: " + new String(ebcdic) + "\n" );

          /*
          * 1����
          buffer.append("blines: " + new String(blines,"EUC-KR") + "\n" );
          */

          /*
          * 2����
          */
          buffer.append("blines:" +  new String(blines, "Cp933") + "\n");

          buffer.append("\n" +  unicodeString(ebcdic) + "\n");



        }

      }catch(FileNotFoundException e) {
        e.printStackTrace() ;
      }catch(UnsupportedEncodingException ex){
      }
      catch(IOException exx){
      }

    }

    return buffer.toString();

  }


  public static String formedHexString(byte[] b, int offset, int length)
  {

    int count = 1 ;
    String hex = "" ;
    StringBuffer sb = new StringBuffer(length * 3) ;    // because of 0xFF => "FF "

    for(int i = offset ; i < offset + length ; i++)
    {
      try {
        hex = Integer.toHexString( b[i] ) ;
      }
      catch(ArrayIndexOutOfBoundsException e) {
        break ;
      }



      if(hex.length() == 1)
        hex = "0" + hex ;

      else if(hex.length() == 8)
        hex = hex.substring(6) ;


      sb.append( hex.toUpperCase() + " " ) ;

      if( (count % 16) == 0 )
        sb.append("\n") ;
      else if( (count % 8) == 0 )
        sb.append(" ") ;

      count++ ;
    }



    return sb.toString() ;
  }

  public static byte[] ebcdicBytes(String unicode)
      throws java.io.UnsupportedEncodingException
  {
      return unicode.getBytes("Cp933") ;			}

      public static String unicodeString(byte[] ebcdic)
          throws java.io.UnsupportedEncodingException
      {
        return new String(ebcdic, "Cp933") ;
      }

      public static void main(String[] args)
      {
        EBCDICtoascii	conver	=	new EBCDICtoascii();
        System.out.println(conver.process(".\\ebcdic_sample.txt"));
      }

}