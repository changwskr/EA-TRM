package wsj.framework;

import java.rmi.*;
import javax.ejb.*;

public interface Enterprise1Home extends EJBHome {
  public Enterprise1 create() throws RemoteException, CreateException;
}