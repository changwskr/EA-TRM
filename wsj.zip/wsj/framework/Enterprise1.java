package wsj.framework;

import java.rmi.*;
import javax.ejb.*;

public interface Enterprise1 extends EJBObject {
}