package wsj.sort;

import java.util.*;

public class GETminmax{

  public static int GETmax(int[] number)
  {
    int max = 0, max_x = 0, min = 0, min_n = 0;
    for(int i=0; i<number.length; i++){
      max = Math.max(number[i], max_x);
      max_x = max;
    }
    System.out.println(max);
    return 0;
  }
  public static int GETmin(int[] number)
  {
    int max = 0, max_x = 0, min = 0, min_n = 0;

    for(int i=0; i<number.length; i++){
      max = Math.max(number[i], max_x);
      max_x = max;
    }

    min = max;
    for(int j=0; j<number.length; j++){
      min = Math.min(number[j], min);
      min_n = min;
    }
    System.out.println(min);
    return min;
  }
  public static void main(String args[])
  {
    int[] number = {43,34,65,22,34,23,20,21,1,2,3,4,5,6,7,8,90,10,11};
    GETminmax.GETmax(number);
    GETminmax.GETmin(number);
  }
}