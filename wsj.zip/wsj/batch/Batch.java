package wsj.batch;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

public class Batch {

  public Batch() {
  }
  public boolean execute(String batchlist_file_fullpath) throws Exception{
    List<String> list = loadBatchJobs(batchlist_file_fullpath);
    return true;
  }
  public static Object loadBatchJobs(String fileName) throws Exception {
    LinkedList<String> list = new LinkedList<String>();
    BufferedReader reader = new BufferedReader( new InputStreamReader( new FileInputStream(fileName) ) );
    String cmd = null;

    while( (cmd =
    return list;
  }
  public static void main(String[] args) {
    Batch batch1 = new Batch();
  }
}