package wsj.diffdate;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.text.SimpleDateFormat;


/**
 * <p>
 * => Functional useful Date class
 * <p>
 */
public class DateUtils {

        public DateUtils() {}

        /**
         * Date -> String
         *
         * @return String The Date string. Type,  yyyyMMdd HH:mm:ss.
         *
         * @param date Date which you want to change.
         */
        public String toString(Date date) throws Exception {

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.KOREA);

                String tmp = "";

                try {
                        tmp = sdf.format(date);
                } catch(Exception e) {
                        throw new Exception(e.getMessage());
                }

                return tmp;
        }

        /**
         * intervals between the two Date.
         *
         * @return long intervals the number of milliseconds.
         *
         * @param start First date string
         * @param end Date Second date string
         */
        public long getTimeInterval(String start, String end) throws Exception {

                long mil = 0;

                try {
                        mil = getTimeInterval(getIncrementDays(start, 0), getIncrementDays(end, 0));

                }catch(Exception e) {}

                return mil;
        }

        /**
         * intervals between the two Date.
         *
         * @return Date intervals the number of milliseconds.
         *
         * @param startDate First Date
         * @param endDate Date Second Date
         */
        public long getTimeInterval(Date startDate, Date endDate) throws Exception {

                return (endDate.getTime() - startDate.getTime());
        }

        /**
         * intervals between the two Date.
         *
         * @return Date intervals Date.
         *
         * @param startDate First Date
         * @param endDate Date Second Date
         */
        public Date getDateInterval(Date startDate, Date endDate) throws Exception {

                return  new Date(endDate.getTime() - startDate.getTime());
        }


        /**
         * Increment Days. Minus Days is backward, Plus Days is forward.
         *
         * @return Date Increment Date.
         *
         * @param date Target Date
         * @param days Increment Days
         */

        public Date getIncrementDays(Date date, int days) throws Exception {

                Calendar calendar = new GregorianCalendar();
                String strDate = "";

                int year = 0;
                int month = 0;
                int day = 0;
                int hour = 0;
                int minute = 0;
                int second = 0;


                try {
                        strDate = changeFormat(date);



                        year = Integer.parseInt(strDate.substring(0,4));
                        month = Integer.parseInt(strDate.substring(5,7));
                        day = Integer.parseInt(strDate.substring(8,10));
                        hour = Integer.parseInt(strDate.substring(11,13));
                        minute = Integer.parseInt(strDate.substring(14,16));
                        second = Integer.parseInt(strDate.substring(17,19));

                } catch(Exception e) {}

                calendar.set(year, month-1, day + days, hour, minute, second);


                try {
                        date = calendar.getTime();
                }catch(Exception e) {}

                return date;
        }

        /**
         * Increment Days. Minus Days is backward, Plus Days is forward.
         *
         * @return Date Increment Date.
         *
         * @param strDate Target date String, yyyy-MM-dd or yyyy-MM-dd HH:mm:ss style only.
         * @param days Increment Days
         */
        public Date getIncrementDays(String strDate, int days) throws Exception {

                SimpleDateFormat sdf = null;
                Calendar calendar = new GregorianCalendar();
                Date date = null;

                int year = 0;
                int month = 0;
                int day = 0;
                int hour = 0;
                int minute = 0;
                int second = 0;


                if(strDate.length() == 10 ) {
                        sdf = new SimpleDateFormat("yyyy-MM-dd", java.util.Locale.KOREA);
                } else {
                        sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.KOREA);
                }

                try {
                        Date tmpDate = sdf.parse(strDate);
                } catch(Exception e) {
                        throw new Exception(e.getMessage());
                }


                try {

                        year = Integer.parseInt(strDate.substring(0,4));
                        month = Integer.parseInt(strDate.substring(5,7));
                        day = Integer.parseInt(strDate.substring(8,10));
                        hour = Integer.parseInt(strDate.substring(11,13));
                        minute = Integer.parseInt(strDate.substring(14,16));
                        second = Integer.parseInt(strDate.substring(17,19));

                } catch(Exception e) {

                        hour = 0;
                        minute = 0;
                        second = 0;
                        //	throw new Exception(e.getMessage()+"Here");
                }


                calendar.set(year, month-1, day + days, hour, minute, second);

                try {
                        date = calendar.getTime();
                }catch(Exception e) {}

                return date;
        }

        /**
         * Days of month.
         *
         * @param days  increase of Days
         * @return Date increment Date
         */
        public Date currentIncrementDays(int days) throws Exception {

                Date retDate = getIncrementDays(new Date(System.currentTimeMillis()), days);

                return retDate;

        }

        /**
         * Days of month.
         *
         * @return int Days of month
         *
         * @param year Target year.
         * @param month Target month
         */
        public int getDaysOfMonth(int year, int month) {
                        /*
                        Check for leap year ..
                        1.Years evenly divisible by four are normally leap years, except for...
                        2.Years also evenly divisible by 100 are not leap years, except for...
                        3.Years also evenly divisible by 400 are leap years.
                        */

                        int[] DOMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};		// Non-Leap year Month days..
                        int[] lDOMonth = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};	// Leap year Month days..

                        if ((year % 4) == 0) {

                                if ((year % 100) == 0 && (year % 400) != 0) {
                                        return DOMonth[month];
                                }

                                return lDOMonth[month];

                        } else {
                                return DOMonth[month];
                        }
        }

        public static void main(String args[]) throws Exception
        {
          DateUtils dateUtil = new DateUtils();

          String nextDate = "";
          String beforeDate = "";
          String days = "";

          try {
            // ������ ���ϱ�. "2003-01-25"�� Date ��ü�� �ٲ㵵 �ǿ� ��:10����
            nextDate = dateUtil.toString(dateUtil.getIncrementDays("2003-01-25", 10) );
            System.out.println("next,2003-01-25 +10:"+nextDate);
            // ������ ���ϱ�. Date ��ü�� "yyyy-mm-dd"�� �ٲ㵵 �ǿ� ��:30����
            beforeDate = dateUtil.toString(dateUtil.getIncrementDays(new java.util.Date(), -30));
            System.out.println("before,30:"+beforeDate);

            // ��¥���� ���ϱ�. "yyyy-mm-dd"�� Date ��ü�� �ٲ㵵 �ǿ�
            days = dateUtil.toString(new Date( dateUtil.getTimeInterval("2003-02-03", "2003-03-10") ));
            System.out.println("diff,2003-02-03| 2003-03-10:" + days);
            } catch(Exception e) {}


        }


}
