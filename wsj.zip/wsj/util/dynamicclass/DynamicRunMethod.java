package wsj.util.dynamicclass;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.lang.reflect.Method;
import java.lang.reflect.*;

public class DynamicRunMethod {
  private static DynamicRunMethod instance;
  public static synchronized DynamicRunMethod getInstance() throws Exception{
    if (instance == null) {
      instance = new DynamicRunMethod();
    }
    return instance;
  }
  public DynamicRunMethod() {
  }
  public void execute(String actionClassName,String methodName,IDT[] arg)
  {
    try {
      System.out.println(Class.forName(actionClassName));
      Method meth = (Class.forName(actionClassName)).getMethod(methodName,new Class[]{IDT[].class});
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
      ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
      ex.printStackTrace();
    }catch (InvocationTargetException ex) {
      ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
      ex.printStackTrace();
    }catch (SecurityException ex) {
      ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,String[] arg)
  {
    try {
      System.out.println(Class.forName(actionClassName));
      Method meth = (Class.forName(actionClassName)).getMethod(methodName,new Class[]{String[].class});
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
      ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
      ex.printStackTrace();
    }catch (InvocationTargetException ex) {
      ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
      ex.printStackTrace();
    }catch (SecurityException ex) {
      ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,IDT arg)
  {
    try {
      Method meth = (Class.forName(actionClassName)).getMethod(methodName,new Class[]{IDT.class});
      System.out.println(meth);
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
            ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
            ex.printStackTrace();
    }catch (InvocationTargetException ex) {
            ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
            ex.printStackTrace();
    }catch (SecurityException ex) {
            ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
            ex.printStackTrace();
    }
  }

  public static void main(String[] args)
  {
    try {
      IDT[] arg = new IDT[3];
      arg[0]=new DT();
      arg[1]=new DT();
      arg[2]=new DT();

      ((DT)arg[0]).str = "0000";
      ((DT)arg[1]).str = "1111";
      ((DT)arg[2]).str = "2222";

     DynamicRunMethod.getInstance().execute("wsj.exchange.dynamicrunmethod.CTEST","execute", (IDT[])arg);
     DynamicRunMethod.getInstance().execute("wsj.exchange.dynamicrunmethod.CTEST","execute", (IDT)arg[1]);
     //DynamicRunMethod.getInstance().execute("wsj.exchange.dynamicrunmethod.ICommon","execute", (IDT)arg[1]);

      String[] arg1 = new String[3];
      arg1[0]=new String("aaaaaaaaa");
      arg1[1]=new String("bbbbbbbbb");
      arg1[2]=new String("ccccccc");
      DynamicRunMethod.getInstance().execute("wsj.exchange.dynamicrunmethod.CTEST","execute", (String[])arg1);

    }
    catch (Exception ex) {
      ex.printStackTrace();
    }

  }

}

interface IDT {
  public void dtexecute(String str);
}

class  DT implements IDT{
  public String str;
  public void dtexecute(String str){
    System.out.println("--DT :" + str);
  }
  public void dtexecute(){
    System.out.println("--DT :" + str);
  }
}

interface  ICommon {
  public void execute(IDT dt);
  public void execute(IDT[] dt);
  public void execute(String[] dt);
}

class  CTEST implements ICommon{
  public void execute(IDT dt){
    System.out.println("--CTEST :" + ((DT)dt).str);
  }
  public void execute(IDT[] dt){
    for( int i =0 ; i<dt.length ; i++ ){
      //System.out.println(((DT)dt[i]).str);
      ((DT)dt[i]).dtexecute();
    }
  }
  public void execute(String[] dt){
    for( int i =0 ; i<dt.length ; i++ ){
      System.out.println(("---"+dt[i]));
    }
  }

}


