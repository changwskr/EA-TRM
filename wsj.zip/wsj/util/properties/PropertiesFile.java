package wsj.util.properties;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;

public class PropertiesFile {

  public PropertiesFile() {
  }



  public synchronized static String GetEnvValue(String envfilename,String tmp)
  {
    String ConfigPath=null;
    Properties p = new Properties();
    FileInputStream fis = null;
    String tmpv = null;
    try {
      fis = new FileInputStream(envfilename);
      p.load(fis);
      tmpv=p.getProperty(tmp);
    }
    catch (IOException e) {
      System.out.println("GetEnvValue() ���� ȯ����ý�12 ���ܹ߻�" );
      e.printStackTrace();
    }
    finally{
      try{
        if( fis != null ){
          fis.close();
        }
      }
      catch (Exception ignore) {
      }
    }
    return tmpv;
  }

  public static void main(String[] args) {
    PropertiesFile getValueInFile1 = new PropertiesFile();

GetEnvValue("C:\\env\\kk.properties","VAL1");
  }
}