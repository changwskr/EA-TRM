package wsj.util.properties;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;

import wsj.exchange.atm.env.UbbConfig;
import wsj.exchange.atm.env.*;
import wsj.exchange.atm.common.ComUtil;

import wsj.exchange.atm.packet.*;

import wsj.util.xml.XMLconfig;
import wsj.util.system.GetHostName;
import wsj.util.log.Logging;

public class EnvironmentValuePropertySavingToFile
{
  public Hashtable envh = new Hashtable();
  private String filename;

  public EnvironmentValuePropertySavingToFile(String filename) throws IOException {
    /*
    this.filename = UbbConfig.getInstance().GetEnvValue("LOGINATM")
                  + ComUtil.getLocalHostName()
                  + "."
                  + filename;
    */
    if( GetHostName.execute().equals(XMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
      this.filename = XMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGINATM")
                    + GetHostName.getLocalHostName()
                    + "."
                    + filename;
    }
    else if ( GetHostName.GetHostName().equals(XMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
      this.filename = XMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","LOGINATM")
                    + GetHostName.getLocalHostName()
                    + "."
                    + filename;
    }
  }

  public void setCosesCommonDTO(IOBoundCDTO cdto){
    envh.put("bankCode",cdto.bankCode);
    envh.put("branchCode",cdto.branchCode);
    envh.put("gIPostBrCode",cdto.gIPostBrCode);
    envh.put("channelType",cdto.channelType);
    envh.put("userId",cdto.userId);
    envh.put("terminalId",cdto.terminalId);
    envh.put("terminalType",cdto.terminalType);
    envh.put("eventNo",cdto.eventNo);
    envh.put("nationCode",cdto.nationCode);
    envh.put("regionCode",cdto.regionCode);
    envh.put("timeZone",cdto.timeZone);
    envh.put("fxRateSeq",cdto.fxRateSeq);
    envh.put("xmlSeq",cdto.xmlSeq);
    envh.put("reqName",cdto.reqName);
    envh.put("trxDate",cdto.trxDate);
    envh.put("bizDate",cdto.bizDate);
    envh.put("trxInTime",cdto.trxInTime);
    envh.put("trxOutTime",cdto.trxOutTime);
    envh.put("trxNumber",cdto.trxNumber);
    envh.put("voucherNum",cdto.voucherNum);
    envh.put("refNum",cdto.refNum);
    envh.put("cifNum",cdto.cifNum);
    envh.put("baseCurrency",cdto.baseCurrency);
    return;
  }

  public void setIOBoundTel80004CDTO(IOBoundTel80004CDTO cdto)
  {
    envh.put("TellerNo",cdto.TellerNo);
    envh.put("TxDate",cdto.TxDate);
    envh.put("TellerStatus",cdto.TellerStatus);
    envh.put("Currency01",cdto.Currency01);
    envh.put("Amount01",cdto.Amount01);
    return;
  }

  public boolean loadingINI()
  {
    try
    {
      IOBoundCDTO cdto = new IOBoundCDTO();
      IOBoundTel80004CDTO tcdto = new IOBoundTel80004CDTO();

      Properties p = new Properties();
      p.load(new FileInputStream(filename));

      envh.put("bankCode",cdto.bankCode);
      envh.put("branchCode",cdto.branchCode);
      envh.put("gIPostBrCode",cdto.gIPostBrCode);
      envh.put("channelType",cdto.channelType);
      envh.put("userId",cdto.userId);
      envh.put("terminalId",cdto.terminalId);
      envh.put("terminalType",cdto.terminalType);
      envh.put("eventNo",cdto.eventNo);
      envh.put("nationCode",cdto.nationCode);
      envh.put("regionCode",cdto.regionCode);
      envh.put("timeZone",cdto.timeZone);
      envh.put("fxRateSeq",cdto.fxRateSeq);
      envh.put("xmlSeq",cdto.xmlSeq);
      envh.put("reqName",cdto.reqName);
      envh.put("trxDate",cdto.trxDate);
      envh.put("bizDate",cdto.bizDate);
      envh.put("trxInTime",cdto.trxInTime);
      envh.put("trxOutTime",cdto.trxOutTime);
      envh.put("trxNumber",cdto.trxNumber);
      envh.put("voucherNum",cdto.voucherNum);
      envh.put("refNum",cdto.refNum);
      envh.put("cifNum",cdto.cifNum);
      envh.put("baseCurrency",cdto.baseCurrency);
      envh.put("TellerNo",tcdto.TellerNo);
      envh.put("TxDate",tcdto.TxDate);
      envh.put("TellerStatus",tcdto.TellerStatus);
      envh.put("Currency01",tcdto.Currency01);
      envh.put("Amount01",tcdto.Amount01);
      envh.put("SijaeOpenFlag","*"); // 10:OPEN , 20:CLOSE

      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        String val = p.getProperty(key);
        envh.put(key,val);
      }

      /*
      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        System.out.println(key+":"+envh.get(key));
      }
      */

      return true;
    }
    catch(Exception e)
    {
      Logging.getInstance().eprintf(10,e);
      return false;
    }
  }

  public void setSijaeOpenFlag(String flag)
  {
    this.envh.put("SijaeOpenFlag",flag);
  }
  /**
    saving config.ini
    @return boolean ���� ���� ����
    */
  public boolean savingINI()
  {
    Properties p = null;
    FileOutputStream fos = null;
    try
    {
      p = new Properties();
      fos = new FileOutputStream(filename);
      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        String val = (String)envh.get(key);
        p.setProperty(key, val);
      }
      p.store(fos, "LOGIN/SIJAEOPEN REFERENCE [ConfigReference]");
      fos.close();
      return true;
    }
    catch(Exception e)
    {
      Logging.getInstance().eprintf(10,e);
      try{
        fos.close();
      }catch(Exception ex){}
      return false;
    }
  }

  public static void main(String args[] ) throws IOException{
    EnvironmentValuePropertySavingToFile senv = new EnvironmentValuePropertySavingToFile("ATM0238001");
    IOBoundCDTO kk = new IOBoundCDTO();
    IOBoundTel80004CDTO kk1 = new IOBoundTel80004CDTO();

    kk.bankCode = "03";
    kk.bizDate = "20021210";
    senv.setCosesCommonDTO(kk);
    senv.setIOBoundTel80004CDTO(kk1);
    senv.savingINI();
    senv.loadingINI();
  }
}

