package wsj.util.zip;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.Vector;
import java.util.zip.ZipOutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.zip.ZipEntry;

public class Zip
{
  public static void main(String[] argv)
                          throws Exception {
  if (argv.length != 2)
    {
      System.out.println(
             "usage: java example.data.Zip <source file/dir name> <target file name>");
      return;
    }

    Zip app = new Zip();
    app.EP(argv[0], argv[1]);
  }

  public void EP(String source, String target)
                          throws Exception {
      Vector files = makeFiles(source);

      ZipOutputStream targetStream =
        new ZipOutputStream( new FileOutputStream(target) );

      //gogo
      File cur = null;
      String baseDir = null;
      Iterator i = files.iterator();

      while( i.hasNext() )
      {
        cur = (File)i.next();

        if( baseDir == null)
        {
          String[] pathStack =
            cur.toString().split( "\\" + File.separator );

          baseDir = pathStack[0] + "\\";
        }

        append( targetStream, baseDir, cur );
      }

      targetStream.closeEntry();
      targetStream.close();
  }

  public Vector makeFiles(String rootName)
                        throws Exception{
    Vector files = new Vector();

    File root = new File(rootName);

    if(root.isDirectory())
    { // Directory Case
      files.addAll( getSubFiles(root) );
    }
    else
      files.add( root );

    return files;
  }

  public Vector getSubFiles(File directory) {
    Vector files = new Vector();
    int i;

    File[] list = directory.listFiles();

    for(i=0; i < list.length; i++)
    {
      if( list[i].isDirectory() )
      { //directory case
        files.addAll( getSubFiles( list[i] ) );
      }else{
        files.add( list[i] );
      }
    }

    return files;
  }

  public void append(ZipOutputStream targetStream, String baseDir, File source)
                        throws Exception {
    FileInputStream sourceStream = new FileInputStream(source);
    ZipEntry zipEntry =  new ZipEntry( source.toString().substring(
                           baseDir.length() ) ) ;

    System.out.println(zipEntry );
    targetStream.putNextEntry( zipEntry );

    byte[] readBuffer = new byte[4096];
    int nRead;
    while( (nRead = sourceStream.read(readBuffer, 0, 4096)) != -1)
        targetStream.write(readBuffer, 0, nRead);

    sourceStream.close();
  }
}
