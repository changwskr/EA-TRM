package wsj.util.zip;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.zip.ZipFile;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;

public class UnZip {
  public static ZipFile zipFile;
  public static final int EOF = -1;

  public static void main( String argv[] )
                           throws Exception{
    if( argv.length != 1 )
    {
      System.out.println( "Usage: java example.data.UnZip [zipfile]" );
      return;
    }

    Enumeration enum;

    zipFile = new ZipFile( argv[0] );

    //���͸� �����
    enum = zipFile.entries();
    while( enum.hasMoreElements() ) {
      ZipEntry target = (ZipEntry)enum.nextElement();

      String[] stack = target.toString().split("\\" + File.separator);
      if( stack.length > 1)
      {
        forceDirectory(stack, target.isDirectory());
      }
    }

    //���������ϱ�
    enum = zipFile.entries();
    while( enum.hasMoreElements() ) {
      ZipEntry target = (ZipEntry)enum.nextElement();
      System.out.print( target.getName() );
      saveEntry( target );
      System.out.println( "...Unpacked" );
    }
  }

  public static void forceDirectory(String[] stack, boolean isDir)
  {
    String path = new String();
    int offset = 0;
    if(!isDir)
      offset = 1;

    for(int i=0; i < stack.length - offset; i++) {
      path += stack[i] + File.separator;
      File file = new File(path);

      if( !file.exists() ) {
        System.out.print( path  );
        file.mkdirs();
        System.out.println( "...Directory Created");
      }
    }
  }

  public static void saveEntry( ZipEntry target )
                      throws Exception {
    if( !target.isDirectory() ) {
      File file = new File( target.getName() );

      InputStream inputStream = zipFile.getInputStream( target );
      BufferedInputStream bufferedInputStream = new BufferedInputStream( inputStream );

      //�̹� �ִ� �����̸� upzip���� �ʴ´�.
      if( file.exists() )
        return;

      FileOutputStream fileOutputStream = new FileOutputStream( file );
      BufferedOutputStream bufferedOutputStream = new BufferedOutputStream( fileOutputStream );

      int c;
      while( ( c = bufferedInputStream.read() ) != EOF ) {
        bufferedOutputStream.write( (byte)c );
      }

      bufferedOutputStream.close();
      fileOutputStream.close();
    }
  }
}
