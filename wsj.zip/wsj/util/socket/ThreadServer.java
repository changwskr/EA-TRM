package wsj.util.socket;

import java.lang.Thread;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ThreadServer extends Thread{

  Socket client_socket = null;

  public ThreadServer(Socket s) {
    client_socket = s;
  }

  public void run(){
    BufferedReader br = null;
    String line = null;

    try {
      br= new BufferedReader(new InputStreamReader(client_socket.getInputStream()));
      while(true){
        line = br.readLine();
        if (line != null)
          System.out.println ("READ(" + Thread.currentThread().toString() + "): " + line );
        else
          break;
      }
    }
    catch (Exception ex){
      System.out.println ("Error : " + ex.toString());
    }
    finally {
      try {
        client_socket.close();
      }
      catch (Exception e){}
    }
  }

  public static void main(String[] args) {
    int port = 7979;
    ServerSocket ss = null;
    Socket client_socket = null;
    BufferedReader br = null;
    String line = null;

    System.out.println ("Echo Server Start !");

    try {
      ss = new ServerSocket(port);
      ss.setReuseAddress(true);
      while(true){
        ThreadServer te = new ThreadServer(ss.accept());
        System.out.println("New Clinet Accepted!");
        te.start();
      }
    }
    catch (Exception ex){
      System.out.println ("Error : " + ex.toString());
    }
    finally {
      try {
        ss.close();
      }
      catch (Exception e){}
    }
    System.out.println ("Echo Server End !");
  }
}