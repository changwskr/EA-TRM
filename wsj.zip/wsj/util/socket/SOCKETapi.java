package wsj.util.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.util.*;
import java.text.*;
import java.io.*;
import wsj.util.bit.ByteUtil;
import wsj.util.log.Logging;

public class SOCKETapi {
    //:~ ���ϼ��� OPEN / CLOSE
    public static final ServerSocket SERVERopen(int PORT)
        throws IOException,UnknownHostException
    {
      ServerSocket server = new ServerSocket(PORT);
      return ( server );
    }
    public static final void SERVERclose(ServerSocket server)
        throws IOException,UnknownHostException
    {
      server.close();
    }
    //:~ ���ϼ��� ACCEPT
   public static final Socket SOKaccept(ServerSocket server)
        throws IOException,UnknownHostException
    {
      Socket sok = server.accept ();
      return( sok );
    }
    //:~ ���Ͻ�Ʈ�� ����
    public static final InputStream SOKgetstris(Socket s)
        throws IOException,UnknownHostException
    {
      InputStream dis = s.getInputStream();
      return dis;
    }
    public static final OutputStream SOKgetstros(Socket s)
        throws IOException,UnknownHostException
    {
      OutputStream dos = s.getOutputStream ();
      return dos;
    }
    public static final BufferedInputStream SOKgetbis(Socket s)
        throws IOException,UnknownHostException
    {
      BufferedInputStream dis = new BufferedInputStream (s.getInputStream ());
      return dis;
    }
    public static final BufferedOutputStream SOKgetbos(Socket s)
        throws IOException,UnknownHostException
    {
      BufferedOutputStream dos = new BufferedOutputStream (s.getOutputStream ());
      return dos;
    }
    public static final DataInputStream SOKgetstrdis(Socket s)
        throws IOException,UnknownHostException
    {
      DataInputStream dis = new DataInputStream (
          new BufferedInputStream (s.getInputStream ()));
      return dis;
    }
    public static final DataOutputStream SOKgetstrdos(Socket s)
        throws IOException,UnknownHostException
    {
      DataOutputStream dos = new DataOutputStream (
          new BufferedOutputStream (s.getOutputStream ()));
      return dos;
    }
    public static final BufferedReader SOKgetstrbis(Socket s)
        throws IOException,UnknownHostException
    {
      BufferedReader bis = new BufferedReader(
          new InputStreamReader(s.getInputStream()));
      return bis;
    }
    public static final PrintWriter SOKgetstrpos(Socket s)
        throws IOException,UnknownHostException
    {
      PrintWriter pos = new PrintWriter(s.getOutputStream());
      return pos;
    }
    public static final ObjectInputStream SOKgetstrois(Socket s)
        throws IOException,UnknownHostException
    {
      ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
      return ois;
    }
    public static final ObjectOutputStream SOKgetstroos(Socket s)
        throws IOException,UnknownHostException
    {
      ObjectOutputStream dos = new ObjectOutputStream(s.getOutputStream());
      return dos;
    }
    //:~ �޽��� �ۼ���
    public static final String SOKrecv (DataInputStream dis)
        throws IOException
    {
      String message = null;
      message = dis.readUTF();
      return message;
    }
    public static final void SOKsend ( DataOutputStream dos, String message )
        throws IOException
    {
      dos.writeUTF (message);
      dos.flush ();
    }
    public static final Object SOKrecv (ObjectInputStream ooi)
        throws IOException,ClassNotFoundException
    {
      Object obj;
      obj = ooi.readObject();
      return obj;
    }
    public static final void SOKsend (ObjectOutputStream oos,Object obj)
        throws IOException
    {
      oos.writeObject( obj );
      //oos.flush ();
      oos.reset();
    }
    //BufferedReader dis,PrintWriter dos
    public static final void SOKsend(PrintWriter pos,String tmp)
        throws IOException
    {
      pos.println(tmp) ;
    }
    public static final String SOKrecv(BufferedReader pos,String tmp)
        throws IOException
    {
      return(pos.readLine());
    }
    /**
     * <p>Title: </p>
     * <p>Description: ����Ÿ��Ʈ�����κ��� ����Ÿ�� ����Ʈ������ �д´�.</p>
     * <p>Copyright: Copyright (c) 2002</p>
     * <p>Company: IMSsystem</p>
     * @author ��  ���
     * @version 1.0
     */

    public static final String read_data(DataInputStream  dis)
        throws IOException {
      byte[] b;
      byte[] bytebuff ;
      long size;
      int div;
      int slice;
      int rest;
      long st=0;
      long et=0;

      try {
        size=dis.readLong();
        bytebuff = new byte[(int)size];
        div=dis.readInt();
        rest=(int)(size%div);
        slice=(int)((size-rest)/div);

        st=System.currentTimeMillis();

        int i=0;
        int sp=0;
        if(slice!=0)
          for(i=0;i<div;i++){
            b=new byte[slice];
            dis.read(b);
            System.arraycopy(b,0,bytebuff,sp,slice);
            sp = sp+slice;
          }

        //���ҵ� ������ ũ���� �迭
        b=new byte[rest];
        //������ ������ ����
        dis.read(b);
        System.arraycopy(b,0,bytebuff,sp,rest);

        //���� ���� �ð�
        et=System.currentTimeMillis();
        //���� �� �ҿ�ð�
    //    System.out.println("---------------------------------------------------");
        System.out.println("size:"+size+",div:"+div+",slice:"+slice +",rest:"+rest);
        System.out.println((et-st)+"/milliseconds,readlen/"+bytebuff.length
                           +" readdata[" + new String(bytebuff)+"]");
        if( bytebuff.length != size ){
          throw new IOException("read_data ex::data length not match");
        }
      }catch(IOException ioe){
        ioe.printStackTrace();
        throw new IOException("read_data ex::"+ioe.getMessage());
      }
      return (new String(bytebuff));
    }

    /**
     * <p>Title: </p>
     * <p>Description: ����Ÿ��Ʈ�����κ��� ����Ÿ�� ����Ʈ������ write�Ѵ�.</p>
     * <p>Copyright: Copyright (c) 2002</p>
     * <p>Company: IMSsystem</p>
     * @author ��  ���
     * @version 1.0
     */

    public static final void write_data(DataOutputStream dos,String senddata)
        throws IOException {
      long size;
      int  div;
      int  slice;
      int  rest;
      long st=0;
      long et=0;
      byte[] bytebuffer=null;
      byte[] b;

      try{
        bytebuffer = senddata.getBytes();
        size=bytebuffer.length;
        // woo test
        // div=100;
        div=300;
        rest=(int)(size%div);
        slice=(int)((size-rest)/div);

        int sp=0;
        int ep=0;
        int ii=0;
        dos.writeLong(size);
        dos.writeInt(div);
        st=System.currentTimeMillis();

        if( slice!=0)
          for(ii=0;ii<div;ii++){
            b=new byte[slice];
            System.arraycopy(bytebuffer,sp,b,0,slice);
            sp += slice;
            dos.write(b);
          }
          b=new byte[rest];
          System.arraycopy(bytebuffer,sp,b,0,rest);
          dos.write(b);
          dos.flush();

          et=System.currentTimeMillis();

//        System.out.println("-------------------------------------------------");
          System.out.println("size:"+size+",div:"+div+",slice:"+slice +",rest:"+rest);
          System.out.println((et-st)+"/milliseconds,sendlen/"
                             +bytebuffer.length+" senddata["
                             + new String(bytebuffer)+"]");

      }catch(IOException ioe){
        ioe.printStackTrace();
        throw new IOException("write_data ex::"+ioe.getMessage());
      }
      return;
    }

    /**
     * <p>Title: read_data</p>
     * <p>Description: ����Ÿ��Ʈ�����κ��� ����Ÿ�� ����Ʈ������ read/write �Ѵ�.</p>
     * <p>Copyright: Copyright (c) 2002</p>
     * <p>Company: IMSsystem</p>
     * @author ��  ���
     * @version 1.0
     */

    public static final String read_data (InputStream in) throws IOException {
      byte[] bytebuff;
      try{
        DataInputStream dis = new DataInputStream(in);
        int size=dis.readInt();
        bytebuff = read_data(in,size);
      }
      catch(Exception ioe){
        ioe.printStackTrace();
        throw new IOException("read_data ex::"+ioe.getMessage());
      }
      return new String(bytebuff);
    }


    private static final byte[] read_data(InputStream in, int len) throws Exception {
      java.io.ByteArrayOutputStream bout = new java.io.ByteArrayOutputStream();
      int bcount = 0;
      byte[] buf = new byte[2048];
      while( bcount < len ) {
        int n = in.read(buf,0, len-bcount < 2048 ? len-bcount : 2048 );
        if (n == -1) break;
        bcount += n;
        bout.write(buf,0,n);
      }
      bout.flush();
      return bout.toByteArray();
    }

    // ���������ϴ� ����Ʈ�� ���̸� ���� write�ϰ� ���� byte�� write�Ѵ�.
    public static final void write_byte (OutputStream out,byte[] bytebuff) throws IOException {
      try{
        DataOutputStream dos = new DataOutputStream(out);
        out.write(bytebuff,0,bytebuff.length);
      }
      catch(IOException ioe){
        ioe.printStackTrace();
        throw new IOException("write_byte ex::"+ioe.getMessage());
      }
      return ;
    }

    // ���������ϴ� ����Ʈ�� ���̸� ���� write�ϰ� ���� byte�� write�Ѵ�.
    public static final void write_data (OutputStream out,String senddata) throws IOException {
      byte[] bytebuff = senddata.getBytes();
      try{
        DataOutputStream dos = new DataOutputStream(out);
        int size = bytebuff.length;
        dos.writeInt(size);
        out.write(bytebuff,0,bytebuff.length);
      }
      catch(IOException ioe){
        ioe.printStackTrace();
        throw new IOException("write_data ex::"+ioe.getMessage());
      }
      return ;
    }

        /*
        protected  INPUTAREA SOKSrecv ()
        {
                String message;
                try {
                        inarea = (INPUTAREA) ooi.readObject();
                        System.out.println("--------recv ok----");
                } catch (IOException ex) {
                        return null;
                } catch (ClassNotFoundException ex1) {
                        return null;
                }
                return inarea;
        }
        */
        /*
        protected  boolean SOKSsend (OUTPUTAREA outarea)
        {

                try {
                        oos.writeObject( outarea );
                        oos.flush ();
                        System.out.println(" send ok -----");
                } catch (IOException ex) {
                        return false;
                }
                return true;
        }

        */

    //:~ Ŭ���̾�Ʈ�� ���� ����
    public static final Socket SOCKETopen(String host,int PORT)
        throws IOException,UnknownHostException
    {
      Socket sokc = new Socket(host, PORT);
      return sokc;
    }

    //:~ �����ڿ� ��ȯ
    public static final void SOCKETclose(Socket sokc)
        throws IOException
    {
      sokc.close() ;
    }

    //:~ Ÿ�Ӿƿ�
    public static final void SOKCKETtimeout(Socket s , int psMilliseconds)
        throws SocketException
    {
      s.setSoTimeout(psMilliseconds);
    }

    //:~ ��Ʈ���ݱ�
    public static final int closeStream(DataInputStream dis,DataOutputStream dos,Socket sok){
      try{
        dos.close();
        dis.close();
        sok.close();
      }catch(Exception e){
        e.printStackTrace();
        return -1;
      }
      return 0;
    }

    public static final int closeStream(ObjectInput dis,ObjectOutput dos,Socket sok){
      try{
        dos.close();
        dis.close();
        sok.close();
      }catch(Exception e){
        e.printStackTrace();
        return -1;
      }
      return 0;
    }
    public static final int closeStream(InputStream dis,OutputStream dos,Socket sok){
      try{
        dos.close();
        dis.close();
        sok.close();
      }catch(Exception e){
        e.printStackTrace();
        return -1;
      }
      return 0;
    }
    public static final int closeStream(BufferedReader dis,PrintWriter dos,Socket sok){
      try{
        dos.close();
        dis.close();
        sok.close();
      }catch(Exception e){
        e.printStackTrace();
        return -1;
      }
      return 0;
    }

    public static final Object read_data (ObjectInputStream ooi)
        throws IOException,ClassNotFoundException
    {
      Object obj;
      obj = ooi.readObject();
      return obj;
    }

    public static final void write_data (ObjectOutputStream oos,Object obj)
        throws IOException
    {
      oos.writeObject( obj );
      oos.flush ();
      oos.reset();
    }



    // ���������ϴ� ����Ʈ�� ���̸� ���� write�ϰ� ���� byte�� write�Ѵ�.
    // ���н������� ������ �� ���� �������̸� 5����Ʈ�� ���� ������ 00005�̷������� ����
    // ��������Ÿ�� ������.
    public static final void jni_write_data (OutputStream out,String senddata) throws IOException {
      byte[] bytebuff = senddata.getBytes();
      try{
        //�����ٵ���Ÿ�� ���̸� ���� �����Ѵ�.
        int size = bytebuff.length;
        String sendlen_buff = ZeroPlusToString(new Integer(size).toString(),5);
        byte[] bytebuff2 = sendlen_buff.getBytes();
        out.write(bytebuff2,0,bytebuff2.length);
        //System.out.println(":::>> send_len : "+ sendlen_buff);

        //������Ÿ�� �����Ѵ�.
        out.write(bytebuff,0,bytebuff.length);
      }
      catch(IOException ioe){
        ioe.printStackTrace();
        Logging.getInstance().eprintf(10,ioe);
        throw new IOException("write_data ex::"+ioe.getMessage());
      }
      return ;
    }
    public static String ZeroPlusToString(String str,int size) {
      StringBuffer tt = new StringBuffer();
      for ( int i = 1; i <= size ; i ++ )
        tt.append('0');
      DecimalFormat fmt = new DecimalFormat(tt.toString());
      fmt = new DecimalFormat(tt.toString());
      return(fmt.format(Integer.valueOf(str).intValue()));
    }
    public static final String jni_read_data (InputStream in) throws IOException {
      byte[] bytebuff;
      try{
        byte[] bytebuff2= null;
        bytebuff2 = read_data(in,5);
        //Logging.getInstance().printf(1, "SOCKETapi->:1:>> recv_len:["+ new String(bytebuff2) +"]");
        int size = Integer.valueOf(new String(bytebuff2)).intValue();
        //Logging.getInstance().printf(1, "SOCKETapi->:::>> recv_len:"+ size);
        bytebuff = read_data(in,size);
      }
      catch(Exception ioe){
        ioe.printStackTrace();
        Logging.getInstance().eprintf(10,ioe);
        throw new IOException("read_data ex::"+ioe.getMessage());
      }
      return new String(bytebuff);
    }

    /////////////////////////////////////////////////////////////////////////
    // �������� ����ȣ��Ʈ���� �ŷ��� ���� ����
    // 8����Ʈ : ȭ���ȣ
    // 4����Ʈ : ������������Ÿ ���̰� ��Ʈ������ �ѱ涧
    // ������������Ÿ
    /////////////////////////////////////////////////////////////////////////
    public static final String jni_read_data2 (InputStream in) throws IOException {
      byte[] bytebuff;
      try{
        byte[] bytebuff2= null;
        //ȭ���ȣ8����Ʈ
        bytebuff2 = read_data(in,8);
        //System.out.println( "SOCKETapi->:1:>> recv_len:["+ new String(bytebuff2) +"]");
        //�ǵ���Ÿ����4����Ʈ
        byte[] bytebuff3= null;
        bytebuff3 = read_data(in,4);
        //��������Ÿ
        int size = Integer.valueOf(new String(bytebuff3)).intValue();
        bytebuff = read_data(in,size);
      }
      catch(Exception ioe){
        ioe.printStackTrace();
        System.out.println(ioe);
        throw new IOException("read_data ex::"+ioe.getMessage());
      }
      return new String(bytebuff);
    }
    /////////////////////////////////////////////////////////////////////////
    // �������� ����ȣ��Ʈ���� �ŷ��� ���� ����
    // 8����Ʈ : ȭ���ȣ
    // 4����Ʈ : ������������Ÿ ���̰� ���̳ʸ��� �ö�
    // ������������Ÿ
    /////////////////////////////////////////////////////////////////////////
    public static final String jni_read_data3 (InputStream in) throws IOException {
      byte[] bytebuff;
      try{
        byte[] bytebuff2= null;
        //ȭ���ȣ8����Ʈ
        bytebuff2 = read_data(in,8);
        //System.out.println( "SOCKETapi->:1:>> displayno:["+ new String(bytebuff2) +"]");
        //�ǵ���Ÿ����4����Ʈ
        byte[] bytebuff3= null;
        bytebuff3 = read_data(in,4);
        int size = ByteUtil.getint(bytebuff3,0);
        //System.out.println( "SOCKETapi->:2:>> realdatalen:["+ size +"]");
        //��������Ÿ
        bytebuff = read_data(in,size);
      }
      catch(Exception ioe){
        ioe.printStackTrace();
        System.out.println(ioe);
        throw new IOException("read_data ex::"+ioe.getMessage());
      }
      return new String(bytebuff);
    }
}