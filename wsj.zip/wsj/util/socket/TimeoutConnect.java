package wsj.util.socket;

import java.net.Socket;
import java.io.IOException;

public class TimeoutConnect implements java.lang.Runnable {
  long timeout;
  String host;
  int port;
  Socket socket = null;
  boolean hasTimedOut = false;

  public TimeoutConnect( long timeout )
  {
    this.timeout = timeout;
  }

  public Socket createSocket(String host, int port) throws Exception
  {
    this.host = host;
    this.port = port;
    this.socket = null;

    // �����带 �����Ͽ� �����Ų��.
    Thread r = new Thread(this);
    r.setDaemon(true);
    r.start();

    // Ÿ�� �ƿ� �ð����� �ش� �����尡 �����⸦ ��ٸ���.
    // ���� ������ ������ �����带 ���� �Ѵ�.
    try{
      r.join(timeout);
    } catch (java.lang.InterruptedException ie){
      r.interrupt();
    }

    if (socket == null){
      hasTimedOut = true;
      throw new IOException("Socket connection timed out: " + host + ":" + port);
    }
    return socket;
  }

  public void run()
  {
    try {
      socket = new Socket(host, port);
    }
    catch (IOException ioe){
    }

    if (hasTimedOut){
      try {
        if (socket != null) socket.close();
      }
      catch (IOException ioe){
      }

      socket = null;
    }
    return;
  }

  public static void main(String[] args) {
    try {
      TimeoutConnect timeoutConnect = new TimeoutConnect(1000);
      timeoutConnect.createSocket("www.yahoo.co.kr1",23);
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
}