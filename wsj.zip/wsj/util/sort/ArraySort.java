package wsj.util.sort;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;

public class ArraySort {

  public ArraySort() {
  }
   /* @ int [] array�� �ִ� ������ ��Ʈ�ϱ�
  *
  *
  */

  public static final int [] SortINTarray(int num[])
  {
    int tar [];
    tar = num;
    Arrays.sort(tar);
    return tar;
  }

  public static void main(String[] args) {
    ArraySort arraySort1 = new ArraySort();
  }
}