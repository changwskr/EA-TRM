package wsj.util.database;


import java.sql.*;
import java.io.*;
import java.util.*;

/**
 * <PRE>
 * Class    : DBMSmanager
 * Function :
 * Comment  : nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn<BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

import wsj.util.properties.ConfigFile;

public class DBMSmanager {

        // ȯ������
/*
        public static String user = ConfigFile.getInstance("C:\\env\\env.properties").GetEnvValue("USER");
        public static String password = ConfigFile.getInstance("C:\\env\\env.properties").GetEnvValue("PASSWD");
        public static String dburl = ConfigFile.getInstance("C:\\env\\env.properties").GetEnvValue("URL");
        public static String driverClass = ConfigFile.getInstance("C:\\env\\env.properties").GetEnvValue("DIRIVER");;
        public static String driverURL = ConfigFile.getInstance("C:\\env\\env.properties").GetEnvValue("DBURL");
        public static Connection connection;
*/
  public static String user  ;
  public static String password  ;
  public static String dburl  ;
  public static String driverClass  ;
  public static String driverURL ;
  public static Connection connection;

        ////////////////////////////////////////////////////////////////////
        //
        ////////////////////////////////////////////////////////////////////
        public static void connect() {
        try {
            Class.forName(driverClass);
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }

        try {
            Properties properties = new Properties();
            properties.put("user", user);
            properties.put("password", password);
            connection = java.sql.DriverManager.getConnection(driverURL, properties);
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }

    public static void disconnect() {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }


    public static void disconnect(Connection connection) {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }



        ////////////////////////////////////////////////////////////////////////////
        // �ϳ��� ����Ÿ���̽� ������ ���ؿ´�
        ////////////////////////////////////////////////////////////////////////////
        public static Connection dbConn() {
                   Connection conn = null;

                   try {
                 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
                 conn = DriverManager.getConnection (dburl, user, password);
                   } catch ( Exception e ) {
                           System.out.println("DriverManager.getConnection Exception ");
                           return null;
                   }
                   return conn;
        }




        ////////////////////////////////////////////////////////////////////////////
        // �ϳ��� ����Ÿ���̽� ������ ���ؿ´�
        ////////////////////////////////////////////////////////////////////////////
        public static Connection dbConn(String user,String passwd) {
                   Connection conn = null;

                   try {
                 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
                 conn = DriverManager.getConnection (dburl , user, passwd);
                   } catch ( Exception e ) {
                           System.out.println("DriverManager.getConnection Exception ");
                           return null;
                   }
                   return conn;
        }

    public static void dbClose(Connection connection) {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }




}


