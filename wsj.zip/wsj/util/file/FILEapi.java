package wsj.util.file;

import java.io.*;
import java.text.*;
import java.util.*;


public class FILEapi {

  public String get_only_filename__except_ext_from_filepath(String path_filename)
  {
    return get_only_filename_except_ext(get_only_filename_from_filepath(path_filename));
  }

  public String get_only_filename_from_filepath(String path_filename)
  {
    String filename=null,directory=null;
    int lastSlash = path_filename.lastIndexOf('/');
    filename = path_filename.substring(lastSlash+1);
    directory = path_filename.substring(0, lastSlash);
    return filename;
  }

  public String get_only_filename_except_ext(String pfilename)
  {
    String filename=null,directory=null;
    int lastSlash = pfilename.lastIndexOf('.');
    //filename = pfilename.substring(lastSlash+1); - class
    //filename = pfilename.substring(lastSlash); - .class
    filename = pfilename.substring(0,lastSlash);
    return filename;
  }

  private static String getFILENAMEabsolutePath(String path,String tfileName)
  {
    DirectoryFinder dirFinder = new DirectoryFinder(path);
    while (dirFinder.hasNextDirectory()) {
      File dir = dirFinder.nextDirectory();
      String subpath = dir.getAbsolutePath();
      FileFinder fileFinder = new FileFinder(subpath, -1);
      while (fileFinder.hasNextFile()) {
        File file = fileFinder.nextFile();
        String filename = file.getAbsolutePath();
        if (file.getName().equals(tfileName)){
          System.out.println("--------"+file.getName()+" "+file.getAbsolutePath() );
          return file.getAbsolutePath();
        }
      }
    }
    return null;
  }

  // -------------------------------------------------------------------
  // _cpfile2file : copy iname oname
  //                ex) iname == "./kk.txt" oname=="./kk.txt1"
  // rtn : ������ ������ ũ�� , error : -1
  // -------------------------------------------------------------------

  public static final int cpFile2File(String iname,String oname)
  {
    int fsize=0;

    try
    {
      FileInputStream  ifp = new FileInputStream(iname);
      FileOutputStream ofp = new FileOutputStream(oname);
      int ch;

      while ((ch=ifp.read()) > -1)
      {
        ofp.write(ch);
        fsize++;
      }
      ifp.close();
      ofp.close();

    }  catch (IOException e){
      System.err.println("I/O Exception error." + e.getMessage());
      return -1;
    }

    return fsize;
  }

  // Ư�� ���丮�� ������ ��� �����
  // args : C:\windows
  public static final void deleteDIR(String args) throws Exception
  {

    File directory = new File( args );

    if(!directory.isDirectory())
    {
      System.err.println( args + " is not directory" );
      return;
    }

    deleteAll( directory );
  }

  public static final void deleteAll( File directory )
  {
    File[] files = directory.listFiles();

    for(int i=0; i < files.length;i++){
      if( files[i].isDirectory() )
        deleteAll( files[i] );
      else
        files[0].delete();
    }
    directory.delete();
  }



  // -------------------------------------------------------------------
  // appendFileWrite : write a file (mode append)
  //                ex) path2filename=="./kk.txt"
  //                    writebuff : ����� string
  //			-1 : error , 0 : success
  // -------------------------------------------------------------------

  public static final int appendFileWrite (String path2filename,String writebuff)
  {
  /*
  if ( writebuff.length() > 2024 ){
   String tmpbuff;
   tmpbuff=writebuff.substring(1,2024);

   try {
       FileOutputStream fos = new FileOutputStream(path2filename, true);
       PrintStream ps = new PrintStream(fos);
       ps.print(tmpbuff+'\n');
       ps.close();
     }catch(Exception e){
       Syste.out.println("appendFileWrite Exception");
       e.printStackTrace();
       return(-1);
     }
  }

  else{
   try {
       FileOutputStream fos = new FileOutputStream(path2filename, true);
       PrintStream ps = new PrintStream(fos);
       ps.print(writebuff+'\n');
       ps.close();
      }catch(Exception e){
       e.printStackTrace();
       Syste.out.println("appendFileWrite Exception");
      }
  }
  */

    try {
      FileOutputStream fos = new FileOutputStream(path2filename, true);
      PrintStream ps = new PrintStream(fos);
      ps.print(writebuff+'\n');
      ps.close();
    }catch(Exception e){
      e.printStackTrace();
      //System.out.println("appendFileWrite Exception");
      return -1;
    }
    return 0;
  }


  public static final String FILEabsolutpath(String fname)
  {
    String strtmp=null;

    try {
      File f = new File(fname);

      if(f.exists());
      else
        throw new IOException(fname + "Not Found");

      strtmp = f.getAbsolutePath();

    }
    catch(Exception ex) {
      System.out.println("FILEabsolutpath Exception :: " + ex.getMessage() );
      System.out.println("FILEabsolutpath FileName  :: " + fname );
      return null;
    }

    return strtmp;
  }


  // @ Comment : ������ ���°� �ٲ���� üŷ�Ѵ�.
  //
  public static final long FILElastmodified ( String fname )
  {

    long strtmp = -1;

    try {

      File f = new File(fname);

      if(f.exists());
      else
        throw new IOException(fname + "Not Found");

      strtmp = f.lastModified();

    }
    catch(Exception ex) {
      System.out.println("FILEabsolutpath Exception :: " + ex.getMessage() );
      System.out.println("FILEabsolutpath FileName  :: " + fname );
      return -1;
    }

    return strtmp;

  }

  public static final boolean DIRmake(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists()) {
        throw new IOException(fname + "DIR is already existing");
      }
      f.mkdirs();
      if(!f.isDirectory())
        throw new IOException(fname + "DIR does not make dir");
    }
    catch(Exception ex) {
      System.out.println("DIRmake Exception :: " + ex.getMessage() );
      System.out.println("DIRmake FileName  :: " + fname );
      return false;
    }
    return true;

  }


  public static final long FILEsize(String fname)
  {
    long strtmp=-1;

    try {
      File f = new File(fname);

      if(f.exists());
      else
        throw new IOException(fname + "Not Found");
      strtmp=f.length();
    }
    catch(Exception ex) {
      System.out.println("FILEabsolutpath Exception :: " + ex.getMessage() );
      System.out.println("FILEabsolutpath FileName  :: " + fname );
      return -1;
    }
    return strtmp;
  }


  public static final boolean FILEexist(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists());
      else
        return false;
    }
    catch(Exception ex) {
      System.out.println("FILEexist Exception :: " + ex.getMessage() );
      System.out.println("FILEexit FileName  :: " + fname );
      return false;
    }
    return true;
  }


  public static final boolean FILEdel(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists());
      else
        return false;

      f.delete();
    }
    catch(Exception ex) {
      System.out.println("FILEdel Exception :: " + ex.getMessage() );
      System.out.println("FILEdel FileName  :: " + fname );
      return false;
    }
    return true;
  }


  public static final boolean FILEmove(String orgfname,String tarfname)
  {
    if( FILEcopy(orgfname,tarfname) ){
      if( FILEdel(orgfname) ){
        return true;
      }
      else
        return false;
    }
    else{
      return false;
    }

  }

  public static final void FILEinfo (File f)
  {
    System.out.println(
        " Absolute path : " + f.getAbsolutePath() +
        "\n     Can read : " + f.canRead() +
        "\n    Can write : " + f.canWrite() +
        "\n      getName : " + f.getName() +
        "\n    getParent : " + f.getParent() +
        "\n      getPath : " + f.getPath() +
        "\n       length : " + f.length() +
        "\n lastModified : " + f.lastModified());

    if(f.isFile())
      System.out.println("it's a file");
    else if(f.isDirectory())
      System.out.println("it's a directory");
  }

  public static final boolean FILErename(String oldfn,String newfn)
  {

    try {

      File old = new File(oldfn), rname = new File(newfn);

      old.renameTo(rname);

    }
    catch(Exception ex) {

      System.out.println("FILErename Exception :: " + ex.getMessage() );
      System.out.println("FILErename FileName  :: " + oldfn + " " + newfn );
      return false;

    }

    return true;

  }

  public static final boolean FILEcopy(String oldfn,String newfn)
  {

    try {
      BufferedReader in = new BufferedReader(new FileReader(oldfn));
      PrintWriter out = new PrintWriter(
          new FileOutputStream(newfn));

      String strtmp;
      while( (strtmp=in.readLine()) != null ) {
        //L.p(strtmp);
        out.println(strtmp);
      }

      in.close();
      out.close();
    }
    catch(Exception ex) {

      System.out.println("FILEcopy Exception :: " + ex.getMessage() );
      System.out.println("FILEcopy FileName  :: " + oldfn + " " + newfn );
      return false;

    }

    return true;

  }

  private final static String usage =
      "Usage:CifFILEapi path1 ...\n" +
      "Creates each path\n" +
      "Usage:CifFILEapi -d path1 ...\n" +
      "Deletes each path\n" +
      "Usage:CifFILEapi -r path1 path2\n" +
      "Renames from path1 to path2\n";


  private static void usage() {
    System.err.println(usage);
    System.exit(1);
  }


  private static void fileData(File f) {

    System.out.println(
        "Absolute path: " + f.getAbsolutePath() +
        "\n Can read: " + f.canRead() +
        "\n Can write: " + f.canWrite() +
        "\n getName: " + f.getName() +
        "\n getParent: " + f.getParent() +
        "\n getPath: " + f.getPath() +
        "\n length: " + f.length() +
        "\n lastModified: " + f.lastModified());


    if(f.isFile())
      System.out.println("it's a file");
    else if(f.isDirectory())
      System.out.println("it's a directory");
  }

  public static synchronized void FCreate(String FNAME,String contentToWrite)
  {
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      fos = new FileOutputStream(FNAME, true);
      ps = new PrintStream(fos);
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }


  public static  void main(String[] args) {

    FILEapi.getFILENAMEabsolutePath("C:\\jws\\ATMPPP\\classes","BoundArea.class");


    FILEabsolutpath("kkk.in");
    FILEcopy("kkk.in","kkk.in.txt");
    DIRmake("C:\\MYTEST\\CHB\\src\\����\\aa");
    System.out.println( FILElastmodified("kkk.in"));



    if(args.length < 1) usage();

    if(args[0].equals("-r")) {
      if(args.length != 3) usage();

      File old = new File(args[1]),
      rname = new File(args[2]);

      old.renameTo(rname);
      fileData(old);
      fileData(rname);
      return; // Exit main
    }

    int count = 0;
    boolean del = false;
    if(args[0].equals("-d")) {
      count++;
      del = true;
    }
    for( ; count < args.length; count++) {
      File f = new File(args[count]);
      if(f.exists()) {
        System.out.println(f + " exists");
        if(del) {
          System.out.println("deleting..." + f);
          f.delete();
        }
      }
      else { // Doesn't exist
        if(!del) {
          f.mkdirs();
          System.out.println("created " + f);
        }
      }
      fileData(f);
    }

  }

  public static ArrayList getFileCount( File dir )
  {
    ArrayList ar = new ArrayList();
    File[] files = dir.listFiles();

    for(int i=0; i<files.length; i++)
    {
      File f = files[i];
      if( f.isDirectory() ){

      }
      else{
        ar.add(i,f.getName());
      }
    }
    return ar;
  }

  /*
  public int getFileCount( File dir )
  {
    int count = 0;
    File[] files = dir.listFiles();
    for(int i=0; i<files.length; i++)
    {
      File f = files[i];
      if( f.isDirectory() )
        count += recursiveDirectory(f);
      else
        count++;
    }
    return count;
  }
  */


}