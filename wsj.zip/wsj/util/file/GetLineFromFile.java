package wsj.util.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;

public class GetLineFromFile {

  public GetLineFromFile() {
  }
  /////////////////////////////////////////////////////////////////////////////
// �ϳ��� ������ �о� ���δ������� ����Ѵ�.
/////////////////////////////////////////////////////////////////////////////
  static void GetLineStrFromFile(){

    String infile = ".\\test.in";
    String line = null;

    try {
      BufferedReader in = new BufferedReader(new FileReader(infile));

      // ������ ���δ����� �����ͼ� �Ľ��� �Ѵ�.
      for(;;)
      {
        if( (line = getFileLine(in)) != null ){
          System.out.println(line);
        }
        else{
          in.close();
          break;
        }
      }
    }
    catch(IOException ioe) {
      System.out.println("cmdFser IOException " + ioe.getMessage() );
      ioe.printStackTrace();
    }
    return ;
  }

  static String getFileLine(BufferedReader in){

    try {
      String line = null;
      if( (line=in.readLine()) != null )
        return line;
      else
        return null;
    }
    catch(IOException ioe) {
      System.out.println("cmdFser IOException " + ioe.getMessage() );
      ioe.printStackTrace();
    }
    return null;
  }

///////////////////////////////////////////////////////////////////////////// < ��


  public void readlinefromfile() throws IOException
  {
    BufferedReader in = new BufferedReader( new FileReader("filename") );

    for( String line; (line = in.readLine()) != null ; )
      System.out.println(line);
  }


  public static void main(String[] args) {
    GetLineFromFile getLineFromFile1 = new GetLineFromFile();
  }
}