package wsj.util.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;

public class FileFinder {

  private File dir;

  private FilenameFilter filter;

  private List files = new ArrayList();

  private int currentIndex = 0;

  public FileFinder(String path) {
    this(path, null, 1);
  }

  public FileFinder(String path, int level) {
    this(path, null, level);
  }

  public FileFinder(String path, FilenameFilter filter) {
    this(path, filter, 1);
  }

  public FileFinder(String path, FilenameFilter filter, int level) {
    this.dir = new File(path);
    this.filter = filter;
    if (filter != null) {
      findFile(dir, dir.listFiles(filter), level);
    } else {
      findFile(dir, dir.listFiles(), level);
    }
  }

  private void findFile(File path, File[] list, int level) {
    --level;
    for (int i = 0; i < list.length; i++) {
      File file = list[i];
      if (file.isDirectory()) {
        if (level > 0 || level <= -1) {
          findFile(file,
                   (filter == null)
                   ? file.listFiles()
                   : file.listFiles(filter), level);
        }
      } else {
        files.add(file);
      }
    }
  }

  public boolean hasNextFile() {
    if (currentIndex < files.size()) {
      return true;
    }
    return false;
  }

  public File nextFile() {
    File file = (File) files.get(currentIndex);
    currentIndex++;
    return file;
  }

}

