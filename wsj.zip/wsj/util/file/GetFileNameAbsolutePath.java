package wsj.util.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class GetFileNameAbsolutePath {

  public GetFileNameAbsolutePath() {
  }

  public static final String getFILENAMEabsolutePath(String path,String tfileName)
  {
    DirectoryFinder dirFinder = new DirectoryFinder(path);
    while (dirFinder.hasNextDirectory()) {
      File dir = dirFinder.nextDirectory();
      String subpath = dir.getAbsolutePath();
      FileFinder fileFinder = new FileFinder(subpath, -1);
      while (fileFinder.hasNextFile()) {
        File file = fileFinder.nextFile();
        String filename = file.getAbsolutePath();
        if (file.getName().equals(tfileName)){
          //System.out.println("--------"+file.getName()+" "+file.getAbsolutePath() );
          return file.getAbsolutePath();
        }
      }
    }
    return null;
  }

  public static void main(String[] args) {
    GetFileNameAbsolutePath getFileNameAbsolutePath1 = new GetFileNameAbsolutePath();
      getFILENAMEabsolutePath("c:\\env","kk.txt");
  }
}