package wsj.util.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;

public class DirectoryFinder {
  private File root;
  private List dirs = new ArrayList();
  private FilenameFilter filter;
  private int currentIndex;

  public DirectoryFinder(String path) {
    this(path, null, 1);
  }

  public DirectoryFinder(String path, FilenameFilter filter) {
    this(path, filter, 1);
  }

  public DirectoryFinder(String path, int level) {
    this(path, null, level);
  }

  public DirectoryFinder(String path, FilenameFilter filter, int level) {
    this.root = new File(path);
    this.filter = filter;
    if (filter != null) {
      findDirectory(root, root.listFiles(filter), level);
    } else {
      findDirectory(root, root.listFiles(), level);
    }
  }

  private void findDirectory(File path, File[] list, int level) {
    if (list == null) {
      //System.out.println("'" + path.getAbsolutePath() + "' directory is not existed.");
      return;
    }
        --level;
        for (int i = 0; i < list.length; i++) {
          File file = list[i];
          if (file.isDirectory()) {
            dirs.add(file);
            if (level > 0) {
              findDirectory(file,
                            (filter == null)
                            ? file.listFiles() : file.listFiles(filter),
                            level);
            }
          }
        } // the end of for
  }

  public boolean hasNextDirectory() {
    if (currentIndex < dirs.size()) {
      return true;
    }
    return false;
  }

  public File nextDirectory() {
    File file = (File) dirs.get(currentIndex);
    ++currentIndex;
    return file;
  }

}
