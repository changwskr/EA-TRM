package wsj.util.file;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;
import wsj.util.date.CalendarUtil;

public class SearchFILE {

  public SearchFILE() {
  }

  public static void main(String[] args) {
    SearchFILE findFile1 = new SearchFILE();
  }

  public
  boolean
  comparefileExt
  (java.io.File file, String fileExt)
  {
    String Ext = "";
    String fileName = "";
    fileName= file.getName();
    String comparefileExt = fileExt.toLowerCase();
    if ( fileName.length() >=3)
    {
      Ext = file.getName().substring(fileName.lastIndexOf(".") + 1 ,fileName.length()).toLowerCase();
      if (comparefileExt.equals("java"))
        comparefileExt = "java";
      if (comparefileExt.equals("class"))
        comparefileExt = "class";
    }
    return Ext.equals(comparefileExt);
  }

  public
  void
/*
  * find_all_files("c:\\kkk","20031123","20031124","java")
 */
  find_all_files(String path,String fromDate,String toDate,String fileExt)
  {
    CalendarUtil calendarUtil  = new CalendarUtil();
    String fileDate ="";
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    Calendar calendar = Calendar.getInstance();
    DirectoryFinder dirFinder = new DirectoryFinder(path);

    while (dirFinder.hasNextDirectory()) {
      try{
        File dir = dirFinder.nextDirectory();
        String subpath = dir.getAbsolutePath();
        FileFinder fileFinder = new FileFinder(subpath, -1);
        while (fileFinder.hasNextFile()) {
          try{
            File file = fileFinder.nextFile();
            String filename = file.getAbsolutePath();
            //---------------------------------------------------------------
            calendar.setTime(new Date(file.lastModified())) ;
            fileDate = formatter.format(new Date(file.lastModified()));
            if ( file.isFile() &&
                 comparefileExt(file,fileExt) &&
                 calendarUtil.compareBetweenDates(fileDate,fromDate)>-1 &&
                 calendarUtil.compareBetweenDates(fileDate,toDate)<=0
                 )
            {
              System.out.println("*--"+file.getName()+" "+file.getAbsolutePath()+" "+fileDate );
            }
            //---------------------------------------------------------------
          }
          catch(Exception ex){
            ex.printStackTrace();
          }
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
    }
    return ;
  }



/*
  * find_all_files("c:\\kkk","java")
  * Ȯ���ڰ� .java�ΰ��� ã�´�.
 */

  public
  void
  find_all_files(String path,String fileExt)
  {
    CalendarUtil calendarUtil  = new CalendarUtil();
    String fileDate ="";
    SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
    Calendar calendar = Calendar.getInstance();
    DirectoryFinder dirFinder = new DirectoryFinder(path);

    while (dirFinder.hasNextDirectory()) {
      try{
        File dir = dirFinder.nextDirectory();
        String subpath = dir.getAbsolutePath();
        FileFinder fileFinder = new FileFinder(subpath, -1);
        while (fileFinder.hasNextFile()) {
          try{
            File file = fileFinder.nextFile();
            String filename = file.getAbsolutePath();
            //---------------------------------------------------------------
            calendar.setTime(new Date(file.lastModified())) ;
            fileDate = formatter.format(new Date(file.lastModified()));
            if ( file.isFile() &&
                 comparefileExt(file,fileExt) )
            {
              System.out.println("*--"+file.getName()+" "+file.getAbsolutePath()+" "+fileDate );
            }
            //---------------------------------------------------------------
          }
          catch(Exception ex){
            ex.printStackTrace();
          }
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
    }
    return ;
  }


}