package wsj.util.system;

//���� �ð� ���ϱ�.
import java.util.Date;
import java.util.Calendar;

public class GetTime {
  public static void main(String[] args) {
    Date date =  new Date();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);

    System.out.println( " MilliSecond Time       : " + date.getTime() );
    System.out.println( " Representation of Date : " + date.toString() );

    //��, ��, �� ���� ��������.
    System.out.println( " My Representation \t: " +
		    calendar.get(Calendar.YEAR) + " Year " +
		    calendar.get(Calendar.MONTH) + " Month " +
		    calendar.get(Calendar.DAY_OF_MONTH) + " Day " );

  }
}
