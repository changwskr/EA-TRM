package wsj.util.system;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.text.*;
import java.util.*;
import java.util.Calendar;
import java.net.*;
import java.io.*;

public class RuntimeCommand {

  public static boolean runBuild2(String cmd){
    boolean succeed = false;
    Process process = null;
    BufferedReader in = null;
    try{
      System.out.println("|* exec command ["+cmd+"]");
      process = Runtime.getRuntime().exec(cmd);
      in = new BufferedReader(new InputStreamReader(process.getInputStream()));
      String error = null;
      while ((error = in.readLine()) != null)
      {
        System.out.println(error);
      }
      succeed=true;
    }catch(Exception e){
      e.printStackTrace();
      succeed=false;
    }finally{
      try{
         process.destroy();
         in.close();
      }catch(Exception e){
        e.printStackTrace();
      }
    }
    return succeed;
  }

  public static int runBuild(String cmd)
  {
    Process process = null;
    BufferedReader in = null;
    int offset=0;
    try{
      System.out.println(cmd);
      process = Runtime.getRuntime().exec(cmd);
      in = new BufferedReader(new InputStreamReader(process.getInputStream()));
      String error = "";
      while ((error = in.readLine()) != null)
      {
        System.out.println(error);
      }
    }catch(Exception e){
      e.printStackTrace();
      offset=-1;
    }finally{
      try{
        process.destroy();
        in.close();
      }catch(Exception e){
        e.printStackTrace();
      }
    }
    return offset;
  }
  public static void main(String args[])
  {
    RuntimeCommand.runBuild2(args[0]);
  }

}