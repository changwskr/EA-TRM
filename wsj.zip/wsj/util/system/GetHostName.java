package wsj.util.system;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import wsj.util.number.Number2String;

public class GetHostName {

  public GetHostName() {
  }
  public final static String execute()
  {
    InetAddress Address=null ;
    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }
  public static final String getLocalHostName()
  {
    InetAddress Address=null ;

    try{
      Address = InetAddress.getLocalHost();

    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }

  public static final String GetHostName()
  {
    InetAddress Address=null ;

    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }


  public static final String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }




  public static final String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }

}