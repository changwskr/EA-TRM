package wsj.util.system;

//�޼ҵ�  ����ð� ���ϱ�.
import java.util.Date;
import java.util.Calendar;

public class GetRunTime{
  public void waitASecond(){
    try{
      Thread.currentThread().sleep(1000);
    }catch(InterruptedException e){
    	e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    GetRunTime object = new GetRunTime();

    long checkPoint1 = System.currentTimeMillis();
    object.waitASecond();
    long checkPoint2 = System.currentTimeMillis();

    long howLong = checkPoint2 - checkPoint1;
    System.out.println("waitASecond()�� �����ϴµ� �ɸ��ð� : " +
		    ((double)howLong/(double)1000) + "��");
  }
}
