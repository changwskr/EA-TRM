package wsj.util.system;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

public class GetSystime {

  public GetSystime() {
  }
  public static void main(String[] args) {
    GetSystime getSystime1 = new GetSystime();
  }

  public static final String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }

}