package wsj.util.system;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;

import wsj.util.number.Number2String;

public class GetSysdate {

  public GetSysdate() {
  }

  public static final String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }

  public static final String GetSysDate(Connection conn, String itvdate)
  {
    String 	seqtmp=null;
    int    	seq=0;
    Statement 	stmt=null;
    ResultSet 	rs=null;

    try {

      String tSQL = "SELECT TO_CHAR( SYSDATE - " + itvdate + ", 'YYYYMMDD' ) FROM DUAL";
      //System.out.println(tSQL);
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();

      seq = rs.getInt(1);
      //System.out.println("bbbbbbbbbbbbbbbbbb" + seq);
      rs.close();
    } catch(SQLException e) {
      System.out.println(e.getMessage());
      return null;
    }
    if (seq==0) return null;
    //System.out.println("aaaaaaaaaaaa" + seq);
    return(Number2String.Int2Str(seq));
  }



  public static void main(String[] args) {
    GetSysdate getSysdate1 = new GetSysdate();
  }
}