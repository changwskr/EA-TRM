package wsj.util.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class CMDexe {

  public CMDexe() {
  }
  public
  int
  runBuild(String cmd)
  {
    Process process = null;
    BufferedReader in = null;
    int offset=0;
    try{
      System.out.println(cmd);
      process = Runtime.getRuntime().exec(cmd);
      in = new BufferedReader(new InputStreamReader(process.getInputStream()));
      String error = null;
      while ((error = in.readLine()) != null)
      {
        System.out.println(error);
      }
    }catch(Exception e){
      e.printStackTrace();
      offset=-1;
    }finally{
      try{
        process.destroy();
        in.close();
      }catch(Exception e){
        e.printStackTrace();
      }
    }
    return offset;
  }

  private
  void
/*
  * execute("cleartool", "checkout -nc " + path);
  * execute("cleartool", "checkin -nc " + path);
 */
  execute(String cmd, String options_plus_path) throws IOException
  {
    Process process = Runtime.getRuntime().exec(cmd + " " + options_plus_path);
    ProcessStream stream = new ProcessStream(process.getErrorStream());
    stream.start();
    BufferedReader in = new BufferedReader(
        new InputStreamReader(process.getInputStream()));
    String msg = null;
    while ((msg = in.readLine()) != null) {
      System.out.println("<" + cmd + ":" + msg + ">");
    }
    process.destroy();
  }


  public static void main(String[] args) {
    CMDexe CMDexe1 = new CMDexe();
  }
}