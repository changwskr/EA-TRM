package wsj.util.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;

public class ProcessStream extends Thread
{
    BufferedReader reader;
    private boolean succeed = true;

    public ProcessStream(InputStream in)
    {
        this.reader = new BufferedReader(new InputStreamReader(in));
        //setDaemon(true);
    }

    public void run() {
        try {
            String error = null;
            while ((error = reader.readLine()) != null) {
//                Debug.info(reader.readLine());
                succeed = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //Debug.debug(e.toString());
        }
    }

    public boolean isSucceed() {
        return succeed;
    }
}
