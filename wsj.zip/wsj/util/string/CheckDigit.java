package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CheckDigit {

  public CheckDigit() {
  }

  /**
   * ����
   * GetIntChk("12a","12a".length())
   *
   * @param string
   * @param piStrLen
   * @return
   */
  public static final boolean GetIntChk(String string,int piStrLen)
  {
    for(int index=0 ; index<piStrLen ; index++){
      if(string.charAt(index) < 48 || string.charAt(index) > 57){
        return(false);
      }
    }
    return true;
  }

  public static void main(String[] args) {
    CheckDigit checkDigit1 = new CheckDigit();
    System.out.println("----"+checkDigit1.GetIntChk("12a","12a".length() ));
  }
}