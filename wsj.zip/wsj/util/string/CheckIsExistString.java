package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CheckIsExistString {

  public CheckIsExistString() {
  }

  /**
   * string ����
   *
   */
  public static final boolean exist_str(String org,String tar){
    if (org.regionMatches(org.indexOf(tar) ,tar,0,tar.length() )){
      return true;
    }
    else{
      return false;
    }
  }

  // org : 1234567  tar : 345 -> org���� tar ��Ʈ���� ���ԵǾ� �ִ��� Ȯ���Ѵ�.
  public static final boolean check_contain_string(String org,String tar){
    if (org.regionMatches(org.indexOf(tar) ,tar,0,tar.length() )){
      return true;
    }
    else{
      return false;
    }
  }

  public static void main(String[] args) {
    CheckIsExistString checkIsExistString1 = new CheckIsExistString();
  }
}