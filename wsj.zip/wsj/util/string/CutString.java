package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class CutString {

  public CutString() {
  }
  /**
   * len ���� �� ���ڿ��� ��� �ڸ���.
   *
   * @param     str �Է� ���ڿ�
   * @param     len ���ڿ� ����
   * @return    String
   */
  public static final String cutString(String str, int len)
  {
    if (str != null) {
      if( str.length() < len+1 ) {
        return str ;
      } else {
        return str.substring(0,len);
      }
    }
    return "" ;
  }

  public static final String cutString(String str, int startpo,int len)
  {
    if (str != null) {
      return str.substring(startpo,(len+1));
    }
    return "" ;
  }

  public static void main(String[] args) {
    CutString cutString1 = new CutString();
  }
}