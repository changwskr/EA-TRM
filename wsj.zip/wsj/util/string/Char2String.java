package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Char2String {

  public Char2String() {
  }
  public static final String execute(char ch)
  {
    String lo=new Character(ch).toString();
    return(lo);
  }
  public static void main(String[] args) {
    Char2String char2String1 = new Char2String();
  }
}