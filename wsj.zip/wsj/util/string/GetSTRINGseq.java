package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.StringTokenizer;

public class GetSTRINGseq {

  public GetSTRINGseq() {
  }

  /**
   * request_name = "cashCard-listCashcard"
   *              = "system" + "-" + "method"
   *
   * catchSTRINGseq("cashCard-listCashcard",1,"-");
   * '-' �����ڸ� �����鼭 ù��° ���ڿ��� ���϶�
   *
   * @param request_name
   * @return
   */
  public static String catchSTRINGseq(String request_name,int seq,String tag)
  {
    StringTokenizer tokenizer = new StringTokenizer(request_name, tag);
    String [] matrix = new String[seq];

    int i = 0;
    while( tokenizer.hasMoreTokens() ){
      matrix[i] = tokenizer.nextToken();
      //System.out.println( "Tokenized String : " + matrix[i] );
      i++;
      if( i==seq )
        break;
    }
    return matrix[seq-1];
  }

  public static void main(String[] args) {
    GetSTRINGseq getSTRINGseq1 = new GetSTRINGseq();
    System.out.println(GetSTRINGseq.catchSTRINGseq("111-222-333",2,"-"));
  }
}