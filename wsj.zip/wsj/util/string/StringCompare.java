package wsj.util.string;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

//��Ʈ�� ��ü, �κ� ���ϱ�.


public class StringCompare{
  public static void main(String[] args) {
    String sourceString = "This is source string";

    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader reader = new BufferedReader(isr);
    String line = null;

    System.out.println("Source string>" + sourceString);
    try{
      while( (line = reader.readLine()) != null ) {
        System.out.println("Inputed string>" + line);
        System.out.println(sourceString.indexOf(line));
        if( sourceString.compareTo(line) == 0 ){
           System.out.println(">>Inputed string equal source string");
        }else if( sourceString.indexOf(line) >= 0){
           System.out.println(">>Inputed string is source's substring");
        }else{
           System.out.println(">>No exist relation!!");
        }
      }
    }catch(IOException e){
      e.printStackTrace();
    }
  }
}
