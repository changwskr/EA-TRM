package wsj.util.string;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class String2Number {

  public String2Number() {
  }
  public static final int Str2Int(String str)
  {
    int i=Integer.valueOf(str).intValue();
    //System.out.println(i);
    return(i);
  }


  public static final int atoi(String str)
  {
    int i=Integer.valueOf(str).intValue();
    //System.out.println(i);
    return(i);
  }


  public static final long Str2Long(String str)
  {
    long l=Long.valueOf(str).longValue();
    //System.out.println(l);
    return(l);
  }


  public static final float Str2Float(String str)
  {
    float f=Float.valueOf(str).floatValue();
    //System.out.println(f);
    return(f);
  }


  public static final double Str2Double(String str)
  {
    double d=Double.valueOf(str).doubleValue();
    //System.out.println(d);
    return(d);
  }


  public static final String Int2Str(int n)
  {
    String s=new Integer(n).toString();
    return(s);
  }


  public static final String Float2Str(float n)
  {
    String s1=new Float(n).toString();
    return(s1);
  }


  public static final String Long2Str(long l)
  {
    String s = new Long(l).toString();
    return( s );
  }


  public static final String Double2Str(double d)
  {
    String s = new Double(d).toString();
    return(s);
  }

  public static void main(String[] args) {
    String2Number string2Number1 = new String2Number();
  }
}