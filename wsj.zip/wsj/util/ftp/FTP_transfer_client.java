package wsj.util.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.util.*;
import wsj.util.string.String2Number;
import wsj.util.file.FILEapi;
import wsj.util.socket.SOCKETapi;

public class FTP_transfer_client {
  private static FTP_transfer_client instance;
  private Socket sk;
  private InputStream is;
  private OutputStream os;

  public static synchronized FTP_transfer_client getInstance() throws Exception{
    if (instance == null) {
      try
      {
        instance = new FTP_transfer_client();
      }
      catch(Exception igex)
      {
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public FTP_transfer_client() {
  }

  public boolean execute (
      String soktarhost,
      String ftptarhost,
      String port,
      String fname,
      String tarpath
      ) throws IOException, FTPException
  {
    try {
      this.sk = new Socket(soktarhost,String2Number.Str2Int(port));
      this.is = this.sk.getInputStream();
      this.os = this.sk.getOutputStream();
      SOCKETapi.write_data(this.os,fname);
      SOCKETapi.write_data(this.os,ftptarhost);
      SOCKETapi.write_data(this.os,tarpath);
      this.closeConnection();
    }
    catch(Exception e){
      e.printStackTrace();
      this.closeConnection();
      return false;
    }
    return true;
  }

  public void closeConnection()
      throws IOException
  {
    this.os.close();
    this.is.close();
    this.sk.close();
  }


  public static void main(String[] args) throws IOException,Exception{
    FTP_transfer_client.getInstance().execute (
        "21.102.1.227","21.101.3.49","30000",
        "C:\\MYTEST\\ATMPPP\\ptest\\FTPapi.java",
        "/home/cosif/atmppp/log" );
  }
}