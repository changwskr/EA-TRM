package wsj.util.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.util.*;
import wsj.util.string.String2Number;
import wsj.util.file.FILEapi;
import wsj.util.socket.SOCKETapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class FTP_transfer_server_thr extends Thread {
  private Socket sk;
  private InputStream is;
  private OutputStream os;
  private String passwd;
  private String userid;

  public FTP_transfer_server_thr(Socket sok) throws IOException,Exception{
    ///////////////////////////////////////////////////////
    //������ ������ ���丮
    ///////////////////////////////////////////////////////
    this.sk = sok;
    this.is = this.sk.getInputStream();
    this.os = this.sk.getOutputStream();
    this.userid = ConfigFile.getInstance("C:\\MYTEST\\ATMPPP\\ptest\\ftpenvfile.env").GetEnvValue("USERID");
    this.passwd = ConfigFile.getInstance("C:\\MYTEST\\ATMPPP\\ptest\\ftpenvfile.env").GetEnvValue("PASSWD");

    InetAddress inet = sok.getInetAddress();
    System.out.println("-----||" + inet.getHostAddress());
    new Thread(this,"FTP_transfer_server_thr_"+inet.getHostAddress()+GetSystime.GetSysTime()).start();
  }

  public void run(){
    long st=0;
    long et=0;

    while(!Thread.currentThread().isInterrupted()){
      try{
        String fileName=SOCKETapi.read_data(this.is);
        String tarhost=SOCKETapi.read_data(this.is);
        String tpath=SOCKETapi.read_data(this.is);
        //���� ���� �ð�
        st=System.currentTimeMillis();
        FTPapi.getInstance().execute(tarhost,this.userid,this.passwd,fileName,tpath,'p','a' );
      }catch(Exception ioe){
        ioe.printStackTrace();
        break;
      }
    }

    try{
      //���� ���� �ð�
      et=System.currentTimeMillis();
      //���� �� �ҿ�ð�
      System.out.println(Thread.currentThread().getName() + " : " + (et-st)+" milliseconds");
      System.out.println("*--------------------------------------------------*");
      System.out.println("* ����Ŭ���̾�Ʈ ���� ����");
      System.out.println("*--------------------------------------------------*");
      System.out.println("* ����/�ð� : " + GetSysdate.GetSysDate() + " : " + GetSystime.GetSysTime().substring(0,6) );
      System.out.println("* ���� Ŭ���̾�Ʈ ���� IP/PORT : " + sk.getLocalAddress() + " : " + sk.getLocalPort() );
      System.out.println("*--------------------------------------------------*");
      is.close();
      os.close();
      sk.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }

  public static void main(String args[]) throws IOException {

  }
}
