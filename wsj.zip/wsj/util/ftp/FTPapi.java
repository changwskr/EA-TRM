package wsj.util.ftp;

/**
 * <PRE>
 * Class    : FTPapi
 * Function :
 * Comment  : File Transfer <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

import java.net.*;
import java.io.*;
import java.text.*;
import java.util.*;
import wsj.util.ftp.*;

public class FTPapi {
  private static FTPapi instance;
  Socket ctrlSocket;					//����� ����
  public final int FILE_SIZE_LOC = 5;
  public final int FILE_NAME_LOC = 9;
  public PrintWriter output_pw;		//���� ��¿� ��Ʈ��
  public BufferedReader input_br;	// �� �Է¿� ��Ʈ��
  final int FTP_PORT = 21 ;			// ftp�� ����� ��Ʈ

  //"21.101.3.49","cosif","cosif","FTPapi.java11","/home/cosif/atmppp/log",'p','a' );
  private String ftpenvfile;
  public String target_ip;
  public String passwd;
  public String userid;


  public static synchronized FTPapi getInstance() throws Exception{
    if (instance == null) {
      try
      {
        instance = new FTPapi();
      }
      catch(Exception igex)
      {
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public static synchronized FTPapi getInstance(String ftpenvfile) throws Exception{
    if (instance == null) {
      try
      {
        instance = new FTPapi();
        instance.ftpenvfile = ftpenvfile;
      }
      catch(Exception igex)
      {
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public FTPapi() {

  }

  public void openConnection(String host)
      throws IOException,UnknownHostException
  {
    this.ctrlSocket = new Socket(host, FTP_PORT);
    this.output_pw = new PrintWriter(ctrlSocket.getOutputStream());
    this.input_br = new BufferedReader(new InputStreamReader(ctrlSocket.getInputStream()));
  }

  public void closeConnection()
      throws IOException
  {
    try{
    this.output_pw.close();
    this.input_br.close();
    this.ctrlSocket.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }

  public void doLogin(String loginname,String password)
  {
    String loginName = "" ;
    String passWord = "" ;

    try{
      loginName = loginname;
      output_pw.println("USER " + loginName) ;
      output_pw.flush() ;
      passWord = password;
      output_pw.println("PASS " + passWord) ;
      output_pw.flush() ;
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

  public void getMsgs(){
    try {
      CtrlListen listener = new CtrlListen(input_br) ;
      Thread listenerthread = new Thread(listener) ;
      listenerthread.start() ;
    }catch(Exception e){
      e.printStackTrace() ;
    }
  }

  public synchronized boolean execute (
      String fname,
      String tarpath,
      char tran_type,
      char tran_mode
      )
      throws IOException, FTPException
  {
    try {
      this.target_ip = ConfigFile.getInstance(this.ftpenvfile).GetEnvValue("TARHOSTIP");
      this.passwd = ConfigFile.getInstance(this.ftpenvfile).GetEnvValue("PASSWORD");
      this.userid = ConfigFile.getInstance(this.ftpenvfile).GetEnvValue("USERID");

      this.openConnection(this.target_ip);
      this.getMsgs() ;
      this.doLogin(this.userid,this.passwd);
      this.FTPprocessing(tran_type,tarpath,tran_mode,fname);
      this.closeConnection() ;
    }catch(Exception e){
      e.printStackTrace();
      this.closeConnection();
      return false;
    }
    return true;
  }

  public synchronized boolean execute (
      String tarhost,
      String user,
      String password,
      String fname,
      String tarpath,
      char tran_type,
      char tran_mode ) throws IOException, FTPException
  {
    try {
      this.openConnection(tarhost);
      this.getMsgs() ;
      ///////////////////////////////////////////////////////////////////////
      // ���ϼ��� ��� : tran_type
      // 		PUT TYPE : p
      //		GET TYPE : g
      // �������� Ÿ�ϵ��丮
      //		/home/test
      // �������� ��� : tran_mode
      //		a : ASCII
      //		b : BINARY
      // ��������
      ////////////////////////////////////////////////////////////////////////
      this.doLogin(user,password);
      // tran_type:p,g tran_mod:a,b
      this.FTPprocessing(tran_type,tarpath,tran_mode,fname);
      this.closeConnection() ;

      /*
      if ( !new File(fname).exists() ) {
        throw new FTPException("!!! File Not Found !!!");
      }
      */

    }catch(Exception e){
      e.printStackTrace();
      this.closeConnection();
      return false;
    }
    return true;
  }


  public synchronized boolean execute
  (   String tarhost,  //ftp host
      String user,     //ftp user
      String password, //ftp passwd
      String fname,    //ftp transfer file name
      String tarpath,  //ftp file location path
      String copypath, //client file location path
      char tran_type,  //ftp get/put type
      char tran_mode   //ftp tran_mode
  ) throws IOException, FTPException
  {
    try
    {
      this.openConnection(tarhost);
      this.getMsgs() ;
      ///////////////////////////////////////////////////////////////////////
      // ���ϼ��� ��� : tran_type
      // 		PUT TYPE : p
      //		GET TYPE : g
      // �������� Ÿ�ϵ��丮
      //		/home/test
      // �������� ��� : tran_mode
      //		a : ASCII
      //		b : BINARY
      // ��������
      ////////////////////////////////////////////////////////////////////////
      this.doLogin(user,password);
      this.FTPprocessing(tran_type,tarpath,tran_mode,fname);
      this.closeConnection() ;

    }catch(Exception e){
      e.printStackTrace();
      this.closeConnection();
      return false;
    }
    return true;
  }

  public void FTPprocessing(
      char FgubunPG,
      String pStargetPath,
      char pTransferType,
      String pSfileName )
      throws IOException, FTPException
  {
    boolean cont = true ;
    try
    {
      //change target path
      doCd(pStargetPath);

      //transfer type
      switch( pTransferType )
      {
        case 'a' :
          doAscii() ;
          break;
        case 'b' :
          doBinary();
          break;
        default :
          System.out.println("Transfer type error") ;
        throw new FTPException("Transfer Type error");

      }

      //file transfer
      switch( FgubunPG )
      {
        case 'p' :
          doPut(pSfileName) ;
          break;
        case 'g' :
          doGet(pSfileName);
          break;
        default :
          System.out.println("FTP Transfer type error") ;
        throw new FTPException("FTP Transfer Type error");
      }
    }
    catch(FTPException ef)
    {
      System.err.println(ef.getMessage());
      throw new IOException();
    }
    catch(Exception e){
      System.err.print(e);
      throw new IOException();
    }
  }

  public void doCd(String pStargetPath)
  {
    String dirName = "" ;
    if( pStargetPath.equals("curdir") )return;

    try{
      dirName = pStargetPath ;
      output_pw.println("CWD " + dirName) ;
      output_pw.flush() ;
      }catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public void doAscii()
  {
    try{
      output_pw.println("TYPE A") ;
      output_pw.flush() ;
      }catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public void doBinary()
  {
    try{
      output_pw.println("TYPE I") ;
      output_pw.flush() ;
      }catch(Exception e)
      {
        e.printStackTrace();
      }
  }

  public void doGet(String pStargetFile)
  {
    String fileName = "" ;
    FileOutputStream outfile =  null ;
    Socket dataSocket = null;
    BufferedInputStream dataInput = null;

    try{
      int n ;
      byte[] buff = new byte[1024] ;

      fileName = pStargetFile;
      outfile =  new FileOutputStream(fileName) ;
      dataSocket = dataConnection("RETR " + fileName) ;
      dataInput = new BufferedInputStream(dataSocket.getInputStream()) ;

      while((n = dataInput.read(buff)) > 0){
        outfile.write(buff,0,n) ;
      }
      dataInput.close();
      dataSocket.close() ;
      outfile.close() ;
      }catch(Exception e)
      {
        e.printStackTrace();
        try{
          dataInput.close();
          dataSocket.close() ;
          outfile.close() ;
        }catch(Exception ex){}
      }
  }

  // ���丮 �Ʒ��� ���丮�� ���۽�Ű�� �ʴ´�.
  public void doPut(String pStargetFile) throws FileNotFoundException,Exception
  {
    String fileName = "" ;
    FileInputStream sendfile = null ;
    Socket dataSocket = null;
    OutputStream ops = null;
    try{
      int n ;
      byte[] buff = new byte[1024] ;
      fileName = pStargetFile;

      File f = new File(fileName);
      if( f.isDirectory() ){
        File [] dir_files = f.listFiles();
        for(int k=0; k<dir_files.length; k++)
        {
          if( dir_files[k].isDirectory() ){
            System.out.println(dir_files[k].getName() + " is Directory");
            continue;
          }
          else if( dir_files[k].isFile() ){
            System.out.println(dir_files[k].getName() + " is File");
          }

          int n1 ;
          byte[] buff1 = new byte[1024] ;
          sendfile = new FileInputStream(dir_files[k]);
          dataSocket = dataConnection("STOR " + dir_files[k].getName()) ;
          OutputStream outstr =  dataSocket.getOutputStream() ;
          ops = outstr;
          while((n = sendfile.read(buff)) > 0){
            outstr.write(buff,0,n) ;
          }
          outstr.close();
          dataSocket.close() ;
          sendfile.close() ;
        }
      }
      else{
        int n1 ;
        byte[] buff1 = new byte[1024] ;

        sendfile = new FileInputStream(f);
        dataSocket = dataConnection("STOR " + f.getName()) ;
        OutputStream outstr =  dataSocket.getOutputStream() ;
        ops = outstr;
        while((n = sendfile.read(buff)) > 0){
          outstr.write(buff,0,n) ;
        }
        outstr.close();
        dataSocket.close() ;
        sendfile.close() ;
      }
    }
    catch(FileNotFoundException e)
    {
        e.printStackTrace();
        try{
          ops.close();
          dataSocket.close();
          sendfile.close();
        }
        catch(Exception ex){}
        throw e;

    }catch(Exception e)
    {
        e.printStackTrace();
        try{
          ops.close();
          dataSocket.close();
          sendfile.close();
        }
        catch(Exception ex){}
        throw e;

    }
  }

  // �������� ������ ��ȯ�� ������ ����ϴ�.
  // �� ������ ���Ͽ� port Ŀ�ǵ�� ��Ʈ�� �����մϴ�.
  public Socket dataConnection(String ctrlcmd) throws IOException
  {
    String cmd = "PORT " ; //PORT Ŀ�ǵ�� ������ ������ ������ ����
    int i ;
    Socket dataSocket = null ;// ������ ���ۿ� ����
    ServerSocket serverDataSocket = null;
    try{
      // �ڽ��� �ּҸ� �䱸�մϴ�
      byte[] address = InetAddress.getLocalHost().getAddress() ;
      // ������ ��Ʈ ��ȣ�� ���� ������ ����ϴ�
      serverDataSocket = new ServerSocket(0,1) ;
      // PORT Ŀ�ǵ�� �۽� �����͸� �غ��մϴ�
      for(i = 0; i < 4; ++i)
        cmd = cmd +  (address[i] & 0xff) + "," ;
      cmd = cmd + (((serverDataSocket.getLocalPort()) / 256) & 0xff)
          + ","
          + (serverDataSocket.getLocalPort() & 0xff) ;
      output_pw.println(cmd) ;
      output_pw.flush() ;
      output_pw.println(ctrlcmd) ;
      output_pw.flush() ;
      dataSocket = serverDataSocket.accept() ;
      serverDataSocket.close() ;
    }
    catch(Exception e)
    {
      e.printStackTrace();
      //woo
      try{
        dataSocket.close();
        serverDataSocket.close();
      }catch(Exception ex){}
      throw new IOException();
    }
    return  dataSocket ;
  }

  // TCP Ŀ�ؼ��� ���� ó���� �����մϴ�
  public static void main2(String[] arg){
    try {
      try {
        //FTPapi.getInstance("ftpenvfile.env").execute("FTPapi.java","/home/cosif/atmppp/log",'p','a');

        FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","FTPapi.java","/home/cosif/atmppp/log",'p','a' );
        //��������
        //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","C:\\MYTEST\\ATMPPP\\ptest\\ftp\\1","/home/cosif/atmppp/log",'p','a' );
        //���丮 ����
        //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","C:\\MYTEST\\ATMPPP\\ptest\\ftp","/home/cosif/atmppp/log",'p','a' );

        //Host�κ��� ������ �о�´�.
        //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","1","/home/cosif/atmppp/log",'g','a' );
        //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","2","/home/cosif/atmppp/log",'g','a' );

      }
      catch( Exception ex )
      {
        System.out.println("FTPapiTransfer Exception 0000");
        System.exit(1);
      }

      System.out.println("FTPapiTransfer Success ");

      System.exit(0) ;      // ���α׷��� ����
    }catch(Exception e){
      e.printStackTrace();
      System.exit(1);
    }
  }

  // TCP Ŀ�ؼ��� ���� ó���� �����մϴ�
  public static void main(String[] args){
    try {
      if( args.length  != 7 ){
        System.out.println("U(���ϼ۽�) : TargetIP# TargetUser# TargetPawwd FileName# TargetPath# p a");
        System.out.println("U(���ϼ���) : TargetIP# TargetUser# TargetPawwd FileName# TargetPath# g b");
      }
      else{
        FTPapi.getInstance().execute(args[0],args[1],args[2],args[3],args[4],args[5].charAt(0) ,args[6].charAt(0) );
      }
    }catch(Exception e){
      e.printStackTrace();
      System.exit(1);
    }
  }

}

