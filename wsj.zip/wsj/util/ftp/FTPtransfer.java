package wsj.util.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.text.*;
import java.util.*;
import wsj.util.ftp.FTPapi;

public class FTPtransfer {
  private static FTPtransfer instance;
  private String ftpenvfile;

  public FTPtransfer() {
  }
  public static synchronized FTPtransfer getInstance() throws Exception{
    if (instance == null) {
      try{
        instance = new FTPtransfer();
      }
      catch(Exception igex){
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }
  public static synchronized FTPtransfer getInstance(String ftpenvfile) throws Exception{
    if (instance == null) {
      try {
        instance = new FTPtransfer();
        instance.ftpenvfile = ftpenvfile;
      }
      catch(Exception igex) {
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }
  public void execute() {
    try {
      //FTPapi.getInstance("ftpenvfile.env").execute("FTPapi.java","/home/cosif/atmppp/log",'p','a');
      FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","FTPapi.java","/home/cosif/atmppp/log",'p','a' );
      //��������
      //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","C:\\MYTEST\\ATMPPP\\ptest\\ftp\\1","/home/cosif/atmppp/log",'p','a' );
      //���丮 ����
      //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","C:\\MYTEST\\ATMPPP\\ptest\\ftp","/home/cosif/atmppp/log",'p','a' );
      //Host�κ��� ������ �о�´�.
      //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","1","/home/cosif/atmppp/log",'g','a' );
      //FTPapi.getInstance().execute("21.101.3.49","cosif","cosif","2","/home/cosif/atmppp/log",'g','a' );
    }
    catch( Exception ex )
    {
      System.out.println("FTPapiTransfer Exception 0000");
      System.exit(1);
    }
    return;
  }
  public static void main(String[] args) {
    FTPtransfer FTPtransfer1 = new FTPtransfer();
  }
}