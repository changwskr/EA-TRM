package wsj.util.ftp;

import java.util.*;
import java.text.*;
import java.io.*;

public class ConfigFile {
  public Hashtable envh = new Hashtable();
  private static ConfigFile instance;
  private static boolean verbose = false;
  private static String ubb_fname;

  public static synchronized ConfigFile getInstance(String fname) throws Exception{
    if (instance == null) {
      instance = new ConfigFile();
      instance.setFname(fname);
    }
    return instance;
  }

  public void setFname(String fname) {
    this.ubb_fname = fname;
  }

  public void setHash(Hashtable envh) {
    this.envh = envh;
  }

  public ConfigFile() {

  }

  public synchronized String GetEnvValue(String tmp) throws IOException
  {
    String ConfigPath=null;

    Properties p = new Properties();
    String tmpv = null;
    FileInputStream fis = new FileInputStream(ubb_fname);
    try {
      p.load(fis);
      tmpv=p.getProperty(tmp);
      fis.close();
    }
    catch (IOException e) {
      System.out.println("GetEnvValue() ���� ȯ����ý� ���ܹ߻�" );
      e.printStackTrace();
      fis.close();
      throw new IOException(this.getClass().toString() + ": " + "GetEnvValue is exception" );
    }
    return tmpv;
  }

  public synchronized void SaveEnvValue() throws IOException
  {
    FileOutputStream fos = null;
    Properties p = null;

    try
    {
      p = new Properties();
      fos = new FileOutputStream(this.ubb_fname);
      for( Enumeration enum = this.envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        String val = (String)this.envh.get(key);
        p.setProperty(key, val);
      }
      p.store(fos, "[ConfigReference]");
      fos.close();
    }
    catch(Exception e)
    {
      e.printStackTrace();
      fos.close();
      throw new IOException(this.getClass().toString() + ": " + "SaveEnvValue is exception" );
    }
  }

}