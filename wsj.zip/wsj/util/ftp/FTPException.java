package wsj.util.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FTPException extends Exception
{
  FTPException(String msg)
  {
    super(msg);
  }
}

