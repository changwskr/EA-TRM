package wsj.util.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.io.*;
import java.util.*;
import wsj.util.string.String2Number;
import wsj.util.file.FILEapi;
import wsj.util.socket.SOCKETapi;
import wsj.util.system.GetSysdate;
import wsj.util.system.GetSystime;

public class FTP_transfer_server extends Thread{
  private ServerSocket ssk;
  private int port;
  private Socket sk;

  public FTP_transfer_server(int port) {
    this.port=port;
    try{
        System.out.println("ȯ������ Ŭ���̾�Ʈ ���� ����� ");
        ssk=new ServerSocket(this.port);
    }
    catch(IOException ex){
        ex.printStackTrace();
        return;
    }
    this.start();
  }

  public FTP_transfer_server() throws IOException,Exception{
    this.port=port;
    try{
        System.out.println("Ŭ���̾�Ʈ ���� ����� ");
        ssk=new ServerSocket( String2Number.Str2Int( ConfigFile.getInstance("C:\\MYTEST\\ATMPPP\\ptest\\ftpenvfile.env").GetEnvValue("SOKCET_DAEMON_PORT") ));
    }
    catch(IOException ex){
        ex.printStackTrace();
        throw ex;
    }
    catch(Exception ex){
        ex.printStackTrace();
        throw ex;
    }
    this.start();
  }

  public void run(){
    while(true){
      try{
        this.sk=ssk.accept();
        System.out.println("*--------------------------------------------------*");
        System.out.println("* ����Ŭ���̾�Ʈ ����");
        System.out.println("*--------------------------------------------------*");
        System.out.println("* ����/�ð� : " + GetSysdate.GetSysDate() + " : " + GetSystime.GetSysTime().substring(0,6) );
        System.out.println("* ���� Ŭ���̾�Ʈ IP/PORT : " + sk.getLocalAddress() + " : " + sk.getLocalPort() );
        System.out.println("*--------------------------------------------------*");
        new FTP_transfer_server_thr(sk);
      }catch(Exception ioe1){
        ioe1.printStackTrace();
        break;
      }
    }
    try{
        this.ssk.close();
    }
    catch(IOException ex){
        ex.printStackTrace();
        return;
    }
 }

  public static void main(String[] args) {
    System.out.println("********************************************************");
    System.out.println("* USAGE : type ��Ʈ1 ��Ʈ2                              *");
    System.out.println("********************************************************");
    System.out.println("* ���� ���� ���� :"+GetSystime.GetSysTime());
    System.out.println("********************************************************");

    FTP_transfer_server exs = new FTP_transfer_server(String2Number.Str2Int(args[0]));
    //FTP_transfer_server exs = new FTP_transfer_server(35530);

  }
}


