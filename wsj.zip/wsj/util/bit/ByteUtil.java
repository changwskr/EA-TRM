package wsj.util.bit;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


public class ByteUtil {
  /**
   * NetUtil ������ �ּ�.
   */
  private ByteUtil() {}
  public static final byte[] short2byte( short s ) {
    byte[] dest = new byte[2];
    dest[1] = (byte)(s & 0xff);
    dest[0] = (byte)((s>>8) & 0xff);
    return dest;
  }
  public static final byte[] int2byte( int i ) {
    byte[] dest = new byte[4];
    dest[3] = (byte)(i & 0xff);
    dest[2] = (byte)((i>>8) & 0xff);
    dest[1] = (byte)((i>>16) & 0xff);
    dest[0] = (byte)((i>>24) & 0xff);
    return dest;
  }
  public static final byte[] long2byte( long l ) {
    byte[] dest = new byte[8];
    dest[7] = (byte)(l & 0xff);
    dest[6] = (byte)((l>>8) & 0xff);
    dest[5] = (byte)((l>>16) & 0xff);
    dest[4] = (byte)((l>>24) & 0xff);
    dest[3] = (byte)((l>>32) & 0xff);
    dest[2] = (byte)((l>>40) & 0xff);
    dest[1] = (byte)((l>>48) & 0xff);
    dest[0] = (byte)((l>>56) & 0xff);
    return dest;
  }
  public static final short getshort( byte[] src, int offset ) {
    return (short)( ((src[offset]&0xff) << 8) | (src[offset+1]&0xff) ) ;
  }
  public static final int getint( byte[] src, int offset ) {
    return ((src[offset]&0xff) << 24) | ((src[offset+1]&0xff) << 16) |
        ((src[offset+2]&0xff) << 8) | (src[offset+3]&0xff) ;
  }
  public static final long getlong( byte[] src, int offset ) {
    return ((long) getint(src,offset) << 32 ) |
        ((long) getint(src, offset+4) & 0xffffffffL ) ;
  }
  public static final byte[] setshort( byte[] dest, int offset, short s ) {
    dest[offset+1] = (byte)(s & 0xff);
    dest[offset] = (byte)((s>>8) & 0xff);
    return dest;
  }
  public static final byte[] setint( byte[] dest, int offset, int i ) {
    dest[offset+3] = (byte)(i & 0xff);
    dest[offset+2] = (byte)((i>>8) & 0xff);
    dest[offset+1] = (byte)((i>>16) & 0xff);
    dest[offset] = (byte)((i>>24) & 0xff);
    return dest;
  }
  public static final byte[] setlong( byte[] dest, int offset, long l ) {
    setint(dest, offset, (int)(l>>32) );
    setint(dest, offset + 4, (int)(l & 0xffffffffL));
    return dest;
  }

  /////////////////////////////////////////////////////////////////////////////
  //
  //
  /////////////////////////////////////////////////////////////////////////////
  public static void main(String args[]){
    //���������� ����Ʈ�� ������� ����Ʈ�κ��� ���� ����
    int i = 10;
    byte[] bytef = ByteUtil.int2byte(i);
    System.out.println(bytef.toString());
    System.out.println(ByteUtil.getint(bytef,0));

    //�������� ����Ʈ�� ������� ����Ʈ�κ��� ���� ����
    long l = 1000000;
    byte[] bytef1 = ByteUtil.long2byte(l);
    System.out.println(bytef1.toString());
    System.out.println(ByteUtil.getlong(bytef1,0));
    //�������� �Ѱ� ����Ʈ�� ����
    int ii = 700000;
    byte[] bytef2 = new byte[4];
    byte[] bytef3 = setint(bytef2,0,ii);
    System.out.println(ByteUtil.getint(bytef3,0));

  }
}