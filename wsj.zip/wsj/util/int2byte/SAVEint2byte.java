package wsj.util.int2byte;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.text.*;
import java.util.*;
import java.io.*;

public class SAVEint2byte {

  //int�� ����Ÿ�� byte[2]�迭�� �ֱ�
  public static byte[] saveint2byte(int value) {
    Integer val = new Integer(value);
    byte[] bytes = new byte[2];

    bytes[0]=(byte)((value&0x0000FF00)>>8);
    bytes[1]=(byte)(value&0x000000FF);

    return bytes;
  }
  public static int savebyte2int(byte[] pbytes) {
    byte[] bytes = pbytes;

    return 0;
  }


  public static void main(String[] args) {
    SAVEint2byte.saveint2byte(300);
  }
}