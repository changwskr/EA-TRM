package wsj.util.xml;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.util.*;
import wsj.util.xml.base.*;
import wsj.util.xml.config.*;

public class XMLconfig {
  private static XMLconfig instance;
  private static String xmlfile = "/home/cosif/atmppp/env/ATMconfig.xml";
  //private static String xmlfile = "atm.conf.file";

  public static synchronized XMLconfig getInstance() {
    if (instance == null) {
      try{
        instance = new XMLconfig();
        XMLconfig.xmlfile = System.getProperty(XMLconfig.xmlfile);
        if( XMLconfig.xmlfile == null )
          XMLconfig.xmlfile = xmlfile;
        }catch(Exception igex){}
    }
    return instance;
  }
  public String GetEnvValue(String ele1,String ele2){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChildTextTrim(ele2);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChildTextTrim(ele3);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3,String ele4){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChild(ele3).getChildTextTrim(ele4);
  }
  public XMLconfig() {
  }
  public static void main(String[] args) {
    XMLconfig.getInstance().GetEnvValue("SERVICE","MAX_TIME_OUT");
  }


}



/********************************************************************************
 * ATMCONFIG.XML
 ********************************************************************************

<?xml version="1.0" encoding="euc-kr"?>

<ENVIRONMENT>

        <TRANSACTION-BLOCKING>
                <MASTER>
                        <KEY>CHBU169</KEY>
                        <TXBLOCKCNT>5</TXBLOCKCNT>
                        <TXCODE>
                                <EMODE>OFF</EMODE>
                                <EVNTS1>80001</EVNTS1>
                                <EVNTE1>80002</EVNTE1>
                                <EVNTS2>80005</EVNTS2>
                                <EVNTE2>80005</EVNTE2>
                                <EVNTS3>*</EVNTS3>
                                <EVNTE3>*</EVNTE3>
                                <EVNTS4>*</EVNTS4>
                                <EVNTE4>*</EVNTE4>
                                <EVNTS5>*</EVNTS5>
                                <EVNTE5>*</EVNTE5>
                        </TXCODE>
                        <TELLER>
                                <TMODE>OFF</TMODE>
                                <TELLS>NotUse</TELLS>
                                <TELLE>NotUse</TELLE>
                                <TELLS1>0238001</TELLS1>
                                <TELLE1>0238001</TELLE1>
                                <TELLS2>*</TELLS2>
                                <TELLE2>*</TELLE2>
                                <TELLS3>*</TELLS3>
                                <TELLE3>*</TELLE3>
                                <TELLS4>*</TELLS4>
                                <TELLE4>*</TELLE4>
                                <TELLS5>*</TELLS5>
                                <TELLE5>*</TELLE5>
                        </TELLER>
                        <BRANCH>
                                <BMODE>OFF</BMODE>
                                <BRCHS>NotUse</BRCHS>
                                <BRCHE>NotUse</BRCHE>
                                <BRCHS1>*</BRCHS1>
                                <BRCHE1>*</BRCHE1>
                                <BRCHS2>*</BRCHS2>
                                <BRCHE2>*</BRCHE2>
                                <BRCHS3>*</BRCHS3>
                                <BRCHE3>*</BRCHE3>
                                <BRCHS4>*</BRCHS4>
                                <BRCHE4>*</BRCHE4>
                                <BRCHS5>*</BRCHS5>
                                <BRCHE5>*</BRCHE5>
                        </BRANCH>
                </MASTER>
                <SLAVE>
                        <KEY>CHBU168</KEY>
                        <TXBLOCKCNT>5</TXBLOCKCNT>
                        <TXCODE>
                                <EMODE>OFF</EMODE>
                                <EVNTS1>80001</EVNTS1>
                                <EVNTE1>80002</EVNTE1>
                                <EVNTS2>80005</EVNTS2>
                                <EVNTE2>80005</EVNTE2>
                                <EVNTS3>*</EVNTS3>
                                <EVNTE3>*</EVNTE3>
                                <EVNTS4>*</EVNTS4>
                                <EVNTE4>*</EVNTE4>
                                <EVNTS5>*</EVNTS5>
                                <EVNTE5>*</EVNTE5>
                        </TXCODE>
                        <TELLER>
                                <TMODE>OFF</TMODE>
                                <TELLS>NotUse</TELLS>
                                <TELLE>NotUse</TELLE>
                                <TELLS1>0238001</TELLS1>
                                <TELLE1>0238001</TELLE1>
                                <TELLS2>*</TELLS2>
                                <TELLE2>*</TELLE2>
                                <TELLS3>*</TELLS3>
                                <TELLE3>*</TELLE3>
                                <TELLS4>*</TELLS4>
                                <TELLE4>*</TELLE4>
                                <TELLS5>*</TELLS5>
                                <TELLE5>*</TELLE5>
                        </TELLER>
                        <BRANCH>
                                <BMODE>OFF</BMODE>
                                <BRCHS>NotUse</BRCHS>
                                <BRCHE>NotUse</BRCHE>
                                <BRCHS1>0238</BRCHS1>
                                <BRCHE1>0238</BRCHE1>
                                <BRCHS2>*</BRCHS2>
                                <BRCHE2>*</BRCHE2>
                                <BRCHS3>*</BRCHS3>
                                <BRCHE3>*</BRCHE3>
                                <BRCHS4>*</BRCHS4>
                                <BRCHE4>*</BRCHE4>
                                <BRCHS5>*</BRCHS5>
                                <BRCHE5>*</BRCHE5>
                        </BRANCH>
                </SLAVE>
        </TRANSACTION-BLOCKING>

        <RESOURCE>
                <TIMEZONE>GMT+09:00</TIMEZONE>
                <TPSVCINFO_LOOP_SEC>20000</TPSVCINFO_LOOP_SEC>
        </RESOURCE>

        <MACHINE>
                <MASTER>
                        <KEY>CHBU169</KEY>
                        <IP>21.101.3.49</IP>
                        <ENV_DIR>/home/cosif/atmppp/env/JBBCONF.ini</ENV_DIR>
                        <TAR_PATH>/home/cosif/atmppp/env/</TAR_PATH>
                        <USER>cosif</USER>
                        <PAWD>cosif</PAWD>
                        <LOGFILENAME>/home/cosif/atmppp/log/bizlog/atmppp</LOGFILENAME>
                        <SYSLOGFILENAME>/home/cosif/atmppp/log/bizlog/system</SYSLOGFILENAME>
                        <BIZLOGFILENAME>/home/cosif/atmppp/log/packet/</BIZLOGFILENAME>
                        <JBB_CONF>/home/cosif/atmppp/env/JBBCONF.ini</JBB_CONF>
                        <LOGINATM>/home/cosif/atmppp/log/atminfo/</LOGINATM>
                </MASTER>
                <SLAVE>
                        <KEY>CHBU168</KEY>
                        <IP>21.101.3.48</IP>
                        <ENV_DIR>/home/cosif/atmppp/env/JBBCONF.ini</ENV_DIR>
                        <TAR_PATH>/home/cosif/atmppp/env/</TAR_PATH>
                        <USER>cosif</USER>
                        <PAWD>cosif</PAWD>
                        <LOGFILENAME>/home/cosif/atmppp/log/bizlog/atmppp</LOGFILENAME>
                        <SYSLOGFILENAME>/home/cosif/atmppp/log/bizlog/system</SYSLOGFILENAME>
                        <BIZLOGFILENAME>/home/cosif/atmppp/log/packet/</BIZLOGFILENAME>
                        <JBB_CONF>/home/cosif/atmppp/env/JBBCONF.ini</JBB_CONF>
                        <LOGINATM>/home/cosif/atmppp/log/atminfo/</LOGINATM>
                </SLAVE>
        </MACHINE>

        <RESOURCEMANAGER>
                <MASTER>
                <DRIVER>oracle.jdbc.driver.OracleDriver</DRIVER>
                        <URL>jdbc:oracle:thin:@21.101.3.49:1521:DEVACCT</URL>
                        <USER>eplaton</USER>
                        <PASSWORD>eplaton</PASSWORD>
                        <InitConnCnt>5</InitConnCnt>
                        <MaxConnCnt>5</MaxConnCnt>
                        <MaxConnTimeout>60</MaxConnTimeout>
                </MASTER>
                <SLAVE>
                        <DRIVER>oracle.jdbc.driver.OracleDriver</DRIVER>
                        <URL>jdbc:oracle:thin:@21.101.3.48:1521:DEVACCT</URL>
                        <USER>eplaton</USER>
                        <PASSWORD>enewton</PASSWORD>
                        <InitConnCnt>5</InitConnCnt>
                        <MaxConnCnt>5</MaxConnCnt>
                        <MaxConnTimeout>60</MaxConnTimeout>
                </SLAVE>
        </RESOURCEMANAGER>

        <EJBPOOL>
                <MASTER>
                        <RMISERVER>21.101.3.49</RMISERVER>
                        <RMIPORT>10000</RMIPORT>
                        <eInitConnCnt>5</eInitConnCnt>
                        <eMaxConnCnt>5</eMaxConnCnt>
                        <eMaxConnTimeout>60</eMaxConnTimeout>
                </MASTER>
                <SLAVE>
                        <RMISERVER>21.101.3.48</RMISERVER>
                        <RMIPORT>10000</RMIPORT>
                        <eInitConnCnt>5</eInitConnCnt>
                        <eMaxConnCnt>5</eMaxConnCnt>
                        <eMaxConnTimeout>60</eMaxConnTimeout>
                </SLAVE>
        </EJBPOOL>

        <SERVICE>
                <SERVICECNT>1</SERVICECNT>
                <MAX_TIME_OUT>305000</MAX_TIME_OUT>
                <SERVICE01>
                        <PORT>45530</PORT>
                        <MAX_THR_CNT>20</MAX_THR_CNT>
                        <LOG>/home/cosif/atmppp/log/ATMserver.45530.out</LOG>
                        <BOOTINFO>M</BOOTINFO>
                </SERVICE01>
                <SERVICE02>
                        <PORT>45531</PORT>
                        <MAX_THR_CNT>2</MAX_THR_CNT>
                        <LOG>/home/cosif/atmppp/log/ATMserver.45530.out</LOG>
                        <BOOTINFO>M</BOOTINFO>
                </SERVICE02>
                <SERVICE03>
                        <PORT>45532</PORT>
                        <MAX_THR_CNT>2</MAX_THR_CNT>
                        <LOG>/home/cosif/atmppp/log/ATMserver.45530.out</LOG>
                        <BOOTINFO>M</BOOTINFO>
                </SERVICE03>
        </SERVICE>

        <NETWORK>
                <MASTER>
                        <RMISERVER>21.101.3.49</RMISERVER>
                        <RMIPORT>10000</RMIPORT>
                </MASTER>
                <SLAVE>
                        <RMISERVER>21.101.3.48</RMISERVER>
                        <RMIPORT>10000</RMIPORT>
                </SLAVE>
        </NETWORK>

</ENVIRONMENT>
 *********************************************************************************/
