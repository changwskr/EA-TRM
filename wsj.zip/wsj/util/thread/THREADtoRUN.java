package wsj.util.thread;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class THREADtoRUN
{
  public static void execute(Runnable obj,String thread_name)
  {
    try{
      Thread thr = new Thread(obj,thread_name);
      thr.start();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
  public static void main()
  {
    THREADtoRUN.execute(new kk(),"thread_name_kk");

  }
}

class kk implements Runnable
{
  public void run()
  {
    System.out.println("--");
    return;
  }
}




