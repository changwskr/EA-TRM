package wsj.util.number;

import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

//�Ҽ� �ݿø� �� ���ϱ�.


public class Round{
  public static void main(String[] args) {
    InputStreamReader isr = new InputStreamReader(System.in);
    BufferedReader reader = new BufferedReader(isr);
    String line = null;

    try{
      while( (line = reader.readLine()) != null ) {
	double number = Double.parseDouble(line);
	int i = (int)number;

	if( (double)i == number ){
          System.out.println("Not float>" + (int)number );
          continue;
	}

        System.out.println("Inputed number>" + number);
        System.out.println("Rounded number>" + Math.round(number));
      }
    }catch(IOException e){
      e.printStackTrace();
    }
  }
}
