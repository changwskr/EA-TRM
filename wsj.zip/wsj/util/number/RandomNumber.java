package wsj.util.number;

//Random �ѹ� �����ϱ�.
import java.util.Random;

public class RandomNumber{
  public static void main(String[] args) {
    Random random = new Random( System.currentTimeMillis() );

    while(true){
      try{
        Thread.currentThread().sleep(500);
      }catch(InterruptedException e){}

      System.out.println( Math.abs( random.nextInt() ) );
    }
  }
}
