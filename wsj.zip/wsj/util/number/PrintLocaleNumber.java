package wsj.util.number;

//���� ���ѹα� ������ ���信 ���߾� ����ϱ�.
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.text.ParseException;

public class PrintLocaleNumber{
  static double myNumber = -1234.56;

  public static void main(String[] args) {

    System.out.println("  Source Number : -1234.56 ");
    System.out.println("  <Locale Name>  : <Pattern>\t: <Localized>\t: <Possible>");
    p( Locale.KOREA, NumberFormat.getInstance(Locale.KOREA) );
    p( Locale.KOREA, NumberFormat.getIntegerInstance(Locale.KOREA) );
    p( Locale.KOREA, NumberFormat.getCurrencyInstance(Locale.KOREA) );
    p( Locale.KOREA, NumberFormat.getPercentInstance(Locale.KOREA) );
  }

  public static void p(Locale loc, NumberFormat form){
    System.out.print(loc.getDisplayName());

    if (form instanceof DecimalFormat) {
      System.out.print(": " + ((DecimalFormat) form).toPattern());
    }

    System.out.print(" \t: " + form.format(myNumber));
    try {
      System.out.println(" \t: " + form.parse(form.format(myNumber)));
    } catch (ParseException e) {}
  }
}
