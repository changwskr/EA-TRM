package wsj.util.compress;

import java.io.*;

public class SYSCompress {

  // @comment : ���ϸ��� �Է¹޾� gzip���� �����Ѵ�.
  // @param   : fileName = filePath + fileName
  //			  type -> c : compress
  //			  type -> u : release
  // @return  : <success : true>
  //			  <fail : false>
  //
  // fileName : C:\\MYTEST\\CHB\\SRC\\Falogght0.wsjang.2002


  public static boolean Compress(char type,String fileName)
  {
    String Compress = "compress -f " + fileName;
    String UNCompress = "uncompress " + fileName;

    if( fileName == null || fileName.equals("") ){
      System.out.println("Compress cFileName :: is null ");
      return false;
    }

    switch( type )
    {
      case 'c':

        try {
          if( !exec_sys_command(Compress) ){
            return false;
          }
          if( !FILEexist(fileName+".Z") ){
            return false;
          }
        }
        catch(Exception ex) {
          ex.printStackTrace();
          System.out.println("Compress cException :: " + ex.getMessage() );
          System.out.println("Compress cFileName :: " + fileName );
          return false;
        }
        return true;

      case 'u':

        try {
          if( FILEexist(fileName) ){
            FILEdel(fileName);
          }

          if( !exec_sys_command(UNCompress) ){
            return false;
          }
          if( !FILEexist(fileName) ){
            return false;
          }
        }
        catch(Exception ex) {
          ex.printStackTrace();
          System.out.println("Compress cException :: " + ex.getMessage() );
          System.out.println("Compress cFileName :: " + fileName );
          return false;
        }
        return true;

      default :
        System.out.println("Compress tException :: " );
      System.out.println("Compress tFileName :: " + fileName );
      return false;
    }
  }

  public static boolean exec_sys_command(String cmd)
  {
    boolean succeed = false;
    Process process = null;
    BufferedReader in = null;
    try{
      process = Runtime.getRuntime().exec(cmd);
      in = new BufferedReader(new InputStreamReader(process.getInputStream()));
      String error = null;
      while ((error = in.readLine()) != null)
      {
        System.out.println(error);
      }
      succeed=true;
    }
    catch(Exception e){
      e.printStackTrace();
      succeed=false;
    }
    finally{
      try{
         process.destroy();
         in.close();
      }catch(Exception e){
        e.printStackTrace();
      }
    }
    return succeed;
  }

  public static void main(String[] args)
      throws IOException {

    //Compress('c',".\\kk.txt");
    //Compress('u',".\\kk.txt");
    try
    {
      SYSCompress.Compress('c',"/home/cosif/samgokgy/src/kk");
      Thread.currentThread().sleep(30000);
      SYSCompress.Compress('u',"/home/cosif/samgokgy/src/kk");
    }
    catch (InterruptedException ex)
    {
    }

  }

  public static boolean FILEexist(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists());
      else
        return false;
    }
    catch(Exception ex) {
      System.out.println("FILEexist Exception :: " + ex.getMessage() );
      System.out.println("FILEexit FileName  :: " + fname );
      return false;
    }
    return true;
  }

  public static boolean FILEdel(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists());
      else
        return false;

      f.delete();
    }
    catch(Exception ex) {
      System.out.println("FILEdel Exception :: " + ex.getMessage() );
      System.out.println("FILEdel FileName  :: " + fname );
      return false;
    }
    return true;
  }



}  ///:~
