package wsj.util.date;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.text.ParseException;

public class NonExistDateException extends ParseException
{

    public NonExistDateException(String s)
    {
        this(s, -1);
    }

    public NonExistDateException(String s, int errOffset)
    {
        super(s, errOffset);
    }
}
