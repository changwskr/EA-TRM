package wsj.util.log;

import java.io.*;
import java.rmi.*;
import java.util.*;
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;

/**
 * <PRE>
 * Class    : Logging
 * Function :
 * Comment  : Log File Writing <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

public class Logging {
  private static Logging instance;
  public String logging_file_name;
  public String log_mode_manage_file_name;
  public long omode;
  public int pint;

  public Logging() throws IOException,NotBoundException {
  }
  public static synchronized Logging getInstance(String logging_file_name,String log_mode_manage_file_name) {
    if (instance == null) {
      try{
        instance = new Logging();
        instance.logging_file_name = logging_file_name;
        instance.log_mode_manage_file_name = log_mode_manage_file_name;
        instance.omode = FILElastmodified(instance.log_mode_manage_file_name);
        instance.pint = Integer.valueOf(Logging.GetEnvValue(instance.log_mode_manage_file_name,"LOGGING_MODE")).intValue();
      }
      catch(Exception igex){
        igex.printStackTrace();
      }
    }
    return instance;
  }
  public static synchronized Logging getInstance(String logging_file_name) {
    if (instance == null) {
      try{
        instance = new Logging();
        instance.logging_file_name = logging_file_name;
      }
      catch(Exception igex){
        igex.printStackTrace();
      }
    }
    return instance;
  }

  public static synchronized Logging getInstance() {
    if (instance == null) {
      try{
        instance = new Logging();
      }
      catch(Exception igex){
        igex.printStackTrace();
      }
    }
    return instance;
  }

  public synchronized static String GetEnvValue(String envfilename,String tmp)
  {
    String ConfigPath=null;
    Properties p = new Properties();
    String tmpv = null;
    try {
      p.load(new FileInputStream(envfilename));
      tmpv=p.getProperty(tmp);
    }
    catch (IOException e) {
      System.out.println("GetEnvValue() ���� ȯ����ý�12 ���ܹ߻�" );
      e.printStackTrace();
    }
    return tmpv;
  }
  public boolean getLoggingMode(int mode){
    try{
      long nmode = FILElastmodified(this.log_mode_manage_file_name);
      if( nmode != this.omode ){
        this.omode = FILElastmodified(instance.log_mode_manage_file_name);
        this.pint = Integer.valueOf(Logging.GetEnvValue(instance.log_mode_manage_file_name,"LOGGING_MODE")).intValue();
      }
      if( mode >= this.pint ){
        return true; //�α볲���
      }
      else
        return false; //�α볲�����ʴ´�
    }
    catch(Exception ex){
      return false;
    }
  }
  public synchronized void printf(int mode,String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      if( !this.getLoggingMode(mode) )
        return;
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = GetSysTime().substring(0,8) + "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }
  public synchronized void printf(String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = GetSysTime().substring(0,8) + "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }

  public synchronized void printf(char mode,String contentToWrite) {
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      switch( mode )
      {
        case 'j':
          LOGFILENAME = "jsp"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           "/weblogic/sh/deploy/jsprcp " + contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
        case 'm':
          LOGFILENAME = "mrd"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           "/weblogic/sh/deploy/mrdrcp " + contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
        case 'c':
          LOGFILENAME = "class"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           "/weblogic/sh/deploy/clsrcp " + contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
        case 'e':
          LOGFILENAME = "ejb"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           "/weblogic/sh/deploy/ejbrcp "+ contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
        case 't':
          LOGFILENAME = "js"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           "/weblogic/sh/deploy/jstrcp " + contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
        default:
          LOGFILENAME = "default"  + "." + GetHostName() + "." + GetSysDate();
          fos = new FileOutputStream(LOGFILENAME, true);
          ps = new PrintStream(fos);
          contentToWrite = GetSysTime().substring(0,8) + "|" +
                           contentToWrite;
          ps.println(contentToWrite);
          ps.flush();
          ps.close();
          fos.close();
          break;
      }
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }

  public synchronized void eprintf(int mode,Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      if( !this.getLoggingMode(mode) )
        return;
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      e.printStackTrace();
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex)
      {}
    }
    return;
  }
  public synchronized void eprintf(Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      e.printStackTrace();
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex)
      {}
    }
    return;
  }

  public static String GetHostName()
  {
    InetAddress Address=null ;
    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }
  public static String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }
  public static String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }
  public static long FILElastmodified ( String fname )
  {
    long strtmp = -1;
    try {
      File f = new File(fname);
      if(f.exists());
      else
        throw new IOException(fname + "Not Found");
      strtmp = f.lastModified();
    }
    catch(Exception ex) {
      System.out.println("FILEabsolutpath Exception :: " + ex.getMessage() );
      System.out.println("FILEabsolutpath FileName  :: " + fname );
      return -1;
    }
    return strtmp;
  }
  ////////////////////////////////////////////////////////////////////////////
  // �ﱹ���� ���� �α��ó
  ////////////////////////////////////////////////////////////////////////////
  public synchronized static void sampdebug(String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      LOGFILENAME = "/home/cosif/samgokgy/log/plog/"  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = GetSysTime().substring(0,8) + "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }
  public static synchronized void samedebug(Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      LOGFILENAME = "/home/cosif/samgokgy/log/plog/"  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      e.printStackTrace();
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex)
      {}
    }
    return;
  }

  public synchronized void logging(String contentToWrite) {
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      fos = new FileOutputStream(this.logging_file_name, true);
      ps = new PrintStream(fos);
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }


}
