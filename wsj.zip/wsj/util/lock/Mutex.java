package wsj.util.lock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Mutex {

  Thread locker = null;

  public Mutex() {
  }

  public static void main(String[] args) {
    Mutex mutexLock1 = new Mutex();

  }
  public void lock() {
    boolean interrupted = false;

    synchronized (this) {
      while (locker != null) {
        try {
          wait();
        }
        catch (InterruptedException e) {
          interrupted = true;
        }

      }

      locker = Thread.currentThread();

      if (interrupted) {
        locker.interrupt();
      }
    }
  }

  public void unlock() {
    synchronized (this) {
      if (!locker.equals(Thread.currentThread())) {
        throw new IllegalMonitorStateException("Mutex.unlock(): Not owner");
      }

      locker = null;
      notify();
    }
  }
}
