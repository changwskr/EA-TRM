package wsj.util.lock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MutexLock {

  Thread locker = null;

  public MutexLock() {
  }

  public static void main(String[] args) {
    MutexLock mutexLock1 = new MutexLock();

  }
  public void lock() {
    boolean interrupted = false;

    synchronized (this) {
      while (locker != null) {
        try {
          wait();
        }
        catch (InterruptedException e) {
          interrupted = true;
        }

      }

      locker = Thread.currentThread();

      if (interrupted) {
        locker.interrupt();
      }
    }
  }

  public void unlock() {
    synchronized (this) {
      if (!locker.equals(Thread.currentThread())) {
        throw new IllegalMonitorStateException("MutexLock.unlock(): Not owner");
      }

      locker = null;
      notify();
    }
  }
}
