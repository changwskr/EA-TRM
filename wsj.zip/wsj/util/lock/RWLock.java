package wsj.util.lock;

public class RWLock {
  int locks;
  int waitingWriters;

  public RWLock() {
    locks = 0;
    waitingWriters = 0;
  }

  public boolean tryRLock() {
    synchronized (this) {
      if ( (locks == -1) || (waitingWriters != 0)) {
        return true;
      }
    }

    return false;
  }

  public void rlock() {
    boolean interrupted = false;

    synchronized (this) {
      try {
        while ( (locks == -1) || (waitingWriters != 0)) {
          wait();
        }
      }
      catch (InterruptedException e) {
        interrupted = true;
      }

      locks++;
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public void wlock() {
    boolean interrupted = false;

    synchronized (this) {
      waitingWriters++;

      try {
        while (locks != 0) {
          wait();
        }
      }
      catch (InterruptedException e) {
        interrupted = true;
      }

      waitingWriters--;
      locks = -1;
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public void unlock() {
    synchronized (this) {
      if (locks == 0) {
        return;
      }

      else if (locks == -1) {
        locks = 0;
      }
      else {
        locks--;

      }
      notifyAll();
    }
  }
}
