package wsj.util.lock;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


public class LockConditionVariable {

  public void wait(Mutex mutex)
  {
    boolean interrupted = false;

    while (true) {
      try {
        synchronized (this) {
          mutex.unlock();
          wait();
          break;
        }
      }
      catch (InterruptedException e) {
        interrupted = true;
      }
    }

    mutex.lock();
    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public void wait(Mutex mutex, long timeout) {
    boolean interrupted = false;

    while (true) {
      try {
        synchronized (this) {
          mutex.unlock();
          wait(timeout);
          break;
        }
      }
      catch (InterruptedException e) {
        interrupted = true;
      }
    }

    mutex.lock();
    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public synchronized void signal() {
    notify();
  }

  public synchronized void broadcast() {
    notifyAll();
  }
  public static void main(String[] args) {
    LockConditionVariable lockConditionVariable1 = new LockConditionVariable();
  }
}