package wsj.util.lock;

public class Semaphore {
  private int value;

  public Semaphore() {
    this(1);
  }

  public Semaphore(int i) {
    if (i < 1) {
      throw new IllegalArgumentException(i + " < 1");
    }
    value = i;
  }

  public void V() {
    value++;

    synchronized (this) {
      notify();
    }
  }

  public void P() throws InterruptedException {
    boolean interrupted = false;

    try {
      value--;

      while (value < 1) {
        synchronized (this) {
          wait();
        }
      }
    }
    catch (InterruptedException e) {
      interrupted = true;
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public void P(long timeout) throws InterruptedException {
    boolean interrupted = false;

    try {
      value--;

      while (value < 1) {
        synchronized (this) {
          wait(timeout);
        }
      }
    }
    catch (InterruptedException e) {
      interrupted = true;
    }

    if (interrupted) {
      Thread.currentThread().interrupt();
    }
  }

  public boolean tryP() {
    while (value > 0) {
      return true;
    }

    return false;
  }

  public synchronized int getValue() {
    return value;
  }
}
