package wsj.util.time;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AsciiToKsc {

  public AsciiToKsc() {
  }
  public static void main(String[] args) {
    AsciiToKsc asciiToKsc1 = new AsciiToKsc();
  }
}