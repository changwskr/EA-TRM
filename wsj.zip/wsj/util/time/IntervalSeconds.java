package wsj.util.time;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import wsj.util.string.String2Number;
import java.util.*;
import java.text.*;

public class IntervalSeconds {

  public IntervalSeconds() {
  }

  public int Interval_GetTimeSec( String psStartTimer, String psEndTimer )
  {
    String ss=null;
    String mm=null;
    String ee=null;
    int startsec=99999999;
    int	endsec=99999999;

    //System.out.println("-------start Interval_GetTimesec");
    /***********************************************************************/
    /* ����Ÿ��                                                            */
    /***********************************************************************/

    ss=psStartTimer.substring(0,2);
    mm=psStartTimer.substring(2,4);
    ee=psStartTimer.substring(4,6);
    startsec = String2Number.Str2Int(ss)*60*60 + String2Number.Str2Int(mm)*60 + String2Number.Str2Int(ee);

    /***********************************************************************/
    /* ����Ÿ��                                                            */
    /***********************************************************************/
    ss=psEndTimer.substring(0,2);
    mm=psEndTimer.substring(2,4);
    ee=psEndTimer.substring(4,6);
    endsec = String2Number.Str2Int(ss)*60*60 + String2Number.Str2Int(mm)*60 + String2Number.Str2Int(ee);

    //System.out.println("-------end Interval_GetTimesec " + new ConvUtil().Int2Str(endsec-startsec));

    return(endsec-startsec);

  }
  /*��¥�� ��¥���� ����� ���̰� ������ �˰� �ͽ��ϴ�. */

  public static long minuteDif () {
    String currentDateTime="03/21/2002 12:00";
    String dbDateTime="2002-03-21 12:12";
    try {
      SimpleDateFormat formatter=new SimpleDateFormat("MM/dd/yyyy HH:mm");
      Date cDate=formatter.parse(currentDateTime);
      long cd=(cDate.getTime())/60000;
      formatter=new SimpleDateFormat("yyyy-MM-dd HH:mm");
      Date dDate=formatter.parse(dbDateTime);
      long dd=(dDate.getTime())/60000;
      return Math.abs(dd-cd);
    }catch (Throwable e) {
      e.printStackTrace();
    }
    return 0;
  }


  public static void main(String[] args) {
    IntervalSeconds intervalSeconds1 = new IntervalSeconds();
  }
}