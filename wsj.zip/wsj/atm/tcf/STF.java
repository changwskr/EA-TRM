package wsj.atm.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import java.net.*;
import java.sql.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.common.FILEapi;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundProtoType;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.socket.ATMserverhandler;
import wsj.atm.socket.ATMserver;
import wsj.atm.tcf.TBL;
import wsj.atm.packet.IOBoundDep80001CDTO;
import wsj.atm.packet.IOBoundDep80002CDTO;
import wsj.atm.packet.IOBoundDep80003CDTO;

public class STF {
  private static STF instance;
  public IOBoundArea in ;
  public IOBoundArea out;
  private String packetinfo;
  private JEN jen;
  public long sttx=0;
  public String bizDate;
  public static String exrate;

  public static synchronized STF getInstance(IOBoundArea pIn,IOBoundArea pOut) {
    if (instance == null) {
      try{
        instance = new STF(pIn,pOut);
        }catch(Exception igex){}
    }
    return instance;
  }

  public STF(IOBoundArea pIn,IOBoundArea pOut) throws IOException {
    this.in = pIn;
    this.out = pOut;
    this.jen = new JEN();
  }

  public static synchronized STF getInstance() {
    if (instance == null) {
      try{
        instance = new STF();
      }catch(Exception igex){
        JLO.getInstance().eprintf(10,igex);
      }
    }
    return instance;
  }

  public STF() throws IOException,Exception{
    this.jen = new JEN();
    this.in = new IOBoundArea();
    this.out = new IOBoundArea();
  }

  public boolean execute(IOBoundArea pIn,IOBoundArea pOut){

    try{
      this.in = pIn;
      this.out = pOut;

      ///////////////////////////////////////////////////////////////
      // ������ �Ľ̽�Ų��.
      ///////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[STF_SPparsing START]");
      if( !STF_SPparsing() ){
        this.in.iohead.setBBrnSeq();
        this.in.iohead.setBErrCode("EI0001",this.out);
        this.in.iohead.setMsg("Application Exception[STF.STF_SPparsing::Parsing Ex]",this.out);
        this.in.iohead.setBInTime();
        this.in.iohead.setBOutTime();
        this.in.iohead.setBSysDate();
        this.STF_SetCurrentTimeMillis();
        this.setInOutHead();
        this.STF_SPcommonLog();
        JLO.getInstance().printf(10,"==================[STF_SPparsing END] (false)");
        return false;
      }
      JLO.getInstance().printf(1,"==================[STF_SPparsing END] (true)"+this.in.iohead.sBErrCode );

      ///////////////////////////////////////////////////////////////
      // �ð��������
      ///////////////////////////////////////////////////////////////
      this.STF_SetCurrentTimeMillis();

      ///////////////////////////////////////////////////////////////
      // INHEAD�� �ʱ�ȭ�Ѵ�.
      ///////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[STF_SPinit START]");
      if( !STF_SPinit() ){
        this.in.iohead.setBErrCode("EI0002",this.out);
        this.in.iohead.setMsg("Application Exception[STF.STF_SPinit]",this.out);
        this.in.iohead.setBInTime();
        this.in.iohead.setBOutTime();
        this.in.iohead.setBSysDate();
        this.setInOutHead();
        this.STF_SPcommonLog();
        JLO.getInstance().printf(10,"==================[STF_SPinit END] (false)");
        return false;
      }
      JLO.getInstance().printf(1,"==================[STF_SPinit END] (true)");

      if( isErr() ){
        this.in.iohead.setBOutTime();
        this.setInOutHead();
        this.STF_SPcommonLog();
        return false;
      }

      ////////////////////////////////////////////////////
      // Input - Output Head Builder
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[setInOutHead START]");
      if( !setInOutHead() ){
        this.in.iohead.setBErrCode("EI0003",this.out);
        this.in.iohead.setMsg("Application Exception[STF.setInOutHead]",this.out);
        this.in.iohead.setBOutTime();
        this.setInOutHead();
        this.STF_SPcommonLog();
        JLO.getInstance().printf(10,"==================[setInOutHead END] (false)");
        return false;
      }
      JLO.getInstance().printf(1,"==================[setInOutHead END] (true)");

      if( isErr() ){
        this.in.iohead.setBOutTime();
        this.setInOutHead();
        this.STF_SPcommonLog();
        return false;
      }

      ////////////////////////////////////////////////////
      // �ŷ������ڵ�
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[STF_SPtxctl START]");
      switch( STF_SPtxctl()){
        case -1:
          this.in.iohead.setBErrCode("EI0004",this.out);
          this.in.iohead.setMsg("Application Exception[STF.STF_SPtxctl]",this.out);
          this.in.iohead.setBOutTime();
          this.setInOutHead();
          this.STF_SPcommonLog();
          JLO.getInstance().printf(10,"==================[STF_SPtxctl END] (false)");
          return false;
        case  1:
          this.in.iohead.setBErrCode("EI0005",this.out);
          this.in.iohead.setMsg("Now, ATM Service Not allow",this.out);
          this.in.iohead.setBOutTime();
          this.setInOutHead();
          this.STF_SPcommonLog();
          JLO.getInstance().printf(10,"==================[STF_SPtxctl END] (false)");
          return false;
        case 0 :
          JLO.getInstance().printf(1,"==================[STF_SPtxctl END] (�ŷ����)");
          break;
      }
      JLO.getInstance().printf(1,"==================[STF_SPtxctl END] (true)");

      if( isErr() ){
        this.in.iohead.setBOutTime();
        this.setInOutHead();
        this.STF_SPcommonLog();
        return false;
      }

      ////////////////////////////////////////////////////
      // ���� ������
      ////////////////////////////////////////////////////
      this.setInOutHead();

      ////////////////////////////////////////////////////
      // SWB-HOST�� POLLING
      ////////////////////////////////////////////////////

       if( this.in.cdto.eventNo.equals("80010") ){
         this.in.sLength = this.out.sLength = "00000";
         this.in.iohead.setBErrCode("EI0100",this.out);
         this.in.iohead.setBOutTime();
         this.in.iohead.setMsg("Application Exception[STF.SWB Polling]",this.out);
         this.setInOutHead();
         this.STF_SPcommonLog();
         return false;
       }

      ////////////////////////////////////////////////////
      // �ŷ��α׸� �����Ѵ�.
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[STF_SPcommonLog START]");
      this.in.iohead.setMsg("Application Infomation[STF.Tx start nomarly]");

      if( !STF_SPcommonLog() ){
        this.in.iohead.setBErrCode("EI0006",this.out);
        this.in.iohead.setBOutTime();
        this.in.iohead.setMsg("Application Exception[STF.STF_SPcommonLog]",this.out);
        this.setInOutHead();
        if ( !this.in.cdto.getEventNo().equals("80010") ){
          JLO.getInstance().printf(10,"==================[STF_SPcommonLog() END] (false)");
        }
        return false;
      }
      JLO.getInstance().printf(1,"==================[STF_SPcommonLog() END] (true)");
    }
    catch(Exception ex){
      ex.printStackTrace();
      this.in.iohead.setBErrCode("EI0007",this.out);
      this.in.iohead.setBOutTime();
      this.in.iohead.setMsg("Application Exception[STF.Module]",this.out);
      this.setInOutHead();
      this.STF_SPcommonLog();
      JLO.getInstance().printf(10,"==================================================����[STF] EN");
      return false;
    }
    return true;
  }

  private boolean STF_SPparsing(){
    String ctmp="*";
    try {
      if( !this.in.setInParsing() ){
        this.in.iohead.sBBrnSeq=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBBrnSeq_LEN );/* ������ ���� Seq ��ȣ */
        this.in.iohead.sBSysDate=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBSysDate_LEN); 	    /* Real ���� */
        this.in.iohead.sBInTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBInTime_LEN);/* Host Input Time */
        this.in.iohead.sBOutTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBOutTime_LEN);
        this.in.iohead.sBErrCode=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBErrCode_LEN);
        this.in.iohead.sMsg=ComUtil.StarToStr(ctmp,IOBoundProtoType.sMsg_LEN);
        this.in.cdto.trxNumber=ComUtil.StarToStr(ctmp,IOBoundProtoType.trxNumber_LEN);
        this.in.iohead.setBErrCode("EI0008");
        this.in.iohead.setMsg("Application Exception[STF.STF_SPparsing]");
        return false;
      }
      this.in.iohead.sBBrnSeq=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBBrnSeq_LEN );/* ������ ���� Seq ��ȣ */
      this.in.iohead.sBSysDate=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBSysDate_LEN); 	    /* Real ���� */
      this.in.iohead.sBInTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBInTime_LEN);/* Host Input Time */
      this.in.iohead.sBOutTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBOutTime_LEN);
      this.in.iohead.sBErrCode=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBErrCode_LEN);
      this.in.iohead.sMsg=ComUtil.StarToStr(ctmp,IOBoundProtoType.sMsg_LEN);
      this.in.cdto.trxNumber=ComUtil.StarToStr(ctmp,IOBoundProtoType.trxNumber_LEN);

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().printf(10,"STF_SPparsing ����");
      this.in.iohead.sBBrnSeq=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBBrnSeq_LEN );/* ������ ���� Seq ��ȣ */
      this.in.iohead.sBSysDate=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBSysDate_LEN); 	    /* Real ���� */
      this.in.iohead.sBInTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBInTime_LEN);/* Host Input Time */
      this.in.iohead.sBOutTime=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBOutTime_LEN);
      this.in.iohead.sBErrCode=ComUtil.StarToStr(ctmp,IOBoundProtoType.sBErrCode_LEN);
      this.in.iohead.sMsg=ComUtil.StarToStr(ctmp,IOBoundProtoType.sMsg_LEN);
      this.in.cdto.trxNumber=ComUtil.StarToStr(ctmp,IOBoundProtoType.trxNumber_LEN);
      this.in.iohead.setBErrCode("EI0009");
      this.in.iohead.setMsg("Application Exception[STF.STF_SPparsing]");
      return false;
    }
    return true;
  }

  public boolean STF_SPinit(){
    try{
      if( !this.in.cdto.eventNo.equals("80010") ){
        if( !this.in.iohead.setBBrnSeq()){
          this.in.iohead.setBErrCode("EI0010",this.out);
          this.in.iohead.setMsg("Application Exception[STF.setSequence]",this.out);
          this.in.iohead.setBInTime();
          this.in.iohead.setBOutTime();
          this.in.iohead.setBSysDate();
          this.bizDate = GetBizDate();
          this.exrate = GetExRate();
          this.in.cdto.setBizDate(this.bizDate);
          this.out.cdto.setBizDate(this.in.cdto.bizDate);
          return false;
        }
      }
      this.in.iohead.setBErrCode("IZZ000",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Infomation[STF.STF_SPinit::start]",this.out);
      this.bizDate = GetBizDate();
      this.exrate = GetExRate();
      this.in.cdto.setBizDate(this.bizDate);
      this.out.cdto.setBizDate(this.in.cdto.bizDate);
      return true;
    }
    catch(Exception ex){
      this.in.iohead.setBErrCode("EI0011",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.STF_SPinit()]",this.out);
      return false;
    }
  }

  private boolean isErr(){
    switch (out.iohead.sBErrCode.charAt(0))
    {
      case 'e':
      case 's':
      case 'E':
      case 'S':
        return true;
      case 'I':
        return false;
      case '*':
      default:
        this.in.iohead.setBErrCode("EI0012",this.out);
      this.in.iohead.setMsg("Application Exception[STF.isErr::Not Set ErrCode]",this.out);
      return true;
    }
  }

  private  synchronized boolean STF_SPcommonLog() {
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      ///////////////////////////////////////////////
      // ping �ŷ��α״� �Ƚ״´�
      ///////////////////////////////////////////////
      if ( this.in.cdto.getEventNo().equals("80010") )
        return true;

      this.in.iohead.setBOutTime();

      LOGFILENAME = this.jen.BIZLOGFILENAME + ComUtil.GetHostName() + "." +
                    this.in.cdto.eventNo + "." +
                    "in" + "." +
                    ComUtil.GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);

      if ( this.in.cdto.getEventNo().equals("80001") )
      {
        String tmp = this.in.toString();
        IOBoundArea inbound = new IOBoundArea(tmp);

        IOBoundDep80001CDTO iobounddeposit =  new IOBoundDep80001CDTO();
        iobounddeposit.setIOBoundDep80001CDTOParsing(inbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80001CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        inbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(inbound.toString('^') );

        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      else if ( this.in.cdto.getEventNo().equals("80002") )
      {
        String tmp = this.in.toString();
        IOBoundArea inbound = new IOBoundArea(tmp);

        IOBoundDep80002CDTO iobounddeposit =  new IOBoundDep80002CDTO();
        iobounddeposit.setIOBoundDep80002CDTOParsing(inbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80002CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        inbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(inbound.toString('^') );

        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      else if ( this.in.cdto.getEventNo().equals("80003") )
      {
        String tmp = this.in.toString();
        IOBoundArea inbound = new IOBoundArea(tmp);

        IOBoundDep80003CDTO iobounddeposit =  new IOBoundDep80003CDTO();
        iobounddeposit.setIOBoundDep80003CDTOParsing(inbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80003CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        inbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(inbound.toString('^') );

        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      else{
        ps.println(this.in.toString('^') );
        ps.flush();
        ps.close();
        fos.close();
      }

    }catch(Exception e){
      this.in.iohead.setBErrCode("EI0013",this.out);
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.STF_SPcommonLog]",this.out);
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        return false;
    }
    return true;
  }

  private boolean setInOutHead()
  {
    try{
      out.iohead.sDInTime = in.iohead.sDInTime;
      out.iohead.sDSysDate = in.iohead.sDSysDate;
      out.iohead.sDTimer = in.iohead.sDTimer;

      out.iohead.sBBrnSeq = in.iohead.sBBrnSeq;
      out.iohead.sBSysDate = in.iohead.sBSysDate;
      out.iohead.sBInTime = in.iohead.sBInTime;
      out.iohead.sBOutTime = in.iohead.sBOutTime;
      out.iohead.sBErrCode = in.iohead.sBErrCode;
      out.iohead.sMsg = in.iohead.sMsg;

      out.iohead.sDLoginOffSet = in.iohead.sDLoginOffSet;
      out.iohead.sDSijaeOpenOffset = in.iohead.sDSijaeOpenOffset;
      out.iohead.sBEodOffset = in.iohead.sBEodOffset;
      out.iohead.sDSijaeClosOffset = in.iohead.sDSijaeClosOffset;
      out.iohead.sDMode = in.iohead.sDMode;

      //////////////////////////////////////////////
      // cdto
      //////////////////////////////////////////////
      out.cdto.bankCode = in.cdto.bankCode;
      out.cdto.branchCode = in.cdto.branchCode ;
      out.cdto.gIPostBrCode = in.cdto.gIPostBrCode;
      out.cdto.channelType = in.cdto.channelType;
      out.cdto.userId = in.cdto.userId;
      out.cdto.terminalId = in.cdto.terminalId;
      out.cdto.terminalType = in.cdto.terminalType;

      //EventNO
      out.cdto.eventNo = in.cdto.eventNo;
      out.cdto.nationCode = in.cdto.nationCode;
      out.cdto.regionCode = in.cdto.regionCode;
      out.cdto.timeZone = in.cdto.timeZone;
      out.cdto.fxRateSeq = in.cdto.fxRateSeq;
      out.cdto.xmlSeq = in.cdto.xmlSeq;
      out.cdto.cifNum = in.cdto.cifNum;
      out.cdto.refNum = in.cdto.refNum;

      //Deleagtion Layer ���� ���� �ʵ�
      out.cdto.reqName = in.cdto.reqName;
      out.cdto.trxDate = in.cdto.trxDate;
      out.cdto.bizDate = in.cdto.bizDate;
      out.cdto.trxInTime = in.cdto.trxInTime;
      out.cdto.trxOutTime = in.cdto.trxOutTime;
      out.cdto.trxNumber = in.cdto.trxNumber;

      //GLG
      out.cdto.voucherNum = in.cdto.voucherNum;

      //�� ���� thing
      out.cdto.refNum = in.cdto.refNum;
      out.cdto.cifNum = in.cdto.cifNum;

      //�� ���� Facade
      out.cdto.baseCurrency = in.cdto.baseCurrency;
      out.cdto.atmSeqNo = in.cdto.atmSeqNo;

      // ��������Ÿ ����
      this.setInDataOutData();
    }
    catch(Exception ex){
      ex.printStackTrace();
      if( out.iohead.sBErrCode.charAt(0) != 'E' ){
        out.iohead.setBErrCode("EI0014");
        out.iohead.setMsg("Application Exception[STF.setInOutHead::Parsing]");
      }
      return false;
    }
    return true;
  }

  private int STF_SPtxctl()
  {
    try{
      JLO.printf(1,this.in.cdto.userId + this.in.cdto.eventNo + this.in.cdto.branchCode);
      if( TBL.getInstance().isBlockingTx( this.in.cdto.userId,
          this.in.cdto.eventNo,
          this.in.cdto.branchCode))
      {
        this.in.iohead.setBErrCode("EI0015",this.out);
        this.in.iohead.setMsg("Now, ATM Service Not allow",this.out);
        return 1;
      }
      return 0;
    }
    catch(Exception ex){
      ex.printStackTrace();
      this.in.iohead.setBErrCode("EI0016",this.out);
      this.in.iohead.setMsg("Application Exception[STF.STF_SPtxctl]",this.out);
      JLO.getInstance().eprintf(10,ex);
      return -1;
    }
  }

  public static CosesCommonDTO getCosesCDTOfromInBoundArea(IOBoundArea inarea,CosesCommonDTO cdto) throws IOException{
    try{
      cdto.setTerminalID(inarea.cdto.terminalId);
      cdto.setTerminalType(inarea.cdto.terminalType);
      cdto.setXmlSeq(inarea.cdto.xmlSeq);
      cdto.setBankCode(inarea.cdto.bankCode);
      cdto.setBranchCode(inarea.cdto.branchCode);
      cdto.setGlPostBranchCode(inarea.cdto.gIPostBrCode);
      cdto.setChannelType(inarea.cdto.channelType);
      cdto.setUserID(inarea.cdto.userId);
      cdto.setEventNo(inarea.cdto.eventNo);
      cdto.setNation(inarea.cdto.nationCode);
      cdto.setRegionCode(inarea.cdto.regionCode);
      cdto.setTimeZone(inarea.cdto.timeZone);
      cdto.setReqName(inarea.cdto.reqName);
      cdto.setSystemDate(inarea.cdto.trxDate);
      cdto.setBusinessDate(inarea.cdto.bizDate);
      cdto.setSystemInTime(inarea.cdto.trxInTime);
      cdto.setSystemOutTime(inarea.cdto.trxOutTime);
      cdto.setTransactionNo(inarea.cdto.trxNumber);
      // ��ȭ�ڵ�κа� multiPL�κ��� �߰��Ѵ�.
      //this.inarea.cdto.CurrencyBase ===
      //this.inarea.cdto.MultiPL ===

      cdto.setTerminalID(ComUtil.CutSpaceToStr(cdto.getTerminalID(),IOBoundProtoType.terminalId_LEN));
      cdto.setTerminalType(ComUtil.CutSpaceToStr(cdto.getTerminalType(),IOBoundProtoType.terminalType_LEN));
      cdto.setXmlSeq(ComUtil.CutSpaceToStr(cdto.getXmlSeq(),IOBoundProtoType.xmlSeq_LEN));
      cdto.setBankCode(ComUtil.CutSpaceToStr(cdto.getBankCode(),IOBoundProtoType.bankCode_LEN));
      cdto.setBranchCode(ComUtil.CutSpaceToStr(cdto.getBranchCode(),IOBoundProtoType.branchCode_LEN));
      cdto.setGlPostBranchCode(ComUtil.CutSpaceToStr(cdto.getGlPostBranchCode(),IOBoundProtoType.gIPostBrCode_LEN));
      cdto.setChannelType(ComUtil.CutSpaceToStr(cdto.getChannelType(),IOBoundProtoType.channelType_LEN));
      cdto.setUserID(ComUtil.CutSpaceToStr(cdto.getUserID(),IOBoundProtoType.userId_LEN));
      cdto.setEventNo(ComUtil.CutSpaceToStr(cdto.getEventNo(),IOBoundProtoType.eventNo_LEN ));
      cdto.setNation(ComUtil.CutSpaceToStr(cdto.getNation(),IOBoundProtoType.nationCode_LEN));
      cdto.setRegionCode(ComUtil.CutSpaceToStr(cdto.getRegionCode(),IOBoundProtoType.regionCode_LEN));
      cdto.setTimeZone(ComUtil.CutSpaceToStr(cdto.getTimeZone(),IOBoundProtoType.timeZone_LEN));
      cdto.setReqName(ComUtil.CutSpaceToStr(cdto.getReqName(),IOBoundProtoType.reqName_LEN));
      cdto.setSystemDate(ComUtil.CutSpaceToStr(cdto.getSystemDate(),IOBoundProtoType.trxDate_LEN ));
      cdto.setBusinessDate(ComUtil.CutSpaceToStr(cdto.getBusinessDate(),IOBoundProtoType.bizDate_LEN));
      cdto.setSystemInTime(ComUtil.CutSpaceToStr(cdto.getSystemInTime(),IOBoundProtoType.trxInTime_LEN));
      cdto.setSystemOutTime(ComUtil.CutSpaceToStr(cdto.getSystemOutTime(),IOBoundProtoType.trxOutTime_LEN));
      cdto.setTransactionNo(ComUtil.CutSpaceToStr(cdto.getTransactionNo(),IOBoundProtoType.trxNumber_LEN));
      cdto.setBaseCurrency(ComUtil.CutSpaceToStr(cdto.getBaseCurrency(),IOBoundProtoType.baseCurrency_LEN));

      return cdto;
    }
    catch(Exception ex){
      ex.printStackTrace();
      throw new IOException();
    }
  }

  public static CosesCommonDTO getCosesCDTOfromInBoundArea(IOBoundArea inarea) throws IOException{
    try{
      CosesCommonDTO cdto = new CosesCommonDTO();

      cdto.setTerminalID(inarea.cdto.terminalId);
      cdto.setTerminalType(inarea.cdto.terminalType);
      cdto.setXmlSeq(inarea.cdto.xmlSeq);
      cdto.setBankCode(inarea.cdto.bankCode);
      cdto.setBranchCode(inarea.cdto.branchCode);
      cdto.setGlPostBranchCode(inarea.cdto.gIPostBrCode);
      cdto.setChannelType(inarea.cdto.channelType);
      cdto.setUserID(inarea.cdto.userId);
      cdto.setEventNo(inarea.cdto.eventNo);
      cdto.setNation(inarea.cdto.nationCode);
      cdto.setRegionCode(inarea.cdto.regionCode);
      cdto.setTimeZone(inarea.cdto.timeZone);
      cdto.setReqName(inarea.cdto.reqName);
      cdto.setSystemDate(inarea.cdto.trxDate);
      cdto.setBusinessDate(inarea.cdto.bizDate);
      cdto.setSystemInTime(inarea.cdto.trxInTime);
      cdto.setSystemOutTime(inarea.cdto.trxOutTime);
      cdto.setTransactionNo(inarea.cdto.trxNumber);
      // ��ȭ�ڵ�κа� multiPL�κ��� �߰��Ѵ�.
      //this.inarea.cdto.CurrencyBase ===
      //this.inarea.cdto.MultiPL ===

      cdto.setTerminalID(ComUtil.CutSpaceToStr(cdto.getTerminalID(),IOBoundProtoType.terminalId_LEN));
      cdto.setTerminalType(ComUtil.CutSpaceToStr(cdto.getTerminalType(),IOBoundProtoType.terminalType_LEN));
      cdto.setXmlSeq(ComUtil.CutSpaceToStr(cdto.getXmlSeq(),IOBoundProtoType.xmlSeq_LEN));
      cdto.setBankCode(ComUtil.CutSpaceToStr(cdto.getBankCode(),IOBoundProtoType.bankCode_LEN));
      cdto.setBranchCode(ComUtil.CutSpaceToStr(cdto.getBranchCode(),IOBoundProtoType.branchCode_LEN));
      cdto.setGlPostBranchCode(ComUtil.CutSpaceToStr(cdto.getGlPostBranchCode(),IOBoundProtoType.gIPostBrCode_LEN));
      cdto.setChannelType(ComUtil.CutSpaceToStr(cdto.getChannelType(),IOBoundProtoType.channelType_LEN));
      cdto.setUserID(ComUtil.CutSpaceToStr(cdto.getUserID(),IOBoundProtoType.userId_LEN));
      cdto.setEventNo(ComUtil.CutSpaceToStr(cdto.getEventNo(),IOBoundProtoType.eventNo_LEN ));
      cdto.setNation(ComUtil.CutSpaceToStr(cdto.getNation(),IOBoundProtoType.nationCode_LEN));
      cdto.setRegionCode(ComUtil.CutSpaceToStr(cdto.getRegionCode(),IOBoundProtoType.regionCode_LEN));
      cdto.setTimeZone(ComUtil.CutSpaceToStr(cdto.getTimeZone(),IOBoundProtoType.timeZone_LEN));
      cdto.setReqName(ComUtil.CutSpaceToStr(cdto.getReqName(),IOBoundProtoType.reqName_LEN));
      cdto.setSystemDate(ComUtil.CutSpaceToStr(cdto.getSystemDate(),IOBoundProtoType.trxDate_LEN ));
      cdto.setBusinessDate(ComUtil.CutSpaceToStr(cdto.getBusinessDate(),IOBoundProtoType.bizDate_LEN));
      cdto.setSystemInTime(ComUtil.CutSpaceToStr(cdto.getSystemInTime(),IOBoundProtoType.trxInTime_LEN));
      cdto.setSystemOutTime(ComUtil.CutSpaceToStr(cdto.getSystemOutTime(),IOBoundProtoType.trxOutTime_LEN));
      cdto.setTransactionNo(ComUtil.CutSpaceToStr(cdto.getTransactionNo(),IOBoundProtoType.trxNumber_LEN));
      cdto.setBaseCurrency(ComUtil.CutSpaceToStr(cdto.getBaseCurrency(),IOBoundProtoType.baseCurrency_LEN));
      return cdto;
    }
    catch(Exception ex){
      ex.printStackTrace();
      throw new IOException();
    }
  }

  public void STF_SetCurrentTimeMillis(){
    this.sttx = System.currentTimeMillis();
    this.in.cdto.setRefNum(ComUtil.LZeroToStr(ComUtil.Long2Str(this.sttx),IOBoundProtoType.refNum_LEN));
    this.out.cdto.setRefNum(this.in.cdto.refNum);
    this.in.cdto.setCifNum(ComUtil.LZeroToStr(ComUtil.Long2Str(this.sttx),IOBoundProtoType.cifNum_LEN));
    this.out.cdto.setCifNum(ComUtil.LZeroToStr(ComUtil.Long2Str(this.sttx),IOBoundProtoType.cifNum_LEN));
  }
  public IOBoundArea getInBoundArea(){
    return this.in.getIOBoundArea();
  }
  public IOBoundArea getOutBoundArea(){
    return this.out.getIOBoundArea();
  }
  public void setInDataOutData(){
    this.out.iodata.sBoundData = this.in.iodata.sBoundData;
    this.out.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.out.iodata.sBoundData.length()),5);
  }

  public String GetHostSeq()
  {
    String 		seqtmp=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;
    Connection  conn = null;
    int    		seq=0;

    try {
      conn = ATMserver.atmdbpool.getConnection();
      String tSQL = "SELECT SQ_COSIFHT_HOSTSEQ.NEXTVAL FROM DUAL";
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();
      seqtmp=ComUtil.Int2Str(rs.getInt(1));
    } catch(Exception e) {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0048",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetHostSeq()]",this.out);
      try {
        stmt.close();
        rs.close();
        ATMserver.atmdbpool.freeConnection(conn);
      }
      catch(Exception ex) { }
      return null;
    }
    try
    {
      stmt.close();
      rs.close();
      ATMserver.atmdbpool.freeConnection(conn);
    }
    catch(SQLException e)
    {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0048",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetHostSeq()]",this.out);
      return null;
    }
    return(ComUtil.ZeroToStr(seqtmp,9));
  }

  public String GetBizDate()
  {
    String 	bizdate=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;
    Connection  conn = null;

    try {
      conn = ATMserver.atmdbpool.getConnection();
      String tSQL = "SELECT DATE_VALUE1 FROM SYSTEM_PARAMETER WHERE SYSTEM='COR' AND KIND='BIZDATE'";
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();
      bizdate=ComUtil.Int2Str(rs.getInt(1));
      this.bizDate = bizdate;
    }
    catch(Exception e) {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0050",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetBizDate()]",this.out);
      try {
        stmt.close();
        rs.close();
        ATMserver.atmdbpool.freeConnection(conn);
      }
      catch(Exception ex) { }
      return null;
    }
    try
    {
      stmt.close();
      rs.close();
      ATMserver.atmdbpool.freeConnection(conn);
    }
    catch(SQLException e)
    {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0050",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetBizDate()]",this.out);
      return null;
    }
    this.bizDate = bizdate;
    JLO.getInstance().printf(1,"business date : " + bizDate);
    return(bizdate);
  }

  public String GetExRate()
  {
    String 	exrate=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;
    Connection  conn = null;

    try {
      conn = ATMserver.atmdbpool.getConnection();
      String tSQL = "SELECT 'USD1=VND'|| ttb FROM currency_code WHERE currency='USD'";
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();
      exrate=(rs.getString(1));
      this.exrate = exrate;
    }
    catch(Exception e) {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0051",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetExRate()]",this.out);
      try {
        stmt.close();
        rs.close();
        ATMserver.atmdbpool.freeConnection(conn);
      }
      catch(Exception ex) { }
      return null;
    }
    try
    {
      stmt.close();
      rs.close();
      ATMserver.atmdbpool.freeConnection(conn);
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setBErrCode("EI0051",this.out);
      this.in.iohead.setBInTime();
      this.in.iohead.setBOutTime();
      this.in.iohead.setBSysDate();
      this.in.iohead.setMsg("Application Exception[STF.GetExRate()]",this.out);
      return null;
    }
    this.exrate = exrate;
    JLO.getInstance().printf(1,"exrate date : " + exrate);
    return(exrate);
  }

}