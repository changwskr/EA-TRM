package wsj.atm.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.text.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;

import wsj.atm.common.FILEapi;
import wsj.atm.log.JLO;

public class TBL2 {
  private static TBL2 instance;
  public static long otxctlmode=0;
  public static long ntxctlmode=0;
  public static String fname=JEN.JBB_CONF_FILE;
  public static Hashtable ht = new Hashtable();

  public static synchronized TBL2 getInstance() {
    if (instance == null) {
      try{
        instance = new TBL2();
      }
      catch(Exception igex){
        JLO.eprintf(10,igex);
      }
    }
    return instance;
  }

  public TBL2() throws IOException {
    /*
    this.ht.put("TXBLOCKCNT",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TXBLOCKCNT"));
    this.ht.put("TMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TMODE"));
    this.ht.put("TELLS",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TELLS"));
    this.ht.put("TELLE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TELLE"));

    this.ht.put("EMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EMODE"));
    this.ht.put("EVNTS1",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS1"));
    this.ht.put("EVNTE1",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE1"));
    this.ht.put("EVNTS2",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS2"));
    this.ht.put("EVNTE2",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE2"));
    this.ht.put("EVNTS3",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS3"));
    this.ht.put("EVNTE3",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE3"));
    this.ht.put("EVNTS4",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS4"));
    this.ht.put("EVNTE4",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE4"));
    this.ht.put("EVNTS5",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS5"));
    this.ht.put("EVNTE5",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE5"));

    this.ht.put("BMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BMODE"));
    this.ht.put("BRCHS",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BRCHS"));
    this.ht.put("BRCHE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BRCHE"));
    */
    try{

      if( ComUtil.GetHostName().equals(
                                       ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){
        this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","TXBLOCKCNT"));
        this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
        this.ht.put("TELLS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"));
        this.ht.put("TELLE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"));

        this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
        this.ht.put("EVNTS1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS1"));
        this.ht.put("EVNTE1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE1"));
        this.ht.put("EVNTS2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS2"));
        this.ht.put("EVNTE2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE2"));
        this.ht.put("EVNTS3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS3"));
        this.ht.put("EVNTE3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE3"));
        this.ht.put("EVNTS4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS4"));
        this.ht.put("EVNTE4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE4"));
        this.ht.put("EVNTS5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS5"));
        this.ht.put("EVNTE5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE5"));

        this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
        this.ht.put("BRCHS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"));
        this.ht.put("BRCHE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"));
      }
      else if( ComUtil.GetHostName().equals(
          ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
        this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","TXBLOCKCNT"));
        this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
        this.ht.put("TELLS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"));
        this.ht.put("TELLE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"));

        this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
        this.ht.put("EVNTS1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS1"));
        this.ht.put("EVNTE1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE1"));
        this.ht.put("EVNTS2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS2"));
        this.ht.put("EVNTE2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE2"));
        this.ht.put("EVNTS3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS3"));
        this.ht.put("EVNTE3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE3"));
        this.ht.put("EVNTS4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS4"));
        this.ht.put("EVNTE4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE4"));
        this.ht.put("EVNTS5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS5"));
        this.ht.put("EVNTE5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE5"));

        this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
        this.ht.put("BRCHS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"));
        this.ht.put("BRCHE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"));
      }
    }
    catch(Exception ex){}
  }

  public boolean changeFileMode() {
    this.ntxctlmode = FILEapi.FILElastmodified(TBL2.fname);
    if( this.ntxctlmode != this.otxctlmode ){
      return true;
    }
    return false;
  }

  public void updateTxCtlInfo() throws IOException{
    if( changeFileMode() ){
      JLO.printf(1,"JBBCONF.INI ���ϼӼ��� ����");
      /*
      this.ht.put("TXBLOCKCNT",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TXBLOCKCNT"));
      this.ht.put("TMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TMODE"));
      this.ht.put("TELLS",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TELLS"));
      this.ht.put("TELLE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("TELLE"));

      this.ht.put("EMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EMODE"));
      this.ht.put("EVNTS1",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS1"));
      this.ht.put("EVNTE1",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE1"));
      this.ht.put("EVNTS2",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS2"));
      this.ht.put("EVNTE2",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE2"));
      this.ht.put("EVNTS3",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS3"));
      this.ht.put("EVNTE3",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE3"));
      this.ht.put("EVNTS4",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS4"));
      this.ht.put("EVNTE4",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE4"));
      this.ht.put("EVNTS5",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTS5"));
      this.ht.put("EVNTE5",UbbConfig.getInstance(TBL2.fname).GetEnvValue("EVNTE5"));

      this.ht.put("BMODE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BMODE"));
      this.ht.put("BRCHS",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BRCHS"));
      this.ht.put("BRCHE",UbbConfig.getInstance(TBL2.fname).GetEnvValue("BRCHE"));

      */
      try{
        if( ComUtil.GetHostName().equals(
            ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){

          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT"));
          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
          this.ht.put("TELLS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"));
          this.ht.put("TELLE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"));

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
          this.ht.put("EVNTS1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS1"));
          this.ht.put("EVNTE1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE1"));
          this.ht.put("EVNTS2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS2"));
          this.ht.put("EVNTE2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE2"));
          this.ht.put("EVNTS3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS3"));

          this.ht.put("EVNTE3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE3"));
          this.ht.put("EVNTS4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS4"));
          this.ht.put("EVNTE4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE4"));
          this.ht.put("EVNTS5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS5"));
          this.ht.put("EVNTE5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE5"));

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
          this.ht.put("BRCHS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"));
          this.ht.put("BRCHE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"));
        }
        else if( ComUtil.GetHostName().equals(
            ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT"));
          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
          this.ht.put("TELLS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"));
          this.ht.put("TELLE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"));

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
          this.ht.put("EVNTS1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS1"));
          this.ht.put("EVNTE1",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE1"));
          this.ht.put("EVNTS2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS2"));
          this.ht.put("EVNTE2",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE2"));
          this.ht.put("EVNTS3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS3"));
          this.ht.put("EVNTE3",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE3"));
          this.ht.put("EVNTS4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS4"));
          this.ht.put("EVNTE4",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE4"));
          this.ht.put("EVNTS5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS5"));
          this.ht.put("EVNTE5",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE5"));

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
          this.ht.put("BRCHS",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"));
          this.ht.put("BRCHE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"));
        }



        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        JLO.getInstance().printf(1,"TMODE:"+ht.get("TMODE"));
        JLO.getInstance().printf(1,"TELLS:"+ht.get("TELLS"));
        JLO.getInstance().printf(1,"TELLE:"+ht.get("TELLE"));
        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        JLO.getInstance().printf(1,"EMODE:"+ht.get("EMODE"));
        JLO.getInstance().printf(1,"EVNTS1:"+ht.get("EVNTS1"));
        JLO.getInstance().printf(1,"EVNTE1:"+ht.get("EVNTE1"));
        JLO.getInstance().printf(1,"EVNTS2:"+ht.get("EVNTS2"));
        JLO.getInstance().printf(1,"EVNTE2:"+ht.get("EVNTE2"));
        JLO.getInstance().printf(1,"EVNTS3:"+ht.get("EVNTS3"));
        JLO.getInstance().printf(1,"EVNTE3:"+ht.get("EVNTE3"));
        JLO.getInstance().printf(1,"EVNTS4:"+ht.get("EVNTS4"));
        JLO.getInstance().printf(1,"EVNTE4:"+ht.get("EVNTE4"));
        JLO.getInstance().printf(1,"EVNTS5:"+ht.get("EVNTS5"));
        JLO.getInstance().printf(1,"EVNTE5:"+ht.get("EVNTE5"));
        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
        JLO.getInstance().printf(1,"BMODE:"+ht.get("BMODE"));
        JLO.getInstance().printf(1,"BRCHS:"+ht.get("BRCHS"));
        JLO.getInstance().printf(1,"BRCHE:"+ht.get("BRCHE"));
        JLO.getInstance().printf(1,"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

        this.otxctlmode = FILEapi.FILElastmodified(TBL2.fname);
      }
      catch(Exception ex){}
    }
  }

  public boolean isBlockingTx(String tellerid,String eventno,String branch) throws IOException{

    this.updateTxCtlInfo();

    /*
    for(Enumeration eti=this.ht.keys(); eti.hasMoreElements(); ){
      String mkey = eti.nextElement().toString();
      String ti = (String)ht.get(mkey);
      JLO.getInstance().printf(1,"----"+mkey+":"+ti);
    }
    */

    if( (ht.get("TMODE").toString().substring(0,2) ).equals("ON") ){
      int st = ComUtil.Str2Int((String)ht.get("TELLS"));
      int et = ComUtil.Str2Int((String)ht.get("TELLE"));
      int ct = ComUtil.Str2Int(tellerid.substring(3,10));
      if( ct >= st && ct <= et ){
        JLO.getInstance().printf(1,"CurrentId:ATM-"+tellerid.substring(3,10));
        JLO.getInstance().printf(1,"TMODE:"+ht.get("TMODE"));
        JLO.getInstance().printf(1,"TELLS:"+ht.get("TELLS"));
        JLO.getInstance().printf(1,"TELLE:"+ht.get("TELLE"));
        return true;
      }
    }
    else if( (ht.get("EMODE").toString().substring(0,2)).equals("ON") ){
      for( int ii=1 ; ii <= ComUtil.Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ((String)ht.get("EVNTS"+ii)).equals("*****") ||  ht.get("EVNTS"+ii)==null )
          continue;
        int st = ComUtil.Str2Int((String)ht.get("EVNTS"+ii));
        int et = ComUtil.Str2Int((String)ht.get("EVNTE"+ii));
        int ct = ComUtil.Str2Int(eventno);

        JLO.getInstance().printf(1,"CurrentEvent:"+eventno);
        JLO.getInstance().printf(1,"EMODE:"+ht.get("EMODE"));
        JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ct >= st && ct <= et ){
          JLO.getInstance().printf(1,"CurrentEvent:"+eventno);
          JLO.getInstance().printf(1,"EMODE:"+ht.get("EMODE"));
          JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
          JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));
          return true;
        }
      }
    }
    else if( (ht.get("BMODE").toString().substring(0,2)).equals("ON") ){
      int st = ComUtil.Str2Int((String)ht.get("BRCHS"));
      int et = ComUtil.Str2Int((String)ht.get("BRCHE"));
      int ct = ComUtil.Str2Int(eventno);
      if( ct >= st && ct <= et ){
        JLO.getInstance().printf(1,"CurrentBranch:"+branch);
        JLO.getInstance().printf(1,"BMODE:"+ht.get("BMODE"));
        JLO.getInstance().printf(1,"BRCHS:"+ht.get("BRCHS"));
        JLO.getInstance().printf(1,"BRCHE:"+ht.get("BRCHE"));
        return true;
      }
    }
    return false;
  }
}