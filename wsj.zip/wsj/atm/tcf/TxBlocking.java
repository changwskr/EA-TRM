package wsj.atm.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.sql.*;
import com.chb.coses.foundation.base.*;
import com.chb.coses.foundation.config.*;


public class TxBlocking {

  public TxBlocking() {
  }
  private int STF_SPtxctl(String userId,String eventNo,String branchCode)
  {
    try{
      if( TXTBL.getInstance().isBlockingTx(
          userId,
          eventNo,
          branchCode))
      {
        System.out.println("Now, ATM Service Not allow");
        return 1;
      }
      return 0;
    }
    catch(Exception ex){
      ex.printStackTrace();
      return -1;
    }
  }


}


class TXTBL {
  private static TXTBL instance;
  public static long otxctlmode=0;
  public static long ntxctlmode=0;
  public static String fname="/home/cosif/atmppp/env/ATMconfig.xml";
  public static Hashtable ht = new Hashtable();

  public static synchronized TXTBL getInstance() {
    if (instance == null) {
      try{
        instance = new TXTBL();
      }
      catch(Exception igex){
      }
    }
    return instance;
  }


  public TXTBL() throws IOException {
    try{
      if( GetHostName().equals(
                    XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){

          this.ht.put("TXBLOCKCNT",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT"));

          this.ht.put("TMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                    this.ht.put("TELLS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"+ii));
                    this.ht.put("TELLE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"+ii));
                    System.out.println((String)this.ht.get("TELLS"+ii));
                    System.out.println((String)this.ht.get("TELLE"+ii));
          }

          this.ht.put("EMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                this.ht.put("EVNTS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS"+ii));
                  this.ht.put("EVNTE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE"+ii));
                    System.out.println((String)this.ht.get("EVNTS"+ii));
                    System.out.println((String)this.ht.get("EVNTE"+ii));

          }

          this.ht.put("BMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                  this.ht.put("BRCHS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"+ii));
                  this.ht.put("BRCHE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"+ii));
                    System.out.println((String)this.ht.get("BRCHS"+ii));
                    System.out.println((String)this.ht.get("BRCHE"+ii));

          }
      }
      else if( GetHostName().equals(
          XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
          this.ht.put("TXBLOCKCNT",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT"));

          this.ht.put("TMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
          for ( int ii=1 ; ii <=Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                    this.ht.put("TELLS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"+ii));
                    this.ht.put("TELLE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                this.ht.put("EVNTS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS"+ii));
                  this.ht.put("EVNTE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                  this.ht.put("BRCHS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"+ii));
                  this.ht.put("BRCHE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"+ii));
          }
      }
    }
    catch(Exception ex){}
  }

  public boolean changeFileMode() {
    this.ntxctlmode = FILElastmodified(TXTBL.fname);
    if( this.ntxctlmode != this.otxctlmode ){
      return true;
    }
    return false;
  }

  public void updateTxCtlInfo() throws IOException{
    int loopcnt=0;

    if( changeFileMode() ){
      System.out.println("JBBCONF.INI ���ϼӼ��� ����");
      try{
        if( GetHostName().equals(
            XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){

          this.ht.put("TXBLOCKCNT",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT"));

          this.ht.put("TMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                    this.ht.put("TELLS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"+ii));
                    this.ht.put("TELLE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                this.ht.put("EVNTS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS"+ii));
                  this.ht.put("EVNTE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
                  this.ht.put("BRCHS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"+ii));
                  this.ht.put("BRCHE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"+ii));
          }

        }
        else if( GetHostName().equals(
            XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
          this.ht.put("TXBLOCKCNT",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT"));

          this.ht.put("TMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                    this.ht.put("TELLS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"+ii));
                    this.ht.put("TELLE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                this.ht.put("EVNTS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS"+ii));
                  this.ht.put("EVNTE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= Str2Int(XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
                  this.ht.put("BRCHS"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"+ii));
                  this.ht.put("BRCHE"+ii,XMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"+ii));
          }
        }
        this.otxctlmode = FILElastmodified(TXTBL.fname);


      }
      catch(Exception ex)
      {
      }
    }
  }

  public boolean isBlockingTx(String tellerid,String eventno,String branch) throws IOException{

    this.updateTxCtlInfo();

    if( (ht.get("TMODE").toString().substring(0,2) ).equals("ON") ){
      for( int ii=1 ; ii <= Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        System.out.println("TELLS"+ii+":"+ht.get("TELLS"+ii));
        System.out.println("TELLE"+ii+":"+ht.get("TELLE"+ii));

        if( ((String)ht.get("TELLS"+ii)).equals("*") ||  ht.get("TELLS"+ii)==null )
          continue;
        int st = Str2Int((String)ht.get("TELLS"+ii));
        int et = Str2Int((String)ht.get("TELLE"+ii));
        int ct = Str2Int(tellerid.substring(3,10));

        System.out.println("CurrentTellerid:"+Str2Int(tellerid.substring(3,10)));
        System.out.println("TMODE:"+ht.get("TMODE"));
        System.out.println("TELLS"+ii+":"+ht.get("TELLS"+ii));
        System.out.println("TELLE"+ii+":"+ht.get("TELLE"+ii));

        if( ct >= st && ct <= et ){
          return true;
        }
      }

    }
    else if( (ht.get("EMODE").toString().substring(0,2)).equals("ON") ){
      for( int ii=1 ; ii <= Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        System.out.println("EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        System.out.println("EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ((String)ht.get("EVNTS"+ii)).equals("*") ||  ht.get("EVNTS"+ii)==null )
          continue;
        int st = Str2Int((String)ht.get("EVNTS"+ii));
        int et = Str2Int((String)ht.get("EVNTE"+ii));
        int ct = Str2Int(eventno);

        System.out.println("CurrentEvent:"+eventno);
        System.out.println("EMODE:"+ht.get("EMODE"));
        System.out.println("EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        System.out.println("EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ct >= st && ct <= et ){
          System.out.println("CurrentEvent:"+eventno);
          System.out.println("EMODE:"+ht.get("EMODE"));
          System.out.println("EVNTS"+ii+":"+ht.get("EVNTS"+ii));
          System.out.println("EVNTE"+ii+":"+ht.get("EVNTE"+ii));
          return true;
        }
      }
    }
    else if( (ht.get("BMODE").toString().substring(0,2)).equals("ON") ){
      for( int ii=1 ; ii <= Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        System.out.println("BRCHS"+ii+":"+ht.get("BRCHS"+ii));
        System.out.println("BRCHE"+ii+":"+ht.get("BRCHE"+ii));

        if( ((String)ht.get("BRCHS"+ii)).equals("*") ||  ht.get("BRCHS"+ii)==null )
          continue;
        int st = Str2Int((String)ht.get("BRCHS"+ii));
        int et = Str2Int((String)ht.get("BRCHE"+ii));
        int ct = Str2Int(branch);

        System.out.println("Currentbranch:"+Str2Int(branch));
        System.out.println("BMODE:"+ht.get("BMODE"));
        System.out.println("BRCHS"+ii+":"+ht.get("BRCHS"+ii));
        System.out.println("BRCHE"+ii+":"+ht.get("BRCHE"+ii));

        if( ct >= st && ct <= et ){
          return true;
        }
      }
    }
    return false;
  }

  public static final String GetHostName()
  {
    InetAddress Address=null ;

    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }

  public static final long FILElastmodified ( String fname )
  {

    long strtmp = -1;

    try {

      File f = new File(fname);

      if(f.exists());
      else
        throw new IOException(fname + "Not Found");

      strtmp = f.lastModified();

    }
    catch(Exception ex) {
      System.out.println("FILEabsolutpath Exception :: " + ex.getMessage() );
      System.out.println("FILEabsolutpath FileName  :: " + fname );
      return -1;
    }

    return strtmp;

  }

  public static final int Str2Int(String str)
  {
    int i=Integer.valueOf(str).intValue();
    //System.out.println(i);
    return(i);
  }

  public static void main(String args[]) {
    TXTBL kk = TXTBL.getInstance();
  }

}


class XMLconfig {
  private static XMLconfig instance;
  private static final String xmlfile2 = "/home/cosif/atmppp/env/ATMconfig.xml";
  private static String xmlfile = "atm.conf.file";

  public static synchronized XMLconfig getInstance() {
    if (instance == null) {
      try{
        instance = new XMLconfig();
        XMLconfig.xmlfile = System.getProperty(XMLconfig.xmlfile);
        if( XMLconfig.xmlfile == null )
          XMLconfig.xmlfile = xmlfile2;
        }catch(Exception igex){}
    }
    return instance;
  }
  public String GetEnvValue(String ele1,String ele2){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChildTextTrim(ele2);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChildTextTrim(ele3);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3,String ele4){
    return XMLCache.getInstance().getXML(XMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChild(ele3).getChildTextTrim(ele4);
  }
  public XMLconfig() {
  }

}
