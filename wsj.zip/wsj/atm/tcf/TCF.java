package wsj.atm.tcf;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import java.sql.*;
import java.text.*;

import wsj.atm.business.*;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.socket.ATMserver;
import wsj.atm.dbpool.DBPool;
import wsj.atm.ejb.EJBPool;
import wsj.atm.packet.IOBoundDep80001CDTO;
import wsj.atm.packet.IOBoundDep80002CDTO;
import wsj.atm.packet.IOBoundDep80003CDTO;


public class TCF {
  private static TCF instance;
  private IOBoundArea inarea;
  private IOBoundArea outarea;
  private STF stf;
  private ETF etf;
  private String packetinfo;
  private String senddata;
  private Connection tcfconn;
  private DBPool atmpool;


  public String setSendData(){
    this.senddata = this.outarea.toString();
    return this.senddata;
  }

  public static synchronized TCF getInstance(String packetinfo) {
    if (instance == null) {
      try{
        instance = new TCF(packetinfo);
        }catch(Exception igex){}
    }
    return instance;
  }

  public TCF(String packetinfo) throws IOException,NotBoundException,Exception {
    this.packetinfo = packetinfo;
    this.inarea = new IOBoundArea(packetinfo);
    this.outarea = new IOBoundArea();
  }

  public TCF() throws Exception {
    this.atmpool = ATMserver.atmdbpool.getDBPool();
  }


  public static synchronized TCF getInstance() {
    if (instance == null) {
      try{
        instance = new TCF();
        }catch(Exception igex){}
    }
    return instance;
  }

  public String execute(String packetinfo){
    try{
      //////////////////////////////////////////////////////
      // �ʱ�ȭ �۾��� �ǽ��Ѵ�.
      //////////////////////////////////////////////////////
      this.packetinfo = packetinfo;
      this.inarea = null;
      this.outarea = null;

      this.inarea = new IOBoundArea(packetinfo);
      this.outarea = new IOBoundArea();

      JLO.getInstance().printf(3,"==============================[STF] START");

      this.stf = new STF();
      this.stf.execute(this.inarea , this.outarea);
      this.inarea = this.stf.getInBoundArea();
      this.outarea = this.stf.getOutBoundArea();

      try{
        if( !this.STF_insert() )
        {
          this.inarea.iohead.setBErrCode("EI0026",this.outarea);
          this.inarea.iohead.setMsg("Application Exception[TCF.STF_insert Error]",this.outarea);
          this.inarea.iohead.setBOutTime();
          JLO.getInstance().printf(10,"==================[tcf] STF_insert Error] (false)");
        }
      }catch(Exception ex){
        JLO.getInstance().eprintf(10,ex);
      }
      JLO.getInstance().printf(3,"STF errcode ["+this.outarea.iohead.sBErrCode+"]");
      JLO.getInstance().printf(3,"==============================[STF] END");

      if( isErr() ){
        if ( !this.inarea.cdto.getEventNo().equals("80010") ){
          JLO.getInstance().printf(10,"=[STF] �����߻� ");
          JLO.getInstance().printf(3,"==============================[ETF] START");
        }
        this.etf = new ETF();
        this.etf.execute(this.inarea ,this.outarea);
        this.inarea = this.etf.getInBoundArea();
        this.outarea = this.etf.getOutBoundArea();

        try{
          if( !this.ETF_insert() )
          {
            this.outarea.iohead.setBErrCode("EI0027",this.outarea);
            this.outarea.iohead.setMsg("Application Exception[TCF.ETF_insert Error]",this.outarea);
            JLO.getInstance().printf(10,"==================[tcf] ETF_insert Error] (false)");
          }
        }catch(Exception ex){
          JLO.getInstance().eprintf(10,ex);
        }
        JLO.getInstance().printf(3,"ETF errcode ["+this.outarea.iohead.sBErrCode+"]");
        JLO.getInstance().printf(3,"==============================[ETF] END");

        this.setSendData();

        if( this.outarea.iodata.sBoundData == null ){
          this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData ;
          this.outarea.iodata.sLength = ComUtil.Int2Str(this.outarea.iodata.sBoundData.length());
          this.outarea.sLength = ComUtil.ZeroToStr(this.outarea.iodata.sLength,5);
        }
        JLO.getInstance().printf(3,"errcode ["+this.outarea.iohead.sBErrCode+"]");
        return this.senddata;
      }
      else{
        //////////////////////////////////////////////////////////////
        // ��������� ȣ���Ѵ�.
        //////////////////////////////////////////////////////////////
        JLO.getInstance().printf(3,"==============================[BIZ] START ");
        JLO.getInstance().printf(3,"eventno ["+this.inarea.cdto.getEventNo() +"]");

        if( "80000".equals(this.inarea.cdto.getEventNo())){
          //ITF::INTERFACE Login
          //this.outarea = new LOG80000(this.inarea,this.outarea).execute();
          this.outarea = new LGI80000(this.inarea,this.outarea).execute();
        }
        else if( "80001".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Withdraw
          this.outarea = new DED80001(this.inarea,this.outarea).execute();
        }
        else if( "80002".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Transfer
          this.outarea = new DED80002(this.inarea,this.outarea).execute();
        }
        else if( "80003".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Query
          this.outarea = new DED80003(this.inarea,this.outarea).execute();
        }
        else if( "80004".equals(this.inarea.cdto.getEventNo())){
          //ATM::Teller Sijae Open
          this.outarea = new TEL80004(this.inarea,this.outarea).execute();
        }
        else if( "80005".equals(this.inarea.cdto.getEventNo())){
          //ATM::Teller Fund Import/Export
          this.outarea = new TEL80005(this.inarea,this.outarea).execute();
        }
        else if( "80006".equals(this.inarea.cdto.getEventNo())){
          //ATM::Teller Sijae Close
          this.outarea = new TEL80006(this.inarea,this.outarea).execute();
        }
        else if( "80007".equals(this.inarea.cdto.getEventNo())){
          //ATM::�ڱ��μ��� �ŷ� ����ȸ
          this.outarea = new TEL80007(this.inarea,this.outarea).execute();
        }
        else if( "80008".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new DED80008(this.inarea,this.outarea).execute();
        }
        else if( "80009".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new CTL80009(this.inarea,this.outarea).execute();
        }
        else if( "80010".equals(this.inarea.cdto.getEventNo())){
          //ITF::SWB�� Polling
          this.outarea.iohead.setBErrCode("IZZ000");
          this.outarea.iohead.setMsg("Application Exception[TCF.Polling]");
          this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
          this.outarea.iodata.sLength = "00000";
          this.outarea.sLength = this.outarea.iodata.sLength;
        }
        else if( "80011".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new DED80011(this.inarea,this.outarea).execute();
        }
        else if( "80012".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new DED80012(this.inarea,this.outarea).execute();
        }
        else if( "80013".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new DED80013(this.inarea,this.outarea).execute();
        }
        else if( "80014".equals(this.inarea.cdto.getEventNo())){
          //ATM::DEPOSIT Account Cancel
          this.outarea = new CAR80014(this.inarea,this.outarea).execute();
        }
        else if( "10000".equals(this.inarea.cdto.getEventNo())){
          //ITF::SWB�� Polling
          this.outarea = (IOBoundArea)new COM10000(this.inarea,this.outarea).execute();
        }
        else{
          this.outarea.iohead.setBErrCode("EI0028");
          this.outarea.iohead.setMsg("Application Exception[TCF.Not Match EventNo]");
          this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
          this.outarea.iodata.sLength = ComUtil.Int2Str(this.outarea.iodata.sBoundData.length());
          this.outarea.sLength = ComUtil.ZeroToStr(this.outarea.iodata.sLength,5);
        }
        JLO.getInstance().printf(3,"BIZ errcode ["+this.outarea.iohead.sBErrCode+"]");
        JLO.getInstance().printf(3,"==============================[BIZ] END");


        //////////////////////////////////////////////////////////////
        // STF ����� ȣ��
        //////////////////////////////////////////////////////////////
        JLO.getInstance().printf(3,"==============================[ETF] START");
        this.etf = new ETF();
        this.etf.execute(this.inarea ,this.outarea);

        try{
          if( !this.ETF_insert() )
          {
            this.outarea.iohead.setMsg("Application Exception[TCF.ETF_insert Error]",this.outarea);
            JLO.getInstance().printf(10,"==================[tcf] ETF_insert Error] (false)");
          }
        }catch(Exception ex){
          JLO.getInstance().eprintf(10,ex);
        }
        JLO.getInstance().printf(3,"ETF errcode ["+this.outarea.iohead.sBErrCode+"]");
        JLO.getInstance().printf(3,"==============================[ETF] END");
      }
    }
    catch(Exception ex){
      JLO.getInstance().printf(10,"TCF ��⿹�� �߻�");
      JLO.getInstance().eprintf(10,ex);
      this.outarea.iohead.setBErrCode("EI0049");
      this.outarea.iohead.setMsg("Application Exception[TCF.Exception]");
      this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
      this.outarea.iodata.sLength = ComUtil.Int2Str(this.outarea.iodata.sBoundData.length());
      this.outarea.sLength = ComUtil.ZeroToStr(this.outarea.iodata.sLength,5);
      this.setSendData();
      return this.senddata;
    }

    this.setSendData();

    JLO.getInstance().printf(1,"//////////////////////////////////////////////////////////////////////////");
    JLO.getInstance().printf(1,"//                              Packet Info                              //");
    JLO.getInstance().printf(1,"//////////////////////////////////////////////////////////////////////////");
    this.outarea.getPacketInfo(this.senddata);
    JLO.getInstance().print(1,"\n");
    JLO.getInstance().printf(1,"//////////////////////////////////////////////////////////////////////////");

    return this.senddata;
  }

  public void setInOut(){
    this.inarea = stf.in;
    this.outarea = stf.out;
    this.etf.in = stf.in;
    this.etf.out = stf.out;
  }

  private boolean isErr(){
    try{
      //switch (this.outarea.iohead.sBErrCode.charAt(0))
      switch (this.outarea.iohead.sBErrCode.charAt(0))
      {
        case 'e':
        case 's':
        case 'E':
        case 'S':
          return true;
        case 'I':
          return false;
        case '*':
          this.inarea.iohead.setBErrCode("EI0029",this.outarea);
          this.inarea.iohead.setMsg("Application Exception[TCF.isErr:NotErrCodeSet]",this.outarea);
          return true;
      }
    }
    catch(Exception ex){
      return false;
    }
    return false;
  }

/*
drop table itfaiinfo;
drop table itfaoinfo;
CREATE TABLE ITFAIINFO
(
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                    VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAIINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_MIS_IND
)
TABLESPACE TSP_MIS
;

CREATE TABLE ITFAOINFO (
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                    VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAOINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_MIS_IND )
   TABLESPACE TSP_MIS
;


CREATE SYNONYM ITFAIINFO FOR RETAIL.ITFAIINFO;
CREATE SYNONYM ITFAOINFO FOR RETAIL.ITFAOINFO;
CREATE TABLE ITFAOINFO (
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                 VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAOINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_RETAIL_IND )
   TABLESPACE TSP_RETAIL
;
*/

  public boolean STF_insert() throws IOException{

    try{
      if( this.inarea.cdto.eventNo.equals("80010") ){
        return true;
      }

      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      this.tcfconn = this.atmpool.getConnection();
      this.atmpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +this.atmpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");

      this.tcfconn.setAutoCommit(false);

      String sql = "INSERT INTO ITFAIINFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      PreparedStatement  pstmt = this.tcfconn.prepareStatement(sql);

      pstmt.setString(1, this.inarea.iohead.sBBrnSeq );
      pstmt.setString(2, this.inarea.iohead.sBSysDate );
      pstmt.setString(3, this.inarea.iohead.sBInTime );
      pstmt.setString(4, this.inarea.iohead.sBOutTime );
      pstmt.setString(5, this.inarea.cdto.eventNo );
      pstmt.setString(6, this.inarea.cdto.bankCode );
      pstmt.setString(7, this.inarea.cdto.branchCode );
      pstmt.setString(8, this.inarea.cdto.bizDate );
      pstmt.setString(9, this.inarea.cdto.userId );
      pstmt.setString(10,this.inarea.iohead.sBErrCode );
      pstmt.setString(11,this.inarea.iohead.sDLoginOffSet);
      pstmt.setString(12,this.inarea.iohead.sDSijaeOpenOffset );
      pstmt.setString(13,this.inarea.iohead.sBEodOffset  );
      pstmt.setString(14,this.inarea.iohead.sDSijaeClosOffset  );
      pstmt.setString(15,this.inarea.iohead.sDMode );
      pstmt.setString(16,this.inarea.cdto.atmSeqNo );

      if ( this.inarea.cdto.getEventNo().equals("80001") )
      {
        String tmp = this.inarea.iodata.sBoundData;
        IOBoundDep80001CDTO iobounddeposit =  new IOBoundDep80001CDTO();
        iobounddeposit.setIOBoundDep80001CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80001CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else if ( this.inarea.cdto.getEventNo().equals("80003") )
      {
        String tmp = this.inarea.iodata.sBoundData;
        IOBoundDep80003CDTO iobounddeposit =  new IOBoundDep80003CDTO();
        iobounddeposit.setIOBoundDep80003CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80003CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else if ( this.inarea.cdto.getEventNo().equals("80002") )
      {
        String tmp = this.inarea.iodata.sBoundData;
        IOBoundDep80002CDTO iobounddeposit =  new IOBoundDep80002CDTO();
        iobounddeposit.setIOBoundDep80002CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80002CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else
        pstmt.setString(17,this.inarea.iodata.sBoundData );

      pstmt.executeUpdate();
      pstmt.close();

    } catch (Exception exception) {
      try {
        this.tcfconn.rollback();
        this.tcfconn.setAutoCommit(true);
      } catch (Exception failure) {
        exception.printStackTrace();
      }
      JLO.getInstance().eprintf(10,exception);
      this.atmpool.freeConnection(tcfconn);
      return false;
    }
    try {
      this.tcfconn.commit();
      this.tcfconn.setAutoCommit(true);
      this.atmpool.freeConnection(tcfconn);
    } catch (Exception exception) {
      exception.printStackTrace();
      this.atmpool.freeConnection(tcfconn);
      return false;
    }
    return true;
  }

  public boolean ETF_insert() throws IOException{

    try{
      if( this.inarea.cdto.eventNo.equals("80010") ){
        return true;
      }
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      this.tcfconn = this.atmpool.getConnection();
      this.atmpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +this.atmpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");

      this.tcfconn.setAutoCommit(false);

      String sql = "INSERT INTO ITFAOINFO VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      PreparedStatement  pstmt = this.tcfconn.prepareStatement(sql);

      pstmt.setString(1, this.outarea.iohead.sBBrnSeq );
      pstmt.setString(2, this.outarea.iohead.sBSysDate );
      pstmt.setString(3, this.outarea.iohead.sBInTime );
      pstmt.setString(4, this.outarea.iohead.sBOutTime );
      pstmt.setString(5, this.outarea.cdto.eventNo );
      pstmt.setString(6, this.outarea.cdto.bankCode );
      pstmt.setString(7, this.outarea.cdto.branchCode );
      pstmt.setString(8, this.outarea.cdto.bizDate );
      pstmt.setString(9, this.outarea.cdto.userId );
      pstmt.setString(10,this.outarea.iohead .sBErrCode );
      pstmt.setString(11,this.outarea.iohead.sDLoginOffSet);
      pstmt.setString(12,this.outarea.iohead.sDSijaeOpenOffset );
      pstmt.setString(13,this.outarea.iohead.sBEodOffset  );
      pstmt.setString(14,this.outarea.iohead.sDSijaeClosOffset    );
      pstmt.setString(15,this.outarea.iohead.sDMode );
      pstmt.setString(16,this.outarea.cdto.atmSeqNo );

      if ( this.outarea.cdto.getEventNo().equals("80001") )
      {
        String tmp = this.outarea.iodata.sBoundData;
        IOBoundDep80001CDTO iobounddeposit =  new IOBoundDep80001CDTO();
        iobounddeposit.setIOBoundDep80001CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80001CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else if ( this.outarea.cdto.getEventNo().equals("80003") )
      {
        String tmp = this.outarea.iodata.sBoundData;
        IOBoundDep80003CDTO iobounddeposit =  new IOBoundDep80003CDTO();
        iobounddeposit.setIOBoundDep80003CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80003CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else if ( this.outarea.cdto.getEventNo().equals("80002") )
      {
        String tmp = this.outarea.iodata.sBoundData;
        IOBoundDep80002CDTO iobounddeposit =  new IOBoundDep80002CDTO();
        iobounddeposit.setIOBoundDep80002CDTOParsing(tmp);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80002CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo = sb.toString();
        pstmt.setString(17,iobounddeposit.toString());
      }
      else
        pstmt.setString(17,this.outarea.iodata.sBoundData );

      pstmt.executeUpdate();
      pstmt.close();

    } catch (Exception exception) {
      try {
        this.tcfconn.rollback();
        this.tcfconn.setAutoCommit(true);
      } catch (Exception failure) {
        exception.printStackTrace();
      }
      JLO.getInstance().eprintf(10,exception);
      this.atmpool.freeConnection(tcfconn);
      return false;
    }
    try {
      this.tcfconn.commit();
      this.tcfconn.setAutoCommit(true);
      this.atmpool.freeConnection(tcfconn);
    } catch (Exception exception) {
      exception.printStackTrace();
      this.atmpool.freeConnection(tcfconn);
      return false;
    }
    return true;
  }


}