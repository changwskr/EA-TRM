package wsj.atm.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.text.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.packet.*;

import wsj.atm.common.FILEapi;
import wsj.atm.log.JLO;

public class TBL {
  private static TBL instance;
  public static long otxctlmode=0;
  public static long ntxctlmode=0;
  public static String fname=JEN.JBB_CONF_FILE;
  public static Hashtable ht = new Hashtable();
  public IOBoundArea in;

  public static synchronized TBL getInstance() {
    if (instance == null) {
      try{
        instance = new TBL();
      }
      catch(Exception igex){
        JLO.eprintf(10,igex);
      }
    }
    return instance;
  }

  public void setInBound(IOBoundArea in){
     this.in = in;
  }

  public TBL() throws IOException {
    try{
      if( ComUtil.GetHostName().equals(
                    ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){

          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT"));

          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
            	this.ht.put("TELLS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"+ii));
            	this.ht.put("TELLE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("TELLS"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("TELLE"+ii));
          }

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
	        this.ht.put("EVNTS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS"+ii));
          	this.ht.put("EVNTE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("EVNTS"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("EVNTE"+ii));

          }

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
          	this.ht.put("BRCHS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"+ii));
          	this.ht.put("BRCHE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("BRCHS"+ii));
            	JLO.getInstance().printf(1,(String)this.ht.get("BRCHE"+ii));

          }
      }
      else if( ComUtil.GetHostName().equals(
          ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT"));

          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
          for ( int ii=1 ; ii <=ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
            	this.ht.put("TELLS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"+ii));
            	this.ht.put("TELLE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
	        this.ht.put("EVNTS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS"+ii));
          	this.ht.put("EVNTE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
          	this.ht.put("BRCHS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"+ii));
          	this.ht.put("BRCHE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"+ii));
          }
      }
    }
    catch(Exception ex){}
  }

  public boolean changeFileMode() {
    this.ntxctlmode = FILEapi.FILElastmodified(TBL.fname);
    if( this.ntxctlmode != this.otxctlmode ){
      return true;
    }
    return false;
  }

  public void updateTxCtlInfo() throws IOException{
    int loopcnt=0;

    if( changeFileMode() ){
      JLO.printf(1,"JBBCONF.INI ���ϼӼ��� ����");
      try{
        if( ComUtil.GetHostName().equals(
            ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","KEY"))){

          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT"));

          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
            	this.ht.put("TELLS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLS"+ii));
            	this.ht.put("TELLE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
	        this.ht.put("EVNTS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTS"+ii));
          	this.ht.put("EVNTE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","TXBLOCKCNT")) ; ii++ ){
          	this.ht.put("BRCHS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHS"+ii));
          	this.ht.put("BRCHE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","MASTER","BRANCH","BRCHE"+ii));
          }

        }
        else if( ComUtil.GetHostName().equals(
            ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","KEY"))){
          this.ht.put("TXBLOCKCNT",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT"));

          this.ht.put("TMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
            	this.ht.put("TELLS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLS"+ii));
            	this.ht.put("TELLE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TELLER","TELLE"+ii));
          }

          this.ht.put("EMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
	        this.ht.put("EVNTS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTS"+ii));
          	this.ht.put("EVNTE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXCODE","EVNTE"+ii));
          }

          this.ht.put("BMODE",ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BMODE"));
          for ( int ii=1 ; ii <= ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","TXBLOCKCNT")) ; ii++ ){
          	this.ht.put("BRCHS"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHS"+ii));
          	this.ht.put("BRCHE"+ii,ATMXMLconfig.getInstance().GetEnvValue("TRANSACTION-BLOCKING","SLAVE","BRANCH","BRCHE"+ii));
          }
        }
        this.otxctlmode = FILEapi.FILElastmodified(TBL.fname);


      }
      catch(Exception ex)
      {
      }
    }
  }

  public boolean isBlockingTx(String tellerid,String eventno,String branch) throws IOException{

    this.updateTxCtlInfo();

    if( (ht.get("TMODE").toString().substring(0,2) ).equals("ON") ){
      for( int ii=1 ; ii <= ComUtil.Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        JLO.getInstance().printf(1,"TELLS"+ii+":"+ht.get("TELLS"+ii));
        JLO.getInstance().printf(1,"TELLE"+ii+":"+ht.get("TELLE"+ii));

        if( ((String)ht.get("TELLS"+ii)).equals("*") ||  ht.get("TELLS"+ii)==null )
          continue;
        int st = ComUtil.Str2Int((String)ht.get("TELLS"+ii));
        int et = ComUtil.Str2Int((String)ht.get("TELLE"+ii));
        int ct = ComUtil.Str2Int(tellerid.substring(3,10));

        JLO.getInstance().printf(1,"CurrentTellerid:"+ComUtil.Str2Int(tellerid.substring(3,10)));
        JLO.getInstance().printf(1,"TMODE:"+ht.get("TMODE"));
        JLO.getInstance().printf(1,"TELLS"+ii+":"+ht.get("TELLS"+ii));
        JLO.getInstance().printf(1,"TELLE"+ii+":"+ht.get("TELLE"+ii));

        if( ct >= st && ct <= et ){
          return true;
        }
      }

    }
    else if( (ht.get("EMODE").toString().substring(0,2)).equals("ON") ){
      for( int ii=1 ; ii <= ComUtil.Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ((String)ht.get("EVNTS"+ii)).equals("*") ||  ht.get("EVNTS"+ii)==null )
          continue;
        int st = ComUtil.Str2Int((String)ht.get("EVNTS"+ii));
        int et = ComUtil.Str2Int((String)ht.get("EVNTE"+ii));
        int ct = ComUtil.Str2Int(eventno);

        JLO.getInstance().printf(1,"CurrentEvent:"+eventno);
        JLO.getInstance().printf(1,"EMODE:"+ht.get("EMODE"));
        JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
        JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));

        if( ct >= st && ct <= et ){
          JLO.getInstance().printf(1,"CurrentEvent:"+eventno);
          JLO.getInstance().printf(1,"EMODE:"+ht.get("EMODE"));
          JLO.getInstance().printf(1,"EVNTS"+ii+":"+ht.get("EVNTS"+ii));
          JLO.getInstance().printf(1,"EVNTE"+ii+":"+ht.get("EVNTE"+ii));
          return true;
        }
      }
    }
    else if( (ht.get("BMODE").toString().substring(0,2)).equals("ON") ){
      for( int ii=1 ; ii <= ComUtil.Str2Int((String)ht.get("TXBLOCKCNT")); ii++ ){
        JLO.getInstance().printf(1,"BRCHS"+ii+":"+ht.get("BRCHS"+ii));
        JLO.getInstance().printf(1,"BRCHE"+ii+":"+ht.get("BRCHE"+ii));

        if( ((String)ht.get("BRCHS"+ii)).equals("*") ||  ht.get("BRCHS"+ii)==null )
          continue;
        int st = ComUtil.Str2Int((String)ht.get("BRCHS"+ii));
        int et = ComUtil.Str2Int((String)ht.get("BRCHE"+ii));
        int ct = ComUtil.Str2Int(branch);

        JLO.getInstance().printf(1,"Currentbranch:"+ComUtil.Str2Int(branch));
        JLO.getInstance().printf(1,"BMODE:"+ht.get("BMODE"));
        JLO.getInstance().printf(1,"BRCHS"+ii+":"+ht.get("BRCHS"+ii));
        JLO.getInstance().printf(1,"BRCHE"+ii+":"+ht.get("BRCHE"+ii));

        if( ct >= st && ct <= et ){
          return true;
        }
      }
    }
    return false;
  }

  public static void main(String args[]) {
    TBL kk = TBL.getInstance();
  }

}
