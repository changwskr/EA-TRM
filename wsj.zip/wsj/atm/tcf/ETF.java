package wsj.atm.tcf;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.sql.*;
import java.text.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundProtoType;
import wsj.atm.socket.ATMserver;
import wsj.atm.dbpool.DBPool;
import wsj.atm.packet.IOBoundDep80001CDTO;
import wsj.atm.packet.IOBoundDep80002CDTO;
import wsj.atm.packet.IOBoundDep80003CDTO;

public class ETF {
  private static ETF instance;
  private JEN jen;
  public IOBoundArea in ;
  public IOBoundArea out;
  public long ettx=0;

  public static synchronized ETF getInstance(IOBoundArea pIn,IOBoundArea pOut) {
    if (instance == null) {
      try{
        instance = new ETF(pIn,pOut);
        }catch(Exception igex){}
    }
    return instance;
  }

  public ETF(IOBoundArea pIn,IOBoundArea pOut) throws IOException {
    this.in = pIn;
    this.out = pOut;
    this.jen = new JEN();
  }

  private String BIZERRCODE;
  public boolean execute(IOBoundArea pIn,IOBoundArea pOut){
    try {
      this.in = pIn;
      this.out = pOut;
      this.ETF_SetCurrentTimeMillis();

      ////////////////////////////////////////////////////
      // ETF_SPinit();
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[ETF_SPinit START]");


      // �����ڵ�� ����Ÿ����
      if( isErr() ){
        //�����ܿ��� ������ �߻��� ��� �̹Ƿ� ������ ���� ó���Ѵ�.
        if( this.out.iodata.sBoundData == null ){
          if ( this.in.iodata.sBoundData == null ) {
            this.in.iodata.sBoundData=" ";
            this.in.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(in.iodata.sBoundData.length()),5);
          }
          this.out.iodata.sBoundData = this.in.iodata.sBoundData ;
          this.out.iodata.sLength = ComUtil.Int2Str(this.out.iodata.sBoundData.length());
          this.out.sLength = ComUtil.ZeroToStr(this.out.iodata.sLength,5);
        }
        this.out.iohead.setBOutTime();
        this.ETF_SPcommonLog();
        if ( !this.out.cdto.getEventNo().equals("80010") ){
          JLO.getInstance().printf(10,this.out.iohead.sBErrCode+"-AppEx[ETF.Application Ex#2]:");
          JLO.getInstance().printf(10,"==================[ETF_SPinit --isErrEND] (flase)");
        }
        return true;
      }

      if( !ETF_SPinit() ){
        this.out.iohead.setBOutTime();
        this.ETF_SPcommonLog();
        JLO.getInstance().printf(10,"==================[ETF_SPinit  ** END] (false)");
        return false;
      }
      JLO.getInstance().printf(1,"==================[ETF_SPinit END] (true)");

      ////////////////////////////////////////////////////
      // ���� ���� ����
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[GetIntChk START]");
      if( !ComUtil.GetIntChk(this.in.sLength, this.in.sLength.length()) ){
        this.out.sLength =
            ComUtil.ZeroToStr( ComUtil.Int2Str(this.out.iodata.sBoundData.length()),5);
      }
      JLO.getInstance().printf(1,"==================[GetIntChk END] (true)");


      ////////////////////////////////////////////////////
      // ȯ������ ����
      ////////////////////////////////////////////////////
      if( out.iohead.sBErrCode.equals("IZZ000") ){
        if( out.cdto.eventNo.equals("80001") ){
          IOBoundDep80001CDTO iobounddeposit =  new IOBoundDep80001CDTO();
          iobounddeposit.setIOBoundDep80001CDTOParsing(out.iodata.sBoundData);
          if( iobounddeposit.TrxCcyu.equals("USD") ) {
            iobounddeposit.TD5 = ComUtil.PSpaceToStr(STF.exrate,iobounddeposit.TD5_LEN);
          }
          out.iodata.sBoundData = iobounddeposit.toString();
        }
        if( out.cdto.eventNo.equals("80002") ){
          IOBoundDep80002CDTO iobounddeposit =  new IOBoundDep80002CDTO();
          iobounddeposit.setIOBoundDep80002CDTOParsing(out.iodata.sBoundData);
          if( iobounddeposit.TrxCcyu.equals("USD") ) {
            iobounddeposit.TD5 = ComUtil.PSpaceToStr(STF.exrate,iobounddeposit.TD5_LEN);
          }
          out.iodata.sBoundData = iobounddeposit.toString();
        }
        if( out.cdto.eventNo.equals("80003") ){
          IOBoundDep80003CDTO iobounddeposit =  new IOBoundDep80003CDTO();
          iobounddeposit.setIOBoundDep80003CDTOParsing(out.iodata.sBoundData);
          if( iobounddeposit.TrxCcyu.equals("USD") ) {
            iobounddeposit.TD5 = ComUtil.PSpaceToStr(STF.exrate,iobounddeposit.TD5_LEN);
          }
          out.iodata.sBoundData = iobounddeposit.toString();
        }
      }

      ////////////////////////////////////////////////////
      //������ �ð��� �����Ѵ�.
      ////////////////////////////////////////////////////
      this.out.iohead.setBOutTime();
      this.ETF_SetCurrentTimeMillis();

      ////////////////////////////////////////////////////
      // LOGGING
      ////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"==================[ETF_SPcommonLog START]");
      if( !ETF_SPcommonLog() ){
        this.ETF_SetCurrentTimeMillis();
        JLO.getInstance().printf(10,"==================[ETF_SPcommonLog END] (false)");
        return false;
      }
      JLO.getInstance().printf(1,"==================[ETF_SPcommonLog END] (true)");
    }
    catch(Exception ex){
      JLO.getInstance().eprintf(10,ex);
      this.ETF_SetCurrentTimeMillis();
      this.out.iohead.setBOutTime();
      this.out.iohead.setBErrCode("EI0018");
      this.out.iohead.setMsg("EI0018-AppEx[ETF.#1]");
      this.setInDataOutData();
      return false;
    }
    return true;
  }

  /////////////////////////////////////////////////////////////////////////////
  public static synchronized ETF getInstance() {
    if (instance == null) {
      try{
        instance = new ETF();
        }catch(Exception igex){}
    }
    return instance;
  }

  public ETF() throws IOException,Exception{
    this.jen = new JEN();
    this.in = new IOBoundArea();
    this.out = new IOBoundArea();
  }


  /////////////////////////////////////////////////////////////////////////////

  private boolean ETF_SPinit() {
    try{

      //���� ����Ÿ���� �������� ����
      if( this.out.sLength.equals("*****") || this.out.sLength.equals("     "))
      {
        this.ETF_SetCurrentTimeMillis();
        this.out.iohead.setBErrCode("EI0022");
        this.out.iohead.setMsg("EI0022-AppEx[ETF_SPinit:DataLengthNotSet]");
        this.out.sLength =
            ComUtil.ZeroToStr( ComUtil.Int2Str(this.out.iodata.sBoundData.length()),5);
      }
    }
    catch(Exception ex){
      this.out.iohead.setBOutTime();
      this.in.iohead.setBErrCode("EI0022");
      this.ETF_SetCurrentTimeMillis();
      this.in.iohead.setMsg("EI0022-AppEx[ETF.ETF_SPinit]");
      JLO.getInstance().eprintf(1,ex);
      return false;
    }

    try{
      //���� ����Ÿ �������� ����
      //�̰�� ���������� �������޽���IZZ000�� ����������, ��µ���Ÿ�� �������� ���� ���
      //�̹Ƿ� ������ ó���Ѵ�.
      if( this.out.iodata.sBoundData == null ){
        this.out.iohead.setBErrCode("EI0047");
        this.out.iohead.setMsg("EI0047-AppEx[ETF_SPinit:DataNotSet]");
        this.setInDataOutData();
      }
    }
    catch(Exception ex){
      this.out.iohead.setBOutTime();
      this.in.iohead.setBErrCode("EI0047");
      this.ETF_SetCurrentTimeMillis();
      this.in.iohead.setMsg("EI0047-AppEx[ETF.ETF_SPinit]");
      JLO.getInstance().eprintf(1,ex);
      return false;
    }
    return true;
  }

  private synchronized boolean ETF_SPcommonLog() {

    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      ///////////////////////////////////////////////
      // ping �ŷ��α״� �Ƚ״´�
      ///////////////////////////////////////////////
      if ( this.out.cdto.getEventNo().equals("80010") )
        return true;
      ////////////////////////////////////////////////
      // ���� �ð��� �����Ѵ�.
      ////////////////////////////////////////////////
      this.out.iohead.setBOutTime();
      this.ETF_SetCurrentTimeMillis();

      long itvmilsec = ComUtil.Str2Long(this.out.cdto.cifNum) - ComUtil.Str2Long(this.out.cdto.refNum);
      float fitv = itvmilsec / 1000.0f;

      LOGFILENAME = this.jen.BIZLOGFILENAME + ComUtil.GetHostName() + "." +
                    this.in.cdto.getEventNo() + "." +
                    "out" + "." +
                    ComUtil.GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);

      if ( this.out.cdto.getEventNo().equals("80001") )

      {
        String tmp = this.out.toString();
        IOBoundArea outbound = new IOBoundArea(tmp);
        IOBoundDep80001CDTO iobounddeposit =  new IOBoundDep80001CDTO();
        iobounddeposit.setIOBoundDep80001CDTOParsing(outbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80001CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        outbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(outbound.toString('^')+"^["+fitv+"]sec" );
        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      else if ( this.out.cdto.getEventNo().equals("80003") )
      {

        String tmp = this.out.toString();
        IOBoundArea outbound = new IOBoundArea(tmp);
        IOBoundDep80003CDTO iobounddeposit =  new IOBoundDep80003CDTO();
        iobounddeposit.setIOBoundDep80003CDTOParsing(outbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80003CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        JLO.getInstance().printf(1,this.out.cdto.getEventNo().equals("80003")+iobounddeposit.SecurityNo);
        outbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(outbound.toString('^')+"^["+fitv+"]sec" );
        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      if ( this.out.cdto.getEventNo().equals("80002") )
      {
        String tmp = this.out.toString();
        IOBoundArea outbound = new IOBoundArea(tmp);
        IOBoundDep80002CDTO iobounddeposit =  new IOBoundDep80002CDTO();
        iobounddeposit.setIOBoundDep80002CDTOParsing(outbound.iodata.sBoundData);
        StringBuffer sb = new StringBuffer();
        for( int i = 0 ; i < IOBoundDep80002CDTO.SecurityNo_LEN ; i++ )
          sb.append('#');
        iobounddeposit.SecurityNo= sb.toString();
        outbound.iodata.sBoundData = iobounddeposit.toString();
        ps.println(outbound.toString('^')+"^["+fitv+"]sec" );
        ps.flush();
        ps.close();
        fos.close();
        return true;
      }
      else{
        ps.println(this.out.toString('^')+"^["+fitv+"]sec" );
        ps.flush();
        ps.close();
        fos.close();
      }
    }catch(Exception e){
      this.ETF_SetCurrentTimeMillis();
      this.out.iohead.setBOutTime();
      this.in.iohead.setBErrCode("EI0024");
      JLO.getInstance().eprintf(10,e);
      this.in.iohead.setMsg("EI0024-AppEx[ETF.ETF_SPcommonLog]");
      try{
        fos.close();
        ps.close();
      }catch(Exception ex){
      }
      return false;
    }
    return true;
  }

  public boolean isErr(){
    try{
      switch (out.iohead.sBErrCode.charAt(0))
      {
        case 'e':
        case 's':
        case 'E':
        case 'S':
          if( out.iohead.sBErrCode.equals("EC9000") ){
            out.iohead.setMsg("Please retry the tranaction");
          }
          if( out.iohead.sBErrCode.substring(0,2).equals("EI") ){
            out.iohead.setMsg("Inquire with teller inside");
          }
          if( out.iohead.sBErrCode.substring(0,2).equals("ED") ){
            if( !out.iohead.sBErrCode.substring(0,6).equals("ED0055") ){
              out.iohead.setMsg("Please retry the tranaction");
            }
          }
          return true;
        case 'I':
          return false;
        case '*':
        default :
          this.ETF_SetCurrentTimeMillis();
          this.out.iohead.setBErrCode("EI0025");
          this.out.iohead.setMsg("AppEx[ETF.isErr:ErrCodeNotset]");
          return true;
      }
    }
    catch(Exception ex){
      return false;
    }
  }
  public void ETF_SetCurrentTimeMillis(){
    this.ettx = System.currentTimeMillis();
    this.in.cdto.setCifNum(ComUtil.LZeroToStr(ComUtil.Long2Str(this.ettx),IOBoundProtoType.cifNum_LEN));
    this.out.cdto.setCifNum(ComUtil.LZeroToStr(ComUtil.Long2Str(this.ettx),IOBoundProtoType.cifNum_LEN));
  }
  public long getItvCurrentTimeMillis(){
    return ( ComUtil.Str2Long(this.out.cdto.cifNum) - ComUtil.Str2Long(this.out.cdto.refNum) );
  }

  public IOBoundArea getInBoundArea(){
    return this.in.getIOBoundArea();
  }
  public IOBoundArea getOutBoundArea(){
    return this.out.getIOBoundArea();
  }
  public void setInDataOutData(){
    this.out.iodata.sBoundData = this.in.iodata.sBoundData;
    this.out.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.out.iodata.sBoundData.length()),5);
  }


}