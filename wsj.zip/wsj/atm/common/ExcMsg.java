package wsj.atm.common;


public class ExcMsg {

	public static void ExcMsgPrnt ( int po , String emsg)
	{
		switch( po )
		{
			case 1:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 2:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 3:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 4:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;

			case 5:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 6:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 7:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 8:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 9:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
			case 10:
				LogManager.log("Exc : " + po + " | " + emsg);
				break;
		}
	}
}
