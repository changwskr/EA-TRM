package wsj.atm.common;

import java.sql.*;
import java.io.*;
import java.util.*;

/**
 * <PRE>
 * Class    : CifDBMSManager
 * Function :
 * Comment  : nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn<BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

public class DBMSManager {

	// ȯ������
	public static ConfigEnv CE = new ConfigEnv();

	public static String user = CE.DBUSER;
	public static String password = CE.DBPASSWORD;
	public static String dburl = CE.DBURL;
	public static String driverClass = CE.DBDIRVER;
	public static String driverURL = CE.DBDIRVER;
	public static Connection connection;



	////////////////////////////////////////////////////////////////////
	//
	////////////////////////////////////////////////////////////////////
	public static void connect() {
        try {
            Class.forName(driverClass);
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }

        try {
            Properties properties = new Properties();
            properties.put("user", user);
            properties.put("password", password);
            connection = java.sql.DriverManager.getConnection(driverURL, properties);
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }

    public static void disconnect() {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }


    public static void disconnect(Connection connection) {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }



	////////////////////////////////////////////////////////////////////////////
	// �ϳ��� ����Ÿ���̽� ������ ���ؿ´�
	////////////////////////////////////////////////////////////////////////////
	public static Connection dbConn() {
   		Connection conn = null;

   		try {
         	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         	conn = DriverManager.getConnection (dburl, user, password);
   		} catch ( Exception e ) {
   			LogManager.log("DriverManager.getConnection Exception ");
   			return null;
   		}
   		return conn;
	}




	////////////////////////////////////////////////////////////////////////////
	// �ϳ��� ����Ÿ���̽� ������ ���ؿ´�
	////////////////////////////////////////////////////////////////////////////
	public static Connection dbConn(String user,String passwd) {
   		Connection conn = null;

   		try {
         	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         	conn = DriverManager.getConnection (CE.DBURL, user, passwd);
   		} catch ( Exception e ) {
   			LogManager.log("DriverManager.getConnection Exception ");
   			return null;
   		}
   		return conn;
	}

    public static void dbClose(Connection connection) {
        try {
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
            throw new RuntimeException(exception.toString());
        }
    }




}


