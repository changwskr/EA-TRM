package wsj.atm.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.Vector;
import java.util.zip.ZipOutputStream;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.zip.ZipEntry;

public class Zip {

  public Zip() {
  }

  public static void main(String[] argv) throws Exception{
    if( argv.length != 2 )
    {
      System.out.println(
          "usage : java wsj.atm.common.Zip <source file/dir name> <target file name>"
          );
      return;
    }
    Zip zip1 = new Zip();
  }

  public void EP(String source,String target) throws Exception
  {
    Vector files = makeFiles(source);
    ZipOutputStream targetStream = new ZipOutputStream(new FileOutputStream(target));
    File cur = null;
    String baseDir = null;
    Iterator i = files.iterator();

    while( i.hasNext() )
    {
      cur = (File)i.next();
      if( baseDir == null )
      {
        //String[] pathStack = cur.toString().split("\\"+File.separator);
        //cur.toString().
      }
    }



  }
  public Vector makeFiles(String rootName) throws Exception
  {
    Vector files = new Vector();
    File root = new File(rootName);
    if( root.isDirectory() )
    {
      files.addAll(getSubFiles(root));
    }
    else
      files.add(root);
    return files;
  }
  public Vector getSubFiles(File directory){
    Vector files = new Vector();
    int i;
    File[] list = directory.listFiles();
    for(i=0;i<list.length;i++)
    {
      if(list[i].isDirectory())
      {
         files.addAll(getSubFiles(list[i]));
      }
      else{
        files.add( list[i] );
      }
    }
    return files;
  }

}