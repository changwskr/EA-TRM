package wsj.atm.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */



import java.text.*;

public class NumberUtil {
    public NumberUtil(){
    }
    /**
    * ���� ���� format���·� �ٲ���
    * ������ ����� DecimalFormat Class����.
    * ex) NumUtil.setFormat("1234567890.21","#,###,###,###.00")
    *  0      a digit
    *  #      a digit, zero shows as absent
    *  .      placeholder for decimal separator
    *  ,      placeholder for grouping separator.
    *  ;      separates formats.
    *  -      default negative prefix.
    * @see java.text.DecimalFormat
    */
    public static String setFormat(String str,String format){
        if((str == null) || str.equals("")) return "";
        if((format == null) || format.equals("")) return str;

        DecimalFormat df = new DecimalFormat(format);
        try {
            return df.format(Double.parseDouble(unsetFormat(str)));
        }catch(Exception e){
            return format;
        }
    }
    public static String setFormat(double num,String format){
        return setFormat(String.valueOf(num),format);
    }
    /*
     * ���ڿ� �� �� �ִ� ',','$','\'�� �������μ� DB�� ���尡���� ���·� ����� �ش�.
    */
    public static String unsetFormat(String str){
        String rtn = str;
        if((rtn == null) || rtn.equals("")) return "";
        return rtn;
    }
}
