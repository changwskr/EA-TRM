/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)Debug.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */

package wsj.atm.common.wafutil;

import java.util.*;
import wsj.atm.common.wafutil.LoggerXmlDAO;

/**
 *	Debug class<p>
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class Debug
{
	/**
	 *	private Default Constructor
	 */
	private Debug() {}

	/**
	 *	trace method
	 *
	 *	@param	msg trace message
	 */
	public static void trace(String msg)
	{
		System.out.println(msg);
	}

	public static void trace(Class cl, String msg)
	{
		LoggerXmlDAO dao = LoggerXmlDAO.getInstance();
		if(!dao.isLogTrace()) return;

		String className = cl.getName();
		if(dao.isTrace(className)) {
			int idx = className.lastIndexOf(".");
			System.out.println(className.substring(idx+1) + " ] " + msg);
		}
	}
}