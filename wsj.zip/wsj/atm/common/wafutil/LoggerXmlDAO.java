/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)LoogerXmlDAO.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */

package wsj.atm.common.wafutil;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import wsj.atm.common.wafutil.XmlUtil;

/**
 *	logger.xml�� ���� Data Access Object<p>
 *	logger.xml�� Log trace�� �� Ŭ�������� �����ϴ� configuration file�̴�.
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class LoggerXmlDAO
{
	/** trace */
	public static final String TRACE="trace";
	/**	log-trace */
	public static final String LOG_TRACE="log-trace";

	/** singleton */
	private static LoggerXmlDAO instance;

	/** logger file path URL */
	private URL loggerFilePath;

	/**		logger configuration */
	private HashMap loggers;

	/** log trace */
	private boolean logTrace;

	/**
	 *	private Default Constructor
	 */
	private LoggerXmlDAO()
	{}

	/**
	 *	LoggerXmlDAO��ü�� ��ȯ�ϴ� factory method
	 *
	 *	@return	LoggerXmlDAO Singleton
	 */
	public static LoggerXmlDAO getInstance()
	{
		if(instance==null)
		{
			synchronized(LoggerXmlDAO.class)
			{
				if(instance==null)
				{
					instance = new LoggerXmlDAO();
				}
			}
		}
		return instance;
	}

	/**
	 *	loggers.xml�� ����� ������ �޸𸮿� �ε��ϴ� �޼���
	 *
	 *	@param	fileUrl	loggers.xml�� URL
	 */
	public void load(URL fileUrl)
	{
		if(loggers==null) loggers = new HashMap();
		loggerFilePath=fileUrl;

		Element root = XmlUtil.loadDocument(fileUrl);
		NodeList nList = root.getChildNodes();

		String lt = XmlUtil.getTagValue(root, LOG_TRACE);
        logTrace = new Boolean(lt).booleanValue();

		for(int i=0;i<nList.getLength();i++)
		{
			Node node = (Node)nList.item(i);
			if(node==null) continue;

			if(node.getNodeType() == Node.ELEMENT_NODE)
			{
				String name = node.getNodeName();
				if( (name!=null) && name.equals(LOG_TRACE) ) continue;

				String trace = XmlUtil.getAttribute(node,TRACE);
				loggers.put(name,new Boolean(trace));
			}
		}
	}

	/**
	 *	logTrace�� ��ȯ�ϴ� method
	 *
	 *	@return boolean logTrace
	 */
	public boolean isLogTrace()
	{
		return logTrace;
	}

	/**
	 *	logTrace�� �����ϴ� �޼���
	 *
	 *	@param	logTrace	��ü logTrace�� ���� flag
	 */
	public synchronized void setLogTrace(boolean logTrace)
	{
		this.logTrace = logTrace;
	}

	/**
	 *	class�� ���� trace ���� ��ȯ�ϴ� method
	 *
	 *	@param	className	class name
	 *	@return	class�� ���� trace
	 */
	public boolean isTrace(String className)
	{
		Boolean b = (Boolean)loggers.get(className);
		if(b!=null) return b.booleanValue();

		return false;
	}

	/**
	 *	class�� ���� trace�� ��ȯ�ϴ� method
	 *
	 *	@param	className	class name
	 *	@param	class�� ���� trace
	 */
	public Boolean getTrace(String className)
	{
		Boolean tmp = (Boolean)loggers.get(className);
		if(tmp==null) return new Boolean(false);

		return tmp;
	}

	/**
	 *	trace�� �����ϴ� method
	 *
	 *	@param	className	class name
	 *	@param	trace	class�� ���� trace
	 */
	public synchronized void setTrace(String className, String trace)
	{
		loggers.put(className, new Boolean(trace));
	}

	/**
	 *	trace �׸��� �����ϴ� �޼���
	 *
	 *	@param	className	class name
	 *	@return	������ class name�� ���� trace
	 */
	public synchronized Boolean removeTrace(String className)
	{
		return (Boolean)loggers.remove(className);
	}

	/**
	 *	key ���� �����ϴ��� check�ϴ� �޼���
	 *
	 *	@param	name	Webpage name
	 *	@return	���翩��
	 */
	public boolean containsKey(String className)
	{
		return loggers.containsKey(className);
	}

	/**
	 *	loggers.xml�� ������ class�� collection�� ��ȯ�ϴ� method
	 *
	 *	@return class�� collection
	 */
	public ArrayList keys()
	{
		Set kset = loggers.keySet();
		ArrayList al = new ArrayList(kset);
		Collections.sort(al);

		return al;
	}

	/**
	 *	loggers.xml�� Webpage �������� �����ϴ� �޼���
	 */
	public synchronized void persist()
	throws IOException
	{
		String filePath = loggerFilePath.toString();

		if(filePath.startsWith("file:")) {
			filePath = filePath.substring(5);
		}
		File f = new File(filePath);

		FileWriter fw = null;
		try {
			Set kset = loggers.keySet();
			ArrayList al = new ArrayList(kset);
			Collections.sort(al);

			StringBuffer sxml = new StringBuffer();
			sxml.append("<?xml version=\"1.0\" encoding=\"euc-kr\"?>\n\n");
			sxml.append("<logger-config>").append("\n\n");

			sxml.append("\t<log-trace>").append(logTrace).append("</log-trace>\n");

			for(int i=0;i<al.size();i++) {
				String className = (String)al.get(i);
				Boolean trace = (Boolean)loggers.get(className);
				sxml.append("\t<").append(className).append("\ttrace=\"");
				sxml.append(trace.toString()).append("\"/>");
				sxml.append("\n");
			}
			sxml.append("</logger-config>");
			fw = new FileWriter(f);
			fw.write(sxml.toString(), 0, sxml.length());
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(fw!=null) fw.close();
		}
	}



}