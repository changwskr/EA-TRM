package wsj.atm.common.wafutil;

/**
 *	Web Application Framework���� ����ϴ� ����� ������ �������̽�<p>
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public interface WebKeys
{
    /**	java:comp/env/path/requests.xml	*/
    public static final String REQUESTS_JNDI = "java:comp/env/path/requests.xml";
    /**	java:comp/env/path/webpages.xml	*/
    public static final String WEBPAGES_JNDI = "java:comp/env/path/webpages.xml";
    /**	java:comp/env/path/environment.xml	*/
    public static final String ENVIRONMENT_JNDI = "java:comp/env/path/environment.xml";
    /**	java:comp/env/path/excetpions.xml	*/
    public static final String EXCEPTIONS_JNDI = "java:comp/env/path/excetpions.xml";
    /**	java:comp/env/path/loggers.xml	*/
    public static final String LOGGERS_JNDI = "java:comp/env/path/loggers.xml";
    /**	java:comp/env/path/servers.xml	*/
    public static final String SERVERS_JNDI = "java:comp/env/path/servers.xml";

    /**	java:comp/env/class/BizDelegationImpl	*/
    public static final String BIZDELEGATION_JNDI = "java:comp/env/class/BizDelegationImpl";
    /**	java:comp/env/jndi/INITIAL_CONTEXT_FACTORY	*/
    public static final String CONTEXT_FACTORY_JNDI = "java:comp/env/jndi/INITIAL_CONTEXT_FACTORY";
    /**	java:comp/env/jndi/PROVIDER_URL	*/
    public static final String PROVIDER_URL_JNDI = "java:comp/env/jndi/PROVIDER_URL";

    /**	CURRENT_REQUEST_NAME	*/
    public static final String CURRENT_REQUEST_NAME="CURRENT_REQUEST_NAME";
    /**	CURRENT_REQUEST_KEY	*/
    public static final String CURRENT_REQUEST_KEY="CURRENT_REQUEST_KEY";

    /**	CURRENT_WEBPAGE_NAME	*/
    public static final String CURRENT_WEBPAGE_NAME="CURRENT_WEBPAGE_NAME";
    /**	CURRENT_WEBPAGE_KEY	*/
    public static final String CURRENT_WEBPAGE_KEY="CURRENT_WEBPAGE_KEY";

    /**	SESSION_KEY	*/
    public static final String SESSION_KEY="userInfo";
    /**	BIZDELEGATION_KEY	*/
    public static final String BIZDELEGATION_KEY="BIZDELEGATION_KEY";
    /** AGENT_KEY */
    public static final String AGENT_KEY="AGENT_KEY";
    /** SESSION_TIMEOUT */
    public static final String SESSION_TIMEOUT="session.timeout";

}