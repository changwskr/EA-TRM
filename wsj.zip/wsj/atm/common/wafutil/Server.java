/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)Server.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */
package wsj.atm.common.wafutil;

import java.io.Serializable;

/**
 *	����� ������ �����ϴ� servers.xml�� ���� Data Model object�̴�.
 *	servers.xml�� ������ server tag�� ���� ������ ǥ���ϴ� class�̴�.
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class Server implements Serializable
{
	/** Server name(unique) */
	private String name;
	/** host name */
	private String hostName;
	/** ip */
	private String ip;
	/** port */
	private int port;
	/** rmiregistry port */
	private int rmiPort;
	/** �ڽ� ���� */
	private boolean self;

	/**
	 *	Default Constructor
	 */
	public Server()
	{}

	/**
	 *	Constructor
	 *
	 *	@param	name		server name
	 *	@param	hostName	host name
	 *	@param	ip			ip
	 *	@param	port		port
	 *	@param	rmiPort		rmiregistry port
	 *	@param	self		�ڽ� ����
	 */
	public Server(String name, String hostName, String ip, int port, int rmiPort, boolean self)
	{
		this.name = name;
		this.hostName = hostName;
		this.ip = ip;
		this.port = port;
		this.rmiPort = rmiPort;
		this.self = self;
	}

	/**
	 *	name�� ���� setter method
	 *
	 *	@param	name	server name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 *	name�� ���� getter method
	 *
	 *	@return		server name
	 */
	public String getName()
	{
		return this.name;
	}

	/**
	 *	hostName�� ���� setter method
	 *
	 *	@param	hostName	hostname
	 */
	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}

	/**
	 *	hostName�� ���� getter method
	 *
	 *	@return hostname
	 */
	public String getHostName()
	{
		return this.hostName;
	}

	/**
	 *	ip�� ���� setter method
	 *
	 *	@param	ip	server ip
	 */
	public void setIp(String ip)
	{
		this.ip = ip;
	}

	/**
	 *	ip�� ���� getter method
	 *
	 *	@return		server ip
	 */
	public String getIp()
	{
		return this.ip;
	}

	/**
	 *	rmiPort�� ���� setter method
	 *
	 *	@param	port	rmiregistry port
	 */
	public void setRMIPort(int port)
	{
		this.rmiPort = port;
	}

	/**
	 *	rmiPort�� ���� getter method
	 *
	 *	@return rmiregitstry port
	 */
	public int getRMIPort()
	{
		return this.rmiPort;
	}

	/**
	 *	was listen port�� ���� setter method
	 *
	 *	@param	port	was listen port
	 */
	public void setPort(int port)
	{
		this.port = port;
	}

	/**
	 *	was listen port�� ���� getter method
	 *
	 *	@return		was listen port
	 */
	public int getPort()
	{
		return this.port;
	}

	/**
	 *	�ڽ� ���θ� �����ϴ� self�� ���� setter method
	 *
	 *	@param	self	�ڽſ���
	 */
	public void setSelf(boolean self)
	{
		this.self = self;
	}

	/**
	 *	�ڽſ��θ� �����ϴ� self�� ���� getter method
	 *
	 *	@return		�ڽſ���
	 */
	public boolean isSelf()
	{
		return this.self;
	}

	/**
	 *	rmiregistry�� ���� URL�� ��ȯ�ϴ� getter method
	 *
	 *	@return rmiregistry url("rmi://ip:port/agent-name")
	 */
	public String getRMIURL()
	{
		return "rmi://"+ip+":"+rmiPort+"/"+name;
	}

	/**
	 *	toString() method
	 */
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("Server [ name=").append(name);
		sb.append(", hostName=").append(hostName);
		sb.append(", ip=").append(ip);
		sb.append(", port=").append(port);
		sb.append(", rmiPort=").append(rmiPort);
		sb.append(", self=").append(self);
		sb.append(" ]");

		return sb.toString();
	}

	/**
	 *	toXml() method
	 */
	public String toXml()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("\t<server name=\"").append(name).append("\" ");
		sb.append("self=\"").append(self).append("\" >\n");
		sb.append("\t\t<host-name>").append(hostName).append("</host-name>\n");
		sb.append("\t\t<rmi-port>").append(rmiPort).append("</rmi-port>\n");
		sb.append("\t\t<ip>").append(ip).append("</ip>\n");
		sb.append("\t\t<port>").append(port).append("<port>\n");
		sb.append("\t</server>\n");

		return sb.toString();
	}
}
