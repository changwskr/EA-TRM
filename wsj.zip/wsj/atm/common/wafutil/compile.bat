@echo off

set JAVA_HOME=C:\bea\jdk131
set WLS_HOME=C:\bea\wlserver6.1
set APP_DOMAIN_HOME=C:\bea\wlserver6.1\config\ibs

set JDBC_DRIVER=%APP_DOMAIN_HOME%\lib\classes12.zip
set FOUNDATION_JAR=%APP_DOMAIN_HOME%\lib\foundation.jar
set FRAMEWORK_JAR=%APP_DOMAIN_HOME%\lib\framework.jar

set IBS_CLASSES=%APP_DOMAIN_HOME%\ibsWEBAPP\WEB-INF\classes

set IBS_CPATH=%IBS_CLASSES%;%FRAMEWORK_JAR%;%FOUNDATION_JAR%;%JDBC_DRIVER%
set MYCPATH=%WLS_HOME%;%WLS_HOME%\lib\weblogic_sp.jar;%WLS_HOME%\lib\weblogic.jar;%IBS_CPATH%

echo +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
echo CLASSPATH=%MYCPATH%
echo +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


if "%1"=="" goto all:

%JAVA_HOME%/bin/javac -d %IBS_CLASSES% -classpath %MYCPATH% %1
goto end:

: all
%JAVA_HOME%/bin/javac -d %IBS_CLASSES% -classpath %MYCPATH% *.java
goto end:

:error 
echo "compile error"

:end