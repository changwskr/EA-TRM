/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)ServerXmlDAO.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */

package wsj.atm.common.wafutil;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import wsj.atm.common.wafutil.XmlUtil;

/**
 *	����� ������ �����ϴ� servers.xml�� ���� Data Access Object�̴�.
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class ServerXmlDAO implements ServerXmlKeys
{
	/** Singleton */
	private static ServerXmlDAO instance;

	/** Server Collection */
	private HashMap servers;

	/**	servers.xml�� ���� URL */
	private URL serverFilePath;

	/**
	 *	private Default Constructor
	 */
	private ServerXmlDAO()
	{}

	/**
	 *	ServerXmlDAO Singleton�� ���� factory method
	 *
	 *	@return		ServerXmlDAO Singleton
	 */
	public static ServerXmlDAO getInstance()
	{
		if(instance==null)
		{
			synchronized(ServerXmlDAO.class)
			{
				if(instance==null)
				{
					instance=new ServerXmlDAO();
				}
			}
		}

		return instance;
	}

	/**
	 *	servers.xml�� ������ �ε��ϴ� �޼���
	 *
	 *	@param	fileUrl	servers.xml������ URL
	 */
	public void load(URL fileUrl)
	{
		if(servers==null) servers = new HashMap();
		serverFilePath=fileUrl;

		Element root = XmlUtil.loadDocument(fileUrl);
		NodeList nList = root.getChildNodes();

		for(int i=0;i<nList.getLength();i++)
		{
			Node node = (Node)nList.item(i);
			if(node==null) continue;

			if(node.getNodeType() == Node.ELEMENT_NODE)
			{
				String name = XmlUtil.getAttribute(node,NAME);
				if(name==null) continue;

				String self = XmlUtil.getAttribute(node,SELF);
				String hostName = XmlUtil.getSubTagValue(node,HOST_NAME);
				String ip = XmlUtil.getSubTagValue(node,IP);
				String port = XmlUtil.getSubTagValue(node,PORT);
				String rmiPort = XmlUtil.getSubTagValue(node,RMI_PORT);

				boolean isSelf = ( (self!=null) && self.equals("true") ) ? true : false;

				Server svr = new Server(
					name, hostName, ip, Integer.parseInt(port), Integer.parseInt(rmiPort), isSelf
				);
                                System.out.println("ServerXmlDAO Server "+i+name);
				servers.put(name,svr);
			}
		}
	}

	/**
	 *	name�� �ش��ϴ� Server ��ü�� ��ȯ�ϴ� �޼���
	 *
	 *	@param	name	ã������ server name
	 *	@return	Server object
	 */
	public Server getServer(String name)
	{
		return (Server)servers.get(name);
	}

	/**
	 *	Server ��ü�� �����ϴ� �޼���
	 *
	 *	@param	server	Server object
	 */
	public void setServer(Server server)
	{
		servers.put(server.getName(),server);
	}

	/**
	 *	name�� �ش��ϴ� Server object�� �����ϴ� �޼���
	 *
	 *	@param	name	server name
	 *	@return Server object
	 */
	public Server removeServer(String name)
	{
		return (Server)servers.remove(name);
	}

	/**
	 *	�����ϰ� �ִ� Server ��ü���� ��ȯ�ϴ� �޼���
	 *
	 *	@return	Server list
	 */
	public Iterator getAllServers()
	{
		return servers.values().iterator();
	}

	/**
	 *	����� �� Server ��ü�� ��ȯ�ϴ� �޼���
	 *
	 *	@return	�� Server object
	 */
	public Server getServer()
	{
		Iterator it = getAllServers();
		while(it.hasNext())
		{
			Server svr = (Server)it.next();
			if(svr.isSelf()) return svr;
		}

		return null;
	}

	/**
	 *	�������� Agent ��ü�� ���� rmiregistry lookup URL���� ��ȯ�ϴ� �޼���
	 *
	 *	@return rmi url collection
	 */
	public ArrayList getRMIURLs()
	{
		ArrayList al = new ArrayList();
		Iterator it = getAllServers();
		while(it.hasNext())
		{
			Server svr = (Server)it.next();
			String url = svr.getRMIURL();
			al.add(url);
		}

		return al;
	}
}