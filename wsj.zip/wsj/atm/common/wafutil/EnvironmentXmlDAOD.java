package wsj.atm.common.wafutil;

import java.io.*;
import java.net.*;
import java.util.*;

import org.w3c.dom.*;

import wsj.atm.common.wafutil.XmlUtil;
/**
 *	environments.xml�� ���� Data Access Object<p>
 *	environments.xml�� ȯ�������� �����ϴ� configuration file�̴�.
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class EnvironmentXmlDAOD
{
    /** EnvironmentXmlDAOD singleton */
    private static EnvironmentXmlDAOD instance;

    /** environments.xml�� ����� properties */
    private static HashMap datas;

    private URL environmentFilePath;

    /**
     *	Default Constructor
     */
    private EnvironmentXmlDAOD(){}

    /**
     *	EnvironmentXmlDAOD Singleton �� factory method
     *
     *	@return	EnvironmentXmlDAOD singleton
     */
    public static EnvironmentXmlDAOD getInstance()
    {
        if(instance == null)
        {
            synchronized(EnvironmentXmlDAOD.class)
            {
                if(instance == null)
                {
                    instance = new EnvironmentXmlDAOD();
                }
            }
        }

        return instance;
    }

    /**
     *	environments.xml�� ����� property�� �޸𸮿� �ε��ϴ� �޼���
     *
     *	@param	fileUrl	environments.xml�� URL
     */
    public void load(URL fileUrl)
    {
        if(datas==null) datas = new HashMap();
        environmentFilePath=fileUrl;

        Element root = XmlUtil.loadDocument(fileUrl);
        NodeList nList = root.getChildNodes();

        for(int i=0;i<nList.getLength();i++)
        {
            Node node = (Node)nList.item(i);
            if(node==null) continue;

            if(node.getNodeType() == Node.ELEMENT_NODE)
            {
                String name = node.getNodeName();
                String value = node.getLastChild().getNodeValue();
                datas.put(name,value);
            }
        }

    }

    /**
     *	key�� �ش��ϴ� property�� ��ȯ�ϴ� getter method
     *
     *	@param	key	property�� key
     *	@return	key�� �ش��ϴ� property
     */
    public String getProperty(String key)
    {
        Object obj = datas.get(key);
        return obj==null?null:(String)obj;
    }

    public String[] getStringArray(String key)
    {
        ArrayList al = new ArrayList();
        String str = (String)datas.get(key);
        StringTokenizer st = new StringTokenizer(str,",");
        while(st.hasMoreElements()) {
            String tmp = st.nextToken();
            al.add(tmp);
        }

        String[] results = new String[al.size()];
        for(int i=0;i<results.length;i++) results[i] = (String)al.get(i);

        return results;
    }

    /**
     *	property�� �����ϴ� �޼���
     *
     *	@param	key		property�� key
     *	@param	value	property
     */
    public void setProperty(String key, String value)
    {
        datas.put(key,value);
    }

    /**
     *	property�� �����ϴ� method
     *
     *	@param	key	property�� key
     *	@return	property value
     */
    public String removeProperty(String key)
    {
        return (String)datas.remove(key);
    }

    /**
     *	key ���� �����ϴ��� check�ϴ� �޼���
     *
     *	@param	key		property name
     *	@return	���翩��
     */
    public boolean containsKey(String key)
    {
        return datas.containsKey(key);
    }

    /**
     *	�����ϰ� �ִ� properties�� name Collection�� ��ȯ�ϴ� �޼���
     *
     *	@return	Request�� name collection
     */
    public ArrayList keys()
    {
        Set kset = datas.keySet();
        ArrayList al = new ArrayList(kset);
        Collections.sort(al);

        return al;
    }

    /**
     *	�����ϰ� �մ� properties���� environments.xml�� �����ϴ� �޼���
     *
     */
    public synchronized void persist()
    throws IOException
    {
        String filePath = environmentFilePath.toString();

        if(filePath.startsWith("file:")) {
            filePath = filePath.substring(5);
        }
        File f = new File(filePath);
        FileWriter fw = null;
        try {
            Set kset = datas.keySet();
            ArrayList al = new ArrayList(kset);
            Collections.sort(al);

            StringBuffer sxml = new StringBuffer();
            sxml.append("<?xml version=\"1.0\" encoding=\"euc-kr\"?>\n\n");
            sxml.append("<environment-config>").append("\n\n");

            for(int i=0;i<al.size();i++) {
                String name = (String)al.get(i);
                String value =(String)datas.get(name);
                sxml.append("\t<").append(name).append(">");
                sxml.append(value);
                sxml.append("</").append(name).append(">");
                sxml.append("\n");
            }
            sxml.append("\n</environment-config>");
            fw = new FileWriter(f);
            fw.write(sxml.toString(), 0, sxml.length());
        } finally {
            if(fw!=null) fw.close();
        }
    }

    /**
     *	trace method
     */
    private void trace(String msg)
    {
        wsj.atm.common.wafutil.Debug.trace(getClass(),msg);
    }

/*
//���ϸ�:environment.xml
//-------------------------------------------------------------------------------
<?xml version="1.0" encoding="euc-kr"?>
<environment-config>
    <admin-id>admin</admin-id>
    <admin-password>1111</admin-password>
    <bizDelegateImpl>rmi://21.102.1.227:10101/IbBizDelegateImpl</bizDelegateImpl>
</environment-config>
//-------------------------------------------------------------------------------
*/
    public static void main(String args[] ){
      EnvironmentXmlDAOD env = EnvironmentXmlDAOD.getInstance();
      // environment.xml :: bizDelegateImpl -- rmi://21.102.1.227:10101/IbBizDelegateImpl
      String rmiName = env.getProperty("bizDelegateImpl");

    }
}