/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)XmlUtil.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */

package wsj.atm.common.wafutil;

import java.net.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;
import wsj.atm.common.wafutil.Debug;

/**
 *	XML Dom�� �����ϱ� ���� Utility class<p>
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class XmlUtil
{
	/**
	 *	private Default Constructor
	 */
	private XmlUtil() {}

	/**
	 *	URL(xml file ���)�� ���� DOM object�� �����Ͽ�, Root Element�� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	url		xml file ����� URL object
	 * @return	DOM object�� root Element object
	 * @since      1.0
     */
	public static Element loadDocument(URL url)
	{
		try {
    		DocumentBuilderFactory factory =
    							DocumentBuilderFactory.newInstance();
    		DocumentBuilder builder = factory.newDocumentBuilder();

    		InputSource xmlSrc = new InputSource(url.openStream());
			Document doc = builder.parse(xmlSrc);

    		Element root = doc.getDocumentElement();
    		root.normalize();

    		return root;
    	}catch (SAXParseException err) {
            trace("XmlUtil Parsing error" + ", line " +
                        err.getLineNumber () + ", uri " + err.getSystemId ());
            trace("XmlUtil error: " + err.getMessage ());
        } catch (SAXException e) {
            trace("XmlUtil error: " + e);
        } catch (java.net.MalformedURLException mfx) {
            trace("XmlUtil error: " + mfx);
        } catch (java.io.IOException e) {
            trace("XmlUtil error: " + e);
        } catch (Exception pce) {
        	pce.printStackTrace();
            trace("XmlUtil error: " + pce);
        }
    	return null;
    }


	/**
	 *	root Element �Ʒ��� Tag text value ���� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	root	root Element object
	 * @param	tagName	tag name
	 * @return	tag�� text value
	 * @since      1.0
     */
	public static String getTagValue(Element root, String tagName)
	{
		NodeList nList = root.getElementsByTagName(tagName);
    	for(int i=0;i<nList.getLength();i++) {
    		Node node = nList.item(i);
    		if(node!=null) {
    			Node child = node.getFirstChild();
    			if( (child!=null) && (child.getNodeValue()!=null) ) {
    				return child.getNodeValue();
    			}
    		}
    	}
    	return "";
    }

    /**
	 *	Node �� sub Tag text value ���� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	node		Node object
	 * @param	subTagName	Node�� sub tag name
	 * @return	sub tag�� text value
	 * @since      1.0
     */
	public static String getSubTagValue(Node node, String subTagName)
    {
    	NodeList nList = node.getChildNodes();
    	for(int i=0;i<nList.getLength();i++) {
    		Node child = nList.item(i);

    		if ( 	(child != null) &&
    				(child.getNodeName() != null) &&
    				child.getNodeName().equals(subTagName) )
    		{
                Node grandChild = child.getFirstChild();
				if(grandChild==null) continue;
				if (grandChild.getNodeValue() != null)
                	return grandChild.getNodeValue();
        	}
    	}
    	return "";
    }

    /**
	 *	root Element�� sub Tag text value ���� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	root		root Element object
	 * @param	tagName		root�� ù��° Node�� tag Name
	 * @param	subTagName	root�� �ι�° Node�� tag name
	 * @return	sub tag�� text value
	 * @since      1.0
     */
	public static String getSubTagValue(Element root, String tagName, String subTagName) {
		String returnString = "";
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null) {
				NodeList  children = node.getChildNodes();
				for (int innerLoop =0; innerLoop < children.getLength(); innerLoop++) {
					Node  child = children.item(innerLoop);
					if ( (child != null) &&
						 (child.getNodeName() != null) &&
						 child.getNodeName().equals(subTagName) ) {
						Node grandChild = child.getFirstChild();
						if ( 	(grandChild!=null) &&
								grandChild.getNodeValue() != null) {
							return grandChild.getNodeValue();
						}
					}
				} // end inner loop
			}
		}
		return returnString;
	}

	/**
	 *	root Element�� sub Tag���� text value ������ ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	root		root Element object
	 * @param	tagName		root�� ù��° Node�� tag Name
	 * @param	subTagName	root�� �ι�° Node�� tag name
	 * @return	sub tag���� text value�� �����ϴ� ArrayList
	 * @since      1.0
     */
	public static ArrayList getSubTagValues(Element root,
											String tagName,
											String subTagName) {
		ArrayList results = new ArrayList();
		NodeList list = root.getElementsByTagName(tagName);
		for (int loop = 0; loop < list.getLength(); loop++) {
			Node node = list.item(loop);
			if (node != null) {
				NodeList  children = node.getChildNodes();
				for (int innerLoop =0; innerLoop < children.getLength(); innerLoop++) {
					Node  child = children.item(innerLoop);
					if ( (child != null) &&
						 (child.getNodeName() != null) &&
						 child.getNodeName().equals(subTagName) ) {
						Node grandChild = child.getFirstChild();
						if ( 	(grandChild!=null) &&
								grandChild.getNodeValue() != null) {
							results.add(grandChild.getNodeValue());
						}
					}
				} // end inner loop
			}
		}
		return results;
	}

    /**
	 *	root Element�� sub Tag�� attribute value�� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	root		root Element object
	 * @param	tagName		root�� ù��° Node�� tag Name
	 * @param	subTagName	root�� �ι�° Node�� tag name
	 * @param	attribute	attribute name
	 * @return	attribute�� value
	 * @since      1.0
     */
	public static String getSubTagAttribute(	Element root,
												String tagName,
												String subTagName,
												String attribute	)
	{
        String returnString = "";
        NodeList list = root.getElementsByTagName(tagName);
        for (int loop = 0; loop < list.getLength(); loop++)
        {
            Node node = list.item(loop);
            if (node != null)
            {
                NodeList  children = node.getChildNodes();
                for (int innerLoop=0;innerLoop<children.getLength();innerLoop++)
                {
                    Node  child = children.item(innerLoop);
                    if (	(child != null) &&
                    		(child.getNodeName() != null) &&
                    		child.getNodeName().equals(subTagName) )
                    {
                        if (child instanceof Element) {
                            return ((Element)child).getAttribute(attribute);
                        }
                    }
                } // end inner loop
            }
        }
        return returnString;
    }

	/**
	 *	Node�� attribute value�� ��ȯ�Ѵ�.
	 *	<p><p>
	 *
	 * @param	node		Node object
	 * @param	attrName	attribute name
	 * @return	attribute�� value
	 * @since      1.0
     */
	public static String getAttribute(Node node, String attrName)
	{
		if(	(node!=null) && (node instanceof Element) )
		{
			return ((Element)node).getAttribute(attrName);
		}

		return "";
	}

	/**
	 *	trace method
	 */
	private static void trace(String msg)
	{
		wsj.atm.common.wafutil.Debug.trace(XmlUtil.class,msg);
	}
}