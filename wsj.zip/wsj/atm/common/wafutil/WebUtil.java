/*
* This software was developed and owned by NACF and IMS System Corp
* Illegal use of this software will violate the Copy Right Law
* ******************************************************
* Program Name : @(#)WebUtil.java
* Function description : Web Application Framework
* Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
* Creation Date : 2002.09.05
* ******************************************************
*                    P R O G R A M H I S T O R Y
* ******************************************************
* DATE			:	PRGMMER		: REASON
*				:				:
 */

package wsj.atm.common.wafutil;

import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import javax.servlet.*;
import javax.servlet.http.*;

import wsj.atm.common.wafutil.WebKeys;
import wsj.atm.common.wafutil.Application;

import com.chb.coses.waf.delegation.BizDelegation;
import com.chb.coses.waf.delegation.BizProcessException;

/**
 *	Utility class<p>
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class WebUtil
{
  /**
   *	private Default Constructor
   */
  private WebUtil(){}

  /**
   *	Web request�� ���� request uri�� �̸��� ��� ��ȯ�ϴ� �޼���.
   *
   *	@param request	javax.servlet.http.HttpServletRequest
   *	@return	Web request URI�� �̸����� Request��ü�� �̸�
   */
  public static String getRequestName(HttpServletRequest request)
  {
    //String requestName = (String)request.getAttribute(WebKeys.CURRENT_REQUEST_NAME);
    //if(requestName!=null) return requestName;
    String requestName=null;
    String fullURL = request.getRequestURI();

    String contextPath = request.getContextPath();
    int startIdx = fullURL.indexOf("/",fullURL.indexOf(contextPath)+1);

    if( startIdx!=-1 ) {
      requestName = fullURL.substring(startIdx+1);
    } else {
      requestName = fullURL.substring(1);
    }
    return requestName;
  }

  /**
   *	Web request�� ���� request uri�� �̸��� ��� ��ȯ�ϴ� �޼���
   *
   *	@param	request		javax.servlet.http.HttpServletRequest
   *	@param	ext			request uri�� Ȯ����(.page, .admin, .popup)
   *	@return	Web request URI�� �̸����� Request��ü�� �̸�
   */
  public static String getPageName(HttpServletRequest request, String ext)
  {
    String fullURL = request.getRequestURI();
    String contextPath = request.getContextPath();

    String pageName = null;
    int startIdx = fullURL.indexOf("/",fullURL.indexOf(contextPath)+1);
    int pageIdx = fullURL.lastIndexOf(ext);//.page or .popup or .admin

    if(pageIdx==-1) return null;

    if( startIdx!=-1 ) {
      pageName = fullURL.substring(startIdx+1,pageIdx);
    } else {
      pageName = fullURL.substring(1,pageIdx);
    }
    return pageName;
  }

  /**
   *	�Ķ������ Object�� ��� get �޼����� ����� �ϳ��� String
   *	��ü�� ����� ��ȯ�ϴ� �޼���
   *
   *	@param	obj	Data Transfer Object
   *	@return	��� get �޼����� ����� ccncatination�� string
   */
  public static String toString(Object obj)
  {
    if(obj==null) return null;

    Class c = obj.getClass();
    Method[] m = c.getDeclaredMethods();
    StringBuffer sb = new StringBuffer();
    sb.append(c.getName()+" [\n");
    for(int i=0;i<m.length;i++) {
      String name = m[i].getName();
      if(name.startsWith("get")) {
        String att = name.substring(4);
        sb.append("\t");
        sb.append(Character.toLowerCase(name.charAt(3))).append(att);
        sb.append("=");
        try {
          Object result = m[i].invoke(obj,new Object[0]);
          sb.append(result).append("\n");
        } catch(Exception e) {
          sb.append("not found method").append("\n");
        }
      }
    }
    sb.append(" ]");
    return sb.toString();
  }

  /**
   *	EJB call method
   *
   *	@param	request	javax.servlet.http.HttpServletRequest
   *	@param	reqDTO	request CDTO
   *	@return	response CDTO
   */
  public static Object callEjb(HttpServletRequest request, Object reqDTO)
      throws BizProcessException, ServletException, Exception
  {
    if(reqDTO != null) {
      BizDelegation biz =
          (BizDelegation)Application.getAttribute(WebKeys.BIZDELEGATION_KEY);
      try {
        return biz.handleEvent(reqDTO,request);
      } catch(BizProcessException e) {
        throw e;
        /*
      } catch(ServletException e) {
        throw e;
       */
      }
      catch(Exception e) {
        throw e;
      }

    }
    throw new ServletException("request cdto is null.");
  }

  public static java.sql.Date toDate(String date)
  {
    String year		= date.substring(0,4);
    String month	= date.substring(4,6);
    String day		= date.substring(6);

    Calendar today = Calendar.getInstance();
    today.set(Integer.parseInt(year),Integer.parseInt(month)-1,Integer.parseInt(day));

    return new java.sql.Date(today.getTime().getTime());

  }
}