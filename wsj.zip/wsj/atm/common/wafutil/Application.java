package wsj.atm.common.wafutil;

/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)Application.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */



import java.io.*;
import java.net.*;
import java.util.*;
import javax.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 *	ServletContext�� �����ϱ� ���� Wapper class<p>
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class Application
{
    /** ServletContext */
    private static ServletContext context;

    /**
     *	Defualt Constructor
     *
     * @since      1.0
     */
    private Application() {}

    /**
     *	ServletContext�� �ʱ�ȭ�Ѵ�. Framework�� �ʱ�ȭ �ɶ� FrontServlet�� init()
     *	method���� ȣ��ȴ�.
     *
     * @param	ctx 	javax.servlet.ServletContext
     * @since      1.0
     */
    public static void init(ServletContext ctx)
    {
        context = ctx;
    }

    public static Object getAttribute(String key)
    {
        return context.getAttribute(key);
    }

    public static Enumeration getAttributeNames()
    {
        return context.getAttributeNames();
    }

    public static ServletContext getContext(String uriPath)
    {
        return context.getContext(uriPath);
    }

    public static ServletContext getContext()
    {
        return context;
    }

    public static String getInitParameter(String name)
    {
        return context.getInitParameter(name);
    }


    public static Enumeration getInitParameterNames()
    {
        return context.getInitParameterNames();
    }

    public static int getMajorVersion()
    {
        return context.getMajorVersion();
    }

    public static String getMimeType(String file)
    {
        return context.getMimeType(file);
    }

    public static int getMinorVersion()
    {
        return context.getMinorVersion();
    }

    public static RequestDispatcher getNamedDispatcher(String name)
    {
        return context.getNamedDispatcher(name);
    }

    public static String getRealPath(String path)
    {
        return context.getRealPath(path);
    }

    public static RequestDispatcher getRequestDispatcher(String path)
    {
        return context.getRequestDispatcher(path);
    }

    public static URL getResource(String path)
     throws MalformedURLException
     {
         return context.getResource(path);
     }

    public static InputStream getResourceAsStream(String path)
    {
        return context.getResourceAsStream(path);
    }

    public static Set getResourcePaths(String path)
    {
        //jeee.jar������ 121�����ΰ��
        // j2ee121
        return context.getResourcePaths();
        //j2ee131
        //return context.getResourcePaths(path);
    }

    public static String getServerInfo()
    {
        return context.getServerInfo();
    }


    public static void setAttribute(String key, Object value)
    {
        context.setAttribute(key,value);
    }

    public static String getServletContextName()
    {
        return context.getServletContextName();
    }

    public static void log(String msg)
    {
        context.log(msg);
    }

    public static void log(String message,Throwable throwable)
     {
         context.log(message,throwable);
     }

     public static void removeAttribute(String name)
     {
          context.removeAttribute(name);
     }

    public static DataSource getDataSource(String pool)
    {
        return (DataSource)context.getAttribute(pool);
    }
}