/*
 * This software was developed and owned by NACF and IMS System Corp
 * Illegal use of this software will violate the Copy Right Law
 * ******************************************************
 * Program Name : @(#)ServerXmlKeys.java
 * Function description : Web Application Framework
 * Programmer Name : Jeon HongSeong(hsjeon70@dreamwiz.com)
 * Creation Date : 2002.09.05
 * ******************************************************
 *                    P R O G R A M H I S T O R Y
 * ******************************************************
 * DATE			:	PRGMMER		: REASON
 *				:				:
 */

package wsj.atm.common.wafutil;

/**
 *	������� ���� ������ �����ϴ� servers.xml ���ϳ��� xml tag��
 *	�����ϴ� �������̽�
 *
 * @version		WAF 1.0		5 Sep 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public interface ServerXmlKeys
{
	/** server-config */
	public static final String ROOT="server-config";
	/** server */
	public static final String SERVER="server";
	/** name */
	public static final String NAME="name";
	/** rmi-port */
	public static final String RMI_PORT="rmi-port";
	/** self */
	public static final String SELF="self";
	/** host-name */
	public static final String HOST_NAME="host-name";
	/** ip */
	public static final String IP="ip";
	/** port */
	public static final String PORT="port";
}