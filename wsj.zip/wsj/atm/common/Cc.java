package wsj.atm.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.lang.reflect.Method;
import java.lang.reflect.*;
//////////////////////////////////////////////////////////////////////////////
/*
���� Ư�� Ŭ���� CTEST ���� �������� ���� Ŭ������ ���� �ǰ� ���⼭
*/
//////////////////////////////////////////////////////////////////////////////

public class Cc {
  private static Cc instance;
  public static synchronized Cc getInstance() throws Exception{
    if (instance == null) {
      instance = new Cc();
    }
    return instance;
  }
  public Cc() {
  }
  public void execute(String actionClassName,String methodName,IDT[] arg)
  {
    try {
      System.out.println(Class.forName(actionClassName));
      Method meth = (Class.forName(actionClassName)).getMethod(methodName,new Class[]{IDT[].class});
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
      ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
      ex.printStackTrace();
    }catch (InvocationTargetException ex) {
      ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
      ex.printStackTrace();
    }catch (SecurityException ex) {
      ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,String[] arg)
  {
    try {
      System.out.println(Class.forName(actionClassName));
      Method meth = (Class.forName(actionClassName)).getMethod(methodName,new Class[]{String[].class});
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
      ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
      ex.printStackTrace();
    }catch (InvocationTargetException ex) {
      ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
      ex.printStackTrace();
    }catch (SecurityException ex) {
      ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
      ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,IDT arg)
  {
    try {
      Method meth = (Class.forName(actionClassName)).getDeclaredMethod(methodName,new Class[]{IDT.class});
      System.out.println(meth);
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
            ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
            ex.printStackTrace();
    }catch (InvocationTargetException ex) {
            ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
            ex.printStackTrace();
    }catch (SecurityException ex) {
            ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
            ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,IDT arg,IDT arg2)
  {
    try {
      Method meth = (Class.forName(actionClassName)).getDeclaredMethod(methodName,new Class[]{IDT.class,IDT.class});
      System.out.println(meth);
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg,arg2});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
            ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
            ex.printStackTrace();
    }catch (InvocationTargetException ex) {
            ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
            ex.printStackTrace();
    }catch (SecurityException ex) {
            ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
            ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,String arg)
  {
    try {
      Method meth = (Class.forName(actionClassName)).getDeclaredMethod(methodName,new Class[]{String.class});
      System.out.println(meth);
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
            ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
            ex.printStackTrace();
    }catch (InvocationTargetException ex) {
            ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
            ex.printStackTrace();
    }catch (SecurityException ex) {
            ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
            ex.printStackTrace();
    }
  }

  public void execute(String actionClassName,String methodName,String arg,String arg2)
  {
    try {
      Method meth = (Class.forName(actionClassName)).getDeclaredMethod(methodName,new Class[]{String.class,String.class});
      System.out.println(meth);
      meth.invoke((Class.forName(actionClassName)).newInstance(),new Object[]{arg,arg2});
    }
    catch (InstantiationException ex) {
      ex.printStackTrace();
    }catch (IllegalAccessException ex) {
            ex.printStackTrace();
    }catch (IllegalArgumentException ex) {
            ex.printStackTrace();
    }catch (InvocationTargetException ex) {
            ex.printStackTrace();
    }catch (NoSuchMethodException ex) {
            ex.printStackTrace();
    }catch (SecurityException ex) {
            ex.printStackTrace();
    }catch (ClassNotFoundException ex) {
            ex.printStackTrace();
    }
  }

  public static void main(String[] args) {

    try {
      IDT[] arg = new IDT[3];
      arg[0]=new DT();
      arg[1]=new DT();
      arg[2]=new DT();

      ((DT)arg[0]).str = "0000";
      ((DT)arg[1]).str = "1111";
      ((DT)arg[2]).str = "2222";

     Cc.getInstance().execute("wsj.atm.common.CTEST","execute", (IDT[])arg);

     Cc.getInstance().execute("wsj.atm.common.CTEST","execute", (IDT)arg[1]);

      String[] arg1 = new String[3];
      arg1[0]=new String("aaaaaaaaa");
      arg1[1]=new String("bbbbbbbbb");
      arg1[2]=new String("ccccccc");
      Cc.getInstance().execute("wsj.atm.common.CTEST","execute", (String[])arg1);
      Cc.getInstance().execute("CTEST","execute", "qqqqqqqqqqqqqqqqqqq");
      Cc.getInstance().execute("CTEST","execute", "qqqqqqqqqqqqqqqqqqq","aaaaaaaaaaaaaaaaa");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }

  }

}

interface IDT {
  public void dtexecute(String str);
}

class  DT implements IDT{
  public String str;
  public void dtexecute(String str){
    System.out.println("--CTEST :" + str);
  }
}

class  CTEST {
  public DT dt;
  public void execute(IDT dt){
    System.out.println("--CTEST :" + ((DT)dt).str);
  }
  public void execute(IDT dt,IDT dt2){
    System.out.println("--CTEST2 :" + ((DT)dt).str+ ((DT)dt2).str);
  }

  public void execute(IDT[] dt){
    for( int i =0 ; i<dt.length ; i++ ){
      System.out.println(((DT)dt[i]).str);
    }
  }
  public void execute(String[] dt){
    for( int i =0 ; i<dt.length ; i++ ){
      System.out.println(("---"+dt[i]));
    }
  }
  public void execute(String dt){
    System.out.println("---string - 1"+dt);
  }

  public void execute(String dt,String dt2){
    System.out.println("---string - 1"+dt+dt2);
  }

}


