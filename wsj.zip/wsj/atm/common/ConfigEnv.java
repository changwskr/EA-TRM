package wsj.atm.common;

/**
 * <PRE>
 * Class    : ConfigEnv
 * Function :
 * Comment  : nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn<BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

import java.util.*;
import java.io.*;

public class ConfigEnv {

	// [ Config.INI ]
	private static final String ConfigPath =
			//"C:\\MYTEST\\CHB\\src\\����-������ Ver3.0\\Config.INI";
			"C:\\MYTEST\\INETCHB\\env\\Config.INI";

	// [ FTP ]
	public String FTPHOSTNAME;
	public String FTPHOSTPORT;
	public String FTPPASSWORD;
	public String FTPUSER;
	public String FTPTARPATH;
	public String FTPORGPATH;
	public String UFTPTARPATH;
	public String UFTPORGPATH;
	//[ JNDI ]
	public String JNDIHOST;
	public String JNDIVNAME;
	public String JNDIANAME;
	public String JNDINAME3;
	public String JNDINAME4;
	public String JNDINAME5;
	// [ DB ]
	public String DBURL;
	public String DBDIRVER;
	public String DBUSER;
	public String DBPASSWORD;
	// [ TABLE ]
	public String LFILEINFO;
	public String FILEINFO;
	//[ FILE ]
	public String FILEPATH;
	public String CONFIGPATH;
	public String UFILEPATH;
	public String UCONFIGPATH;
	//[ THREAD POOL ]
	public String MINTHRCNT;
	public String MAXTHRCNT;
	//[ HOSTNAME ]
	public String HOSTNAME1;
	public String HOSTNAME2;
	public String HOSTNAME3;
	public String HOSTNAME4;
	public String HOSTNAME5;
	// [ LOG ]
	public String LOGFILENAME;
	public String SHINLOGFILE;
	// [ PORT ]
	public int PORT;
	public int RMIPORT;


	public ConfigEnv()
	{
		/////////////////////////////////////////////////////////////////
		Properties p = new Properties();
		try {
			p.load(new FileInputStream(ConfigPath));
			//[FTP]
			FTPHOSTNAME = p.getProperty("FTPHOSTNAME");
			FTPHOSTPORT = p.getProperty("FTPHOSTPORT");
			FTPPASSWORD = p.getProperty("FTPPASSWORD");
			FTPUSER = p.getProperty("FTPUSER");
			FTPTARPATH = ComUtil.ascToksc( p.getProperty("FTPTARPATH") );
			FTPORGPATH = ComUtil.ascToksc( p.getProperty("FTPORGPATH") );
			//[ JNDI ]
			JNDIHOST = p.getProperty("JNDIHOST");
			JNDIVNAME = p.getProperty("JNDIVNAME");
			JNDIANAME = p.getProperty("JNDIANAME");
			JNDINAME3 = p.getProperty("JNDINAME3");
			JNDINAME4 = p.getProperty("JNDINAME4");
			JNDINAME5 = p.getProperty("JNDINAME5");
			// [ DB ]
			DBURL = p.getProperty("DBURL");
			DBDIRVER = p.getProperty("DBDIRVER");
			DBUSER = p.getProperty("DBUSER");
			DBPASSWORD = p.getProperty("DBPASSWORD");
			// [ TABLE ]
			LFILEINFO = p.getProperty("LFILEINFO");
			FILEINFO = p.getProperty("FILEINFO");
			//[ FILE ]
			FILEPATH = ComUtil.ascToksc( p.getProperty("FILEPATH") );
			CONFIGPATH = ComUtil.ascToksc( p.getProperty("CONFIGPATH") );
			//[ THREAD POOL ]
			MINTHRCNT = p.getProperty("MINTHRCNT");
			MAXTHRCNT = p.getProperty("MAXTHRCNT");
			//[ HOSTNAME ]
			HOSTNAME1 = p.getProperty("HOSTNAME1");
			HOSTNAME2 = p.getProperty("HOSTNAME2");
			HOSTNAME3 = p.getProperty("HOSTNAME3");
			HOSTNAME4 = p.getProperty("HOSTNAME4");
			HOSTNAME5 = p.getProperty("HOSTNAME5");
			//[ LOG ]
			LOGFILENAME = p.getProperty("LOGFILENAME");
			SHINLOGFILE = p.getProperty("SHINLOGFILE");
			//[ PORT ]
			PORT = ComUtil.Str2Int(p.getProperty("PORT"));
			RMIPORT = ComUtil.Str2Int(p.getProperty("RMIPORT"));

	    }
	    catch (IOException e) {
	    	LogManager.log("ConfigEnv���� ȯ����ý� ���ܹ߻�" );
	    }
	}
}
