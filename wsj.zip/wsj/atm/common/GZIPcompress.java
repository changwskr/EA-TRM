package wsj.atm.common;

import java.io.*;
import java.util.zip.*;

/**
 * <PRE>
 * Class    : CifGZIPcompress
 * Function :
 * Comment  : Log File Writing <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */


public class GZIPcompress {

	private String fileName;
	private String filePath;
	public  String curDir;

	public GZIPcompress(String fileName,String filePath)
	{
		this.fileName = fileName;
		this.filePath = filePath;
	}


	public boolean GZIPcompress()
	{
		try {

		    DataInputStream in = new DataInputStream(
		    		new BufferedInputStream(
		    				new FileInputStream(this.filePath+"\\"+this.fileName)));
		    PrintWriter out = new PrintWriter(
		    		new GZIPOutputStream(
		    				new FileOutputStream(this.filePath+"\\"+this.fileName+".gz")));

		    String strtmp;
		    while( (strtmp=in.readLine()) != null ) {
		    	out.println(ComUtil.ascToksc(strtmp));
		    }

		    in.close();
		    out.close();
		}
		catch(Exception ex) {
			System.out.println("GZIPcompress Exception :: " + ex.getMessage() );
			System.out.println("GZIPcompress FileName :: " + this.fileName );
			return false;
		}

		return true;
	}

	public boolean UGZIPrelease()
	{
		try {

	        BufferedReader in = new BufferedReader(
	        		new InputStreamReader(
	        				new GZIPInputStream(
	        					new FileInputStream(this.filePath+"\\"+this.fileName+".gz"))));

		    PrintWriter out = new PrintWriter(
		    		new FileOutputStream(this.filePath+"\\"+this.fileName+".new"));

		    String strtmp;
		    while( ( strtmp=in.readLine() ) != null ){
		      	out.println(strtmp);
		     }

		    in.close();
		    out.close();

		}
		catch(Exception ex) {
			System.out.println("GZIPcompress uException :: " + ex.getMessage() );
			System.out.println("GZIPcompress uFileName :: " + fileName );
			return false;
		}

		return true;

	}


	// @comment : ���ϸ��� �Է¹޾� gzip���� �����Ѵ�.
	// @param   : fileName = filePath + fileName
	//			  type -> c : compress
	//			  type -> u : release
	// @return  : <success : true>
	//			  <fail : false>
	//
	// fileName : C:\\MYTEST\\CHB\\SRC\\Falogght0.wsjang.2002


	public static final boolean GZIPcompress(char type,String fileName)
	{
		switch( type )
		{
			case 'c':

				try {

				    DataInputStream in = new DataInputStream(
				    		new BufferedInputStream( new FileInputStream(fileName)));
				    PrintWriter out = new PrintWriter(
				    		new GZIPOutputStream( new FileOutputStream(fileName+".gz")));

				    String strtmp;
				    while( (strtmp=in.readLine()) != null ) {
				    	out.println(ComUtil.ascToksc(strtmp));
				    }

				    in.close();
				    out.close();
				}
				catch(Exception ex) {
					System.out.println("GZIPcompress cException :: " + ex.getMessage() );
					System.out.println("GZIPcompress cFileName :: " + fileName );
					return false;
				}
				return true;

			case 'u':

				try {

			        BufferedReader in = new BufferedReader(
			        		new InputStreamReader(
			        				new GZIPInputStream(new FileInputStream(fileName+".gz"))));
				    //PrintWriter out = new PrintWriter( new FileOutputStream(fileName+".new"));
				    PrintWriter out = new PrintWriter( new FileOutputStream(fileName));

				    String strtmp;
				    while( ( strtmp=in.readLine() ) != null ){
				      	out.println(strtmp);
				     }

				    in.close();
				    out.close();

				}
				catch(Exception ex) {
					System.out.println("GZIPcompress uException :: " + ex.getMessage() );
					System.out.println("GZIPcompress uFileName :: " + fileName );
					return false;
				}
				return true;

			default :
				System.out.println("GZIPcompress tException :: " );
				System.out.println("GZIPcompress tFileName :: " + fileName );
				return false;
		}
	}





  public static void main(String[] args)
  throws IOException {

		GZIPcompress('c',".\\kk.txt");
		GZIPcompress('u',".\\kk.txt");
		GZIPcompress.GZIPcompress('c',"C:\\MYTEST\\CHB\\src\\����-������ Ver1.0\\FALOGGH1.wsjang.20020718");
		GZIPcompress.GZIPcompress('u',"C:\\MYTEST\\CHB\\src\\����-������ Ver1.0\\tmp\\FALOGGH1.wsjang.20020718");

  }

}  ///:~
