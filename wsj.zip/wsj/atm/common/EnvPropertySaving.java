package wsj.atm.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.common.ComUtil;
import wsj.atm.log.JLO;
import wsj.atm.packet.*;

public class EnvPropertySaving
{
  public Hashtable envh = new Hashtable();
  private String filename;

  public EnvPropertySaving(String filename) throws IOException {
    /*
    this.filename = UbbConfig.getInstance().GetEnvValue("LOGINATM")
                  + ComUtil.getLocalHostName()
                  + "."
                  + filename;
    */
    if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
      this.filename = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGINATM")
                    + ComUtil.getLocalHostName()
                    + "."
                    + filename;
    }
    else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
      this.filename = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","LOGINATM")
                    + ComUtil.getLocalHostName()
                    + "."
                    + filename;
    }
  }

  public void setCosesCommonDTO(IOBoundCDTO cdto){
    envh.put("bankCode",cdto.bankCode);
    envh.put("branchCode",cdto.branchCode);
    envh.put("gIPostBrCode",cdto.gIPostBrCode);
    envh.put("channelType",cdto.channelType);
    envh.put("userId",cdto.userId);
    envh.put("terminalId",cdto.terminalId);
    envh.put("terminalType",cdto.terminalType);
    envh.put("eventNo",cdto.eventNo);
    envh.put("nationCode",cdto.nationCode);
    envh.put("regionCode",cdto.regionCode);
    envh.put("timeZone",cdto.timeZone);
    envh.put("fxRateSeq",cdto.fxRateSeq);
    envh.put("xmlSeq",cdto.xmlSeq);
    envh.put("reqName",cdto.reqName);
    envh.put("trxDate",cdto.trxDate);
    envh.put("bizDate",cdto.bizDate);
    envh.put("trxInTime",cdto.trxInTime);
    envh.put("trxOutTime",cdto.trxOutTime);
    envh.put("trxNumber",cdto.trxNumber);
    envh.put("voucherNum",cdto.voucherNum);
    envh.put("refNum",cdto.refNum);
    envh.put("cifNum",cdto.cifNum);
    envh.put("baseCurrency",cdto.baseCurrency);
    return;
  }

  public void setIOBoundTel80004CDTO(IOBoundTel80004CDTO cdto)
  {
    envh.put("TellerNo",cdto.TellerNo);
    envh.put("TxDate",cdto.TxDate);
    envh.put("TellerStatus",cdto.TellerStatus);
    envh.put("Currency01",cdto.Currency01);
    envh.put("Amount01",cdto.Amount01);
    return;
  }

  public boolean loadingINI()
  {
    try
    {
      IOBoundCDTO cdto = new IOBoundCDTO();
      IOBoundTel80004CDTO tcdto = new IOBoundTel80004CDTO();

      Properties p = new Properties();
      p.load(new FileInputStream(filename));

      envh.put("bankCode",cdto.bankCode);
      envh.put("branchCode",cdto.branchCode);
      envh.put("gIPostBrCode",cdto.gIPostBrCode);
      envh.put("channelType",cdto.channelType);
      envh.put("userId",cdto.userId);
      envh.put("terminalId",cdto.terminalId);
      envh.put("terminalType",cdto.terminalType);
      envh.put("eventNo",cdto.eventNo);
      envh.put("nationCode",cdto.nationCode);
      envh.put("regionCode",cdto.regionCode);
      envh.put("timeZone",cdto.timeZone);
      envh.put("fxRateSeq",cdto.fxRateSeq);
      envh.put("xmlSeq",cdto.xmlSeq);
      envh.put("reqName",cdto.reqName);
      envh.put("trxDate",cdto.trxDate);
      envh.put("bizDate",cdto.bizDate);
      envh.put("trxInTime",cdto.trxInTime);
      envh.put("trxOutTime",cdto.trxOutTime);
      envh.put("trxNumber",cdto.trxNumber);
      envh.put("voucherNum",cdto.voucherNum);
      envh.put("refNum",cdto.refNum);
      envh.put("cifNum",cdto.cifNum);
      envh.put("baseCurrency",cdto.baseCurrency);
      envh.put("TellerNo",tcdto.TellerNo);
      envh.put("TxDate",tcdto.TxDate);
      envh.put("TellerStatus",tcdto.TellerStatus);
      envh.put("Currency01",tcdto.Currency01);
      envh.put("Amount01",tcdto.Amount01);
      envh.put("SijaeOpenFlag","*"); // 10:OPEN , 20:CLOSE

      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        String val = p.getProperty(key);
        envh.put(key,val);
      }

      /*
      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        System.out.println(key+":"+envh.get(key));
      }
      */

      return true;
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      return false;
    }
  }

  public void setSijaeOpenFlag(String flag)
  {
    this.envh.put("SijaeOpenFlag",flag);
  }
  /**
    saving config.ini
    @return boolean ���� ���� ����
    */
  public boolean savingINI()
  {
    Properties p = null;
    FileOutputStream fos = null;
    try
    {
      p = new Properties();
      fos = new FileOutputStream(filename);
      for( Enumeration enum = envh.keys(); enum.hasMoreElements(); )
      {
        String key = enum.nextElement().toString();
        String val = (String)envh.get(key);
        p.setProperty(key, val);
      }
      p.store(fos, "LOGIN/SIJAEOPEN REFERENCE [ConfigReference]");
      fos.close();
      return true;
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      try{
        fos.close();
      }catch(Exception ex){}
      return false;
    }
  }

  public static void main(String args[] ) throws IOException{
    EnvPropertySaving senv = new EnvPropertySaving("ATM0238001");
    IOBoundCDTO kk = new IOBoundCDTO();
    IOBoundTel80004CDTO kk1 = new IOBoundTel80004CDTO();

    kk.bankCode = "03";
    kk.bizDate = "20021210";
    senv.setCosesCommonDTO(kk);
    senv.setIOBoundTel80004CDTO(kk1);
    senv.savingINI();
    senv.loadingINI();
  }
}

