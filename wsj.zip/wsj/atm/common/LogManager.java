package wsj.atm.common;

import java.io.*;
import java.util.*;

/**
 * <PRE>
 * Class    : CifLogManager
 * Function :
 * Comment  : Log File Writing <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */


public class LogManager {


	public static String HOSTNAME=ComUtil.GetHostName();
	public static ConfigEnv CE = new ConfigEnv();


	/**
	  * �� �޼ҵ�� ������ ��Ʈ���� �α����Ͽ� ����Ѵ�.
	  * The file is created, if it does not exist.
	  * @param contentToWrite java.lang.String
	  * @return boolean - true, if the append is successful. false, otherwise.
	  */
	public static boolean log(String contentToWrite,Thread thr) {
		String LOGFILENAME = CE.LOGFILENAME + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
	      boolean result=true;

	      try{
	        contentToWrite = ComUtil.getCurrentDate() + "-" + thr.currentThread().getName() +"|"+ contentToWrite + "\n";
	        DataOutputStream dos=new DataOutputStream(new FileOutputStream(LOGFILENAME,true));
	        //dos.writeBytes(contentToWrite);
	        dos.writeUTF(contentToWrite);
	        dos.close();
	      }catch(Exception e){
	        result=false;
	      }
	      return result;
	}

	public static boolean log(String contentToWrite) {
	    boolean result=true;

		String LOGFILENAME = CE.LOGFILENAME + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
   		try {
			contentToWrite = ComUtil.getCurrentDate() + "-" + HOSTNAME+ "|" + contentToWrite + "\n";
		   	FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
		   	PrintStream ps = new PrintStream(fos);
		   	ps.print(contentToWrite);
		   	ps.close();
	   	}catch(Exception e){
	   		e.printStackTrace();
	   		System.out.println("appendFileWrite Exception");
	   		return false;
	   	}

		return true;

	}


	public static boolean log(String thr, String contentToWrite) {
	    boolean result=true;

		String LOGFILENAME = CE.LOGFILENAME + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
   		try {
			contentToWrite = ComUtil.getCurrentDate() + "-" + HOSTNAME+ "|" + thr +"|" + contentToWrite + "\n";
		   	FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
		   	PrintStream ps = new PrintStream(fos);
		   	ps.print(contentToWrite);
		   	ps.close();
	   	}catch(Exception e){
	   		e.printStackTrace();
	   		System.out.println("appendFileWrite Exception");
	   		return false;
	   	}

		return true;

	}

	public static boolean shinlog(String contentToWrite) {
	    boolean result=true;

		String LOGFILENAME = CE.SHINLOGFILE + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
   		try {
			contentToWrite = ComUtil.getCurrentDate() + "-" + HOSTNAME+ "|" +"|" + contentToWrite + "\n";
		   	FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
		   	PrintStream ps = new PrintStream(fos);
		   	ps.print(contentToWrite);
		   	ps.close();
	   	}catch(Exception e){
	   		e.printStackTrace();
	   		System.out.println("appendFileWrite Exception");
	   		return false;
	   	}

		return true;

	}



	public static boolean log2(String contentToWrite) {
	    boolean result=true;

		String LOGFILENAME = CE.LOGFILENAME + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();

   		try {
			contentToWrite = ComUtil.getCurrentDate() + "-"
						+ HOSTNAME+ "|"
						+ Thread.currentThread().getName() +"|"
						+ contentToWrite + "\n";

		   	FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
		   	PrintStream ps = new PrintStream(fos);
		   	ps.print(contentToWrite);
		   	ps.close();

	   	}catch(Exception e){
	   		e.printStackTrace();
	   		System.out.println("appendFileWrite Exception");
	   		return false;
	   	}

		return true;
	}


	public static boolean err(String contentToWrite) {
	    boolean result=true;

		String LOGFILENAME = CE.LOGFILENAME + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();

   		try {
			contentToWrite = ComUtil.getCurrentDate() + "-"
						+ HOSTNAME+ "|"
						+ Thread.currentThread().getName() +"|"
						+ contentToWrite + "\n";

		   	FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
		   	PrintStream ps = new PrintStream(fos);
		   	ps.print(contentToWrite);
		   	ps.close();

	   	}catch(Exception e){
	   		e.printStackTrace();
	   		System.out.println("appendFileWrite Exception");
	   		return false;
	   	}

		return true;
	}


}
