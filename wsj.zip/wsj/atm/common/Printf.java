package wsj.atm.common;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.text.MessageFormat;
import java.util.Date;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.IOException;

public class Printf {
  MessageFormat format;

  public Printf() {
    format = new MessageFormat("At {1,time} on {1,date}, inputed string \"{0}\"");
  }

  public static void main(String[] args) {
    Printf printf1 = new Printf();
  }
}