package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.math.BigDecimal;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.InquiryConditionCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import com.chb.coses.deposit.transfer.AccountPageCDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import com.chb.coses.deposit.transfer.TransactionHistoryPageItemsCDTO;

// ��� ��� �ŷ�
public class IOBoundDep80008CDTO {

  //atm-swb-packet
  public String  AccountNumber;
  public String  BankCode;
  public String  atmTransactionNo;
  public String  transactionDate;
  public String  approveStatus;
  public String  approveUserId;
  public String  txAmount;

  //transactionNo
  public String transactionNo;

  public static final int AccountNumber_LEN=11;
  public static final int BankCode_LEN=2;
  public static final int atmTransactionNo_LEN=20;
  public static final int transactionDate_LEN=8;
  public static final int approveStatus_LEN=2;
  public static final int approveUserId_LEN=10;
  public static final int txAmount_LEN=17;

  public IOBoundDep80008CDTO() {
    ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN );
    ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    ComUtil.SpaceToStr(this.atmTransactionNo,this.atmTransactionNo_LEN );
    ComUtil.SpaceToStr(this.transactionDate,this.transactionDate_LEN );
    ComUtil.SpaceToStr(this.approveStatus,this.approveStatus_LEN );
    ComUtil.SpaceToStr(this.approveUserId,this.approveUserId_LEN );
    ComUtil.SpaceToStr(this.txAmount,this.txAmount_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN )
        + ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN )
        + ComUtil.SpaceToStr(this.atmTransactionNo,this.atmTransactionNo_LEN )
        + ComUtil.SpaceToStr(this.transactionDate,this.transactionDate_LEN )
        + ComUtil.SpaceToStr(this.approveStatus,this.approveStatus_LEN )
        + ComUtil.SpaceToStr(this.approveUserId,this.approveUserId_LEN )
        + ComUtil.SpaceToStr(this.txAmount,this.txAmount_LEN );

  }
  public boolean setIOBoundDep80008CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = this.AccountNumber
              = packetinfo.substring(curp,IOBoundDep80008CDTO.AccountNumber_LEN);
      JLO.getInstance().printf(1,"AccountNumber:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.AccountNumber_LEN;
      dumytmp = this.BankCode
              = packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.BankCode_LEN));
      JLO.getInstance().printf(1,"BANKCODE:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.BankCode_LEN;
      dumytmp = this.atmTransactionNo
              = packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.atmTransactionNo_LEN));
      JLO.getInstance().printf(1,"atmtrxno:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.atmTransactionNo_LEN;
      dumytmp = this.transactionDate
              = packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.transactionDate_LEN));
      JLO.getInstance().printf(1,"transactionDate:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.transactionDate_LEN;
      dumytmp=this.approveStatus
             =packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.approveStatus_LEN));
      JLO.getInstance().printf(1,"approveStatus:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.approveStatus_LEN;
      dumytmp=this.approveUserId
             =packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.approveUserId_LEN));
      JLO.getInstance().printf(1,"approveUserId:["+dumytmp+"]");

      curp += IOBoundDep80008CDTO.approveUserId_LEN;
      dumytmp=this.txAmount
             =packetinfo.substring(curp,(curp+IOBoundDep80008CDTO.txAmount_LEN));
      JLO.getInstance().printf(1,"txAmount:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public void IOBoundDep80008CDTOInfo(){
    ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN );
    ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    ComUtil.SpaceToStr(this.atmTransactionNo,this.atmTransactionNo_LEN );
    ComUtil.SpaceToStr(this.transactionDate,this.transactionDate_LEN );
    ComUtil.SpaceToStr(this.approveStatus,this.approveStatus_LEN );
    ComUtil.SpaceToStr(this.approveUserId,this.approveUserId_LEN );
  }

  public synchronized String getTransactionNo(CosesCommonDTO cosesdto)
  {
    InquiryConditionCDTO icdto = null;
    try{
      icdto = new InquiryConditionCDTO();
      icdto.setAccountNumber(this.AccountNumber);
      icdto.setBankCode(this.BankCode);
      icdto.setToAmount(new BigDecimal(txAmount));
      icdto.setPageNumber(1);
      icdto.setLinePerPage(25);
      icdto.setAtmSeqNo(this.atmTransactionNo);

      JLO.getInstance().printf(1,"^_^ get for cancel deposit, start to get 'deposit-pageListTransactionNo' ");
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-pageListTransactionNo",
                         cosesdto,icdto);
      if( outbound.errcode.equals ("IZZ000") ){
        AccountPageCDTO result = (AccountPageCDTO)outbound.getParameter();
        if( result.size()== 0 ){
          JLO.getInstance().printf(10,"^_^ Don't get Transaction Number(1) result.size==0 , end [deposit-pageListTransactionNo]");
          JLO.getInstance().printf(10,"AccountPageCDTO : " + result.toString() );
          return "0000000000000000";
        }
        else{
          TransactionHistoryPageItemsCDTO dto = null;
          Iterator iterator = result.iterator();
          while(iterator.hasNext())
          {
            dto = (TransactionHistoryPageItemsCDTO)iterator.next();
            JLO.getInstance().printf(1,"^_^ end = Transaction No ???[" + dto.getTransactionNo() +"]");
          }
          return dto.getTransactionNo();
        }
      }
      else{
        JLO.getInstance().printf(10,"^_^ Don't get Transaction Number(2) , end [deposit-pageListTransactionNo]");
        return "0000000000000000";
      }
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      return "0000000000000000";
    }
  }
  public static void main(String[] args) {
    IOBoundDep80008CDTO IOBoundDep80008CDTO1 = new IOBoundDep80008CDTO();
  }
}