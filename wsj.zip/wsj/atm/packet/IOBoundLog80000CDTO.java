package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.packet.IOBoundProtoType;
import wsj.atm.common.ComUtil;
import wsj.atm.log.JLO;
import wsj.atm.bound.*;

public class IOBoundLog80000CDTO implements Serializable,Cloneable {

  //�Էº�
  public String  bankcode;
  public String  tellerid;
  public String  password;
  public String  workingkey;

  //��º�

  public static final int bankcode_LEN=2;
  public static final int tellerid_LEN=10;
  public static final int password_LEN=8;
  public static final int workingkey_LEN=16;

  public IOBoundLog80000CDTO() {
    this.bankcode = ComUtil.SpaceToStr(this.bankcode,this.bankcode_LEN );
    this.tellerid = ComUtil.SpaceToStr(this.tellerid,this.tellerid_LEN );
    this.password = ComUtil.SpaceToStr(this.password,this.password_LEN );
    this.workingkey = ComUtil.SpaceToStr(this.workingkey,this.workingkey_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.bankcode,this.bankcode_LEN )
        + ComUtil.SpaceToStr(this.tellerid,this.tellerid_LEN )
        + ComUtil.SpaceToStr(this.password,this.password_LEN )
        + ComUtil.SpaceToStr(this.workingkey,this.workingkey_LEN );
  }

  public boolean setIOBoundLog80000CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      curp = 0;
      dumytmp = this.bankcode
              = packetinfo.substring(curp,IOBoundLog80000CDTO.bankcode_LEN);
      JLO.getInstance().printf(1,"bankcode:["+dumytmp+"]");

      curp += IOBoundLog80000CDTO.bankcode_LEN;
      dumytmp = this.tellerid
              = packetinfo.substring(curp,(curp+IOBoundLog80000CDTO.tellerid_LEN));
      JLO.getInstance().printf(1,"tellerid:["+dumytmp+"]");

      curp += IOBoundLog80000CDTO.tellerid_LEN;
      dumytmp = this.password
              = packetinfo.substring(curp,(curp+IOBoundLog80000CDTO.password_LEN));
      JLO.getInstance().printf(1,"Passwd:["+dumytmp+"]");

      curp += IOBoundLog80000CDTO.password_LEN;
      dumytmp = this.workingkey
              = packetinfo.substring(curp,(curp+IOBoundLog80000CDTO.workingkey_LEN));
      JLO.getInstance().printf(1,"workingkey:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public IOBoundCDTO getIOBoundCDTO(BoundArea bound) throws IOException{
    IOBoundCDTO cdto = null;
    try
    {
      bound.setFormat();

      cdto = new IOBoundCDTO();
      cdto.terminalId = bound.cdto.getTerminalID();
      cdto.terminalType = bound.cdto.getTerminalType();
      //������� �ʴ´�
      //cdto.xmlSeq = bound.cdto.getXmlSeq();
      cdto.bankCode = bound.cdto.getBankCode();
      cdto.branchCode = bound.cdto.getBranchCode();
      cdto.gIPostBrCode = bound.cdto.getGlPostBranchCode();
      cdto.channelType = bound.cdto.getChannelType();
      cdto.userId = bound.cdto.getUserID();
      cdto.nationCode = bound.cdto.getNation();
      cdto.regionCode = bound.cdto.getRegionCode();
      cdto.timeZone = bound.cdto.getTimeZone();
      cdto.fxRateSeq = "FX";
      cdto.reqName = bound.cdto.getReqName();
      cdto.trxDate = bound.cdto.getSystemDate();
      cdto.bizDate = bound.cdto.getBusinessDate();
      cdto.trxInTime = bound.cdto.getSystemInTime();
      cdto.trxOutTime = bound.cdto.getSystemOutTime();
      cdto.trxNumber = bound.cdto.getTransactionNo();
    }
    catch(Exception ex){
      ex.printStackTrace();
      throw new IOException();
    }
    return cdto;
  }

  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }

}