package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;

import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;


public class IOBoundDep80003CDTO {

  public String  AccountNumber;
  public String  BankCode;
  public String  PbKind;
  public String  TrxCcyu;
  public String  Amount;
  public String  TransactionAmount;
  public String  TrxStatus;
  public String  FeeWaivFlag;
  public String  ApproveStatus;
  public String  TxCode;
  public String  SecurityNo;
  public String  AtmSeqNo;
  public String  CashCardNo;
  public String  TargetAccountNo;
  public String  TransactionNo;
  public String  TD5;
  public String  TD6;
  public String  TD7;
  public String  TD8;
  public String  TD9;
  public String  TD10;
  public String  FeeAmount;
  public String  ColleceedBalance;

  public static final int AccountNumber_LEN=11;
  public static final int BankCode_LEN=2;
  public static final int PbKind_LEN=1;
  public static final int TrxCcyu_LEN=3;
  public static final int Amount_LEN=17;
  public static final int TransactionAmount_LEN=17;
  public static final int TrxStatus_LEN=2;
  public static final int FeeWaivFlag_LEN=1;
  public static final int ApproveStatus_LEN=2;
  public static final int TxCode_LEN=4;
  public static final int SecurityNo_LEN=16;
  public static final int AtmSeqNo_LEN=20;
  public static final int CashCardNo_LEN=16;
  public static final int TargetAccountNo_LEN=16;
  public static final int TransactionNo_LEN=16;
  //////////////////////////////////////////////////////////////
// ���� 6�ڸ��� �������
//////////////////////////////////////////////////////////////

  public static final int RealSecurityNo_LEN=6;

  public static final int TD5_LEN=20;
  public static final int TD6_LEN=20;
  public static final int TD7_LEN=20;
  public static final int TD8_LEN=20;
  public static final int TD9_LEN=20;
  public static final int TD10_LEN=20;
  public static final int FeeAmount_LEN=17;
  public static final int ColleceedBalance_LEN=17;

  public IOBoundDep80003CDTO() {
    ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN );
    ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    ComUtil.SpaceToStr(this.PbKind,this.PbKind_LEN );
    ComUtil.SpaceToStr(this.TrxCcyu,this.TrxCcyu_LEN );
    ComUtil.SpaceToStr(this.Amount,this.Amount_LEN );
    ComUtil.SpaceToStr(this.TransactionAmount,this.TransactionAmount_LEN );
    ComUtil.SpaceToStr(this.TrxStatus,this.TrxStatus_LEN );
    ComUtil.SpaceToStr(this.FeeWaivFlag,this.FeeWaivFlag_LEN );
    ComUtil.SpaceToStr(this.ApproveStatus,this.ApproveStatus_LEN );
    ComUtil.SpaceToStr(this.TxCode,this.TxCode_LEN );
    ComUtil.SpaceToStr(this.SecurityNo,this.SecurityNo_LEN );
    ComUtil.SpaceToStr(this.AtmSeqNo,this.AtmSeqNo_LEN );
    ComUtil.SpaceToStr(this.CashCardNo,this.CashCardNo_LEN );
    ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN );
    ComUtil.SpaceToStr(this.TransactionNo,this.TransactionNo_LEN );
    ComUtil.SpaceToStr(this.TD5,this.TD5_LEN );
    ComUtil.SpaceToStr(this.TD6,this.TD5_LEN );
    ComUtil.SpaceToStr(this.TD7,this.TD7_LEN );
    ComUtil.SpaceToStr(this.TD8,this.TD8_LEN );
    ComUtil.SpaceToStr(this.TD9,this.TD9_LEN );
    ComUtil.SpaceToStr(this.TD10,this.TD10_LEN );
    ComUtil.SpaceToStr(this.FeeAmount,this.FeeAmount_LEN );
    ComUtil.SpaceToStr(this.ColleceedBalance,this.ColleceedBalance_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN )
    + ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN )
    + ComUtil.SpaceToStr(this.PbKind,this.PbKind_LEN )
    + ComUtil.SpaceToStr(this.TrxCcyu,this.TrxCcyu_LEN )
    + ComUtil.SpaceToStr(this.Amount,this.Amount_LEN )
    + ComUtil.SpaceToStr(this.TransactionAmount,this.TransactionAmount_LEN )
    + ComUtil.SpaceToStr(this.TrxStatus,this.TrxStatus_LEN )
    + ComUtil.SpaceToStr(this.FeeWaivFlag,this.FeeWaivFlag_LEN )
    + ComUtil.SpaceToStr(this.ApproveStatus,this.ApproveStatus_LEN )
    + ComUtil.SpaceToStr(this.TxCode,this.TxCode_LEN )
    + ComUtil.SpaceToStr(this.SecurityNo,this.SecurityNo_LEN )
    + ComUtil.SpaceToStr(this.AtmSeqNo,this.AtmSeqNo_LEN )
    + ComUtil.SpaceToStr(this.CashCardNo,this.CashCardNo_LEN )
    + ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN )
    + ComUtil.SpaceToStr(this.TransactionNo,this.TransactionNo_LEN )
    + ComUtil.SpaceToStr(this.TD5,this.TD5_LEN )
    + ComUtil.SpaceToStr(this.TD6,this.TD5_LEN )
    + ComUtil.SpaceToStr(this.TD7,this.TD7_LEN )
    + ComUtil.SpaceToStr(this.TD8,this.TD8_LEN )
    + ComUtil.SpaceToStr(this.TD9,this.TD9_LEN )
    + ComUtil.SpaceToStr(this.TD10,this.TD10_LEN )
    + ComUtil.SpaceToStr(this.FeeAmount,this.FeeAmount_LEN )
    + ComUtil.SpaceToStr(this.ColleceedBalance,this.ColleceedBalance_LEN );

  }
  public void toPrint(){
    JLO.getInstance().printf(4,
                             "{AccountNumber["+AccountNumber    + "]"
                             + "BankCode["+BankCode         + "]"
                             + "PbKind["+PbKind           + "]"
                             + "TrxCcyu["+TrxCcyu          + "]"
                             + "Amount["+Amount           + "]"
                             + "TransactionAmount["+TransactionAmount+ "]"
                             + "TrxStatus["+TrxStatus        + "]"
                             + "FeeWaivFlag["+FeeWaivFlag      + "]"
                             + "ApproveStatus["+ApproveStatus    + "]"
                             + "TxCode["+TxCode           + "]"
                             //+ "SecurityNo["+SecurityNo       + "]"
                             + "SecurityNo[******]"
                             + "AtmSeqNo["+AtmSeqNo         + "]"
                             + "CashCardNo["+CashCardNo       + "]"
                             + "TargetAccountNo["+TargetAccountNo  + "]"
                             + "TransactionNo["+TransactionNo    + "]"
                             + "TD5["+TD5              + "]"
                             + "TD6["+TD6              + "]"
                             + "TD7["+TD7              + "]"
                             + "TD8["+TD8              + "]"
                             + "TD9["+TD9              + "]"
                             + "TD10["+TD10             + "]"
                             + "FeeAmount["+FeeAmount        + "]"
                             + "ColleceedBalance ["+ColleceedBalance + "] }");
  }

  public boolean setIOBoundDep80003CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = this.AccountNumber
              = packetinfo.substring(curp,IOBoundDep80003CDTO.AccountNumber_LEN);
      JLO.getInstance().printf(1,"AccountNumber:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.AccountNumber_LEN;
      dumytmp = this.BankCode
              = packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.BankCode_LEN));
      JLO.getInstance().printf(1,"BANKCODE:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.BankCode_LEN;
      dumytmp = this.PbKind
              = packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.PbKind_LEN));
      JLO.getInstance().printf(1,"PBKIND:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.PbKind_LEN;
      dumytmp = this.TrxCcyu
              = packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TrxCcyu_LEN));
      JLO.getInstance().printf(1,"TrxCcyu:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TrxCcyu_LEN;
      dumytmp=this.Amount
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.Amount_LEN;
      dumytmp=this.TransactionAmount
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TransactionAmount_LEN));
      JLO.getInstance().printf(1,"TransactionAmount:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TransactionAmount_LEN;
      dumytmp=this.TrxStatus
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TrxStatus_LEN));
      JLO.getInstance().printf(1,"TrxStatus:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TrxStatus_LEN;
      dumytmp=this.FeeWaivFlag
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.FeeWaivFlag_LEN));
      JLO.getInstance().printf(1,"FeeWaivFlag:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.FeeWaivFlag_LEN;
      dumytmp=this.ApproveStatus
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.ApproveStatus_LEN));
      JLO.getInstance().printf(1,"ApproveStatus:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.ApproveStatus_LEN;
      dumytmp=this.TxCode
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TxCode_LEN));
      JLO.getInstance().printf(1,"TxCode:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TxCode_LEN;
      dumytmp=this.SecurityNo
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.SecurityNo_LEN));
      JLO.getInstance().printf(1,"SecurityNo:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.SecurityNo_LEN;
      dumytmp=this.AtmSeqNo
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.AtmSeqNo_LEN));
      JLO.getInstance().printf(1,"AtmSeqNo:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.AtmSeqNo_LEN;
      dumytmp=this.CashCardNo
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.CashCardNo_LEN));
      JLO.getInstance().printf(1,"CashCardNo:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.CashCardNo_LEN;
      dumytmp=this.TargetAccountNo
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TargetAccountNo_LEN));
      JLO.getInstance().printf(1,"TargetAccountNo:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TargetAccountNo_LEN;
      dumytmp=this.TransactionNo
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TransactionNo_LEN));
      JLO.getInstance().printf(1,"TransactionNo:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TransactionNo_LEN;
      dumytmp=this.TD5
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD5_LEN));
      JLO.getInstance().printf(1,"TD5:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD5_LEN;
      dumytmp=this.TD6
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD6_LEN));
      JLO.getInstance().printf(1,"TD6:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD6_LEN;
      dumytmp=this.TD7
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD7_LEN));
      JLO.getInstance().printf(1,"TD7:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD7_LEN;
      dumytmp=this.TD8
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD8_LEN));
      JLO.getInstance().printf(1,"TD8:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD8_LEN;
      dumytmp=this.TD9
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD9_LEN));
      JLO.getInstance().printf(1,"TD9:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD9_LEN;
      dumytmp=this.TD10
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.TD10_LEN));
      JLO.getInstance().printf(1,"TD10:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.TD10_LEN;
      dumytmp=this.FeeAmount
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.FeeAmount_LEN));
      JLO.getInstance().printf(1,"FeeAmount:["+dumytmp+"]");

      curp += IOBoundDep80003CDTO.FeeAmount_LEN;
      dumytmp=this.ColleceedBalance
             =packetinfo.substring(curp,(curp+IOBoundDep80003CDTO.ColleceedBalance_LEN));
      JLO.getInstance().printf(1,"ColleceedBalance:["+dumytmp+"]");
    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public void IOBoundDep80003CDTOInfo(){
    ComUtil.SpaceToStr(this.AccountNumber,this.AccountNumber_LEN );
    ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    ComUtil.SpaceToStr(this.PbKind,this.PbKind_LEN );
    ComUtil.SpaceToStr(this.TrxCcyu,this.TrxCcyu_LEN );
    ComUtil.SpaceToStr(this.Amount,this.Amount_LEN );
    ComUtil.SpaceToStr(this.TransactionAmount,this.TransactionAmount_LEN );
    ComUtil.SpaceToStr(this.TrxStatus,this.TrxStatus_LEN );
    ComUtil.SpaceToStr(this.FeeWaivFlag,this.FeeWaivFlag_LEN );
    ComUtil.SpaceToStr(this.ApproveStatus,this.ApproveStatus_LEN );
    ComUtil.SpaceToStr(this.TxCode,this.TxCode_LEN );
    ComUtil.SpaceToStr(this.SecurityNo,this.SecurityNo_LEN );
    ComUtil.SpaceToStr(this.AtmSeqNo,this.AtmSeqNo_LEN );
    ComUtil.SpaceToStr(this.CashCardNo,this.CashCardNo_LEN );
    ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN );
    ComUtil.SpaceToStr(this.TransactionNo,this.TransactionNo_LEN );
    ComUtil.SpaceToStr(this.TD5,this.TD5_LEN );
    ComUtil.SpaceToStr(this.TD6,this.TD5_LEN );
    ComUtil.SpaceToStr(this.TD7,this.TD7_LEN );
    ComUtil.SpaceToStr(this.TD8,this.TD8_LEN );
    ComUtil.SpaceToStr(this.TD9,this.TD9_LEN );
    ComUtil.SpaceToStr(this.TD10,this.TD10_LEN );
    ComUtil.SpaceToStr(this.FeeAmount,this.FeeAmount_LEN );
    ComUtil.SpaceToStr(this.ColleceedBalance,this.ColleceedBalance_LEN );
  }

  public void setTransactionNo(String bizDate,CosesCommonDTO cdto){
    String txNo =
        TCPCallEJB.getTransactionNo( this.AccountNumber,
        this.BankCode,
        bizDate,
        this.Amount,
        cdto );
    if( txNo.equals("0000000000000000") ){
      this.TransactionNo = txNo;
    }
    else
      this.TransactionNo = txNo;
  }
  public void setTransactionNo(String trxNo){
    if( trxNo != null ){
       this.TransactionNo = trxNo;
    }
  }
 public static void main(String[] args) {
    IOBoundDep80003CDTO IOBoundDep80003CDTO1 = new IOBoundDep80003CDTO();
  }
}

