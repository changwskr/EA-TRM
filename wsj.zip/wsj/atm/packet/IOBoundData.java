package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class IOBoundData implements Serializable{
  public String sLength; /* sIndata�� ���� */
  public String sBoundData;
  public IOBoundData() {
  }
}