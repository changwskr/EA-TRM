package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;

import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;


public class IOBoundDep80011CDTO {
  public String  TargetAccountNo;
  public String  TargetCustName;
  public String  TD1;
  public String  TD2;
  public String  TD3;
  public String  TD4;

  public static final int TargetAccountNo_LEN=16;
  public static final int TargetCustName_LEN=50;
  public static final int TD1_LEN=20;
  public static final int TD2_LEN=20;
  public static final int TD3_LEN=20;
  public static final int TD4_LEN=20;

  public IOBoundDep80011CDTO() {
    TargetAccountNo=ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN );
    TargetCustName=ComUtil.SpaceToStr(this.TargetCustName,this.TargetCustName_LEN );
    TD1=ComUtil.SpaceToStr(this.TD1,this.TD1_LEN );
    TD2=ComUtil.SpaceToStr(this.TD2,this.TD2_LEN );
    TD3=ComUtil.SpaceToStr(this.TD1,this.TD3_LEN );
    TD4=ComUtil.SpaceToStr(this.TD2,this.TD4_LEN );
  }

  public String toString(){
    return  ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN )
        + ComUtil.SpaceToStr(this.TargetCustName,this.TargetCustName_LEN )
        + ComUtil.SpaceToStr(this.TD1,this.TD1_LEN )
        + ComUtil.SpaceToStr(this.TD2,this.TD2_LEN )
        + ComUtil.SpaceToStr(this.TD3,this.TD3_LEN )
        + ComUtil.SpaceToStr(this.TD4,this.TD4_LEN );

  }

  public void toPrint(){
    JLO.getInstance().printf(4,
                             "{TargetAccountNo["+TargetAccountNo+ "]"
                             + "TargetCustName["+TargetCustName        + "]"
                             + "TD1["+TD1              + "]"
                             + "TD2["+TD2              + "]"
                             + "TD3["+TD3              + "]"
                             + "TD4["+TD4              + "]"
                             + "] }");
  }

  public boolean setIOBoundDep80011CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;

      dumytmp=this.TargetAccountNo
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TargetAccountNo_LEN));
      JLO.getInstance().printf(1,"TargetAccountNo:["+dumytmp+"]");
      curp += IOBoundDep80011CDTO.TargetAccountNo_LEN;

      dumytmp=this.TargetCustName
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TargetCustName_LEN));
      JLO.getInstance().printf(1,"TargetCustName:["+dumytmp+"]");
      curp += IOBoundDep80011CDTO.TargetCustName_LEN;

      dumytmp=this.TD1
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TD1_LEN));
      JLO.getInstance().printf(1,"TD1:["+dumytmp+"]");
      curp += IOBoundDep80011CDTO.TD1_LEN;

      dumytmp=this.TD2
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TD2_LEN));
      JLO.getInstance().printf(1,"TD2:["+dumytmp+"]");

      dumytmp=this.TD3
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TD3_LEN));
      JLO.getInstance().printf(1,"TD1:["+dumytmp+"]");
      curp += IOBoundDep80011CDTO.TD3_LEN;

      dumytmp=this.TD4
             =packetinfo.substring(curp,(curp+IOBoundDep80011CDTO.TD4_LEN));
      JLO.getInstance().printf(1,"TD4:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public void IOBoundDep80011CDTOInfo(){
    ComUtil.SpaceToStr(this.TargetAccountNo,this.TargetAccountNo_LEN );
    ComUtil.SpaceToStr(this.TargetCustName,this.TargetCustName_LEN );
    ComUtil.SpaceToStr(this.TD1,this.TD1_LEN );
    ComUtil.SpaceToStr(this.TD2,this.TD2_LEN );
    ComUtil.SpaceToStr(this.TD3,this.TD3_LEN );
    ComUtil.SpaceToStr(this.TD4,this.TD4_LEN );
  }

 public static void main(String[] args) {
    IOBoundDep80011CDTO IOBoundDep80011CDTO1 = new IOBoundDep80011CDTO();
  }
}

