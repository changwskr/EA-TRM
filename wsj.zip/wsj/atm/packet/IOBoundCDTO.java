package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;

public class IOBoundCDTO implements Serializable{
  //UI Layer ���� ���� �ʵ�
  public String bankCode ="**";
  public String branchCode = "****";
  public String gIPostBrCode = "****";
  public String channelType = "**";
  public String userId = "**********";
  public String terminalId = "************";
  public String terminalType = "******";
  //EventNO
  public String eventNo = "*****";
  public String nationCode = "**";
  public String regionCode = "**";
  public String timeZone = "**";
  public String fxRateSeq = "**";
  public String xmlSeq = "**";

  //Deleagtion Layer ���� ���� �ʵ�
  public String reqName = "**********";
  public String trxDate = "********";
  public String bizDate = "********";
  public String trxInTime = "********";
  public String trxOutTime = "********";

  public String trxNumber = "****************";

  //GLG
  public String voucherNum = "****************";

  //�� ���� thing
  public String refNum = "****************";
  public String cifNum = "****************";

  //�� ���� Facade
  public String baseCurrency = "***";
  public String atmSeqNo = "********************";

  /* ���� �ʵ�� Ʋ��
  fxRateSeq
  vouchernum
  refNum
  cifNum
  returnCode
  */

  public String getBankCode()
  {
    return bankCode;
  }
  public void setBankCode(String bankCode)
  {
    this.bankCode = bankCode;
  }
  public void setBranchCode(String branchCode)
  {
    this.branchCode = branchCode;
  }
  public String getBranchCode()
  {
    return branchCode;
  }
  public void setGIPostBrCode(String gIPostBrCode)
  {
    this.gIPostBrCode = gIPostBrCode;
  }
  public String getGIPostBrCode()
  {
    return gIPostBrCode;
  }
  public void setChannelType(String channelType)
  {
    this.channelType = channelType;
  }
  public String getChannelType()
  {
    return channelType;
  }
  public void setUserId(String userId)
  {
    this.userId = userId;
  }
  public String getUserId()
  {
    return userId;
  }
  public void setTerminalId(String terminalId)
  {
    this.terminalId = terminalId;
  }
  public String getTerminalId()
  {
    return terminalId;
  }
  public void setTerminalType(String terminalType)
  {
    this.terminalType = terminalType;
  }
  public String getTerminalType()
  {
    return terminalType;
  }
  public void setEventNo(String eventNo)
  {
    this.eventNo = eventNo;
  }
  public String getEventNo()
  {
    return eventNo;
  }
  public void setNationCode(String nationCode)
  {
    this.nationCode = nationCode;
  }
  public String getNationCode()
  {
    return nationCode;
  }
  public void setRegionCode(String regionCode)
  {
    this.regionCode = regionCode;
  }
  public String getRegionCode()
  {
    return regionCode;
  }
  public void setTimeZone(String timeZone)
  {
    this.timeZone = timeZone;
  }
  public String getTimeZone()
  {
    return timeZone;
  }
  public void setFxRateSeq(String fxRateSeq)
  {
    this.fxRateSeq = fxRateSeq;
  }
  public String getFxRateSeq()
  {
    return fxRateSeq;
  }
  public void setXmlSeq(String xmlSeq)
  {
    this.xmlSeq = xmlSeq;
  }
  public String getXmlSeq()
  {
    return xmlSeq;
  }
  public void setReqName(String reqName)
  {
    this.reqName = reqName;
  }
  public String getReqName()
  {
    return reqName;
  }
  public void setTrxDate(String trxDate)
  {
    this.trxDate = trxDate;
  }
  public String getTrxDate()
  {
    return trxDate;
  }
  public void setBizDate(String bizDate)
  {
    this.bizDate = bizDate;
  }
  public String getBizDate()
  {
    return bizDate;
  }
  public void setTrxInTime(String trxInTime)
  {
    this.trxInTime = trxInTime;
  }
  public String getTrxInTime()
  {
    return trxInTime;
  }
  public void setTrxOutTime(String trxOutTime)
  {
    this.trxOutTime = trxOutTime;
  }
  public String getTrxOutTime()
  {
    return trxOutTime;
  }
  public void setTrxNumber(String trxNumber)
  {
    if( trxNumber != null )
      this.trxNumber = trxNumber;
  }
  public String getTrxNumber()
  {
    return trxNumber;
  }
  public void setVoucherNum(String voucherNum)
  {
    this.voucherNum = voucherNum;
  }
  public String getVoucherNum()
  {
    return voucherNum;
  }
  public void setRefNum(String refNum)
  {
    this.refNum = refNum;
  }
  public String getRefNum()
  {
    return refNum;
  }
  public void setCifNum(String cifNum)
  {
    this.cifNum = cifNum;
  }
  public String getCifNum()
  {
    return cifNum;
  }
  public void setBaseCurrency(String baseCurrency)
  {
    this.baseCurrency = baseCurrency;
  }
  public String getBaseCurrency()
  {
    return baseCurrency;
  }
  ///////////////////////////////////////////////////////////////////
  public void setAtmSeqNo(String atmSeqNo)
  {
    this.atmSeqNo = atmSeqNo;
  }
  public String getAtmSeqNo()
  {
    return atmSeqNo;
  }
  ///////////////////////////////////////////////////////////////////
  public IOBoundCDTO getIOBoundCDTO(){
    return this;
  }
}
