package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.math.BigDecimal;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import com.chb.coses.wPilot.transfer.ItfaoinfoCDTO;


//--
//private String brnhostseq = Constants.BLANK;
//private String systemdate = Constants.BLANK ;
//private String intime = Constants.BLANK;
//private String outtime = Constants.BLANK;
//private String eventno = Constants.BLANK;
//private String bankcode = Constants.BLANK;
//private String branchcode = Constants.BLANK;
//private String bizdate = Constants.BLANK;
//private String userid = Constants.BLANK;
//private String errcode = Constants.BLANK;
//
public class IOBoundCOM10000CDTO {


  public String  brnhostseq;
  public String  systemdate;

  public String  intime;

  public String  outtime;
  public String  eventno;
  public String  bankcode;

  public String  branchcode;
  public String  bizdate;
  public String  userid;

  public String  errcode;

  public boolean tx_ok=false;
  public String  real_systemdate;
  public static final int brnhostseq_LEN=16;
  public static final int systemdate_LEN=16;

  public static final int outtime_LEN=11;
  public static final int intime_LEN=1;
  public static final int eventno_LEN=17;
  public static final int bankcode_LEN=3;

  public static final int branchcode_LEN=11;
  public static final int bizdate_LEN=17;
  public static final int userid_LEN=3;

  public static final int errcode_LEN=11;
  public static final int ternaryColleceedBalance_LEN=17;
  public static final int ternaryCurrency_LEN=3;

  public static final int dummy_1_LEN=20;
  public static final int dummy_2_LEN=20;

  public IOBoundCOM10000CDTO() {
    ComUtil.SpaceToStr(this.brnhostseq,this.brnhostseq_LEN );
    ComUtil.SpaceToStr(this.systemdate,this.systemdate_LEN );
    ComUtil.SpaceToStr(this.outtime,this.outtime_LEN );
    ComUtil.SpaceToStr(this.intime,this.intime_LEN );
    ComUtil.SpaceToStr(this.eventno,this.eventno_LEN );
    ComUtil.SpaceToStr(this.bankcode,this.bankcode_LEN );
    ComUtil.SpaceToStr(this.branchcode,this.branchcode_LEN );
    ComUtil.SpaceToStr(this.bizdate,this.bizdate_LEN );
    ComUtil.SpaceToStr(this.userid,this.userid_LEN );
    ComUtil.SpaceToStr(this.errcode,this.errcode_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.brnhostseq,this.brnhostseq_LEN )
        + ComUtil.SpaceToStr(this.systemdate,this.systemdate_LEN )
        + ComUtil.SpaceToStr(this.intime,this.intime_LEN )

        + ComUtil.SpaceToStr(this.outtime,this.outtime_LEN )
        + ComUtil.SpaceToStr(this.eventno,this.eventno_LEN )
        + ComUtil.SpaceToStr(this.bankcode,this.bankcode_LEN )

        + ComUtil.SpaceToStr(this.branchcode,this.branchcode_LEN )
        + ComUtil.SpaceToStr(this.bizdate,this.bizdate_LEN )
        + ComUtil.SpaceToStr(this.userid,this.userid_LEN )

        + ComUtil.SpaceToStr(this.errcode,this.errcode_LEN );
  }

  public boolean setIOBoundCOM10000CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      curp = 0;
      dumytmp = this.brnhostseq
              = packetinfo.substring(curp,IOBoundCOM10000CDTO.brnhostseq_LEN);
      JLO.getInstance().printf(1,"brnhostseq:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.brnhostseq_LEN;

      dumytmp = this.systemdate
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.systemdate_LEN));
      JLO.getInstance().printf(1,"systemdate:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.systemdate_LEN;

      //////////////////////////////////////////////////////////////////////////
      // real password
      //////////////////////////////////////////////////////////////////////////
      this.real_systemdate = ComUtil.CutSpaceToStr(this.systemdate,this.systemdate_LEN);
      //////////////////////////////////////////////////////////////////////////

      dumytmp = this.intime
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.intime_LEN));
      JLO.getInstance().printf(1,"intime:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.intime_LEN;

      dumytmp = this.outtime
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.outtime_LEN));
      JLO.getInstance().printf(1,"primaryAccount:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.outtime_LEN;

      dumytmp = this.eventno
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.eventno_LEN));
      JLO.getInstance().printf(1,"eventno:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.eventno_LEN;

      dumytmp = this.bankcode
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.bankcode_LEN));
      JLO.getInstance().printf(1,"bankcode:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.bankcode_LEN;

      dumytmp = this.branchcode
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.branchcode_LEN));
      JLO.getInstance().printf(1,"branchcode:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.branchcode_LEN;

      dumytmp = this.bizdate
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.bizdate_LEN));
      JLO.getInstance().printf(1,"bizdate:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.bizdate_LEN;

      dumytmp = this.userid
              = packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.userid_LEN));
      JLO.getInstance().printf(1,"userid:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.userid_LEN;

      dumytmp=this.errcode
             =packetinfo.substring(curp,(curp+IOBoundCOM10000CDTO.errcode_LEN));
      JLO.getInstance().printf(1,"errcode:["+dumytmp+"]");
      curp += IOBoundCOM10000CDTO.errcode_LEN;

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public void IOBoundCOM10000CDTOInfo(){
    ComUtil.SpaceToStr(this.brnhostseq,this.brnhostseq_LEN );
    ComUtil.SpaceToStr(this.systemdate,this.systemdate_LEN );
    ComUtil.SpaceToStr(this.intime,this.intime_LEN );
    ComUtil.SpaceToStr(this.outtime,this.outtime_LEN );
    ComUtil.SpaceToStr(this.eventno,this.eventno_LEN );
    ComUtil.SpaceToStr(this.bankcode,this.bankcode_LEN );
    ComUtil.SpaceToStr(this.branchcode,this.branchcode_LEN );
    ComUtil.SpaceToStr(this.bizdate,this.bizdate_LEN );
    ComUtil.SpaceToStr(this.userid,this.userid_LEN );
    ComUtil.SpaceToStr(this.errcode,this.errcode_LEN );
  }

  public ItfaoinfoCDTO getItfaoinfoInquery(CosesCommonDTO commondto)
  {
    ItfaoinfoCDTO icdto = null;
    ItfaoinfoCDTO result = null;
    try{
      icdto = new ItfaoinfoCDTO();
      icdto.setBankcode(commondto.getBankCode() );
      icdto.setBizdate("20030630");
      icdto.setBranchcode(commondto.getBranchCode() );
      icdto.setBrnhostseq("CN200306300003635");
      icdto.setErrcode("IZZ000");
      icdto.setEventno("80000");
      icdto.setIntime("13510044");
      icdto.setOuttime("13510271");
      icdto.setSystemdate("20030630");
      icdto.setUserid("ATM0239001");

      BoundArea outbound=(BoundArea)TCPCallEJB.getInstance().callEJB2("wPilot-inquiryItfaoinfo", commondto,icdto);
      if( outbound.errcode.equals ("IZZ000") ){
        result = (ItfaoinfoCDTO)outbound.getParameter();
      }
      else{
        JLO.getInstance().printf(1,"Fail to get ItfaoinfoPrimary");
        this.tx_ok = false;
        return null;
      }
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      this.tx_ok = false;
      return null;
    }
    this.tx_ok = true;
    return result;
  }

  public void settx_ok(boolean arg){
    this.tx_ok = arg;
  }

  public String getrealpassword(){
    return( ComUtil.CutSpaceToStr(this.systemdate,this.systemdate_LEN) );
  }



}



