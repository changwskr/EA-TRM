package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


public class IOBoundTxMgrCDTO {
  String key;
  String srttime;
  String endtime;
  String errcode;
  int interval;
  boolean stf_offset=false;
  boolean biz_offset=false;
  boolean etf_offset=false;

  public void init(){
    boolean stf_offset=false;
    boolean biz_offset=false;
    boolean etf_offset=false;
  }
}

