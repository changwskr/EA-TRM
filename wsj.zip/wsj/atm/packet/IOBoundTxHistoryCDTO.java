package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import java.sql.*;
import java.text.*;
import java.util.Date;
import wsj.atm.packet.IOBoundDep80001CDTO;
import wsj.atm.packet.IOBoundDep80002CDTO;
import wsj.atm.socket.ATMserver;
public class IOBoundTxHistoryCDTO {
  private String  eventNo;
  private String  atmTx_no;
  private String  inTx_data;
  private String  host_seq;
  private String  card_no;
  private IOBoundDep80001CDTO iobound80001;
  private IOBoundDep80002CDTO iobound80002;

  public IOBoundTxHistoryCDTO() {
  }

  public void seteventNo(String arg){ this.eventNo = arg;   }
  public void setatmTx_no(String arg){ this.atmTx_no = arg;  }
  public void setinTx_data(String arg){ this.inTx_data = arg;   }
  public void sethost_seq(String arg){ this.host_seq = arg;  }
  public void setcard_no(String arg){ this.card_no = arg;  }

  public String geteventNo( ){return(this.eventNo);   }
  public String getatmTx_no( ){ return(this.atmTx_no);  }
  public String getinTx_data( ){ return(this.inTx_data);   }
  public String gethost_seq( ){ return(this.host_seq);  }
  public String getcard_no( ){ return(this.card_no);  }

  public void toPrint(){
  }

  public static IOBoundTxHistoryCDTO GetIOBoundTxHistoryCDTO(String atmtxseq,String bizdate)
  {
    IOBoundTxHistoryCDTO info = null;
    Statement  stmt = null;
    ResultSet rs = null;
    Connection conn = null;
    try {
      conn = ATMserver.atmdbpool.getConnection();
      stmt = conn.createStatement();
      String sql = "SELECT eventno,atmseqno,data,brnhostseq " +
                   "FROM ITFAIINFO " +
                   "WHERE atmseqno = '" + atmtxseq + "' AND bizdate = '" + bizdate + "'";
      rs = stmt.executeQuery(sql);
      if (rs.next()) {
        info = new IOBoundTxHistoryCDTO();
        info.seteventNo(rs.getString(1));
        info.setatmTx_no(rs.getString(2));
        info.setinTx_data(rs.getString(3));
        info.sethost_seq(rs.getString(4));
      }
    }
    catch (Exception exception) {
      exception.printStackTrace();
      try{
        stmt.close();
        rs.close();
      } catch (Exception exception1) {
        exception1.printStackTrace();
      }
      ATMserver.atmdbpool.freeConnection(conn);
      return null;
    }
    try{
      stmt.close();
      rs.close();
    } catch (Exception exception) {
      exception.printStackTrace();
      ATMserver.atmdbpool.freeConnection(conn);
      return null;
    }
    ATMserver.atmdbpool.freeConnection(conn);

    if( info.geteventNo().equals("80001") ){
      info.iobound80001 = new IOBoundDep80001CDTO();
      info.iobound80001.setIOBoundDep80001CDTOParsing(info.inTx_data);
      info.setcard_no(info.iobound80001.CashCardNo);
    }
    else if( info.geteventNo().equals("80002") ){
      info.iobound80002 = new IOBoundDep80002CDTO();
      info.iobound80002.setIOBoundDep80002CDTOParsing(info.inTx_data);
      info.setcard_no(info.iobound80002.CashCardNo);
    }
    else {
      return null;
    }
    return info;
  }
}


