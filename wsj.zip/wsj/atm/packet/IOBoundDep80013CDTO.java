package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.math.BigDecimal;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import com.chb.coses.cashCard.transfer.CashCardCDTO;

public class IOBoundDep80013CDTO {

  public String  cardNumber;
  public String  passwordNo;

  public String  RecordCount;

  public String  primaryAccountNo;
  public String  primaryColleceedBalance;
  public String  primaryCurrency;

  public String  secondaryAccountNo;
  public String  secondaryColleceedBalance;
  public String  secondaryCurrency;

  public String  ternaryAccountNo;
  public String  ternaryColleceedBalance;
  public String  ternaryCurrency;

  public String  dummy_1;
  public String  dummy_2;

  public boolean tx_ok=false;
  public String  real_passwordNo;
  public static final int cardNumber_LEN=16;
  public static final int passwordNo_LEN=16;

  public static final int primaryAccountNo_LEN=11;
  public static final int RecordCount_LEN=1;
  public static final int primaryColleceedBalance_LEN=17;
  public static final int primaryCurrency_LEN=3;

  public static final int secondaryAccountNo_LEN=11;
  public static final int secondaryColleceedBalance_LEN=17;
  public static final int secondaryCurrency_LEN=3;

  public static final int ternaryAccountNo_LEN=11;
  public static final int ternaryColleceedBalance_LEN=17;
  public static final int ternaryCurrency_LEN=3;

  public static final int dummy_1_LEN=20;
  public static final int dummy_2_LEN=20;

  public IOBoundDep80013CDTO() {
    ComUtil.SpaceToStr(this.cardNumber,this.cardNumber_LEN );
    ComUtil.SpaceToStr(this.passwordNo,this.passwordNo_LEN );
    ComUtil.SpaceToStr(this.primaryAccountNo,this.primaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.RecordCount,this.RecordCount_LEN );
    ComUtil.SpaceToStr(this.primaryColleceedBalance,this.primaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.primaryCurrency,this.primaryCurrency_LEN );
    ComUtil.SpaceToStr(this.secondaryAccountNo,this.secondaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.secondaryColleceedBalance,this.secondaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.secondaryCurrency,this.secondaryCurrency_LEN );
    ComUtil.SpaceToStr(this.ternaryAccountNo,this.ternaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.ternaryColleceedBalance,this.ternaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.ternaryCurrency,this.ternaryCurrency_LEN );
    ComUtil.SpaceToStr(this.dummy_1,this.dummy_1_LEN );
    ComUtil.SpaceToStr(this.dummy_2,this.dummy_2_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.cardNumber,this.cardNumber_LEN )
        + ComUtil.SpaceToStr(this.passwordNo,this.passwordNo_LEN )
        + ComUtil.SpaceToStr(this.RecordCount,this.RecordCount_LEN )

        + ComUtil.SpaceToStr(this.primaryAccountNo,this.primaryAccountNo_LEN )
        + ComUtil.SpaceToStr(this.primaryColleceedBalance,this.primaryColleceedBalance_LEN )
        + ComUtil.SpaceToStr(this.primaryCurrency,this.primaryCurrency_LEN )

        + ComUtil.SpaceToStr(this.secondaryAccountNo,this.secondaryAccountNo_LEN )
        + ComUtil.SpaceToStr(this.secondaryColleceedBalance,this.secondaryColleceedBalance_LEN )
        + ComUtil.SpaceToStr(this.secondaryCurrency,this.secondaryCurrency_LEN )

        + ComUtil.SpaceToStr(this.ternaryAccountNo,this.ternaryAccountNo_LEN )
        + ComUtil.SpaceToStr(this.ternaryColleceedBalance,this.ternaryColleceedBalance_LEN )
        + ComUtil.SpaceToStr(this.ternaryCurrency,this.ternaryCurrency_LEN )

        + ComUtil.SpaceToStr(this.dummy_1,this.dummy_1_LEN )
        + ComUtil.SpaceToStr(this.dummy_2,this.dummy_2_LEN );
  }

  public boolean setIOBoundDep80013CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      curp = 0;
      dumytmp = this.cardNumber
              = packetinfo.substring(curp,IOBoundDep80013CDTO.cardNumber_LEN);
      JLO.getInstance().printf(1,"cardNumber:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.cardNumber_LEN;

      dumytmp = this.passwordNo
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.passwordNo_LEN));
      JLO.getInstance().printf(1,"passwordNo:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.passwordNo_LEN;

      //////////////////////////////////////////////////////////////////////////
      // real password
      //////////////////////////////////////////////////////////////////////////
      this.real_passwordNo = ComUtil.CutSpaceToStr(this.passwordNo,this.passwordNo_LEN);
      //////////////////////////////////////////////////////////////////////////

      dumytmp = this.RecordCount
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.RecordCount_LEN));
      JLO.getInstance().printf(1,"RecordCount:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.RecordCount_LEN;

      dumytmp = this.primaryAccountNo
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.primaryAccountNo_LEN));
      JLO.getInstance().printf(1,"primaryAccount:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.primaryAccountNo_LEN;

      dumytmp = this.primaryColleceedBalance
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.primaryColleceedBalance_LEN));
      JLO.getInstance().printf(1,"primaryColleceedBalance:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.primaryColleceedBalance_LEN;

      dumytmp = this.primaryCurrency
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.primaryCurrency_LEN));
      JLO.getInstance().printf(1,"primaryCurrency:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.primaryCurrency_LEN;

      dumytmp = this.secondaryAccountNo
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.secondaryAccountNo_LEN));
      JLO.getInstance().printf(1,"secondaryAccountNo:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.secondaryAccountNo_LEN;

      dumytmp = this.secondaryColleceedBalance
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.secondaryColleceedBalance_LEN));
      JLO.getInstance().printf(1,"secondaryColleceedBalance:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.secondaryColleceedBalance_LEN;

      dumytmp = this.secondaryCurrency
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.secondaryCurrency_LEN));
      JLO.getInstance().printf(1,"secondaryCurrency:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.secondaryCurrency_LEN;

      dumytmp=this.ternaryAccountNo
             =packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.ternaryAccountNo_LEN));
      JLO.getInstance().printf(1,"ternaryAccountNo:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.ternaryAccountNo_LEN;

      dumytmp = this.ternaryColleceedBalance
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.ternaryColleceedBalance_LEN));
      JLO.getInstance().printf(1,"ternaryColleceedBalance:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.ternaryColleceedBalance_LEN;

      dumytmp = this.ternaryCurrency
              = packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.ternaryCurrency_LEN));
      JLO.getInstance().printf(1,"ternaryCurrency:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.ternaryCurrency_LEN;

      dumytmp=this.dummy_1
             =packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.dummy_1_LEN));
      JLO.getInstance().printf(1,"dummy_1:["+dumytmp+"]");
      curp += IOBoundDep80013CDTO.dummy_1_LEN;
      dumytmp=this.dummy_2
             =packetinfo.substring(curp,(curp+IOBoundDep80013CDTO.dummy_2_LEN));
      JLO.getInstance().printf(1,"dummy_2:["+dumytmp+"]");
    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

  public void IOBoundDep80013CDTOInfo(){
    ComUtil.SpaceToStr(this.cardNumber,this.cardNumber_LEN );
    ComUtil.SpaceToStr(this.passwordNo,this.passwordNo_LEN );
    ComUtil.SpaceToStr(this.RecordCount,this.RecordCount_LEN );
    ComUtil.SpaceToStr(this.primaryAccountNo,this.primaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.primaryColleceedBalance,this.primaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.primaryCurrency,this.primaryCurrency_LEN );
    ComUtil.SpaceToStr(this.secondaryAccountNo,this.secondaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.secondaryColleceedBalance,this.secondaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.secondaryCurrency,this.secondaryCurrency_LEN );
    ComUtil.SpaceToStr(this.ternaryAccountNo,this.ternaryAccountNo_LEN );
    ComUtil.SpaceToStr(this.ternaryColleceedBalance,this.ternaryColleceedBalance_LEN );
    ComUtil.SpaceToStr(this.ternaryCurrency,this.ternaryCurrency_LEN );
    ComUtil.SpaceToStr(this.dummy_1,this.dummy_1_LEN );
    ComUtil.SpaceToStr(this.dummy_2,this.dummy_2_LEN );
  }

  public CashCardCDTO getCashCardInquery(CosesCommonDTO commondto)
  {
    CashCardCDTO icdto = null;
    CashCardCDTO result = null;
    try{
      icdto = new CashCardCDTO();
      icdto.setCardNumber(this.cardNumber);
      icdto.setPasswordNo(this.passwordNo);
      BoundArea outbound=(BoundArea)TCPCallEJB.getInstance().callEJB2("cashCard-inquiryCashCard", commondto,icdto);
      if( outbound.errcode.equals ("IZZ000") ){
        result = (CashCardCDTO)outbound.getParameter();
      }
      else{
        JLO.getInstance().printf(1,"Fail to get CashCardPrimary");
        this.tx_ok = false;
        return null;
      }
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      this.tx_ok = false;
      return null;
    }
    this.tx_ok = true;
    return result;
  }

  public void settx_ok(boolean arg){
    this.tx_ok = arg;
  }

  public String getrealpassword(){
    return( ComUtil.CutSpaceToStr(this.passwordNo,this.passwordNo_LEN) );
  }


  public static void main(String[] args) {
    IOBoundDep80013CDTO IOBoundDep80013CDTO1 = new IOBoundDep80013CDTO();
  }

}

