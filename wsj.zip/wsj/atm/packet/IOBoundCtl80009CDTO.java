package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.math.BigDecimal;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;

// ��� ��� �ŷ�
public class IOBoundCtl80009CDTO {

  public String  CloseOffset;
  public String  BankCode;
  public String  bizDate;
  public String  errorcode;
  public String  dummy1;
  public String  dummy2;
  public String  dummy3;
  public String  dummy4;
  public String  dummy5;

  public static final int CloseOffset_LEN=2;
  public static final int errorcode_LEN=1;
  public static final int BankCode_LEN=2;
  public static final int bizDate_LEN=8;
  public static final int dummy1_LEN=10;
  public static final int dummy2_LEN=10;
  public static final int dummy3_LEN=10;
  public static final int dummy4_LEN=10;
  public static final int dummy5_LEN=10;

  public IOBoundCtl80009CDTO() {
    ComUtil.SpaceToStr(this.CloseOffset,this.CloseOffset_LEN );
    ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    ComUtil.SpaceToStr(this.bizDate,this.bizDate_LEN );
    ComUtil.SpaceToStr(this.errorcode ,this.errorcode_LEN );
    ComUtil.SpaceToStr(this.dummy1,this.dummy1_LEN );
    ComUtil.SpaceToStr(this.dummy2,this.dummy2_LEN );
    ComUtil.SpaceToStr(this.dummy3,this.dummy3_LEN );
    ComUtil.SpaceToStr(this.dummy4,this.dummy4_LEN );
    ComUtil.SpaceToStr(this.dummy5,this.dummy5_LEN );
  }

  public String toString(){
    return ComUtil.SpaceToStr(this.CloseOffset,this.CloseOffset_LEN )
        + ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN )
        + ComUtil.SpaceToStr(this.bizDate,this.bizDate_LEN )
        + ComUtil.SpaceToStr(this.errorcode,this.errorcode_LEN )
        + ComUtil.SpaceToStr(this.dummy1,this.dummy1_LEN )
        + ComUtil.SpaceToStr(this.dummy2,this.dummy2_LEN )
        + ComUtil.SpaceToStr(this.dummy3,this.dummy3_LEN )
        + ComUtil.SpaceToStr(this.dummy4,this.dummy4_LEN )
        + ComUtil.SpaceToStr(this.dummy5,this.dummy5_LEN );
  }

  public boolean setIOBoundCtl80009CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      //��Ŷ������ �Ľ� (IOBoundHead)
      curp = 0;
      dumytmp = this.CloseOffset
              = packetinfo.substring(curp,IOBoundCtl80009CDTO.CloseOffset_LEN);
      JLO.getInstance().printf(1,"CloseOffset:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.CloseOffset_LEN;
      dumytmp = this.BankCode
              = packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.BankCode_LEN));
      JLO.getInstance().printf(1,"BANKCODE:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.BankCode_LEN;
      dumytmp = this.bizDate
              = packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.bizDate_LEN));
      JLO.getInstance().printf(1,"atmtrxno:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.bizDate_LEN;
      dumytmp = this.errorcode
              = packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.errorcode_LEN));
      JLO.getInstance().printf(1,"atmtrxno:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.errorcode_LEN;
      dumytmp = this.dummy1
              = packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.dummy1_LEN));
      JLO.getInstance().printf(1,"dummy1:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.dummy1_LEN;
      dumytmp=this.dummy2
             =packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.dummy2_LEN));
      JLO.getInstance().printf(1,"dummy2:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.dummy2_LEN;
      dumytmp=this.dummy3
             =packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.dummy3_LEN));
      JLO.getInstance().printf(1,"dummy3:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.dummy3_LEN;
      dumytmp=this.dummy4
             =packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.dummy4_LEN));
      JLO.getInstance().printf(1,"dummy4:["+dumytmp+"]");

      curp += IOBoundCtl80009CDTO.dummy4_LEN;
      dumytmp=this.dummy5
             =packetinfo.substring(curp,(curp+IOBoundCtl80009CDTO.dummy5_LEN));
      JLO.getInstance().printf(1,"dummy5:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }

}


