package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;

import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;


// �μ��� �ŷ�
public class IOBoundTel80005CDTO implements Serializable,Cloneable {

  //�Էº�
  public String  TellerNo;
  public String  TargetTellerNo;
  public String  Currency;
  public String  TxAmount;

  //��º�
  public String  BankCode;//&
  public String  BranchCode;//&
  public String  Currency01;
  public String  Amount01;
  public String  Currency02;
  public String  Amount02;
  public String  Currency03;
  public String  Amount03;

  public static final int TellerNo_LEN=10;
  public static final int TargetTellerNo_LEN=10;
  public static final int Currency_LEN=3;
  public static final int Amount_LEN=17;

  public static final int TxAmount_LEN=17;

  public static final int BankCode_LEN=2;
  public static final int BranchCode_LEN=4;


  public IOBoundTel80005CDTO() {
    this.TellerNo = ComUtil.PSpaceToStr(this.TellerNo,this.TellerNo_LEN );
    this.TargetTellerNo = ComUtil.PSpaceToStr(this.TargetTellerNo,this.TargetTellerNo_LEN );
    this.Currency = ComUtil.PSpaceToStr(this.Currency,this.Currency_LEN );
    this.TxAmount = ComUtil.PSpaceToStr(this.TxAmount,this.TxAmount_LEN );

    this.BankCode = ComUtil.PSpaceToStr(this.BankCode,this.BankCode_LEN );
    this.BranchCode = ComUtil.PSpaceToStr(this.BranchCode,this.BranchCode_LEN );
    this.Currency01 = ComUtil.PSpaceToStr(this.Currency01,this.Currency_LEN );
    this.Amount01 = ComUtil.PSpaceToStr(this.Amount01,this.Amount_LEN );


    this.Currency02 = ComUtil.PSpaceToStr(this.Currency02,this.Currency_LEN );
    this.Amount02 = ComUtil.PSpaceToStr(this.Amount02,this.Amount_LEN );


    this.Currency03 = ComUtil.PSpaceToStr(this.Currency03,this.Currency_LEN );
    this.Amount03 = ComUtil.PSpaceToStr(this.Amount03,this.Amount_LEN );

  }

  public String toString(){
    return ComUtil.PSpaceToStr(this.TellerNo,this.TellerNo_LEN )
        + ComUtil.PSpaceToStr(this.TargetTellerNo,this.TargetTellerNo_LEN )
        + ComUtil.PSpaceToStr(this.Currency,this.Currency_LEN )
        + ComUtil.PSpaceToStr(this.TxAmount,this.TxAmount_LEN )
        + ComUtil.PSpaceToStr(this.BankCode,this.BankCode_LEN )
        + ComUtil.PSpaceToStr(this.BranchCode,this.BranchCode_LEN )
        + ComUtil.PSpaceToStr(this.Currency01,this.Currency_LEN )
        + ComUtil.PSpaceToStr(this.Amount01,this.Amount_LEN )
        + ComUtil.PSpaceToStr(this.Currency02,this.Currency_LEN )
        + ComUtil.PSpaceToStr(this.Amount02,this.Amount_LEN )
        + ComUtil.PSpaceToStr(this.Currency03,this.Currency_LEN )
        + ComUtil.PSpaceToStr(this.Amount03,this.Amount_LEN );
  }

  public boolean setIOBoundTel80005CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      curp = 0;
      dumytmp = this.TellerNo
              = packetinfo.substring(curp,IOBoundTel80005CDTO.TellerNo_LEN);
      JLO.getInstance().printf(1,"TellerNo:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.TellerNo_LEN;
      dumytmp = this.TargetTellerNo
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.TargetTellerNo_LEN));
      JLO.getInstance().printf(1,"TargetTellerNo:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.TargetTellerNo_LEN;
      dumytmp = this.Currency
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Currency_LEN;
      dumytmp = this.TxAmount
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.TxAmount_LEN));
      JLO.getInstance().printf(1,"TxAmount:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.TxAmount_LEN;
      dumytmp = this.BankCode
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.BankCode_LEN));
      JLO.getInstance().printf(1,"BankCode:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.BankCode_LEN;
      dumytmp = this.BranchCode
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.BranchCode_LEN));
      JLO.getInstance().printf(1,"BranchCode:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.BranchCode_LEN;
      dumytmp = this.Currency01
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency01:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Currency_LEN;
      dumytmp = this.Amount01
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount01:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Amount_LEN;
      dumytmp = this.Currency02
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency02:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Currency_LEN;
      dumytmp = this.Amount02
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount02:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Amount_LEN;
      dumytmp = this.Currency03
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency03:["+dumytmp+"]");

      curp += IOBoundTel80005CDTO.Currency_LEN;
      dumytmp = this.Amount03
              = packetinfo.substring(curp,(curp+IOBoundTel80005CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount03:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }
  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }

}