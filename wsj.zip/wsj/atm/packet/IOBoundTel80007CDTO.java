package wsj.atm.packet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;

import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;


// �μ��� �ŷ�
public class IOBoundTel80007CDTO implements Serializable,Cloneable {

  //�Էº�
  public String  TellerNo;
  public String  TargetTellerNo;
  public String  Currency;

  //��º�
  public String  TxDate;
  public String  BankCode;//&
  public String  BranchCode;//&
  public String  Currency01;
  public String  Amount01;
  public String  Currency02;
  public String  Amount02;
  public String  Currency03;
  public String  Amount03;

  public static final int TellerNo_LEN=10;
  public static final int TargetTellerNo_LEN=10;
  public static final int Currency_LEN=3;
  public static final int Amount_LEN=17;
  public static final int TxDate_LEN=8;
  public static final int BankCode_LEN=2;
  public static final int BranchCode_LEN=4;


  public IOBoundTel80007CDTO() {
    this.TellerNo = ComUtil.SpaceToStr(this.TellerNo,this.TellerNo_LEN );
    this.TargetTellerNo = ComUtil.SpaceToStr(this.TargetTellerNo,this.TargetTellerNo_LEN );
    this.Currency = ComUtil.SpaceToStr(this.Currency,this.Currency_LEN );
    this.TxDate = ComUtil.SpaceToStr(this.TxDate,this.TxDate_LEN );

    this.BankCode = ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN );
    this.BranchCode = ComUtil.SpaceToStr(this.BranchCode,this.BranchCode_LEN );
    this.Currency01 = ComUtil.SpaceToStr(this.Currency01,this.Currency_LEN );
    this.Amount01 = ComUtil.SpaceToStr(this.Amount01,this.Amount_LEN );


    this.Currency02 = ComUtil.SpaceToStr(this.Currency02,this.Currency_LEN );
    this.Amount02 = ComUtil.SpaceToStr(this.Amount02,this.Amount_LEN );

    this.Currency03 = ComUtil.SpaceToStr(this.Currency03,this.Currency_LEN );
    this.Amount03 = ComUtil.SpaceToStr(this.Amount03,this.Amount_LEN );

  }

  public String toString(){
    return ComUtil.SpaceToStr(this.TellerNo,this.TellerNo_LEN )
        + ComUtil.SpaceToStr(this.TargetTellerNo,this.TargetTellerNo_LEN )
        + ComUtil.SpaceToStr(this.Currency,this.Currency_LEN )
        + ComUtil.SpaceToStr(this.TxDate,this.TxDate_LEN )
        + ComUtil.SpaceToStr(this.BankCode,this.BankCode_LEN )
        + ComUtil.SpaceToStr(this.BranchCode,this.BranchCode_LEN )
        + ComUtil.SpaceToStr(this.Currency01,this.Currency_LEN )
        + ComUtil.SpaceToStr(this.Amount01,this.Amount_LEN )
        + ComUtil.SpaceToStr(this.Currency02,this.Currency_LEN )
        + ComUtil.SpaceToStr(this.Amount02,this.Amount_LEN )
        + ComUtil.SpaceToStr(this.Currency03,this.Currency_LEN )
        + ComUtil.SpaceToStr(this.Amount03,this.Amount_LEN );
  }

  public boolean setIOBoundTel80007CDTOParsing(String packetinfo){
    int curp=0;
    String dumytmp;

    try {
      curp = 0;
      dumytmp = this.TellerNo
              = packetinfo.substring(curp,IOBoundTel80007CDTO.TellerNo_LEN);
      JLO.getInstance().printf(1,"TellerNo:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.TellerNo_LEN;
      dumytmp = this.TargetTellerNo
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.TargetTellerNo_LEN));
      JLO.getInstance().printf(1,"TargetTellerNo:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.TargetTellerNo_LEN;
      dumytmp = this.Currency
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Currency_LEN;
      dumytmp = this.TxDate
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.TxDate_LEN));
      JLO.getInstance().printf(1,"TxDate:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.TxDate_LEN;
      dumytmp = this.BankCode
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.BankCode_LEN));
      JLO.getInstance().printf(1,"BankCode:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.BankCode_LEN;
      dumytmp = this.BranchCode
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.BranchCode_LEN));
      JLO.getInstance().printf(1,"BranchCode:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.BranchCode_LEN;
      dumytmp = this.Currency01
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency01:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Currency_LEN;
      dumytmp = this.Amount01
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount01:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Amount_LEN;
      dumytmp = this.Currency02
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency02:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Currency_LEN;
      dumytmp = this.Amount02
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount02:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Amount_LEN;
      dumytmp = this.Currency03
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Currency_LEN));
      JLO.getInstance().printf(1,"Currency03:["+dumytmp+"]");

      curp += IOBoundTel80007CDTO.Currency_LEN;
      dumytmp = this.Amount03
              = packetinfo.substring(curp,(curp+IOBoundTel80007CDTO.Amount_LEN));
      JLO.getInstance().printf(1,"Amount03:["+dumytmp+"]");

    }
    catch( Exception ex ){
      ex.printStackTrace();
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
    return true;
  }
  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }

}