package wsj.atm.sql;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


public class ATMsql {

  public ATMsql() {
  }
  public static void main(String[] args) {
    ATMsql ATMsql1 = new ATMsql();
  }
}


/**
 CREATE HOSTSEQ
 CONN retail/samtron
 DROP SEQUENCE SQ_COSIFHT_HOSTSEQ;
 CREATE SEQUENCE SQ_COSIFHT_HOSTSEQ
  INCREMENT BY 1
  START WITH   1
  MAXVALUE     9999999
  CYCLE
  ORDER
  ;
  GRANT SELECT ON SQ_COSIFHT_HOSTSEQ to eplaton;
  conn eplaton/eplaton
  create synonym SQ_COSIFHT_HOSTSEQ for retail.SQ_COSIFHT_HOSTSEQ;

  ///////////////////////////////////////////////////////////////////////////////
  CREATE TABLE LIVE_TRANSFER (
  LIVESEQ  VARCHAR(10)    NOT NULL,
  SYSTEM   VARCHAR2 (50)  NOT NULL,
  ORG_HOSTNAME  VARCHAR (50)    NOT NULL,
  ORG_FILE_NAME  VARCHAR (500)      NOT NULL,
  TAR_HOSTNAME  VARCHAR (50)    NOT NULL,
  TAR_FILE_PATH  VARCHAR (500)      ,
  REGISTER_ID  VARCHAR (50)      ,
  REGISTER_DATE  CHAR (8)      NOT NULL,
  REGISTER_TIME  CHAR (6)      NOT NULL,
  UPDATE_YN CHAR(1),
  TRANSFER_TIME  CHAR (6)      NOT NULL,
  FILE_TYPE  CHAR (30)      ,
  CONSTRAINT PK_LIVE_TRANSFER PRIMARY KEY (LIVESEQ)
  )
  /

  CREATE TABLE LIVE_XTRANSFER (
 LIVESEQ  VARCHAR(10)    NOT NULL,
  SYSTEM   VARCHAR2 (50)  NOT NULL,
  ORG_HOSTNAME  VARCHAR (50)    NOT NULL,
  ORG_FILE_NAME  VARCHAR (500)      NOT NULL,
  TAR_HOSTNAME  VARCHAR (50)    NOT NULL,
  TAR_FILE_PATH  VARCHAR (500)      ,
  REGISTER_ID  VARCHAR (50)      ,
  REGISTER_DATE  CHAR (8)      NOT NULL,
  REGISTER_TIME  CHAR (6)      NOT NULL,
  UPDATE_YN CHAR(1),
  TRANSFER_TIME  CHAR (20)      ,
  FILE_TYPE  CHAR (30)      ,
  CONSTRAINT PK_LIVE_XTRANSFER PRIMARY KEY (LIVESEQ)
  )




/*
drop table itfaiinfo;
drop table itfaoinfo;
CREATE TABLE ITFAIINFO
(
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                    VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAIINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_MIS_IND
)
TABLESPACE TSP_MIS
;

CREATE TABLE ITFAOINFO (
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                    VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAOINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_MIS_IND )
   TABLESPACE TSP_MIS
;


CREATE SYNONYM ITFAIINFO FOR RETAIL.ITFAIINFO;
CREATE SYNONYM ITFAOINFO FOR RETAIL.ITFAOINFO;
CREATE TABLE ITFAOINFO (
   brnhostseq              VARCHAR2(20)   NOT NULL,
   systemdate              VARCHAR2(10)    NOT NULL,
   intime                  VARCHAR2(10)    NOT NULL,
   outtime                 VARCHAR2(10)    NOT NULL,
   eventno                 VARCHAR2(10)    NOT NULL,
   bankcode                VARCHAR2(5)    NOT NULL,
   branchcode              VARCHAR2(8)    NOT NULL,
   bizdate                 VARCHAR2(10)    NOT NULL,
   userid                  VARCHAR2(12)   NOT NULL,
   errcode                 VARCHAR2(8)   NOT NULL,
   loginoffset             VARCHAR2(2) ,
   sijaeopenoffset         VARCHAR2(2) ,
   eodoffset               VARCHAR2(2) ,
   sijaeclosoffset         VARCHAR2(2) ,
   atmmode                 VARCHAR2(2) ,
   atmseqno                VARCHAR2(20),
   data                    VARCHAR2(2000),
   CONSTRAINT PK_ITFAOINFO PRIMARY KEY ( brnhostseq )
   USING INDEX TABLESPACE TSP_RETAIL_IND )
   TABLESPACE TSP_RETAIL
;
*/
