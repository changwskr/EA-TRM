package wsj.atm.ejb;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;

import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;


import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.exception.BizDelegateException;
import com.chb.coses.framework.transfer.*;
import com.chb.coses.cosesFramework.transfer.*;
import com.chb.coses.cosesFramework.business.delegate.*;
import wsj.atm.log.JLO;
import javax.rmi.PortableRemoteObject;
import com.chb.coses.user.business.facade.IUserManagement;
import com.chb.coses.user.business.facade.UserManagementSBHome;
import com.chb.coses.user.business.facade.UserManagementSB;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import com.chb.coses.deposit.transfer.InquiryConditionCDTO;
import com.chb.coses.deposit.transfer.AccountPageCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.TransactionHistoryPageItemsCDTO;
import wsj.atm.socket.ATMserver;
import wsj.atm.ejb.EJBPool;
import wsj.atm.common.*;

public class TCPCallEJB {
  private static TCPCallEJB instance;
  public static CosesBizDelegateHome bizHome = null;
  public static CosesBizDelegate remote = null;
  public int isUse = 0;

  private Context ctx;
  public String url = "t3://localhost:7001";
  public String initial_context = "weblogic.jndi.WLInitialContextFactory";
  public CosesCommonDTO cosescommon;
  public CosesEvent event;
  public IEvent result ;

  public static synchronized TCPCallEJB getInstance() {
    if (instance == null) {
      try{
        /*
        String ip = UbbConfig.getInstance().GetEnvValue("RMISERVER");
        String port = UbbConfig.getInstance().GetEnvValue("RMIPORT");
        */
        String ip=null,port=null;
        if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
          ip = ATMXMLconfig.getInstance().GetEnvValue("EJBPOOL","MASTER","RMISERVER");
          port = ATMXMLconfig.getInstance().GetEnvValue("EJBPOOL","MASTER","RMIPORT");
        }
        else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
          ip = ATMXMLconfig.getInstance().GetEnvValue("EJBPOOL","SLAVE","RMISERVER");
          port = ATMXMLconfig.getInstance().GetEnvValue("EJBPOOL","SLAVE","RMIPORT");
        }
        JLO.getInstance().printf(1,"HOSTNAME(M) - " + ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY"));
        JLO.getInstance().printf(1,"HOSTNAME(S) - " + ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY"));
        JLO.getInstance().printf(1,"TCPCallEJB IP : "+ ip + " PORT : " + port );
        instance = new TCPCallEJB(ip,port);
      }
      catch(Exception igex)
      {
        JLO.getInstance().eprintf(10,igex);
        return null;
      }
    }
    return instance;
  }

  public TCPCallEJB(String ip,String port) throws Exception{
    try{
      this.url = "t3://"+ip+":"+port;
      JLO.getInstance().printf(1,"TCPCallEJB URL : "+ url );
      this.ctx = this.getInitialContext();
      this.event = new CosesEvent();
    }catch(Exception ex){
      ex.printStackTrace();
      throw ex;
    }
  }

  public Context getInitialContext()throws NamingException
  {
    if (ctx == null) {
      try {
        Properties p = new Properties();
        p.put(Context.INITIAL_CONTEXT_FACTORY,initial_context);
        p.put(Context.PROVIDER_URL, this.url);
        ctx = new InitialContext(p);
      } catch (NamingException ne) {
        //JLO.getInstance().printf(10,"** Unable to connect to the server at:"+url);
        JLO.getInstance().eprintf(10,ne);
        throw ne;
      }
    }
    return ctx;
  }

  public Object getHome() throws NamingException
  {
    if(this.bizHome==null) {
      Object obj = ctx.lookup(CosesBizDelegateHome.class.getName());
      bizHome = (CosesBizDelegateHome)PortableRemoteObject.narrow(
          obj,CosesBizDelegateHome.class
          );
      return bizHome;
    }
    else
      return this.bizHome;
  }

  public boolean getHome2()
  {
    try{
      Object obj = ctx.lookup(CosesBizDelegateHome.class.getName());
      bizHome = (CosesBizDelegateHome)PortableRemoteObject.narrow( obj,CosesBizDelegateHome.class );
      return true;
    }
    catch(Exception ex){
      return false;
    }
  }

  public Object getRemote() throws Exception
  {
    if(this.remote==null) {
      this.remote = this.bizHome.create();
      return this.remote ;
    }
    else
      return this.remote;
  }

  public synchronized Object callEJB(String callBizAction,BoundArea inbound)
      throws IOException
  {
    Object tmp = inbound.getParameter();
    if(!(tmp instanceof IDTO) ) {
      inbound.errcode = "EI0030";
      return inbound;
    }

    try {
      inbound.setBizAction(callBizAction);
      inbound.setCommand(BoundArea.CALL_BATCH_EJB);
      inbound.errcode = "IZZ000";

      // ������� ���� ����
      this.cosescommon = inbound.cdto;
      /*
      this.cosescommon.setTimeZone(UbbConfig.getInstance().GetEnvValue("TIMEZONE"));
      */
      this.cosescommon.setTimeZone(ATMXMLconfig.getInstance().GetEnvValue("RESOURCE","TIMEZONE"));
      this.event.setCommon(this.cosescommon);
      this.event.setAction(inbound.getBizAction());
      this.event.setRequest((IDTO)inbound.getParameter());

      this.bizHome = (CosesBizDelegateHome) this.getHome();
      this.remote = (CosesBizDelegate) this.getRemote();

      this.result = this.remote.execute(event);
      if( result.getResponse() == null ){
        inbound.errcode = "EI0031";
        inbound.setParameter((Object)"void");
        return (Object)inbound;
      }
      else{
        inbound.errcode = "IZZ000";
        inbound.setParameter((Object)result.getResponse());
        return (Object)inbound;
      }
    } catch(Exception e) {
      JLO.getInstance().eprintf(10,e);
      inbound.errcode = "EI0032";
      inbound.setParameter((Object)"void");
      return (Object)inbound;
    }
  }

  //bizaction:ȣ�⼭��
  //cdto:�������
  //obj:���۵���Ÿ
  public synchronized Object callEJB2(String callBizAction,CosesCommonDTO cdto,Object obj)
      throws IOException
  {
    BoundArea inbound = new BoundArea(BoundArea.CMD_INITIAL);
    try {
      this.isUse = 1;
      JLO.getInstance().printf(1,("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
      inbound.setParameter(obj);
      inbound.cdto = cdto;

      Object tmp = inbound.getParameter();
      if(!(tmp instanceof IDTO) ) {
        inbound.errcode = "EI0033";
        inbound.errmsg = "EI0033 error crack";
        this.isUse = 0;
        JLO.getInstance().printf(1,("EJBCall (1):"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return inbound;
      }

      inbound.setBizAction(callBizAction);
      inbound.setCommand(BoundArea.CALL_BATCH_EJB);
      inbound.errcode = "IZZ000";

      // ������� ���� ����
      this.cosescommon = inbound.cdto;
      /*
      this.cosescommon.setTimeZone(UbbConfig.getInstance().GetEnvValue("TIMEZONE"));
      */
      this.cosescommon.setTimeZone(ATMXMLconfig.getInstance().GetEnvValue("RESOURCE","TIMEZONE"));
      this.cosescommon.setFxRateCount(1);

      //JLO.getInstance().printf(1,"bankcode["+cosescommon.getBankCode()+"]" );
      this.event.setCommon(this.cosescommon);
      this.event.setAction(inbound.getBizAction());
      this.event.setRequest((IDTO)inbound.getParameter());

      this.bizHome = (CosesBizDelegateHome) this.getHome();
      this.remote = (CosesBizDelegate) this.getRemote();

      this.result = this.remote.execute(event);
      if( result.getResponse() == null )
      {
        inbound.errcode = "EI0034";
        inbound.setParameter((Object)"void");
        inbound.errmsg = "EI0034 error crack";
        this.isUse = 0;
        JLO.getInstance().printf(10,("EJBCall (2):"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return (Object)inbound;
      }
      else{
        inbound.errcode = "IZZ000";
        inbound.setParameter((Object)result.getResponse());
        this.isUse = 0;
        JLO.getInstance().printf(1,("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
        return (Object)inbound;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        inbound.errcode = "EI0035";
        inbound.errmsg = "Call Coses Exception-BizActionException";
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        inbound.errcode = "EI0036";
        inbound.errmsg = "Call Coses Exception-RemoteException";
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        inbound.errcode = "EI0037";
        inbound.errmsg = "Call Coses Exception-CosesAppException";
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,getClass()+"------------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = "*";
        String exceptionMsg = "*";
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        inbound.errcode = "EC" + exceptionCode;
        inbound.errmsg= exceptionMsg;
        JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+inbound.errcode+"]");
      }
      else
      {
        JLO.getInstance().eprintf(10,e);
        inbound.errcode = "EI0038";
        inbound.errmsg= "Call Coses Exception-Other";
      }

      inbound.setParameter((Object)"void");
      this.isUse = 0;
      JLO.getInstance().printf(1,("EJBCall::"+this.toString()+"-["+this.checkisUsingBizDelegate()+"]"));
      return (Object)inbound;
    }
  }

  public synchronized boolean checkisUsingBizDelegate () {
    if( this.isUse == 1 )
      return true;
    else
      return false;
  }

  public static synchronized String getTransactionNo(
      String AccountNumber,String BankCode,String bizDate,
      String txAmount,CosesCommonDTO cosesdto)
  {
    InquiryConditionCDTO icdto = null;
    try{
      icdto = new InquiryConditionCDTO();
      icdto.setAccountNumber(AccountNumber);
      icdto.setBankCode(BankCode);
      icdto.setFromDate(bizDate);
      icdto.setToDate(bizDate);
      icdto.setFromAmount(new BigDecimal(txAmount));
      icdto.setToAmount(new BigDecimal(txAmount));
      icdto.setPageNumber(1);

      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-pageListTransactionHistory",
                         cosesdto,icdto);

      if( outbound.errcode.equals ("IZZ000") ){
        AccountPageCDTO result = (AccountPageCDTO)outbound.getParameter();
        if( result.size()== 0 ){
          JLO.getInstance().printf(1,"Transaction Number�� ���ϴµ� ���� -- 1 ");
          return "0000000000000000";
        }
        else{
          TransactionHistoryPageItemsCDTO cdto = (TransactionHistoryPageItemsCDTO)result.get(result.size()-1);
          JLO.getInstance().printf(1,"Transaction Number�� ���ϴµ� �������� : " + cdto.getTransactionNo());
          for( int ii=0; ii<result.size();ii++)
          {
            TransactionHistoryPageItemsCDTO dto = (TransactionHistoryPageItemsCDTO)result.get(ii);
            JLO.getInstance().printf(1,"Transaction No�� �����ϱ��....???"+dto.getTransactionNo());
          }
          return cdto.getTransactionNo();
        }
      }
      else{
        JLO.getInstance().printf(1,"Transaction Number�� ���ϴµ� ���� -- 2 ");
        return "0000000000000000";
      }
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
      return "0000000000000000";
    }
  }

//  public static synchronized AccountQueryCDTO getAccountQueryCDTO(String AccountNumber,String BankCode,CosesCommonDTO cdto)
  public static synchronized BoundArea getAccountQueryCDTO(String AccountNumber,String BankCode,CosesCommonDTO cdto)

  {
    try{
      AccountQueryCDTO acdto = new AccountQueryCDTO();
      acdto.setAccountNumber(AccountNumber);
      acdto.setBankCode(BankCode);

      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("deposit-getAccountInfo",cdto,acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      if( outbound.errcode.equals ("IZZ000") ){
        AccountQueryCDTO result = (AccountQueryCDTO)outbound.getParameter();
        return outbound;
      }
      else{
         AccountQueryCDTO result = new AccountQueryCDTO();
         outbound.setParameter(result);
         return outbound;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "EI0047";
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "EI0048";
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "EI0049";
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
      }
      else{
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "EI0050";
      }
    }
    return null;
  }


  public synchronized BoundArea Login(BoundArea inbound) throws IOException
  {
    String bankCode = inbound.cdto.getBankCode();
    String tellerId = inbound.tellerId;
    String passwd = inbound.passwd;

//    System.out.println("bankcode:"+bankCode+"]");
//    System.out.println("bankcode:"+tellerId+"]");
//    System.out.println("passwd:"+passwd+"]");

    UserManagementSBHome home = null;
    UserManagementSB remote = null;

    try {
      Object obj = this.ctx.lookup(UserManagementSBHome.class.getName());
      home = (UserManagementSBHome)PortableRemoteObject.narrow(obj,UserManagementSBHome.class );
      if(home!=null){
        JLO.getInstance().printf(1,"[TCPCallEJB : home --> "+home.toString()+"]");
      }else{
        JLO.getInstance().printf(1,"[TCPCallEJB : home --> home is null...]");
        inbound.errcode ="EI0039";
        return inbound;
      }

      remote = home.create();
      if(remote!=null){
        JLO.getInstance().printf(1,"[TCPCallEJB : remote --> "+remote.toString()+"]");
      }else{
        JLO.getInstance().printf(1,"[TCPCallEJB : home --> remote is null...]");
        inbound.errcode ="EI0040";
        return inbound;
      }
    } catch(NamingException e) {
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0041";
      JLO.getInstance().printf(1,"fail.ejbLookup.UserManagementSBHome");
      return inbound;
    } catch(CreateException e) {
      JLO.getInstance().printf(1,"fail.create.UserManagementSB");
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0042";
      return inbound;
    } catch(RemoteException e) {
      JLO.getInstance().printf(1,"fail.callEjb");
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0043";
      return inbound;
    } catch(Exception e) {
      JLO.getInstance().printf(1,"fail.callEjb");
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0044";
      return inbound;
    }

    CosesCommonDTO cosescommon = null;
    try {
      cosescommon = remote.login(bankCode,tellerId,passwd);
      JLO.getInstance().printf(1,"[TCPCallEJB : cosescommon --> "+ cosescommon.toString()+"]");
    } catch(RemoteException e) {
      JLO.getInstance().printf(1,"fail.callEjb");
      e.printStackTrace();
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0045";
      return inbound;
    } catch(Exception e) {
      JLO.getInstance().printf(1,"fail.callEjb."+e.getMessage());
      e.printStackTrace();
      JLO.getInstance().eprintf(10,e);
      inbound.errcode ="EI0046";
      return inbound;
    }

    inbound.errcode = "IZZ000";
    this.cosescommon = cosescommon;
    inbound.cdto = cosescommon;
    return inbound;
  }

}
