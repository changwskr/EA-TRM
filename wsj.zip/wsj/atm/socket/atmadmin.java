package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;
import wsj.atm.common.*;
import wsj.atm.env.*;

public class atmadmin {
  private static atmadmin instance;
  private Socket socket;
  private OutputStream os;
  private InputStream is;
  private int port;
  private String hostip;
  private String hostname=ComUtil.GetHostName();
  private String recvdata;

  public atmadmin() {
  }
  public void setSocket() throws IOException,Exception{
    this.socket = new Socket(this.hostip ,this.port);
    this.setIOstream();
  }
  public Socket getSocket() {
    return this.socket;
  }
  public void setIp(String ip){
    this.hostip = ip;
  }
  public String getIp() {
    return this.hostip;
  }
  public void setPort(int Port){
    this.port = port;
  }
  public int getPort() {
    return this.port;
  }
  public void setTimeout(int missec) throws java.net.SocketException {
    this.socket.setSoTimeout(missec);
  }
  public void setIOstream() throws java.io.IOException {
    this.is = this.socket.getInputStream();
    this.os = this.socket.getOutputStream();
  }
  public void setCloseStream() throws IOException{
    this.is.close();
    this.os.close();
    this.socket.close();
  }
  public synchronized String getRecvdata(){
    return this.recvdata;
  }
  public static synchronized atmadmin getInstance(String ip,int port) throws Exception{
    if (instance == null) {
      try{
        instance = new atmadmin();
        instance.setIp(ip);
        instance.setPort(port);
        instance.setSocket();
      }
      catch(Exception igex){
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }
  public static synchronized atmadmin getInstance( ) throws Exception{
    if (instance == null) {
      try{
        instance = new atmadmin();
      }
      catch(Exception igex){
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public synchronized boolean sendrecv(String senddata,int timeout){
    try{
      this.recvdata = null;
      setTimeout(timeout);
      SOCKETapi.write_data(this.os ,senddata);
      recvdata=SOCKETapi.read_data(this.is);
    }
    catch(Exception ex){
      ex.printStackTrace();
      try{
        this.setCloseStream();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }
  public synchronized boolean sendrecv(String ip,int port,String senddata,
                                       int timeout){
    try{
      Socket socket = new Socket(ip ,port);
      InputStream is = socket.getInputStream();
      OutputStream os = socket.getOutputStream();
      this.recvdata = null;
      socket.setSoTimeout(timeout);
      SOCKETapi.jni_write_data(os ,senddata);
      recvdata=SOCKETapi.jni_read_data(is);
      System.out.println(recvdata);
      is.close();
      os.close();
      socket.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
      try{
        is.close();
        os.close();
        socket.close();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }
  public synchronized boolean send(String senddata){
    try{
      this.recvdata = null;
      SOCKETapi.write_data(this.os ,senddata);
      System.out.println("Send["+senddata+"]");
    }
    catch(Exception ex){
      ex.printStackTrace();
      try{
        this.setCloseStream();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }
  public synchronized boolean recv(int timeout){
    try{
      this.recvdata = null;
      setTimeout(timeout);
      SOCKETapi.read_data(this.is);
      System.out.println("Send["+recvdata+"]");
    }
    catch(Exception ex){
      ex.printStackTrace();
      try{
        this.setCloseStream();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }
  public static final boolean runtime(String cmd){
    try{
      //System.out.println(cmd);
      Runtime runtime = Runtime.getRuntime();
      runtime.exec("/home/cosif/atmppp/bin/atmbt " + cmd);
    }
    catch(IOException ex){
      //System.out.println("���ܹ߻�"+ex.getMessage());
      ex.printStackTrace();
      return false;
    }
    return true;
  }
  public static void main(String args[]) throws IOException,Exception {
    int port = 9999;
    String ip = "188.238.50.50";
    String adminserver_port = System.getProperty("adminserver_port");
    String adminserver_ip = System.getProperty("adminserver_ip");

    if( args[0].equals("stop") ){
      atmadmin.getInstance().sendrecv(adminserver_ip,ComUtil.Str2Int(adminserver_port),atmcmddef.C_SHUTDOWN,20000);
      /*
      try{
        Runtime runtime = Runtime.getRuntime();
        runtime.exec(System.getProperty("atmstop") );
      }
      catch(IOException ex){
        ex.printStackTrace();
      }
      */
    }
    else if( args[0].equals("info") ){
      atmadmin.getInstance().sendrecv(adminserver_ip,ComUtil.Str2Int(adminserver_port),atmcmddef.C_TPSVCINFO,20000);
    }
    else if( args[0].equals("cdb") ){
      atmadmin.getInstance().sendrecv(adminserver_ip,ComUtil.Str2Int(adminserver_port),atmcmddef.C_DBPOOLCHK,60000);
    }
    else if( args[0].equals("cejb") ){
      atmadmin.getInstance().sendrecv(adminserver_ip,ComUtil.Str2Int(adminserver_port),atmcmddef.C_TCPCALLEJBCHK,60000);
    }
    else if( args[0].equals("rejb") ){
      atmadmin.getInstance().sendrecv(adminserver_ip,ComUtil.Str2Int(adminserver_port),atmcmddef.C_REINITIAL_TCPCALLEJB,60000);
    }
    else if( args[0].equals("boot") ){
      try{
        Runtime runtime = Runtime.getRuntime();
        runtime.exec(System.getProperty("atmboot") );
      }
      catch(IOException ex){
        ex.printStackTrace();
      }
    }
  }
}
