package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.net.*;
import java.util.*;
import java.io.*;
import java.sql.*;
import wsj.atm.common.*;
import wsj.atm.log.*;
import wsj.atm.packet.*;

public class ATMcontrolflow extends Thread{
  private static ATMcontrolflow instance;
  private Socket socket;
  private OutputStream os;
  private InputStream is;
  private String recvdata;
  private String tarhostip;

  public ATMcontrolflow() {
  }

  public static synchronized ATMcontrolflow getInstance( ) throws Exception{
    if (instance == null) {
      try{
        instance = new ATMcontrolflow();
      }
      catch(Exception igex){
        igex.printStackTrace();
        throw igex;
      }
    }
    return instance;
  }

  public String gettarhostip()
  {
    if( ComUtil.GetHostName().equals("CVBU001") || ComUtil.GetHostName().equals("CVBU002") )
    {
      this.tarhostip = "188.238.2.150";
      return this.tarhostip;
    }
    else
    {
      this.tarhostip = "21.101.3.49";
      return this.tarhostip;
    }
  }

  public boolean sendrecv(String ip,int port,String senddata,int timeout)
  {
    try
    {
      Socket socket = new Socket(ip ,port);
      InputStream is = socket.getInputStream();
      OutputStream os = socket.getOutputStream();

      this.recvdata = null;
      socket.setSoTimeout(timeout);

      SOCKETapi.jni_write_data(os ,senddata);
      recvdata=SOCKETapi.jni_read_data(is);

      is.close();
      os.close();
      socket.close();
      JLO.getInstance().printf(1,"Send["+senddata+"]");
      JLO.getInstance().printf(1,"Recv["+recvdata+"]");

    }
    catch(Exception ex)
    {
      JLO.getInstance().eprintf(10,ex);
      try{
        is.close();
        os.close();
        socket.close();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }


  public boolean msendrecv(String ip,int port,String senddata,int timeout)
  {
    try
    {
      Socket socket = new Socket(ip ,port);
      InputStream is = socket.getInputStream();
      OutputStream os = socket.getOutputStream();

      this.recvdata = null;
      socket.setSoTimeout(timeout);

      SOCKETapi.jni_write_data(os ,senddata);
      recvdata=SOCKETapi.jni_read_data(is);

      is.close();
      os.close();
      socket.close();
      System.out.println("Send["+senddata+"]");
      System.out.println("Recv["+recvdata+"]");

    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      try{
        is.close();
        os.close();
        socket.close();
      }
      catch(Exception ex1){
        ex1.printStackTrace();
      }
      return false;
    }
    return true;
  }

  private int time_sleep = 90000;
  private String o_bizdate = "nothing";
  private String o_txstats = "nothing";

  private boolean start_ox = false;
  private IOBoundCtl80009CDTO iodata;

  public void run() {

    Thread.currentThread().setName("ATMA_CTL");

    while( true ) {
      try{
        Thread.currentThread().sleep(time_sleep);

        if( !start_ox)
        {
          o_txstats = GetTxStatus();
          o_bizdate = GetBizDate();
          start_ox = true;
          opensession();
        }


        if( this.change_actionPerformed() )
        {
          JLO.getInstance().printf(1,"| ");
          JLO.getInstance().printf(1,"| >");
          JLO.getInstance().printf(10,"|===================[ ATM ACTION ]==================>");
          iodata = new IOBoundCtl80009CDTO();
          iodata.BankCode = "03";
          iodata.CloseOffset = o_txstats;
          iodata.bizDate = o_bizdate;

          if( iodata.CloseOffset == null || iodata.bizDate == null ){
            JLO.getInstance().printf(10, "[��������/Ʈ����ǻ��¸� ���ϴµ� �����߻�]" );
            continue;
          }

          JLO.getInstance().printf(10,"|  ");
          String lengthdata = ComUtil.ZeroToStr( ComUtil.Int2Str(iodata.toString().length()), 5);
          JLO.getInstance().printf(10,"==Request["+iodata.toString()+"]");

          if( sendrecv(gettarhostip(),45531,iodata.toString(),10000000) ){
            JLO.getInstance().printf(10,"==Receive["+this.recvdata+"]");
          }
          else{
            JLO.getInstance().printf(10,"==Receive[exception]");
            // 10�ʰ������� 3�а� �����մϴ�.
            int cnt=0;
            while( true ){
              if( cnt++ == 18 ) {
                JLO.getInstance().printf(10,"==per 180 second resend fail");
                break;
              }
              Thread.currentThread().sleep(10000);
              JLO.getInstance().printf(10,"==Request2["+iodata.toString()+"]");
              if( sendrecv(gettarhostip(),45531,iodata.toString(),10000000) ){
                JLO.getInstance().printf(10,"==Receive2["+this.recvdata+"]");
                break;
              }
            }
          }
        }
      }
      catch(Exception ex){
        JLO.debuging(10,ex);
        continue;
      }
    }
  }

  private void opensession(){
    try{
      JLO.getInstance().printf(1,"|  ");
      JLO.getInstance().printf(1,"|  >");
      JLO.getInstance().printf(10,"|===================[ ATM OPENSESSION ]==================>");
      IOBoundCtl80009CDTO iodata = new IOBoundCtl80009CDTO();
      iodata.BankCode = "03";
      o_txstats = GetTxStatus();
      o_bizdate = GetBizDate();
      iodata.CloseOffset = o_txstats;
      iodata.bizDate = o_bizdate;

      if( iodata.CloseOffset == null || iodata.bizDate == null ){
        JLO.getInstance().printf(10, "[��������/Ʈ����ǻ��¸� ���ϴµ� �����߻�]" );
      }

      JLO.getInstance().printf(10,"|  ");
      String lengthdata = ComUtil.ZeroToStr( ComUtil.Int2Str(iodata.toString().length()), 5);
      JLO.getInstance().printf(10,"==oRequest["+iodata.toString()+"]");

      if( sendrecv(gettarhostip(),45531,iodata.toString(),10000000) ){
        JLO.getInstance().printf(10,"==oReceive["+this.recvdata+"]");
      }
      else{
        JLO.getInstance().printf(10,"==oReceive[exception]");
        // 10�ʰ������� 3�а� �����մϴ�.
        int cnt=0;
        while( true ){
          if( cnt++ == 18 ) {
            JLO.getInstance().printf(10,"==oper 180 second resend fail");
            break;
          }
          Thread.currentThread().sleep(10000);
          JLO.getInstance().printf(10,"==oRequest2["+iodata.toString()+"]");
          if( sendrecv(gettarhostip(),45531,iodata.toString(),10000000) ){
            JLO.getInstance().printf(10,"==oReceive2["+this.recvdata+"]");
            break;
          }
        }
      }
    }
    catch(Exception ex){
    }
  }

  private String bizDate;
  public String GetBizDate()
  {
    String 	bizdate=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;
    Connection  conn = null;

    try {
      conn = ATMserver.atmdbpool.getConnection();
      String tSQL = "SELECT DATE_VALUE1 FROM SYSTEM_PARAMETER WHERE SYSTEM='COR' AND KIND='BIZDATE'";
      //String tSQL = "SELECT FILE_SYSTEM_DATE FROM FILE_INTERFACE_INFO WHERE FILE_SIZE='9999'";
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();
      bizdate=ComUtil.Int2Str(rs.getInt(1));
      this.bizDate = bizdate;
    }
    catch(Exception e) {
      JLO.debuging(10,e);
      try {
        stmt.close();
        rs.close();
        ATMserver.atmdbpool.freeConnection(conn);
      }
      catch(Exception ex) { }
      return null;
    }
    try
    {
      stmt.close();
      rs.close();
      ATMserver.atmdbpool.freeConnection(conn);
    }
    catch(SQLException e)
    {
      JLO.debuging(10,e);
      return null;
    }
    this.bizDate = bizdate;
    JLO.getInstance().printf(1,"business date : " + bizDate);
    return(bizdate);
  }

  public String GetTxStatus()
  {
    String 	txStatus=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;
    Connection  conn = null;

    try {
      conn = ATMserver.atmdbpool.getConnection();
      String tSQL = "SELECT CHAR_VALUE1 FROM SYSTEM_PARAMETER WHERE BANK_CODE='03' AND SYSTEM='COR' AND GROUP_CODE='SETUP' AND KIND='BIZOPENBIT'";
      //String tSQL = "SELECT STATUS FROM FILE_INTERFACE_INFO WHERE FILE_SIZE='9999'";
      stmt = conn.createStatement();
      rs = stmt.executeQuery(tSQL);
      rs.next();
      txStatus=ComUtil.Int2Str(rs.getInt(1));
    }
    catch(Exception e) {
      JLO.debuging(10,e);
      try {
        stmt.close();
        rs.close();
        ATMserver.atmdbpool.freeConnection(conn);
      }
      catch(Exception ex) { }
      return null;
    }
    try
    {
      stmt.close();
      rs.close();
      ATMserver.atmdbpool.freeConnection(conn);
    }
    catch(SQLException e)
    {
      JLO.debuging(10,e);
      return null;
    }
    JLO.getInstance().printf(1,"business status : " + txStatus);
    return(txStatus);
  }

  public boolean change_actionPerformed()
  {
    try{
      if( GetTxStatus().equals("30") )
        return false;
      if( !o_txstats.equals(GetTxStatus())){
        o_txstats = GetTxStatus();
        //o_bizdate = GetBizDate();
        JLO.getInstance().printf(1,"tx_status changed : " + o_txstats);
        return true;
      }
      else if (!o_bizdate.equals(GetBizDate())){
        // �������� �ٲ�� ���� ���������� ������ �����Ѵٴ� �ǹ�
        // �̹Ƿ� ������ �ð��� ���� �ξ, 20���°� 10 ���·� ���ϴ� ���� ��ٸ��� ���ش�.
        Thread.currentThread().sleep(60000*30);
        o_txstats = GetTxStatus();
        o_bizdate = GetBizDate();
        JLO.getInstance().printf(1,"Business Date changed : " + o_bizdate);
        return true;
      }
      return false;
    }
    catch(Exception ex){
      JLO.getInstance().eprintf(10,ex);
      return false;
    }
  }

  public static void main(String args[]) throws IOException,Exception {
    if( args.length != 4 ){
      System.out.println("java wsj.atm.socket.ATMcontrolflow bizstats bizdate ip port ");
      System.out.println("java wsj.atm.socket.ATMcontrolflow 10|20 20030508 188.238.50.50 45531");
      System.out.println("java wsj.atm.socket.ATMcontrolflow 10|20 20030508 21.101.3.45 45531");
      System.exit(0);
    }

    if( args[0].length() != 2 )
      System.exit(0);
    if( args[1].length() != 8 )
      System.exit(0);

    IOBoundCtl80009CDTO io = new IOBoundCtl80009CDTO();
    io.BankCode = "03";
    io.bizDate = args[1];
    io.CloseOffset = args[0];
    System.out.println("["+io.toString()+"]");

    ATMcontrolflow acf = new ATMcontrolflow();
    if( acf.msendrecv(args[2],ComUtil.Str2Int(args[3]) , io.toString(),10000000) ){
      //System.out.println("recv:["+ATMcontrolflow.getInstance().getRecvdata()+"]");
    }
    else{
      System.out.println("recv error");
    }
  }
}
