package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.sql.*;

import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;
import wsj.atm.common.ComUtil;
import wsj.atm.common.FILEapi;
import wsj.atm.common.SOCKETapi;
//import wsj.atm.common.wafutil.Debug;
import wsj.atm.dbpool.DBPool;
import wsj.atm.ejb.EJBPool;
import wsj.atm.log.JLO;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.packet.*;
import wsj.atm.business.*;
import wsj.atm.ejb.*;
import wsj.atm.bound.*;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.teller.transfer.*;

public class ATMserveradmin extends Thread{
  private ATMserver atmsrv;
  private ServerSocket serverSocket;
  private Socket u_srv_sok;
  private int PORT;
  private InputStream is;
  private OutputStream os;
  public static DBPool atmdbpool;
  public static EJBPool atmejbpool;
  private StringBuffer sb;

  public ATMserveradmin(ATMserver atmsrv,int port,DBPool atmdbpool,EJBPool atmejbpool) {
    try{
      this.atmsrv = atmsrv;
      this.PORT = port;
      this.serverSocket = SOCKETapi.SERVERopen(this.PORT);
      this.atmdbpool = atmdbpool;
      this.atmejbpool = atmejbpool;
    }
    catch(Exception ex){
      ex.printStackTrace();

      JLO.getInstance().eprintf(10,ex);
      System.exit(0);
    }
  }

  public void run(){
    String tmp=null;
    Thread.currentThread().setName("ATMserveradmin");

    for( ; ; ){
      try{
        JLO.getInstance().printf(1,"*ATMserveradmin*::");
        this.u_srv_sok = SOCKETapi.SOKaccept(this.serverSocket);
        JLO.getInstance().printf(1,"->ATMserveradmin����:ip-:"+u_srv_sok.getInetAddress().getHostAddress());
        this.u_srv_sok.setSoTimeout( ComUtil.STR2INT( ATMXMLconfig.getInstance().GetEnvValue("SERVICE","MAX_TIME_OUT")));
        this.is = this.u_srv_sok.getInputStream();
        this.os = this.u_srv_sok.getOutputStream();

        for( ; ; ){
          try{
            tmp = SOCKETapi.jni_read_data(this.is);
            String snddata = execute(tmp);
            SOCKETapi.jni_write_data(this.os,snddata);
          }
          catch(Exception ex3){
            ex3.printStackTrace();
            break;
          }
        }

        try{
          this.is.close();
          this.os.close();
          this.u_srv_sok.close();
        }
        catch(Exception ex4){
          ex4.printStackTrace();
        }
      }
      catch(Exception ex){
        ex.printStackTrace();
        return;
      }
    }
  }
  public String execute (String tmp){
    ////////////////////////////////////////////////////////////////////
    // stopmode checking
    ////////////////////////////////////////////////////////////////////
    if( tmp.equals(atmcmddef.C_SHUTDOWN) ){
      JLO.getInstance().printf(1,"C_SHUTDOWN");
      this.stopmode();
      return this.sb.toString();
    }
    else if( tmp.equals(atmcmddef.C_TPSVCINFO) ){
      JLO.getInstance().printf(1,"C_TPSVCINFO st");
      this.atmadmininfo();
      return this.rtndata;
    }
    else if( tmp.equals(atmcmddef.C_TCPCALLEJBCHK) ){
      JLO.getInstance().printf(1,"C_TCPCALLEJBCHK st");
      this.tcpcallejbchk4();
      return this.sb.toString();
    }
    else if( tmp.equals(atmcmddef.C_DBPOOLCHK) ){
      JLO.getInstance().printf(1,"C_DBPOOLCHK st");
      this.dbpoolchk();
      return this.sb.toString();
    }
    else if( tmp.equals(atmcmddef.C_REINITIAL_TCPCALLEJB) ){
      JLO.getInstance().printf(1,"C_REINITIAL_TCPCALLEJB st");
      this.reinitial_tcpcallejb();
      return this.sb.toString();
    }

    return atmcmddef.S_SUCCESS;
  }

  public synchronized void tcpcallejbchk()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();

      IOBoundArea in = new IOBoundArea();
      IOBoundArea out = new IOBoundArea();
      in.cdto.setUserId("ATM0238003");
      in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      in.cdto.channelType = "03"; /* ATM �ŷ����� �����Ѵ� */
      in.cdto.setBankCode("03");
      IOBoundLog80000CDTO lcdto = new IOBoundLog80000CDTO();
      lcdto.bankcode = in.cdto.getBankCode();
      lcdto.password = ComUtil.PSpaceToStr(in.cdto.getUserId(),8);
      lcdto.tellerid = ComUtil.PSpaceToStr(in.cdto.getUserId(),10);
      String logindata = lcdto.toString();
      in.iodata.sBoundData = logindata;
      in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
      out = in;
      out = new LGI80000(in,out).execute();

      this.sb = null;
      this.sb = new StringBuffer();

      switch( out.iohead.sBErrCode.charAt(0) )
      {
        case 'E':
          Vector vector = atmejbpool.getVector();
          sb.append("==============================================================================");
          sb.append("\n");
          sb.append("                 ejbpool initialize information(coses abnormal)");
          sb.append("\n");
          sb.append("==============================================================================");
          sb.append("\n");
          for(int i= 0; i<vector.size(); i++)
          {
            Thread.currentThread().sleep(100);
            TCPCallEJB te = (TCPCallEJB)vector.get(i);
            if( !te.checkisUsingBizDelegate() ){
              sb.append( "["+(i+1)+"] : "+te.checkisUsingBizDelegate()+"(Old)");
              sb.append("\n");
              te = null;
              te = createTCPCallEJB();
              sb.append( "["+(i+1)+"] : "+te.toString()+"(New)");
              sb.append("\n");
            }
            else{
              sb.append( "["+(i+1)+"] : "+te.toString()+"(Old)");
              sb.append("\n");
            }
            sb.append("------------------------------------------------------------------------------");
            sb.append("\n");

          }
          return;
        case 'I':
          break;
      }

      Vector vector = ATMserver.atmejbpool.getVector();
      sb.append("==============================================================================");
      sb.append("\n");
      sb.append("                 ejbpool initialize information (coses normal)");
      sb.append("\n");
      sb.append("==============================================================================");
      sb.append("\n");
      for(int i= 0; i<vector.size(); i++)
      {
        Thread.currentThread().sleep(100);
        sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Old)");
        sb.append("\n");
        TCPCallEJB te = (TCPCallEJB)vector.get(i);
        sb.append( "["+(i+1)+"] : Usage-"+te.checkisUsingBizDelegate());
        sb.append("\n");
        sb.append("------------------------------------------------------------------------------");
        sb.append("\n");
      }
    }
    catch(Exception ex){
    }
  }

  public synchronized void tcpcallejbchk3()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();

      BoundArea inbound = new BoundArea(BoundArea.CMD_INITIAL) ;
      inbound.tellerId = "ATM0238003";
      inbound.passwd = "ATM02380";
      inbound.setBankCode("03");
      inbound.errcode = "IZZ000";
      inbound=TCPCallEJB.getInstance().Login(inbound);

      if( inbound.errcode.charAt(0)=='E' ){
        sb.append("-\n");
        sb.append("Coses System Problem Checking Network,Application,System\n");
        sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
        return;
      }
      JLO.getInstance().printf(1,">");
      JLO.getInstance().printf(1,">login tx success");

      // ������ȸ
      AccountQueryCDTO acdto = new AccountQueryCDTO();
      acdto.setAccountNumber("23807051130");
      acdto.setBankCode("03");
      acdto.setSecurityNo("1111");
      //acdto.setCashCardNo("111111111111111111111111");
      inbound.setParameter(acdto);

      JLO.getInstance().printf(1,">deposit selection success");

      sb.append("==============================================================================");
      sb.append("\n");
      sb.append("                 ejbpool initialize information(coses abnormal)");
      sb.append("\n");
      sb.append("==============================================================================");
      sb.append("\n");

      TCPCallEJB ejbinstance = null;
      Vector vector = atmejbpool.getVector();
      for(int i= 0; i<vector.size(); i++)
      {
        try {
          Thread.currentThread().sleep(100);
          JLO.getInstance().printf(1,">--");
          JLO.getInstance().printf(1,">get a tcpejb instance : " + vector.get(i).toString() );
          //ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
          ejbinstance = (TCPCallEJB)vector.get(i);
          JLO.getInstance().printf(1,">deposit-getAccountInfo call start");
          BoundArea outbound=(BoundArea)ejbinstance.callEJB2("deposit-getAccountInfo",inbound.cdto,acdto);
          if( outbound.errcode.equals ("EC9000") ||
              outbound.errcode.equals ("EI0035") ||
              outbound.errcode.equals ("EI0036") ||
              outbound.errcode.equals ("EI0037") ||
              outbound.errcode.equals ("EI0038") )
          {
            sb.append( "["+(i+1)+"] : "+ejbinstance.toString()+"(Old)");
            sb.append("\n");
            ejbinstance = createTCPCallEJB();
            JLO.getInstance().printf(1,">call error to create tcpcall ejb : "+ejbinstance);
            sb.append( "["+(i+1)+"] : "+ejbinstance.toString()+"(New)");
            sb.append("\n");
          }
          else
          {
            JLO.getInstance().printf(1,">call success tcpcall ejb : "+ejbinstance);
            sb.append( "["+(i+1)+"] : "+ejbinstance.toString()+"(Old)");
            sb.append("\n");
          }
          //ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
          sb.append("------------------------------------------------------------------------------");
          sb.append("\n");
        }
        catch(Exception ex){
          JLO.getInstance().eprintf(10,ex);
          sb.append("["+(i+1)+"] : "+ex.toString() + "\n");
        }
      }
    }
    catch(Exception ex){
      sb.append("-\n");
      sb.append("Coses System Problem Checking Network,Application,System\n");
      sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
      return;
    }
  }

  public synchronized void tcpcallejbchk2()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();

      BoundArea inbound = new BoundArea(BoundArea.CMD_INITIAL) ;
      inbound.tellerId = "ATM0238003";
      inbound.passwd = "ATM02380";
      inbound.setBankCode("03");
      inbound.errcode = "IZZ000";
      inbound=TCPCallEJB.getInstance().Login(inbound);

      if( inbound.errcode.charAt(0)=='E' ){
        sb.append("-\n");
        sb.append("Coses System Problem Checking Network,Application,System\n");
        sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
        return;
      }
      JLO.getInstance().printf(1,">");
      JLO.getInstance().printf(1,">login tx success");

      TransferCDTO acdto = new TransferCDTO();
      acdto.setTellerNo( "ATM0238003" );
      acdto.setOutTxDate(inbound.cdto.getBusinessDate());

      JLO.getInstance().printf(1,">deposit selection success");

      TCPCallEJB ejbinstance = this.createTCPCallEJB();
      if( (ejbinstance != null) && ejbinstance.getHome2()){
        Vector vector = ATMserver.atmejbpool.getVector();
        sb.append("==============================================================================\n");
        sb.append("                 ejbpool initialize information (coses normal) \n");
        sb.append("==============================================================================\n");
        for(int i= 0; i<vector.size(); i++)
        {
          Thread.currentThread().sleep(100);
          sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Old)\n");
          TCPCallEJB te = (TCPCallEJB)vector.get(i);
          sb.append( "["+(i+1)+"] : Usage-"+te.checkisUsingBizDelegate()+"\n");
          sb.append("------------------------------------------------------------------------------\n");
        }
        return;
      }

      sb.append("==============================================================================\n");
      sb.append("                 ejbpool initialize information (coses abnormal) \n");
      sb.append("==============================================================================\n");

      Vector vector = atmejbpool.getVector();
      for(int i= 0; i<vector.size(); i++)
      {
        try {
          Thread.currentThread().sleep(100);
          JLO.getInstance().printf(1,">--");
          JLO.getInstance().printf(1,">get a tcpejb instance : " + vector.get(i).toString() );

          //ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
          ejbinstance = (TCPCallEJB)vector.get(i);
          JLO.getInstance().printf(1,">teller-getAccountInfo call start");
          sb.append( "["+(i+1)+"] : "+ejbinstance.toString()+"(Old)\n");
          ejbinstance = createTCPCallEJB();
          if( ejbinstance == null ){
            JLO.getInstance().printf(1,">call error to create tcpcall ejb : "+ejbinstance);
            sb.append("["+(i+1)+"] : "+"createTCPCallEJB exception" + "\n");
          }
          else{
            sb.append( "["+(i+1)+"] : "+ejbinstance.toString()+"(New)\n");
          }
          //ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
          sb.append("------------------------------------------------------------------------------\n");
        }
        catch(Exception ex){
          JLO.getInstance().eprintf(10,ex);
          sb.append("["+(i+1)+"] : "+ex.toString() + "\n");
        }
      }
    }
    catch(Exception ex){
      sb.append("-\n");
      sb.append("Coses System Problem Checking Network,Application,System\n");
      sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
      return;
    }
  }

  public synchronized void tcpcallejbchk4()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();
      int failover = 0;
      Vector vector = ATMserver.atmejbpool.getVector();
      sb.append("==============================================================================\n");
      sb.append("                                  EJBpool Check Failover \n");
      sb.append("==============================================================================\n");

      for(int i= 0; i<vector.size(); i++)
      {
        Thread.currentThread().sleep(100);
        JLO.getInstance().printf(1,">--");
        JLO.getInstance().printf(1,">Get a tcpejb instance : " + vector.get(i).toString() );

        TCPCallEJB ejbinstance = (TCPCallEJB)vector.get(i);
        sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Original) \n");

        if( !ejbinstance.getHome2()){
          sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Is Abnormal to start Failover) \n");
          sb.append("------------------------------------------------------------------------------\n");
          failover = 1;
          break;
        }
        else{
          sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Is normal)\n");
        }
        //sb.append( "["+(i+1)+"] : Usage-"+ejbinstance.checkisUsingBizDelegate()+"\n");
        sb.append("------------------------------------------------------------------------------\n");
      }
      if( failover == 0 )
        return;
      for(int i= 0; i<vector.size(); i++)
      {
        Thread.currentThread().sleep(100);
        JLO.getInstance().printf(1,">--");
        JLO.getInstance().printf(1,">Get a fail tcpejb instance : " + vector.get(i).toString() );

        TCPCallEJB ejbinstance = (TCPCallEJB)vector.get(i);
        sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Original) \n");
        ejbinstance = createTCPCallEJB();
        if( ejbinstance == null ){
          JLO.getInstance().printf(1,">Call error to create tcpcall ejb : "+ejbinstance);
          sb.append("["+(i+1)+"] : "+"CreateTCPCallEJB exception" + "\n");
        }
        else{
          JLO.getInstance().printf(1,">Call success to create tcpcall ejb : "+ejbinstance);
          sb.append( "["+(i+1)+"] : Get Success - "+ejbinstance.toString()+"(New)\n");
        }
        //sb.append( "["+(i+1)+"] : Usage-"+ejbinstance.checkisUsingBizDelegate()+"\n");
        sb.append("------------------------------------------------------------------------------\n");
      }
    }
    catch(Exception ex){
      sb.append("-\n");
      sb.append("Coses System Problem Checking Network,Application,System\n");
      sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
      return;
    }
  }

  public synchronized void reinitial_tcpcallejb()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();
      int failover = 0;
      Vector vector = ATMserver.atmejbpool.getVector();
      sb.append("==============================================================================\n");
      sb.append("                                  EJBpool Check Failover \n");
      sb.append("==============================================================================\n");

      for(int i= 0; i<vector.size(); i++)
      {
        Thread.currentThread().sleep(100);
        JLO.getInstance().printf(1,">--");
        JLO.getInstance().printf(1,">Get a fail tcpejb instance : " + vector.get(i).toString() );

        TCPCallEJB ejbinstance = (TCPCallEJB)vector.get(i);
        sb.append( "["+(i+1)+"] : "+(vector.get(i)).toString()+"(Original) \n");
        ejbinstance = null;
        ejbinstance = createTCPCallEJB();
        if( ejbinstance == null ){
          JLO.getInstance().printf(1,">Call error to create tcpcall ejb : "+ejbinstance);
          sb.append("["+(i+1)+"] : "+"CreateTCPCallEJB exception" + "\n");
        }
        else{
          JLO.getInstance().printf(1,">Call success to create tcpcall ejb : "+ejbinstance);
          sb.append( "["+(i+1)+"] : Get Success - "+ejbinstance.toString()+"(New)\n");
        }
        //sb.append( "["+(i+1)+"] : Usage-"+ejbinstance.checkisUsingBizDelegate()+"\n");
        sb.append("------------------------------------------------------------------------------\n");
      }
    }
    catch(Exception ex){
      sb.append("-\n");
      sb.append("Coses System Problem Checking Network,Application,System\n");
      sb.append("if hava problem in SYSTE,WAS and DB, to Restart CPD is a special method\n" );
      return;
    }
  }


  private synchronized TCPCallEJB createTCPCallEJB(){
    TCPCallEJB ejbinstance= null;
    try {
      String ip = System.getProperty("rmiserver");
      String port = System.getProperty("rmiport");
      ejbinstance = new TCPCallEJB(ip,port);
    }
    catch(Exception exception) {
      JLO.getInstance().eprintf(10,exception);
      return null;
    }
    return ejbinstance;
  }

  ////////////////////////////////////////////////////////////////////////////
  // atmserver forced shutdown
  // cauction 1. all client must be stoped
  // cauction 2. all transaction must be stoped
  ////////////////////////////////////////////////////////////////////////////
  public synchronized boolean stopmode(){
    try{
      this.sb = null;
      this.sb = new StringBuffer();

      sb.append("............................................................");
      sb.append("\n");
      sb.append(" ATMserver & ATMserverhandler is going shutdown");
      sb.append("\n");
      sb.append(" . wait a minute ");
      sb.append("\n");
      sb.append("............................................................");
      sb.append("\n");

      this.atmsrv.setstopflag(true);
      for(int i=0;i<atmsrv.atmhandler.size();i++){
        ATMserverhandler ah = (ATMserverhandler)atmsrv.atmhandler.get(i);
        if( ah.CurThread.isAlive() ){
          int lcnt = 0;
          while( true ){
            if( ah.loc == 1 ){
              Thread.currentThread().sleep(100);
              lcnt++;
              if( lcnt >= 120 ) {
                sb.append(ah.getCurrentThread().getName()+".. is forced shutdown");
                sb.append("\n");
                break;
              }
              continue;
            }
            else
              break;
          }
          if( ah.u_srv_sok != null ) {
            try{
              ah.is.close();
              ah.os.close();
              ah.u_srv_sok.close();
              }catch(Exception ex){}
          }
          ah.CurThread.stop();
        }
      }
      this.atmsrv.atmdbpool.release();
      this.atmsrv.atmejbpool.release();
      this.atmsrv.tpsvcinfo.stop();
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
    return true;
  }
  private String rtndata;
  public synchronized boolean atmadmininfo(){
    try{
      this.rtndata = null;
      this.atmsrv.tpsvcinfo.prntCLTINFO2();
      String p1 = this.atmsrv.tpsvcinfo.sb.toString();
      this.atmsrv.tpsvcinfo.prntTHRINFO2();
      String p2 = this.atmsrv.tpsvcinfo.sb.toString();
      rtndata = p1 + p2;
      return true;
    }
    catch(Exception ex){return false;}
  }
  public synchronized void setstopflag(boolean flag){
    try{
      this.atmsrv.stopflag = flag;
      for(int i=0;i<atmsrv.atmhandler.size();i++){
        ATMserverhandler ah = (ATMserverhandler)this.atmsrv.atmhandler.get(i);
        ah.setstopflag(flag);
      }
    }
    catch(Exception ex){}
  }

  public boolean selectdumy(Connection conn)
  {
    String 	seqtmp=null;
    Statement 	stmt=null;
    ResultSet 	rs=null;

    try {
      String tSQL = "SELECT TO_CHAR(SYSDATE,'YYMMDD') FROM DUAL";
      stmt = conn.createStatement( );
      rs = stmt.executeQuery(tSQL);
      rs.next();
      seqtmp=rs.getString(1);
      stmt.close();
      rs.close();
    } catch(Exception e) {
      try {
        stmt.close();
        rs.close();
      }
      catch(Exception ex) { }
      return false;
    }

    return true;
  }

  public void dbpoolchk()
  {
    try
    {
      this.sb = null;
      this.sb = new StringBuffer();
      Vector vector = atmdbpool.getVector();
      sb.append("==============================================================================");
      sb.append("\n");
      sb.append("                            dbpool initialize information");
      sb.append("\n");
      sb.append("==============================================================================");
      sb.append("\n");
      for(int i= 0; i<vector.size(); i++)
      {
        Thread.currentThread().sleep(100);
        //Connection conn = atmdbpool.getConnection();
        Connection conn = (Connection)vector.get(i);
        if( !selectdumy(conn) ){
          conn.close();
          conn = null;
          conn = atmdbpool.createConnection();
          sb.append( "["+(i+1)+"] : "+conn.toString()+"(New)");
          sb.append("\n");
        }
        else{
          sb.append( "["+(i+1)+"] : "+conn.toString()+"(Old)");
          sb.append("\n");
        }
        sb.append("------------------------------------------------------------------------------");
        //atmdbpool.freeConnection(conn);
        sb.append("\n");
      }
    }
    catch(Exception ex){
    }
  }

}