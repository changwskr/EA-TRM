package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.atm.common.ComUtil;
import wsj.atm.common.SOCKETapi;
//import wsj.atm.common.wafutil.Debug;
import wsj.atm.dbpool.DBPool;
import wsj.atm.ejb.EJBPool;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

public class CLTINFO {
  private static CLTINFO instance;

  private String key;
  private Thread thr;
  private Socket sok;
  private String cli_ip;
  private String cli_port;
  private String teller_id;
  private String pid;
  private String start_time;
  private String systemdate;
  public int sijae_openoffset=0;
  public int sijae_closeoffset=0;
  public int login_offset=0;

  private long evt80000_txcnt=0;
  public long tc80000_ecnt=0;
  public long tc80000_scnt=0;

  private long evt80001_txcnt=0;
  public long tc80001_ecnt=0;
  public long tc80001_scnt=0;

  private long evt80002_txcnt=0;
  public long tc80002_ecnt=0;
  public long tc80002_scnt=0;

  private long evt80003_txcnt=0;
  public long tc80003_ecnt=0;
  public long tc80003_scnt=0;

  private long evt80004_txcnt=0;
  public long tc80004_ecnt=0;
  public long tc80004_scnt=0;

  private long evt80005_txcnt=0;
  public long tc80005_ecnt=0;
  public long tc80005_scnt=0;

  private long evt80006_txcnt=0;
  public long tc80006_ecnt=0;
  public long tc80006_scnt=0;

  private long evt80007_txcnt=0;
  public long tc80007_ecnt=0;
  public long tc80007_scnt=0;

  private long evt80008_txcnt=0;
  public long tc80008_ecnt=0;
  public long tc80008_scnt=0;

  private long evt80009_txcnt=0;
  public long tc80009_ecnt=0;
  public long tc80009_scnt=0;

  private long evt80010_txcnt=0;
  public long tc80010_ecnt=0;
  public long tc80010_scnt=0;

  public long tc80011_ecnt=0;
  public long tc80011_scnt=0;
  private long evt80011_txcnt=0;

  public long tc80012_ecnt=0;
  public long tc80012_scnt=0;
  private long evt80012_txcnt=0;

  public long tc80013_ecnt=0;
  public long tc80013_scnt=0;
  private long evt80013_txcnt=0;

  public long tc80014_ecnt=0;
  public long tc80014_scnt=0;
  private long evt80014_txcnt=0;

  public long tc80015_ecnt=0;
  public long tc80015_scnt=0;
  private long evt80015_txcnt=0;

  public long tc80016_ecnt=0;
  public long tc80016_scnt=0;
  private long evt80016_txcnt=0;

  public long tc80017_ecnt=0;
  public long tc80017_scnt=0;
  private long evt80017_txcnt=0;

  public long tc80018_ecnt=0;
  public long tc80018_scnt=0;
  private long evt80018_txcnt=0;

  public long tc80019_ecnt=0;
  public long tc80019_scnt=0;
  private long evt80019_txcnt=0;

  public long tc80020_ecnt=0;
  public long tc80020_scnt=0;
  private long evt80020_txcnt=0;

  private long txcnt=0;
  private int  liveseq=0;
  private boolean srtOffset = true;
  private boolean exitflag = false;

  public CLTINFO() {
  }

  public static synchronized CLTINFO getInstance() {
    if (instance == null) {
      try{
        instance = new CLTINFO();
      }catch(Exception igex){
        JLO.getInstance().eprintf(10,igex);
        throw new RuntimeException();
      }
    }
    return instance;
  }

  public String getKey(){
    return this.key;
  }
  public Thread getThread(){
    return this.thr;
  }
  public Socket getSocket(){
    return this.sok;
  }
  public String getIP(){
    return this.cli_ip;
  }
  public String getPORT(){
    return this.cli_port;
  }
  public String getTeller_id(){
    return this.teller_id;
  }
  public String getSrtTime(){
    return this.start_time;
  }
  public void setSocket(Socket sok){
    this.sok=sok;
    this.setIP(this.sok.getInetAddress().getHostAddress());
    this.setPORT(ComUtil.Int2Str( this.sok.getPort()));
  }
  public void setIP(String ip){
    this.cli_ip=ip;
  }
  public void setPORT(String port){
    this.cli_port=port;
  }
  public void setSrtTime(){
    this.start_time = ComUtil.GetSysTime();
  }
  public long getTxcnt(int type){
    switch( type )
    {
      case 80000:
        return this.evt80000_txcnt;
      case 80001:
        return this.evt80001_txcnt;
      case 80002:
        return this.evt80002_txcnt;
      case 80003:
        return this.evt80003_txcnt;
      case 80004:
        return this.evt80004_txcnt;
      case 80005:
        return this.evt80005_txcnt;
      case 80006:
        return this.evt80006_txcnt;
      case 80007:
        return this.evt80007_txcnt;
      case 80008:
        return this.evt80008_txcnt;
      case 80009:
        return this.evt80009_txcnt;
      case 80010:
        return this.evt80010_txcnt;
      case 80011:
        return this.evt80011_txcnt;
      case 80012:
        return this.evt80012_txcnt;
      case 80013:
        return this.evt80013_txcnt;
      case 80014:
        return this.evt80014_txcnt;
      case 80015:
        return this.evt80015_txcnt;
      case 80016:
        return this.evt80016_txcnt;
      case 80017:
        return this.evt80017_txcnt;
      case 80018:
        return this.evt80018_txcnt;
      case 80019:
        return this.evt80019_txcnt;
      case 80020:
        return this.evt80020_txcnt;
      case 100000: //��ü�Ǽ��� ���Ѵ�.
         return this.txcnt;
      default:
        return this.txcnt;
    }
  }
  public void addEvt80000_txcnt(){
    this.evt80000_txcnt++;
    this.txcnt++;
  }
  public void addEvt80001_txcnt(){
    this.evt80001_txcnt++;
    this.txcnt++;
  }
  public void addEvt80002_txcnt(){
    this.evt80002_txcnt++;
    this.txcnt++;
  }
  public void addEvt80003_txcnt(){
    this.evt80003_txcnt++;
    this.txcnt++;
  }
  public void addEvt80004_txcnt(){
    this.evt80004_txcnt++;
    this.txcnt++;
  }
  public void addEvt80005_txcnt(){
    this.evt80005_txcnt++;
    this.txcnt++;
  }
  public void addEvt80006_txcnt(){
    this.evt80006_txcnt++;
    this.txcnt++;
  }
  public void addEvt80007_txcnt(){
    this.evt80007_txcnt++;
    this.txcnt++;
  }
  public void addEvt80008_txcnt(){
    this.evt80008_txcnt++;
    this.txcnt++;
  }
  public void addEvt80009_txcnt(){
    this.evt80009_txcnt++;
    this.txcnt++;
  }
  public void addEvt80010_txcnt(){
    this.evt80010_txcnt++;
    this.txcnt++;
  }
  public void addEvt80011_txcnt(){
    this.evt80011_txcnt++;
    this.txcnt++;
  }
  public void addEvt80012_txcnt(){
    this.evt80012_txcnt++;
    this.txcnt++;
  }
  public void addEvt80013_txcnt(){
    this.evt80013_txcnt++;
    this.txcnt++;
  }
  public void addEvt80014_txcnt(){
    this.evt80014_txcnt++;
    this.txcnt++;
  }
  public void addEvt80015_txcnt(){
    this.evt80015_txcnt++;
    this.txcnt++;
  }
  public void addEvt80016_txcnt(){
    this.evt80016_txcnt++;
    this.txcnt++;
  }
  public void addEvt80017_txcnt(){
    this.evt80018_txcnt++;
    this.txcnt++;
  }
  public void addEvt80018_txcnt(){
    this.evt80018_txcnt++;
    this.txcnt++;
  }
  public void addEvt80019_txcnt(){
    this.evt80019_txcnt++;
    this.txcnt++;
  }
  public void addEvt80020_txcnt(){
    this.evt80020_txcnt++;
    this.txcnt++;
  }
  public void setThread(Thread thr){
    this.thr=thr;
  }
  public void setKey(String key){
    this.key=key;
  }
  public void setTeller_id(String teller_id){
    this.teller_id=teller_id;
  }
  public void setSystemDate(String SystemDate){
    this.systemdate=SystemDate;
  }
  public String getSystemDate(){
    return this.systemdate;
  }
  public void addLiveseq(){
    this.liveseq++;
  }
  public int getLiveseq(){
    return this.liveseq;
  }
  public void setSrtOffset(boolean offset){
    this.srtOffset = offset;
  }
  public boolean getSrtOffset(){
    return this.srtOffset;
  }
  public void setExitflag(boolean offset){
    this.exitflag = offset;
  }
  public boolean getExitflag(){
    return this.exitflag;
  }

  public void addTxcnt(IOBoundArea in){
    if( in.cdto.eventNo.equals("80000") ){
      addEvt80000_txcnt();
    }
    else if( in.cdto.eventNo.equals("80001") ){
      addEvt80001_txcnt();
    }
    else if( in.cdto.eventNo.equals("80002") ){
      addEvt80002_txcnt();
    }
    else if( in.cdto.eventNo.equals("80003") ){
      addEvt80003_txcnt();
    }
    else if( in.cdto.eventNo.equals("80004") ){
      addEvt80004_txcnt();
    }
    else if( in.cdto.eventNo.equals("80005") ){
      addEvt80005_txcnt();
    }
    else if( in.cdto.eventNo.equals("80006") ){
      addEvt80006_txcnt();
    }
    else if( in.cdto.eventNo.equals("80007") ){
      addEvt80007_txcnt();
    }
    else if( in.cdto.eventNo.equals("80008") ){
      addEvt80008_txcnt();
    }
    else if( in.cdto.eventNo.equals("80009") ){
      addEvt80009_txcnt();
    }
    else if( in.cdto.eventNo.equals("80010") ){
      addEvt80010_txcnt();
    }
    else if( in.cdto.eventNo.equals("80011") ){
      addEvt80011_txcnt();
    }
    else if( in.cdto.eventNo.equals("80012") ){
      addEvt80012_txcnt();
    }
    else if( in.cdto.eventNo.equals("80013") ){
      addEvt80013_txcnt();
    }
    else if( in.cdto.eventNo.equals("80014") ){
      addEvt80014_txcnt();
    }
    else if( in.cdto.eventNo.equals("80015") ){
      addEvt80015_txcnt();
    }
    else if( in.cdto.eventNo.equals("80016") ){
      addEvt80016_txcnt();
    }
    else if( in.cdto.eventNo.equals("80017") ){
      addEvt80017_txcnt();
    }
    else if( in.cdto.eventNo.equals("80018") ){
      addEvt80018_txcnt();
    }
    else if( in.cdto.eventNo.equals("80019") ){
      addEvt80019_txcnt();
    }
    else if( in.cdto.eventNo.equals("80020") ){
      addEvt80020_txcnt();
    }

  }
  public void addSETxcnt(IOBoundArea in){
    if( in.cdto.eventNo.equals("80000") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80000_ecnt++; break;
        case 'I': this.tc80000_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80001") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80001_ecnt++; break;
        case 'I': this.tc80001_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80002") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80002_ecnt++; break;
        case 'I': this.tc80002_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80003") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80003_ecnt++; break;
        case 'I': this.tc80003_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80004") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80004_ecnt++; break;
        case 'I': this.tc80004_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80005") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80005_ecnt++; break;
        case 'I': this.tc80005_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80006") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80006_ecnt++; break;
        case 'I': this.tc80006_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80007") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80007_ecnt++; break;
        case 'I': this.tc80007_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80008") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80008_ecnt++; break;
        case 'I': this.tc80008_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80009") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80009_ecnt++; break;
        case 'I': this.tc80009_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80010") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80010_ecnt++; break;
        case 'I': this.tc80010_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80011") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80011_ecnt++; break;
        case 'I': this.tc80011_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80012") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80012_ecnt++; break;
        case 'I': this.tc80012_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80013") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80013_ecnt++; break;
        case 'I': this.tc80013_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80014") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80014_ecnt++; break;
        case 'I': this.tc80014_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80015") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80015_ecnt++; break;
        case 'I': this.tc80015_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80016") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80016_ecnt++; break;
        case 'I': this.tc80016_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80017") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80017_ecnt++; break;
        case 'I': this.tc80017_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80018") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80018_ecnt++; break;
        case 'I': this.tc80018_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80019") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80019_ecnt++; break;
        case 'I': this.tc80019_scnt++; break;
      }
    }
    else if( in.cdto.eventNo.equals("80020") ){
      switch( in.iohead.sBErrCode.charAt(0) )
      {
        case 'E': this.tc80020_ecnt++; break;
        case 'I': this.tc80020_scnt++; break;
      }
    }
  }
  public void setZeroTrxCnt(){
    this.evt80000_txcnt=0;
    this.evt80001_txcnt=0;
    this.evt80002_txcnt=0;
    this.evt80003_txcnt=0;
    this.evt80004_txcnt=0;
    this.evt80005_txcnt=0;
    this.evt80006_txcnt=0;
    this.evt80007_txcnt=0;
    this.evt80008_txcnt=0;
    this.evt80009_txcnt=0;
    this.evt80010_txcnt=0;
    this.evt80011_txcnt=0;
    this.evt80012_txcnt=0;
    this.evt80013_txcnt=0;
    this.evt80014_txcnt=0;
    this.evt80015_txcnt=0;
    this.evt80016_txcnt=0;
    this.evt80017_txcnt=0;
    this.evt80018_txcnt=0;
    this.evt80019_txcnt=0;
    this.evt80020_txcnt=0;

    this.tc80000_ecnt = 0;
    this.tc80000_scnt = 0;

    this.tc80001_ecnt = 0;
    this.tc80001_scnt = 0;

    this.tc80002_ecnt = 0;
    this.tc80002_scnt = 0;

    this.tc80003_ecnt = 0;
    this.tc80003_scnt = 0;

    this.tc80004_ecnt = 0;
    this.tc80004_scnt = 0;

    this.tc80005_ecnt = 0;
    this.tc80005_scnt = 0;

    this.tc80006_ecnt = 0;
    this.tc80006_scnt = 0;

    this.tc80007_ecnt = 0;
    this.tc80007_scnt = 0;

    this.tc80008_ecnt = 0;
    this.tc80008_scnt = 0;

    this.tc80009_ecnt = 0;
    this.tc80009_scnt = 0;

    this.tc80010_ecnt = 0;
    this.tc80010_scnt = 0;

    this.tc80011_ecnt = 0;
    this.tc80011_scnt = 0;

    this.tc80012_ecnt = 0;
    this.tc80012_scnt = 0;

    this.tc80013_ecnt = 0;
    this.tc80013_scnt = 0;

    this.tc80014_ecnt = 0;
    this.tc80014_scnt = 0;

    this.tc80015_ecnt = 0;
    this.tc80015_scnt = 0;

    this.tc80016_ecnt = 0;
    this.tc80016_scnt = 0;

    this.tc80017_ecnt = 0;
    this.tc80017_scnt = 0;

    this.tc80018_ecnt = 0;
    this.tc80018_scnt = 0;

    this.tc80019_ecnt = 0;
    this.tc80019_scnt = 0;

    this.tc80020_ecnt = 0;
    this.tc80020_scnt = 0;

    this.txcnt=0;
    this.liveseq=0;
  }
  public void updateBizmanage(IOBoundArea in){
    if( !in.iohead.sBErrCode.equals("IZZ000") )
      return;

    if( in.cdto.eventNo.equals("80000") ){
      this.login_offset = 1;
    }
    else if( in.cdto.eventNo.equals("80004") ){
      this.sijae_openoffset = 1;
    }
    else if( in.cdto.eventNo.equals("80006") ){
      this.sijae_closeoffset = 1;
    }
  }

  public void printinfo(){
  }
}

