package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;
import java.rmi.*;

import wsj.atm.common.ComUtil;
import wsj.atm.common.FILEapi;
import wsj.atm.common.SOCKETapi;
//import wsj.atm.common.wafutil.Debug;
import wsj.atm.dbpool.DBPool;
import wsj.atm.ejb.EJBPool;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;

public class ATMserver extends Thread {
  private Vector v_sok_fd_tbl = new Vector();
  private ServerSocket serverSocket;
  private Socket u_srv_sok;
  private int PORT;
  private int MAX_THR_CNT;
  private String svcname;
  public static DBPool atmdbpool;
  public static EJBPool atmejbpool;
  public static TPSVCINFO tpsvcinfo;
  public boolean stopflag=false;
  public ArrayList atmhandler;
  public ATMserveradmin adminsrv;
  public ATMcontrolflow atmcontrol;

  public ATMserver(int MAX_THR_CNT,int PORT,String svcname)
      throws IOException,NotBoundException
  {
    this.MAX_THR_CNT=MAX_THR_CNT;
    this.PORT = PORT;
    this.svcname = svcname;
    try{
      Thread.currentThread().setName("ATMM_TM");
      this.atmdbpool = DBPool.getInstance();
      this.atmejbpool = EJBPool.getInstance();
      this.tpsvcinfo = TPSVCINFO.getInstance();
      this.atmdbpool.printStates();
      this.atmejbpool.printStates();
      this.atmhandler = new ArrayList();
      String adminserver_port = System.getProperty("adminserver_port");
      String adminserver_ip = System.getProperty("adminserver_ip");
      this.adminsrv = new ATMserveradmin(this,ComUtil.Str2Int(adminserver_port),atmdbpool,atmejbpool);
      this.atmcontrol = new ATMcontrolflow();

      for( int ii=0 ; ii<MAX_THR_CNT ; ii++ ){
        if( ii <= 9 ){
          ATMserverhandler ah = new ATMserverhandler(v_sok_fd_tbl,"ATMH_T0"+ComUtil.Int2Str(ii));
          atmhandler.add(ii,ah);
        }
        else{
          ATMserverhandler ah = new ATMserverhandler(v_sok_fd_tbl,"ATMH_T"+ComUtil.Int2Str(ii));
          atmhandler.add(ii,ah);
        }
      }
      this.serverSocket = SOCKETapi.SERVERopen(this.PORT);
      new Thread(this,"ATMH_TM").start();
    }
    catch(Exception ex){
      ex.printStackTrace();

      JLO.getInstance().eprintf(10,ex);
      System.exit(0);
    }
  }

  public DBPool getDBPool() {
    if( atmdbpool == null ){
      this.atmdbpool = DBPool.getInstance();
    }
    return this.atmdbpool;
  }

  public EJBPool getEJBPool() {
    if( atmejbpool == null ){
      this.atmejbpool = EJBPool.getInstance();
    }
    return this.atmejbpool;
  }

  public void run() {
    /////////////////////////////////////////////////////////////////////////
    // TPSVCINFO������ ����Ѵ�.
    // atmadmin�� �̿��� ���Ҷ� ����� �� �ִ� ������ ���� �ϴ� ���´�.
    // ��� ������� ���
    /////////////////////////////////////////////////////////////////////////
    //this.tpsvcinfo.start();
    this.adminsrv.start();
    this.atmcontrol.start();

    for( ; ; ){
      try{
        System.out.print("*���Ӵ����*::");
        this.u_srv_sok = SOCKETapi.SOKaccept(this.serverSocket);
        ////////////////////////////////////////////////////////////////////
        // stopmode checking
        ////////////////////////////////////////////////////////////////////
        if( this.stopmode(this.u_srv_sok) ){
          break;
        }
        ///////////////////////////////////////////////////////////////////
        // admininfo manage
        ///////////////////////////////////////////////////////////////////
        if( this.atmadmininfo(this.u_srv_sok) ){
          continue;
        }

        JLO.getInstance().printf(1,"->����:ip-:"+u_srv_sok.getInetAddress().getHostAddress());
        ////////////////////////////////////////////////////////////////////
        // connection �� �����Ѵ�.
        ////////////////////////////////////////////////////////////////////
        if( TPSVCINFO.sok_conn_manage(this.u_srv_sok ,this.MAX_THR_CNT) ){
          continue;
        }
        ///////////////////////////////////////////////////////////////////
        // server socket time out set
        ///////////////////////////////////////////////////////////////////
        this.u_srv_sok.setSoTimeout(
            ComUtil.STR2INT(
                ATMXMLconfig.getInstance().GetEnvValue("SERVICE","MAX_TIME_OUT")));

        v_sok_fd_tbl.add(this.u_srv_sok);
        synchronized (v_sok_fd_tbl) {
          v_sok_fd_tbl.notifyAll();
        }
      }
      catch(Exception ex){
        ex.printStackTrace();

        JLO.getInstance().eprintf(10,ex);
        return;
      }
    }
    JLO.getInstance().printf(1,".. ATMserver is shutdown");
    System.exit(2);

  }

  public void prnttpsvcinfo(){
    try{
      if( this.tpsvcinfo.h_client.size() > 0 )
        this.tpsvcinfo.prntCLTINFO();
    }
    catch(Exception ex)
    {
    }
  }
  public static void main(String[] args) throws Exception {
    try {
      if( args.length  > 0 ){
        JLO.getInstance().printf(1,"USAGE : Thr# Port# svcname");
        JLO.getInstance().printf(1,"          *-------------------------------------------------------*");
        JLO.getInstance().printf(1,"          * ���� ���� ���� [ATMserver]                            *");
        JLO.getInstance().printf(1,"          *-------------------------------------------------------*");
        JLO.getInstance().printf(1,"          * ATMserver: "+ args[0] +" "+ args[1] +" "+ args[2]);
        JLO.getInstance().printf(1,"          *  - svc stime: "+ ComUtil.GetSysDate() + ":�� " + ComUtil.GetSysTime().substring(0,6) +":��" );
        JLO.getInstance().printf(1,"          *-------------------------------------------------------*");
        int max_clt_cnt = ComUtil.Str2Int(args[0]);
        new ATMserver(max_clt_cnt,ComUtil.Str2Int(args[1]),args[2]);
      }
      else{
        //int max_clt_cnt = ComUtil.Str2Int(UbbConfig.getInstance().GetEnvValue("ATMserverhandler_MAX_THR_CNT"));
        int max_clt_cnt = ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("SERVICE","SERVICE01","MAX_THR_CNT"));
        //int port = ComUtil.Str2Int(UbbConfig.getInstance().GetEnvValue("ATMserver_port"));
        int port = ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("SERVICE","SERVICE01","PORT"));
        new ATMserver(max_clt_cnt,port,"ATMsvc");
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }

  private void trace(String msg)
  {
      //wsj.atm.common.wafutil.Debug.trace(getClass(),msg);
  }

  ////////////////////////////////////////////////////////////////////////////
  // atmserver forced shutdown
  // cauction 1. all client must be stoped
  // cauction 2. all transaction must be stoped
  ////////////////////////////////////////////////////////////////////////////
  public synchronized boolean stopmode(Socket sok){
    String stopatmfilename = System.getProperty("atm.admin.info") + "stopatm.xti";
    try{
      if( FILEapi.FILEexist(stopatmfilename) ){
        JLO.getInstance().printf(1,"");
        JLO.getInstance().printf(1,"............................................................");
        JLO.getInstance().printf(1," ATMserver & ATMserverhandler is going shutdown");
        JLO.getInstance().printf(1," . wait a minute " + stopatmfilename);
        JLO.getInstance().printf(1,"............................................................");
        this.setstopflag(true);
        for(int i=0;i<atmhandler.size();i++){
          ATMserverhandler ah = (ATMserverhandler)atmhandler.get(i);
          if( ah.CurThread.isAlive() ){
            int lcnt = 0;
            while( true ){
              if( ah.loc == 1 ){
                Thread.currentThread().sleep(500);
                lcnt++;
                if( lcnt >= 120 ) {
                  JLO.getInstance().printf(1,ah.getCurrentThread().getName()+".. is forced shutdown");
                  break;
                }
                continue;
              }
              else
                break;
            }
            if( ah.u_srv_sok != null ) {
              try{
                ah.is.close();
                ah.os.close();
                ah.u_srv_sok.close();
                }catch(Exception ex){}
            }
            ah.CurThread.stop();
          }
        }
        this.atmdbpool.release();
        this.atmejbpool.release();
        tpsvcinfo.stop();
        JLO.getInstance().printf(1,"............................................................");
        FILEapi.FILEdel(stopatmfilename);
        sok.close();
        return true;
      }
      else{
        this.setstopflag(false);
        return false;
      }
    }
    catch(Exception ex){return false;}
  }
  public synchronized boolean atmadmininfo(Socket sok){
    String atmadminfilename = System.getProperty("atm.admin.info")+"atmadmin.xti";
    try{
      if( FILEapi.FILEexist(atmadminfilename) ){
        JLO.getInstance().printf(1,"");
        JLO.getInstance().printf(1,"............................................................");
        JLO.getInstance().printf(1," ATMserver & ATMserverhandler infomation");
        JLO.getInstance().printf(1," . wait a minute " + atmadminfilename);
        JLO.getInstance().printf(1,"............................................................");
        this.tpsvcinfo.prntCLTINFO();
        this.tpsvcinfo.prntTHRINFO();
        FILEapi.FILEdel(atmadminfilename);
        sok.close();
        return true;
      }
      else{
        return false;
      }
    }
    catch(Exception ex){return false;}
  }
  public synchronized void setstopflag(boolean flag){
    try{
      this.stopflag = flag;
      for(int i=0;i<atmhandler.size();i++){
        ATMserverhandler ah = (ATMserverhandler)this.atmhandler.get(i);
        ah.setstopflag(flag);
      }
    }
    catch(Exception ex){}
  }
  public synchronized boolean getstopflag(){
    return this.stopflag;
  }
}
