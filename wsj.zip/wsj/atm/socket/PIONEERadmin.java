package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.util.Date;
import wsj.atm.common.*;

class PIONEERadmin extends Thread {

  public PIONEERadmin(int port) throws IOException{
    try{
    }
    catch(Exception ex){
      ex.printStackTrace();
      throw new IOException(ex.getMessage());
    }
    System.out.println("ServerSocket open success");
    new Thread(this,"PIONEERadmin").start();
    return;
  }

  public static void main(String args[]) throws IOException{
    new PIONEERadmin(ComUtil.Str2Int(args[0]));
  }

  public void run() {
    while(true){
      try{
        //=================================================================||
        Thread PIONEERthr = new Thread( new Runnable() {
          public void run(){
            while(!Thread.currentThread().isInterrupted()){
              try{
                System.out.println("---------------------------------->>>>>>");
              }
              catch(Exception ex){
                ex.printStackTrace();
                break;
              }
            }
          }
        });
        PIONEERthr.start();
        //=================================================================||
      }
      catch(Exception ex){
        ex.printStackTrace();
        break;
      }
    }
  }
}