package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class atmcmddef {

  ////////////////////////////////////////////////////////
  // �������� Ŭ���̾�Ʈ�� ������ ReqID
  ////////////////////////////////////////////////////////
  public static final String S_T = (String)"0x01";		//
  public static final String S_U = (String)"0x02";		//
  public static final String S_PR = (String)"0x03";		//
  public static final String S_PT = (String)"0x04";		//
  public static final String S_SUCCESS = "0x05";

  ////////////////////////////////////////////////////////
  // Ŭ���̾�Ʈ���� ������ ������ ReqID
  ////////////////////////////////////////////////////////
  public static final String C_SHUTDOWN = (String)"0x01";		// ATMserver shutdown �䱸
  public static final String C_TPSVCINFO = (String)"0x02";		// ATMserver tpsvcinfo �䱸

  public static final String C_PR = (String)"0x03";		//
  public static final String C_PT = (String)"0x04";		//
  public static final String C_TCPCALLEJBCHK = (String)"0x05";
  public static final String C_DBPOOLCHK = (String)"0x06";
  public static final String C_REINITIAL_TCPCALLEJB = (String)"0x07";

}

