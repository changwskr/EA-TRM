package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.io.*;
import java.text.*;
import java.net.*;
import wsj.atm.common.ComUtil;
import wsj.atm.common.SOCKETapi;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;

public class TPSVCINFO extends Thread{
  private static TPSVCINFO instance;
  public static Hashtable h_client = new Hashtable();
  public static Hashtable h_thread = new Hashtable();
  private static int sok_conn_cli_cnt=0;
  public StringBuffer sb;

  public TPSVCINFO() {
  }


  //////////////////////////////////////////////////////////////////////////////
  // Ŭ���̾�Ʈ ���� ����
  //////////////////////////////////////////////////////////////////////////////
  public static synchronized void sok_conn_add(){
    TPSVCINFO.sok_conn_cli_cnt++;
  }
  public static synchronized void sok_conn_minus(){
    TPSVCINFO.sok_conn_cli_cnt--;
  }
  public static synchronized int get_sok_conn(){
    return TPSVCINFO.sok_conn_cli_cnt;
  }
  public static synchronized boolean sok_conn_manage(Socket sok,int max_thr_cnt){
    if( TPSVCINFO.get_sok_conn() >= max_thr_cnt ){
      JLO.printf(1,"############# ���� ���Ͽ���  ����  : " + TPSVCINFO.get_sok_conn() );
      JLO.printf(1,"############# ���� ���������� ���� : " + max_thr_cnt);
      JLO.printf(1,"############# ���� ������ ���� �����մϴ� : ");

      System.out.println("############# ���� ���Ͽ���  ����  : " + TPSVCINFO.get_sok_conn() );
      System.out.println("############# ���� ���������� ���� : " + max_thr_cnt);
      System.out.println("############# ���� ������ ���� �����մϴ� : ");

      try{
        sok.close();
      }
      catch(Exception ex){
      }
      return true;
    }
    else
      return false;
  }
  //////////////////////////////////////////////////////////////////////////////

  public static synchronized TPSVCINFO getInstance() {
    if (instance == null) {
      try{
        instance = new TPSVCINFO();
      }catch(Exception igex){
        JLO.getInstance().eprintf(10,igex);
        throw new RuntimeException();
      }
    }
    return instance;
  }
  ///////////////////////////////////////////////////////////////////////////
  // Thread INFO
  ///////////////////////////////////////////////////////////////////////////
  public synchronized void addThread(Object process,String key) throws Exception {
    if( existThread(key)){
      Object t = (Object)getThread(key);
      t = process;
    }
    else{
      h_thread.put(key,process);
    }
  }
  public synchronized Object getThread(String key){
    if( existThread(key) )
      return( (Object)h_thread.get(key) );
    else
      return null;
  }
  public synchronized boolean existThread(String key){
    if( h_thread.containsKey(key) )
      return true;
    else
      return false;
  }
  public synchronized boolean delThread(String key){
    if( existThread(key) ){
      h_thread.remove(key);
      return true;
    }
    else
      return false;
  }
  public synchronized boolean updateaddThread(Object process,String key) throws Exception {
    if( this.existThread(key) ){
      Object ti2 = (Object)this.getThread(key);
      THRINFO thrinfo = (THRINFO)process;
      THRINFO thrinfo2 = (THRINFO)ti2;
      return true;
    }
    else{
      /////////////////////////////////////////////////////////////////////////
      // ���ʻ��Ը�
      /////////////////////////////////////////////////////////////////////////
      THRINFO thrinfo = (THRINFO)process;
      this.addThread(process,key);
      return true;
    }
  }
  public static synchronized void updateaddThread(THRINFO thrinfo,Socket sok,Vector vc_tbl_sok,IOBoundArea in)
      throws Exception
  {
    /*
    if( in.cdto.eventNo.equals("80010") )
      return;
    */


    if( !ATMserver.tpsvcinfo.existThread(Thread.currentThread().getName()) )
    {
      ////////////////////////////////////////////////////////////////////////
      // ���ʰŷ��̹Ƿ� ���������� �����Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      thrinfo.setSocket(sok);
      thrinfo.setSrtTime();
      thrinfo.setSystemDate(ComUtil.GetSysDate());
      thrinfo.setTeller_id(in.cdto.userId);
      thrinfo.setKey(Thread.currentThread().getName());
      thrinfo.setThread(Thread.currentThread());
      thrinfo.setSrtOffset(false);
      thrinfo.addTxcnt(in);
      thrinfo.addLiveseq();
      thrinfo.setExitflag(false);
      //������ �ʿ���� ������ ������.
      //thrinfo.setVector(vc_tbl_sok);
      ATMserver.tpsvcinfo.addThread(thrinfo,thrinfo.getThreadName());
    }
    else
    {
      ////////////////////////////////////////////////////////////////////////
      // ���ʰŷ��� �ƴϹǷ� �ؽ��� �������� �����Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      THRINFO hthrinfo = (THRINFO)ATMserver.tpsvcinfo.getThread((String)Thread.currentThread().getName());
      if( !hthrinfo.getSystemDate().equals(ComUtil.GetSysDate()) ){
        hthrinfo.setZeroTrxCnt();
        hthrinfo.setExitflag(false);
        hthrinfo.setSystemDate(ComUtil.GetSysDate());
        hthrinfo.setSrtTime();
      }
      if( !sok.equals(hthrinfo.getSocket()) ){
        hthrinfo.setSocket(sok);
      }
      if( !(sok==hthrinfo.getSocket())){
        hthrinfo.setSocket(sok);
      }
      hthrinfo.setSocket(sok);
      hthrinfo.setKey(Thread.currentThread().getName());
      hthrinfo.setThread(Thread.currentThread());
      hthrinfo.addTxcnt(in);
      thrinfo = hthrinfo;
    }
  }

  public static synchronized void updateaddThread(THRINFO thrinfo,IOBoundArea in)
      throws Exception
  {
    /*
    if( in.cdto.eventNo.equals("80010") )
      return;
    if( in.cdto.userId == null || in.cdto.userId.equals("          ") || in.cdto.userId.equals("**********"))
      return ;
    */

    ////////////////////////////////////////////////////////////////////////
    // ATM�� ������ �ŷ� ����/���� ������ �����Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    thrinfo.addSETxcnt(in);
    ////////////////////////////////////////////////////////////////////////
    // ATM�� ���� ���� �ڱ��μ��� ������ �����Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    thrinfo.updateBizmanage(in);
  }

  ///////////////////////////////////////////////////////////////////////////
  // CLIENT INFO
  ///////////////////////////////////////////////////////////////////////////
  public synchronized void addClient(Object process,String key) throws Exception {
    if( existClient(key)){
      Object t = (Object)getClient(key);
      t = process;
    }
    else{
      h_client.put(key,process);
    }
  }
  public synchronized Object getClient(String key){
    if( existClient(key) )
      return( (Object)h_client.get(key) );
    else
      return null;
  }
  public synchronized boolean existClient(String key){
    if( h_client.containsKey(key) )
      return true;
    else
      return false;
  }
  public synchronized boolean delClient(String key){
    if( existClient(key) ){
      h_client.remove(key);
      return true;
    }
    else
      return false;
  }
  public synchronized boolean updateaddClient(Object process,String key) throws Exception {
    if( this.existClient(key) ){
      Object ti2 = (Object)this.getClient(key);
      CLTINFO cltinfo = (CLTINFO)process;
      CLTINFO cltinfo2 = (CLTINFO)ti2;
      return true;
    }
    else{
      /////////////////////////////////////////////////////////////////////////
      // ���ʻ��Ը�
      /////////////////////////////////////////////////////////////////////////
      CLTINFO cltinfo = (CLTINFO)process;
      this.addClient(process,key);
      return true;
    }
  }
  public static synchronized void updateaddClient(CLTINFO pcltinfo,Socket sok,IOBoundArea in)
      throws Exception
  {
    CLTINFO cltinfo = null;
    if( pcltinfo != null )
      cltinfo = pcltinfo;
    else
      cltinfo = new CLTINFO();

    if( in.cdto.eventNo.equals("80010") )
      return;
    if( in.cdto.userId == null || in.cdto.userId.equals("          ") || in.cdto.userId.equals("**********"))
      return ;

    if( !ATMserver.tpsvcinfo.existClient(in.cdto.userId) )
    {
      ////////////////////////////////////////////////////////////////////////
      // ���ʰŷ��̹Ƿ� ���������� �����Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      cltinfo.setKey(in.cdto.userId);
      cltinfo.setSocket(sok);
      cltinfo.setSrtTime();
      cltinfo.setSystemDate(ComUtil.GetSysDate());
      cltinfo.setTeller_id(in.cdto.userId);
      cltinfo.setThread(Thread.currentThread());
      cltinfo.setSrtOffset(false);
      cltinfo.addTxcnt(in);
      cltinfo.addLiveseq();
      cltinfo.setExitflag(false);

      ATMserver.tpsvcinfo.addClient(cltinfo,in.cdto.userId);
    }
    else
    {
      ////////////////////////////////////////////////////////////////////////
      // ���ʰŷ��� �ƴϹǷ� �ؽ��� �������� �����Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient((String)in.cdto.userId);
      if( !cltinfo.getSystemDate().equals(ComUtil.GetSysDate()) ){
        cltinfo.setZeroTrxCnt();
        cltinfo.setExitflag(false);
        cltinfo.setSystemDate(ComUtil.GetSysDate());
        cltinfo.setSrtTime();
      }
      if( !sok.equals(cltinfo.getSocket()) ){
        cltinfo.setSocket(sok);
        cltinfo.addLiveseq();
      }
      cltinfo.setKey(in.cdto.userId);
      cltinfo.setThread(Thread.currentThread());
      cltinfo.addTxcnt(in);
    }
  }

  public static synchronized void updateaddClient(CLTINFO cltinfo,IOBoundArea in)
      throws Exception
  {
    if( in.cdto.eventNo.equals("80010") )
      return;
    if( in.cdto.userId == null || in.cdto.userId.equals("          ") || in.cdto.userId.equals("**********"))
      return ;

    ////////////////////////////////////////////////////////////////////////
    // ATM�� ������ �ŷ� ����/���� ������ �����Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    cltinfo.addSETxcnt(in);
    ////////////////////////////////////////////////////////////////////////
    // ATM�� ���� ���� �ڱ��μ��� ������ �����Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    cltinfo.updateBizmanage(in);
  }

  public synchronized void prntCLTINFO2() {
    this.sb = null;
    this.sb = new StringBuffer();

    sb.append("===============================================================\n");
    sb.append("|                        C L T I N F O                        |\n");
    sb.append("===============================================================\n");
    sb.append("ATMserver.tpsvcinfo.h_client:"+ATMserver.tpsvcinfo.h_client.size()+"\n");
    for(Enumeration eti=ATMserver.tpsvcinfo.h_client.keys(); eti.hasMoreElements(); ){
      String mkey = eti.nextElement().toString();
      if( mkey == null || mkey.charAt(0) == ' ' )
        continue ;

      CLTINFO ti = (CLTINFO)ATMserver.tpsvcinfo.h_client.get(mkey);
      sb.append( "key               : [" + ti.getKey() + "]\n");
      sb.append( "Thread:           : [" + ti.getThread().getName() + "]\n");
      sb.append( "Socket sok        : [" + ti.getSocket() + "]\n");
      sb.append( "cli_ip            : [" + ti.getIP() + "]\n");
      sb.append( "cli_port          : [" + ti.getPORT()  + "]\n");
      sb.append( "teller_id         : [" + ti.getTeller_id() + "]\n");
      sb.append( "start_time        : [" + ti.getSrtTime()  + "]\n");
      sb.append( "systemdate        : [" + ti.getSystemDate()  + "]\n");
      sb.append( "sijae_openoffset  : [" + ti.sijae_openoffset   + "]\n");
      sb.append( "sijae_closeoffset : [" + ti.sijae_closeoffset  + "]\n");
      sb.append( "login_offset      : [" + ti.login_offset  + "]\n");
      sb.append( "liveseq           : [" + ti.getLiveseq() + "]\n");
      sb.append( "srtOffset         : [" + ti.getSrtOffset()  + "]\n");
      sb.append( "exitFlag          : [" + ti.getExitflag()  + "]\n");
      sb.append( "evt80000_txcnt    : [" + ti.getTxcnt(80000) + "]" + " S:["+ti.tc80000_scnt+"]" + " E:["+ti.tc80000_ecnt+"]\n");
      sb.append( "evt80001_txcnt    : [" + ti.getTxcnt(80001) + "]" + " S:["+ti.tc80001_scnt+"]" + " E:["+ti.tc80001_ecnt+"]\n");
      sb.append( "evt80002_txcnt    : [" + ti.getTxcnt(80002) + "]" + " S:["+ti.tc80002_scnt+"]" + " E:["+ti.tc80002_ecnt+"]\n");
      sb.append( "evt80003_txcnt    : [" + ti.getTxcnt(80003) + "]" + " S:["+ti.tc80003_scnt+"]" + " E:["+ti.tc80003_ecnt+"]\n");
      sb.append( "evt80004_txcnt    : [" + ti.getTxcnt(80004) + "]" + " S:["+ti.tc80004_scnt+"]" + " E:["+ti.tc80004_ecnt+"]\n");
      sb.append( "evt80005_txcnt    : [" + ti.getTxcnt(80005) + "]" + " S:["+ti.tc80005_scnt+"]" + " E:["+ti.tc80005_ecnt+"]\n");
      sb.append( "evt80006_txcnt    : [" + ti.getTxcnt(80006) + "]" + " S:["+ti.tc80006_scnt+"]" + " E:["+ti.tc80006_ecnt+"]\n");
      sb.append( "evt80007_txcnt    : [" + ti.getTxcnt(80007) + "]" + " S:["+ti.tc80007_scnt+"]" + " E:["+ti.tc80007_ecnt+"]\n");
      sb.append( "evt80008_txcnt    : [" + ti.getTxcnt(80008) + "]" + " S:["+ti.tc80008_scnt+"]" + " E:["+ti.tc80008_ecnt+"]\n");
      sb.append( "evt80009_txcnt    : [" + ti.getTxcnt(80009) + "]" + " S:["+ti.tc80009_scnt+"]" + " E:["+ti.tc80009_ecnt+"]\n");
      sb.append( "evt80010_txcnt    : [" + ti.getTxcnt(80010) + "]" + " S:["+ti.tc80010_scnt+"]" + " E:["+ti.tc80010_ecnt+"]\n");
      sb.append( "evt80011_txcnt    : [" + ti.getTxcnt(80011) + "]" + " S:["+ti.tc80011_scnt+"]" + " E:["+ti.tc80011_ecnt+"]\n");
      sb.append( "evt80012_txcnt    : [" + ti.getTxcnt(80012) + "]" + " S:["+ti.tc80012_scnt+"]" + " E:["+ti.tc80012_ecnt+"]\n");
      sb.append( "evt80013_txcnt    : [" + ti.getTxcnt(80013) + "]" + " S:["+ti.tc80013_scnt+"]" + " E:["+ti.tc80013_ecnt+"]\n");
      sb.append( "evt80014_txcnt    : [" + ti.getTxcnt(80014) + "]" + " S:["+ti.tc80014_scnt+"]" + " E:["+ti.tc80014_ecnt+"]\n");
      sb.append( "evt80015_txcnt    : [" + ti.getTxcnt(80015) + "]" + " S:["+ti.tc80015_scnt+"]" + " E:["+ti.tc80015_ecnt+"]\n");
      sb.append( "evt80016_txcnt    : [" + ti.getTxcnt(80016) + "]" + " S:["+ti.tc80016_scnt+"]" + " E:["+ti.tc80016_ecnt+"]\n");
      sb.append( "evt80017_txcnt    : [" + ti.getTxcnt(80017) + "]" + " S:["+ti.tc80017_scnt+"]" + " E:["+ti.tc80017_ecnt+"]\n");
      sb.append( "evt80018_txcnt    : [" + ti.getTxcnt(80018) + "]" + " S:["+ti.tc80018_scnt+"]" + " E:["+ti.tc80018_ecnt+"]\n");
      sb.append( "evt80019_txcnt    : [" + ti.getTxcnt(80019) + "]" + " S:["+ti.tc80019_scnt+"]" + " E:["+ti.tc80019_ecnt+"]\n");
      sb.append( "evt80020_txcnt    : [" + ti.getTxcnt(80020) + "]" + " S:["+ti.tc80020_scnt+"]" + " E:["+ti.tc80020_ecnt+"]\n");
      sb.append( "txcnt             : [" + ti.getTxcnt(100000)  + "]\n");
      sb.append("===============================================================\n");
    }
    sb.append("===============================================================\n");
  }

  public synchronized void prntCLTINFO() {

    JLO.getInstance().debuging(3,"===============================================================");
    JLO.getInstance().debuging(3,"|                        C L T I N F O                        |");
    JLO.getInstance().debuging(3,"===============================================================");
    for(Enumeration eti=ATMserver.tpsvcinfo.h_client.keys(); eti.hasMoreElements(); ){
      String mkey = eti.nextElement().toString();
      if( mkey == null || mkey.charAt(0) == ' ' )
        continue ;

      CLTINFO ti = (CLTINFO)ATMserver.tpsvcinfo.h_client.get(mkey);

      JLO.getInstance().debuging(3, "key               : [" + ti.getKey() + "]" );
      JLO.getInstance().debuging(3, "Thread:           : [" + ti.getThread().getName() + "]" );
      JLO.getInstance().debuging(3, "Socket sok        : [" + ti.getSocket() + "]" );
      JLO.getInstance().debuging(3, "cli_ip            : [" + ti.getIP() + "]" );
      JLO.getInstance().debuging(3, "cli_port          : [" + ti.getPORT()  + "]" );
      JLO.getInstance().debuging(3, "teller_id         : [" + ti.getTeller_id() + "]" );
      JLO.getInstance().debuging(3, "start_time        : [" + ti.getSrtTime()  + "]" );
      JLO.getInstance().debuging(3, "systemdate        : [" + ti.getSystemDate()  + "]" );
      JLO.getInstance().debuging(3, "sijae_openoffset  : [" + ti.sijae_openoffset   + "]" );
      JLO.getInstance().debuging(3, "sijae_closeoffset : [" + ti.sijae_closeoffset  + "]" );
      JLO.getInstance().debuging(3, "login_offset      : [" + ti.login_offset  + "]" );
      JLO.getInstance().debuging(3, "liveseq           : [" + ti.getLiveseq() + "]" );
      JLO.getInstance().debuging(3, "srtOffset         : [" + ti.getSrtOffset()  + "]" );
      JLO.getInstance().debuging(3, "exitFlag          : [" + ti.getExitflag()  + "]" );
      JLO.getInstance().debuging(3, "evt80000_txcnt    : [" + ti.getTxcnt(80000) + "]" + " S:["+ti.tc80000_scnt+"]" + " E:["+ti.tc80000_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80001_txcnt    : [" + ti.getTxcnt(80001) + "]" + " S:["+ti.tc80001_scnt+"]" + " E:["+ti.tc80001_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80002_txcnt    : [" + ti.getTxcnt(80002) + "]" + " S:["+ti.tc80002_scnt+"]" + " E:["+ti.tc80002_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80003_txcnt    : [" + ti.getTxcnt(80003) + "]" + " S:["+ti.tc80003_scnt+"]" + " E:["+ti.tc80003_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80004_txcnt    : [" + ti.getTxcnt(80004) + "]" + " S:["+ti.tc80004_scnt+"]" + " E:["+ti.tc80004_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80005_txcnt    : [" + ti.getTxcnt(80005) + "]" + " S:["+ti.tc80005_scnt+"]" + " E:["+ti.tc80005_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80006_txcnt    : [" + ti.getTxcnt(80006) + "]" + " S:["+ti.tc80006_scnt+"]" + " E:["+ti.tc80006_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80007_txcnt    : [" + ti.getTxcnt(80007) + "]" + " S:["+ti.tc80007_scnt+"]" + " E:["+ti.tc80007_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80008_txcnt    : [" + ti.getTxcnt(80008) + "]" + " S:["+ti.tc80008_scnt+"]" + " E:["+ti.tc80008_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80009_txcnt    : [" + ti.getTxcnt(80009) + "]" + " S:["+ti.tc80009_scnt+"]" + " E:["+ti.tc80009_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80010_txcnt    : [" + ti.getTxcnt(80010) + "]" + " S:["+ti.tc80010_scnt+"]" + " E:["+ti.tc80010_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80011_txcnt    : [" + ti.getTxcnt(80011) + "]" + " S:["+ti.tc80011_scnt+"]" + " E:["+ti.tc80011_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80012_txcnt    : [" + ti.getTxcnt(80012) + "]" + " S:["+ti.tc80012_scnt+"]" + " E:["+ti.tc80012_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80013_txcnt    : [" + ti.getTxcnt(80013) + "]" + " S:["+ti.tc80013_scnt+"]" + " E:["+ti.tc80013_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80014_txcnt    : [" + ti.getTxcnt(80014) + "]" + " S:["+ti.tc80014_scnt+"]" + " E:["+ti.tc80014_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80015_txcnt    : [" + ti.getTxcnt(80015) + "]" + " S:["+ti.tc80015_scnt+"]" + " E:["+ti.tc80015_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80016_txcnt    : [" + ti.getTxcnt(80016) + "]" + " S:["+ti.tc80016_scnt+"]" + " E:["+ti.tc80016_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80017_txcnt    : [" + ti.getTxcnt(80017) + "]" + " S:["+ti.tc80017_scnt+"]" + " E:["+ti.tc80017_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80018_txcnt    : [" + ti.getTxcnt(80018) + "]" + " S:["+ti.tc80018_scnt+"]" + " E:["+ti.tc80018_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80019_txcnt    : [" + ti.getTxcnt(80019) + "]" + " S:["+ti.tc80019_scnt+"]" + " E:["+ti.tc80019_ecnt+"]"  );
      JLO.getInstance().debuging(3, "evt80020_txcnt    : [" + ti.getTxcnt(80020) + "]" + " S:["+ti.tc80020_scnt+"]" + " E:["+ti.tc80020_ecnt+"]"  );
      JLO.getInstance().debuging(3, "txcnt             : [" + ti.getTxcnt(100000)  + "]" );
      JLO.getInstance().debuging(3,"===============================================================");
    }
    JLO.getInstance().debuging(3,"===============================================================");
  }

  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }
  public void run() {
    Thread.currentThread().setName("TPSVCINFO");
    while(true){
      try{
        ATMserver.atmdbpool.printInfo();
        ATMserver.atmejbpool.printInfo();
        this.prntCLTINFO();
        this.prntTHRINFO();
        //CPD(CosesProxyDaemon)�� thread isLive ����
        this.isLiveNStart();
        //CDP���� ������ ȯ�������� SecondMaster�� ������ �����Ѵ�.
        //Thread.currentThread().sleep(ComUtil.Str2Int(UbbConfig.getInstance().GetEnvValue("TPSVCINFO_LOOP_SEC")));
        Thread.currentThread().sleep(ComUtil.Str2Int(ATMXMLconfig.getInstance().GetEnvValue("RESOURCE","TPSVCINFO_LOOP_SEC")));
      }
      catch(Exception ex){
        ex.printStackTrace();
      }
    }
  }
  public boolean isLiveNStart(){
    try{
      for(Enumeration eti=ATMserver.tpsvcinfo.h_thread.keys(); eti.hasMoreElements(); ){
       String mkey = eti.nextElement().toString();
       THRINFO ti = (THRINFO)ATMserver.tpsvcinfo.h_thread.get(mkey);
       // ���� ���ξ����尡 ���� ��쿡�� ��� �����尡 Daemon���� �����ϱ� �ʾұ� ������
       // shutdown�ǹǷ� ������ �ʿ䰡 ����.
       if( ti.getThreadName().equals("ATMH_TM") ){
         continue;
       }
       if( !ti.getThread().isAlive() ){
         JLO.getInstance().debuging(4,"% " +ti.getKey()+" -> thread is died " + ti.getThread().isAlive());
         ATMserverhandler handler = new ATMserverhandler(ti.getVector(),ti.getThreadName());
         ATMserver.tpsvcinfo.delThread(mkey);
       }
      }
   }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
    return true;
  }

  public synchronized void prntTHRINFO2() {
    this.sb = null;
    this.sb = new StringBuffer();

    sb.append("#\n");
    sb.append("#\n");
    sb.append("#\n");
    sb.append("###############################################################\n");
    sb.append("|                        T H  R I N F O                        |\n");
    sb.append("===============================================================\n");
    sb.append("ATMserver.tpsvcinfo.h_thread:"+ATMserver.tpsvcinfo.h_thread.size()+"\n");

    for(Enumeration eti=ATMserver.tpsvcinfo.h_thread.keys(); eti.hasMoreElements(); ){
      String mkey = eti.nextElement().toString();
      if( mkey == null || mkey.charAt(0) == ' ' )
        continue ;

      THRINFO ti = (THRINFO)ATMserver.tpsvcinfo.h_thread.get(mkey);
      sb.append( "key               : [" + ti.getKey() + "]\n");
      sb.append( "Thread:           : [" + ti.getThread().getName() + "]\n");
      sb.append( "Thread Live       : [" + ti.getThread().isAlive() + "]\n");
      sb.append( "Socket sok        : [" + ti.getSocket() + "]\n");
      sb.append( "cli_ip            : [" + ti.getIP() + "]\n");
      sb.append( "cli_port          : [" + ti.getPORT()  + "]\n");
      sb.append( "start_time        : [" + ti.getSrtTime()  + "]\n");
      sb.append( "systemdate        : [" + ti.getSystemDate()  + "]\n");
      sb.append( "liveseq           : [" + ti.getLiveseq() + "]\n");
      sb.append( "evt80000_txcnt    : [" + ti.getTxcnt(80000) + "]" + " S:["+ti.tc80000_scnt+"]" + " E:["+ti.tc80000_ecnt+"]\n");
      sb.append( "evt80001_txcnt    : [" + ti.getTxcnt(80001) + "]" + " S:["+ti.tc80001_scnt+"]" + " E:["+ti.tc80001_ecnt+"]\n");
      sb.append( "evt80002_txcnt    : [" + ti.getTxcnt(80002) + "]" + " S:["+ti.tc80002_scnt+"]" + " E:["+ti.tc80002_ecnt+"]\n");
      sb.append( "evt80003_txcnt    : [" + ti.getTxcnt(80003) + "]" + " S:["+ti.tc80003_scnt+"]" + " E:["+ti.tc80003_ecnt+"]\n");
      sb.append( "evt80004_txcnt    : [" + ti.getTxcnt(80004) + "]" + " S:["+ti.tc80004_scnt+"]" + " E:["+ti.tc80004_ecnt+"]\n");
      sb.append( "evt80005_txcnt    : [" + ti.getTxcnt(80005) + "]" + " S:["+ti.tc80005_scnt+"]" + " E:["+ti.tc80005_ecnt+"]\n");
      sb.append( "evt80006_txcnt    : [" + ti.getTxcnt(80006) + "]" + " S:["+ti.tc80006_scnt+"]" + " E:["+ti.tc80006_ecnt+"]\n");
      sb.append( "evt80007_txcnt    : [" + ti.getTxcnt(80007) + "]" + " S:["+ti.tc80007_scnt+"]" + " E:["+ti.tc80007_ecnt+"]\n");
      sb.append( "evt80008_txcnt    : [" + ti.getTxcnt(80008) + "]" + " S:["+ti.tc80008_scnt+"]" + " E:["+ti.tc80008_ecnt+"]\n");
      sb.append( "evt80009_txcnt    : [" + ti.getTxcnt(80009) + "]" + " S:["+ti.tc80009_scnt+"]" + " E:["+ti.tc80009_ecnt+"]\n");
      sb.append( "evt80010_txcnt    : [" + ti.getTxcnt(80010) + "]" + " S:["+ti.tc80010_scnt+"]" + " E:["+ti.tc80010_ecnt+"]\n");
      sb.append( "evt80011_txcnt    : [" + ti.getTxcnt(80011) + "]" + " S:["+ti.tc80011_scnt+"]" + " E:["+ti.tc80011_ecnt+"]\n");
      sb.append( "evt80012_txcnt    : [" + ti.getTxcnt(80012) + "]" + " S:["+ti.tc80012_scnt+"]" + " E:["+ti.tc80012_ecnt+"]\n");
      sb.append( "evt80013_txcnt    : [" + ti.getTxcnt(80013) + "]" + " S:["+ti.tc80013_scnt+"]" + " E:["+ti.tc80013_ecnt+"]\n");
      sb.append( "evt80014_txcnt    : [" + ti.getTxcnt(80014) + "]" + " S:["+ti.tc80014_scnt+"]" + " E:["+ti.tc80014_ecnt+"]\n");
      sb.append( "evt80015_txcnt    : [" + ti.getTxcnt(80015) + "]" + " S:["+ti.tc80015_scnt+"]" + " E:["+ti.tc80015_ecnt+"]\n");
      sb.append( "evt80016_txcnt    : [" + ti.getTxcnt(80016) + "]" + " S:["+ti.tc80016_scnt+"]" + " E:["+ti.tc80016_ecnt+"]\n");
      sb.append( "evt80017_txcnt    : [" + ti.getTxcnt(80017) + "]" + " S:["+ti.tc80017_scnt+"]" + " E:["+ti.tc80017_ecnt+"]\n");
      sb.append( "evt80018_txcnt    : [" + ti.getTxcnt(80018) + "]" + " S:["+ti.tc80018_scnt+"]" + " E:["+ti.tc80018_ecnt+"]\n");
      sb.append( "evt80019_txcnt    : [" + ti.getTxcnt(80019) + "]" + " S:["+ti.tc80019_scnt+"]" + " E:["+ti.tc80019_ecnt+"]\n");
      sb.append( "evt80020_txcnt    : [" + ti.getTxcnt(80020) + "]" + " S:["+ti.tc80020_scnt+"]" + " E:["+ti.tc80020_ecnt+"]\n");
      sb.append( "txcnt             : [" + ti.getTxcnt(100000)  + "]\n");
      sb.append("===============================================================\n");
    }
    sb.append("===============================================================\n");
  }

  public synchronized void prntTHRINFO() {
    JLO.getInstance().debuging(4,"#");
    JLO.getInstance().debuging(4,"#");
    JLO.getInstance().debuging(4,"#");
    JLO.getInstance().debuging(4,"###############################################################");
    JLO.getInstance().debuging(4,"|                        T H  R I N F O                        |");
    JLO.getInstance().debuging(4,"===============================================================");

    for(Enumeration eti=ATMserver.tpsvcinfo.h_thread.keys(); eti.hasMoreElements(); ){
      String mkey = eti.nextElement().toString();
      if( mkey == null || mkey.charAt(0) == ' ' )
        continue ;

      THRINFO ti = (THRINFO)ATMserver.tpsvcinfo.h_thread.get(mkey);
      JLO.getInstance().debuging(4, "key               : [" + ti.getKey() + "]" );
      JLO.getInstance().debuging(4, "Thread:           : [" + ti.getThread().getName() + "]" );
      JLO.getInstance().debuging(4, "Thread Live       : [" + ti.getThread().isAlive() + "]" );
      JLO.getInstance().debuging(4, "Socket sok        : [" + ti.getSocket() + "]" );
      JLO.getInstance().debuging(4, "cli_ip            : [" + ti.getIP() + "]" );
      JLO.getInstance().debuging(4, "cli_port          : [" + ti.getPORT()  + "]" );
      JLO.getInstance().debuging(4, "start_time        : [" + ti.getSrtTime()  + "]" );
      JLO.getInstance().debuging(4, "systemdate        : [" + ti.getSystemDate()  + "]" );
      JLO.getInstance().debuging(4, "liveseq           : [" + ti.getLiveseq() + "]" );
      JLO.getInstance().debuging(4, "evt80000_txcnt    : [" + ti.getTxcnt(80000) + "]" + " S:["+ti.tc80000_scnt+"]" + " E:["+ti.tc80000_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80001_txcnt    : [" + ti.getTxcnt(80001) + "]" + " S:["+ti.tc80001_scnt+"]" + " E:["+ti.tc80001_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80002_txcnt    : [" + ti.getTxcnt(80002) + "]" + " S:["+ti.tc80002_scnt+"]" + " E:["+ti.tc80002_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80003_txcnt    : [" + ti.getTxcnt(80003) + "]" + " S:["+ti.tc80003_scnt+"]" + " E:["+ti.tc80003_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80004_txcnt    : [" + ti.getTxcnt(80004) + "]" + " S:["+ti.tc80004_scnt+"]" + " E:["+ti.tc80004_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80005_txcnt    : [" + ti.getTxcnt(80005) + "]" + " S:["+ti.tc80005_scnt+"]" + " E:["+ti.tc80005_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80006_txcnt    : [" + ti.getTxcnt(80006) + "]" + " S:["+ti.tc80006_scnt+"]" + " E:["+ti.tc80006_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80007_txcnt    : [" + ti.getTxcnt(80007) + "]" + " S:["+ti.tc80007_scnt+"]" + " E:["+ti.tc80007_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80008_txcnt    : [" + ti.getTxcnt(80008) + "]" + " S:["+ti.tc80008_scnt+"]" + " E:["+ti.tc80008_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80009_txcnt    : [" + ti.getTxcnt(80009) + "]" + " S:["+ti.tc80009_scnt+"]" + " E:["+ti.tc80009_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80010_txcnt    : [" + ti.getTxcnt(80010) + "]" + " S:["+ti.tc80010_scnt+"]" + " E:["+ti.tc80010_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80011_txcnt    : [" + ti.getTxcnt(80011) + "]" + " S:["+ti.tc80011_scnt+"]" + " E:["+ti.tc80011_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80012_txcnt    : [" + ti.getTxcnt(80012) + "]" + " S:["+ti.tc80012_scnt+"]" + " E:["+ti.tc80012_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80013_txcnt    : [" + ti.getTxcnt(80013) + "]" + " S:["+ti.tc80013_scnt+"]" + " E:["+ti.tc80013_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80014_txcnt    : [" + ti.getTxcnt(80014) + "]" + " S:["+ti.tc80014_scnt+"]" + " E:["+ti.tc80014_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80015_txcnt    : [" + ti.getTxcnt(80015) + "]" + " S:["+ti.tc80015_scnt+"]" + " E:["+ti.tc80015_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80016_txcnt    : [" + ti.getTxcnt(80016) + "]" + " S:["+ti.tc80016_scnt+"]" + " E:["+ti.tc80016_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80017_txcnt    : [" + ti.getTxcnt(80017) + "]" + " S:["+ti.tc80017_scnt+"]" + " E:["+ti.tc80017_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80018_txcnt    : [" + ti.getTxcnt(80018) + "]" + " S:["+ti.tc80018_scnt+"]" + " E:["+ti.tc80018_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80019_txcnt    : [" + ti.getTxcnt(80019) + "]" + " S:["+ti.tc80019_scnt+"]" + " E:["+ti.tc80019_ecnt+"]"  );
      JLO.getInstance().debuging(4, "evt80020_txcnt    : [" + ti.getTxcnt(80020) + "]" + " S:["+ti.tc80020_scnt+"]" + " E:["+ti.tc80020_ecnt+"]"  );
      JLO.getInstance().debuging(4, "txcnt             : [" + ti.getTxcnt(100000)  + "]" );
      JLO.getInstance().debuging(4,"===============================================================");
    }
    JLO.getInstance().debuging(4,"===============================================================");
  }
}