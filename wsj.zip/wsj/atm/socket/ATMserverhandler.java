package wsj.atm.socket;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.text.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.common.SOCKETapi;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
//import wsj.atm.common.wafutil.Debug;
import wsj.atm.bound.BoundArea;
import wsj.atm.tcf.TCF;
import wsj.atm.common.EnvPropertySaving;
import wsj.atm.ejb.EJBPool;

public class ATMserverhandler extends Thread {
  private Vector v_sok_fd_tbl;
  public String name;
  public Thread CurThread;
  public boolean connectFlagOffSet=false;
  private boolean stopflag=false;

  public Socket u_srv_sok=null;
  public InputStream is;
  public OutputStream os;
  private int PORT;
  private CLTINFO cltinfo;
  private THRINFO thrinfo;
  private EJBPool atmejbpool;

  private int atmserverlivecnt=0;
  public int loc=0;
  ////////////////////////////////////////////////////////////////////////////
  // �α��ΰŷ��ü� ������� BoundArea�� �����ϰ� �ִ´�.
  ////////////////////////////////////////////////////////////////////////////
  public static BoundArea login_boundarea;

  public ATMserverhandler(Vector v_sok_fd_tbl,String name) throws IOException {
    try{
      this.v_sok_fd_tbl = v_sok_fd_tbl;
      this.name = name;
      this.connectFlagOffSet=false;
      this.cltinfo = new CLTINFO();
      this.thrinfo = new THRINFO();
      this.atmejbpool = ATMserver.atmejbpool;
      this.start();
    }
    catch(Exception ex){
      ex.printStackTrace();

      JLO.getInstance().eprintf(10,ex);
      throw new IOException();
    }
  }

  public THRINFO getTHRINFO(){
    return this.thrinfo;
  }
  public Thread getCurrentThread() {
    return this.CurThread;
  }
  public void run() {
    Thread.currentThread().setName(this.name);
    this.loc = 0;
    this.CurThread=Thread.currentThread();
    for ( ; ; ) {
      this.loc = 0;
      connectFlagOffSet=false;
      synchronized (v_sok_fd_tbl) {
        while (v_sok_fd_tbl.isEmpty()) {
          try {
            v_sok_fd_tbl.wait();
          }
          catch (InterruptedException ex) {
          }
        }
        try{
          Object o = v_sok_fd_tbl.remove(0);
          this.u_srv_sok=(Socket)o;
          this.is = this.u_srv_sok.getInputStream();
          this.os = this.u_srv_sok.getOutputStream();
        }
        catch(Exception ex){

          JLO.getInstance().eprintf(10,ex);
          try{
            this.is.close();
            this.os.close();
            this.u_srv_sok.close();
          }
          catch(Exception ex2){}
          continue;
        }
      }
      /////////////////////////////////////////////////////////////////
      // ����������� �����Ѵ�. ���� �ϳ��� Ŭ���̾�Ʈ connection�� ������Ų��
      /////////////////////////////////////////////////////////////////
      connectFlagOffSet=true;
      TPSVCINFO.sok_conn_add();

      String senddata = null;
      String tmp = null;
      for( ; ; ){
        try{
          //atmhandler thread control
          //user:atmshutdown->atmserver:stopflag-true->atmhandler:break
          /*
          if( stopmode() ){
            break;
          }
          */

          //tmp = SOCKETapi.read_data(this.is );
          this.loc = 0;
          tmp = SOCKETapi.jni_read_data(this.is );
          this.loc = 1;
          JLO.getInstance().printf(5,"\n\n\n");
          JLO.getInstance().printf(5,"==���ŵ���Ÿ:["+tmp+"]");

          //////////////////////////////////////////////////////////////////
          // Ʈ����� ������ �����Ѵ�.
          //////////////////////////////////////////////////////////////////
          senddata = execute(tmp);
          //////////////////////////////////////////////////////////////////
          //SOCKETapi.write_data(this.os,senddata);
          SOCKETapi.jni_write_data(this.os,senddata);
          JLO.getInstance().printf(5,"==�۽ŵ���Ÿ:["+senddata+"]");
        }
        catch(Exception ex3){
          connectFlagOffSet=false;
          ex3.printStackTrace();
          JLO.getInstance().eprintf(10,ex3);
          break;
        }
      }

      ////////////////////////////////////////////////////////////////////
      // connection count�� �ٿ��ش�.
      ////////////////////////////////////////////////////////////////////
      connectFlagOffSet=false;
      TPSVCINFO.sok_conn_minus();

      try{
        this.is.close();
        this.os.close();
        this.u_srv_sok.close();
      }
      catch(Exception ex4){
        ex4.printStackTrace();
        JLO.getInstance().eprintf(10,ex4);
      }

      ////////////////////////////////////////////////////////////////////////////
      // Ŭ���̾�Ʈ�� �������� ����
      ////////////////////////////////////////////////////////////////////////////
      this.cltinfo.setExitflag(true);
      //ATMserver.tpsvcinfo.prntCLTINFO();

      ////////////////////////////////////////////////////////////////////
      // atmhandler thread control
      // user:atmshutdown->atmserver:stopflag-true->atmhandler:break
      ////////////////////////////////////////////////////////////////////
      /*
      if( stopmode() ){
        break;
      }
      */
    }
  }

  public String execute(String tmp){
    String senddata=tmp;
    IOBoundArea in = null;

    try{
      in = new IOBoundArea(senddata);

      //////////////////////////////////////////////////////////////////
      // Ŭ���̾�Ʈ�� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      ATMserver.tpsvcinfo.updateaddClient(this.cltinfo,this.u_srv_sok,in);
      this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(in.cdto.userId);

      //////////////////////////////////////////////////////////////////
      // ���� �������� ���������� �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      ATMserver.tpsvcinfo.updateaddThread(this.thrinfo,this.u_srv_sok,this.v_sok_fd_tbl,in);
      this.thrinfo = (THRINFO)ATMserver.tpsvcinfo.getThread(Thread.currentThread().getName());

      //////////////////////////////////////////////////////////////////
      // Ʈ����� ������ �����Ѵ�.
      //////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(3,"=========================================TCF ST");
      TCF tcf = new TCF(); tcf.execute(tmp);
      senddata = tcf.setSendData();
      JLO.getInstance().printf(3,"=========================================TCF END");

      try{
        //////////////////////////////////////////////////////////////////
        // Ŭ���̾�Ʈ�� ���������� �����Ѵ�.
        //////////////////////////////////////////////////////////////////
        ATMserver.tpsvcinfo.updateaddClient(this.cltinfo,new IOBoundArea(senddata));
        //////////////////////////////////////////////////////////////////
        // �������� ���������� �����Ѵ�.
        //////////////////////////////////////////////////////////////////
        ATMserver.tpsvcinfo.updateaddThread(this.thrinfo,new IOBoundArea(senddata));
      }
      catch(Exception igex){
        JLO.getInstance().eprintf(10,igex);
        JLO.getInstance().printf(10,"�̿��ܴ� �����ؼ� �ϴ� swb�� ������ ���������� ���� Ʈ�������� �Ϸ��Ų��");
      }
    }
    catch(Exception ex){
      JLO.getInstance().eprintf(10,ex);
      in.setInParsing();
      in.iohead.sBErrCode = "EI0999";
      return in.toString();
    }
    return senddata;
  }
  private void trace(String msg)
  {
      //wsj.atm.common.wafutil.Debug.trace(getClass(),msg);
  }
  public synchronized boolean stopmode(){
    try{
      if( this.stopflag ) {
        return true;
      }
      return false;
    }
    catch(Exception ex){return false;}
  }
  public synchronized void setstopflag(boolean flag){
    this.stopflag = flag;
  }
  public synchronized boolean getstopflag(){
    return this.stopflag;
  }
}

