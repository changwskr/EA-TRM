package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;

import wsj.atm.common.*;
import wsj.atm.env.*;
import wsj.atm.log.*;
import wsj.atm.packet.*;

public class EX07_CALLATM extends Thread {
  public static int gTxCnt=0;
  private Socket csocket;
  private OutputStream cdos;
  private InputStream cdis;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  public IOBoundArea in ;
  public IOBoundArea out ;

  private int txcnt;
  public static int txamount=0;
  private int atmseqno=0;


  public static void main(String args[]) throws IOException {

    Hashtable tb = new Hashtable();
    System.out.println("Usage :: port thr#cnt tx#cnt tx#amount");
    System.out.println("      :: ������ȸ ���õ� ������ �����Ѵ�");

    ///////////////////////////////////////////////////////////////////////
    // ����� ������ ä���.
    ///////////////////////////////////////////////////////////////////////
    txamount = ComUtil.Str2Int(args[3]);

    for(int i=1;i<=Integer.valueOf(args[1]).intValue();i++){
      new EX07_CALLATM("188.238.50.50",
                   Integer.valueOf(args[0]).intValue(),
                   tb,
                   ComUtil.Str2Int(args[2])).start();
    }
  }

  public EX07_CALLATM (String IP,int port,Hashtable thrmanage,int txcnt) throws IOException {
    this.port = port;
    this.hostip = IP;
    this.thrmanage=thrmanage;
    this.txcnt = txcnt;
  }

  private int cnt =0;
  String srttime;
  String recvdata;

  public void run(){
    Thread.currentThread().setName("EX07_CALLATM");
    srttime = ComUtil.GetSysTime();
    String recvdata = null;
    String senddata = null;
    try{
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
	  System.out.println("------waiting -- enter");
        System.in.read(); System.in.read();

    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }

    ////////////////////////////////////////////////////////////////////////
    // �α��� �ŷ��� �ǽ��Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    System.out.println("# �α��� ###############################################################");
    if( !LOG80000("ATM0238001","03","ATM02380") ){
        return;
    }
    System.out.println("################################################################");

    ////////////////////////////////////////////////////////////////////////
    // ����OPEN �ŷ��� �ǽ��Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    System.out.println("# ���� OPEN ###############################################################");
    if( !TEL80004("ATM0238001",this.out.cdto.bizDate) ){
      if( this.out.iohead.sBErrCode.equals( "EC1501" )){
        System.out.println("�̹� �ش��ڷ��� open �� �����Դϴ� �ŷ��� �����մϴ�");
      }
      else
        return;
    }

    System.out.println("################################################################");
    ////////////////////////////////////////////////////////////////////////
    // �ڱ��μ��� �ŷ��� �ǽ��Ѵ�.[ATM�� �����ⳳ����� �ڷ���ȣ���ؼ� ������ �ڱ�
    // ���¿� �Ա��Ѵ�.
    // ATM teller
    // �ⳳ tellner
    ////////////////////////////////////////////////////////////////////////
    System.out.println("## �ڱ��μ���(�Ա�) #############################################################");
    while(true){
      if( !TEL80005("VAULT     ","VND",ComUtil.Int2Str(this.txamount),"ATM0238001") ){
        try{
          Thread.currentThread().sleep(2000);
          }catch(Exception iex){}
          System.out.println("�ڵ�ȭ��� ��� �����ⳳ����� ���縦 OPEN �ϱ⸦ ����Ѵ�");
          continue;
      }
      break;
    }

    System.out.println("################################################################");
    System.out.println("# �ڱ��μ��ݾ� : " + this.txamount );
    System.out.println("################################################################");

    while(true){
      try{
        System.out.println("----------------------------------------------------["+cnt+"]");
        System.out.println("����մϴ� (����)");
        System.in.read(); System.in.read();
        this.DEP80001();
        System.out.println("################################################################");
        System.out.println("# ��������� ���� : " + this.txamount );
        System.out.println("################################################################");

        System.out.println("�������մϴ� (����)"+this.in.cdto.atmSeqNo);
        System.in.read(); System.in.read();

        this.DEP80008("1000000", "23807040022", this.in.cdto.atmSeqNo);

        System.out.println("������ü�մϴ� (����)");
        System.in.read(); System.in.read();
        this.DEP80002();
        System.out.println("################################################################");
        System.out.println("# ������ü�� ���� : " + this.txamount );
        System.out.println("################################################################");

        System.out.println("�ܾ���ȸ�մϴ� (����)");
        System.in.read(); System.in.read();
        this.DEP80003();

        cnt++;
        if(cnt==txcnt) break;
      }
      catch(Exception ex){
      ex.printStackTrace();
        try{
          this.cdis.close();
          this.cdos.close();
          this.csocket.close();
          this.csocket = new Socket(this.hostip ,this.port);
          this.hostname = this.csocket.getInetAddress().getHostAddress();
          this.cdis = this.csocket.getInputStream();
          this.cdos = this.csocket.getOutputStream();
        }
        catch(Exception ex1){
          ex1.printStackTrace();
          System.exit(0);
        }
        cnt++;
        if(cnt==txcnt) break;
        continue;
      }
    }

    ////////////////////////////////////////////////////////////////////////
    // �ڱ��μ��� �ŷ��� �ǽ��Ѵ�.
    // [ATM�� �����ⳳ����� �ڷ���ȣ���ؼ� ������ �ⳳ������� �Ա��Ѵ�.
    // ATM teller
    // �ⳳ tellner
    ////////////////////////////////////////////////////////////////////////
    System.out.println("�ڱ��μ��� ����ȸ �ŷ��� �ǽ��Ѵ�.(1)");
    if( !TEL80007("ATM0238001") ){
      try{
        Thread.currentThread().sleep(2000);
        }catch(Exception iex){}
    }

    System.out.println("## �ڱ��μ���(����) #############################################################");
    while(true){
      if( !TEL80005("ATM0238001","VND",ComUtil.Int2Str(this.txamount) ,"VAULT     ") ){
        try{
          Thread.currentThread().sleep(2000);
          }catch(Exception iex){}
          System.out.println("�ڵ�ȭ��� ��� �����ⳳ����� ���縦 OPEN �ϱ⸦ ����Ѵ�");
          continue;
      }
      break;
    }

    System.out.println("################################################################");
    System.out.println("# �ڱݹݳ��ݾ� : " + this.txamount );
    System.out.println("################################################################");

    System.out.println("�ڱ��μ��� ����ȸ �ŷ��� �ǽ��Ѵ�.(2)");
    if( !TEL80007("ATM0238001") ){
      try{
        Thread.currentThread().sleep(2000);
        }catch(Exception iex){}
    }

    ////////////////////////////////////////////////////////////////////////
    // ����close �ŷ��� �ǽ��Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    System.out.println("#���� CLOSE###############################################################");
    if( !TEL80006(
                  "ATM0238001",
                  "10",
                  this.out.cdto.bizDate,
                  this.out.cdto.bankCode,
                  "VND",
                  "0") )
    {
      System.out.println("���� close ����");
    }

    System.out.println("################################################################");
    System.out.println(Thread.currentThread().getName()
    + " Ŭ���̾�Ʈ ���� ["+srttime+":"+ComUtil.GetSysTime()+"]["+cnt+"]"+ComUtil.ItvSec(srttime,ComUtil.GetSysTime()));

    try{
      this.cdis.close();
      this.cdos.close();
      this.csocket.close();
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex1){
      ex1.printStackTrace();
      System.exit(0);
    }

  }

  public boolean LOG80000(String userid,String bankcode,String password)
  {
    try{
      this.in = new IOBoundArea();
      this.out = null;
      ///////////////////////////////////////////////////////////////////////
      // �α��ΰŷ��� �ǽ��Ѵ�
      ///////////////////////////////////////////////////////////////////////
      //�������� �ۼ�
      in.cdto.setUserId(ComUtil.PSpaceToStr(userid,IOBoundProtoType.userId_LEN ) );
      in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      in.cdto.channelType = "03"; /* ATM �ŷ����� �����Ѵ� */
      in.cdto.setEventNo("80000");
      in.iohead.sDTimer = "99000";
      in.cdto.setBankCode(bankcode);
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      IOBoundLog80000CDTO lcdto = new IOBoundLog80000CDTO();
      lcdto.bankcode = bankcode;
      lcdto.password = ComUtil.PSpaceToStr(userid,8);
      lcdto.tellerid = ComUtil.PSpaceToStr(userid,10);
      String logindata = lcdto.toString();

      in.iodata.sBoundData = logindata;
      in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
      String senddata = in.toString();

      System.out.println("���۵���Ÿ:["+senddata+"]");
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);

      String recvdata = SOCKETapi.jni_read_data(this.cdis);
      System.out.println("���ŵ���Ÿ:["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);

      if( out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-�α��� �ŷ�����----------::"+out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-�α��� �ŷ�����----:: ������ �籸���Ѵ�."+out.iohead.sBErrCode );
        this.in.iohead = this.out.iohead;
        this.in.cdto = this.out.cdto;
        System.out.println(this.in.cdto.userId +":"+this.in.cdto.bizDate +":"+this.in.cdto.baseCurrency);
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println("login �ŷ��� �����߽��ϴ�.");
      return false;
    }
  }

  private IOBoundTel80004CDTO io80004cdto;
  public boolean TEL80004(String tellerno,String bizdate)
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80004");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80004cdto = new IOBoundTel80004CDTO();
      this.io80004cdto.TellerNo = ComUtil.PSpaceToStr(tellerno,10);
      this.io80004cdto.TxDate = bizdate;

      this.in.iodata.sBoundData = this.io80004cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80004����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("TEL80004����["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-TEL80004 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        this.in.iohead = this.out.iohead;
        this.in.cdto = this.out.cdto;
        System.out.println("-TEL80004 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  //�ڱ��μ��� ����ȸ
  private IOBoundTel80005CDTO io80005cdto;
  public boolean TEL80005(String tellerno,String currency,String txamount,String targettellerno)
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80005");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80005cdto = new IOBoundTel80005CDTO();
      this.io80005cdto.TellerNo = ComUtil.PSpaceToStr(tellerno,io80005cdto.TellerNo_LEN );
      this.io80005cdto.Currency = ComUtil.PSpaceToStr(currency,io80005cdto.Currency_LEN );
      this.io80005cdto.TxAmount = ComUtil.ZeroToStr(txamount,io80005cdto.Amount_LEN );

      this.io80005cdto.TargetTellerNo = ComUtil.PSpaceToStr(targettellerno,io80005cdto.TargetTellerNo_LEN );

      this.in.iodata.sBoundData = this.io80005cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80005����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("TEL80005����["+recvdata+"]");
      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-TEL80005 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        this.io80005cdto.setIOBoundTel80005CDTOParsing(this.out.iodata.sBoundData);
        System.out.println("-TEL80005 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        System.out.println("teller no : "+this.io80005cdto.TellerNo );
        System.out.println("target teller no : " + this.io80005cdto.TargetTellerNo );
        System.out.println("request txamt : " + this.io80005cdto.TxAmount  );
        System.out.println("currentCashBalance : " + this.io80005cdto.Amount01 );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  private IOBoundTel80006CDTO io80006cdto;
  public boolean TEL80006(
      String tellerno,String tellerstatus,String txdate,
      String bankcode,String currency01,String amount01 )
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80006");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80006cdto = new IOBoundTel80006CDTO();
      this.io80006cdto.TellerNo = ComUtil.PSpaceToStr(tellerno,this.io80006cdto.TellerNo_LEN );
      this.io80006cdto.TellerStatus = tellerstatus;
      this.io80006cdto.TxDate = txdate;
      this.io80006cdto.BankCode = bankcode;
      this.io80006cdto.Currency01 = currency01;
      this.io80006cdto.Amount01 = ComUtil.ZeroToStr(amount01,this.io80006cdto.Amount_LEN );

      this.in.iodata.sBoundData = this.io80006cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80006����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("TEL80006����["+recvdata+"]");
      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-TEL80006 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-TEL80006 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }


  private IOBoundDep80001CDTO io80001cdto;
  public boolean DEP80001()
  {
    int wtxamt = 1000;
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80001");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80001cdto = new IOBoundDep80001CDTO();
      this.io80001cdto.AccountNumber = "23807040022";
      this.io80001cdto.BankCode = in.cdto.bankCode;
      this.io80001cdto.PbKind = "N";
      this.io80001cdto.TrxCcyu = "VND";
      ////////////////////////////////////////////////////////////////////////
      // ��������ŷ��� �ǽ��Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      // 1.�ڱ��μ��ߴ� �ݾ׿��� 1�鸸�� ����
      this.io80001cdto.Amount = ComUtil.ZeroToStr(ComUtil.Int2Str(wtxamt) ,this.io80001cdto.Amount_LEN) ;
      this.io80001cdto.TransactionAmount = this.io80001cdto.Amount;
      this.io80001cdto.TrxStatus = "50";
      this.io80001cdto.FeeWaivFlag = "N";
      this.io80001cdto.ApproveStatus = "50";
      this.io80001cdto.ColleceedBalance = ComUtil.ZeroToStr("0000",this.io80001cdto.ColleceedBalance_LEN) ;
      this.io80001cdto.SecurityNo = "1111            ";
      this.io80001cdto.CashCardNo = "1111111111111111";
      this.io80001cdto.AtmSeqNo = in.cdto.atmSeqNo;

      this.in.iodata.sBoundData = this.io80001cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80001����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("TEL80001����["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-DEP80001 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        // 1.�ŷ����� :: �ڱ��μ��ߴ� �ݾ׿��� 1�鸸���� ����
        this.txamount = this.txamount - wtxamt;
        System.out.println("-DEP80001 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  private IOBoundDep80002CDTO io80002cdto;
  public boolean DEP80002()
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80002");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80002cdto = new IOBoundDep80002CDTO();
      this.io80002cdto.AccountNumber = "23807040022";
      // ������ü�� ���ؼ� �ִ´�.
      //this.io80002cdto.TargetAccountNo = "0001100100000048";
      //this.io80002cdto.TargetAccountNo = "0238100800000304";
      this.io80002cdto.TargetAccountNo = "23807040031     ";

      this.io80002cdto.BankCode = in.cdto.bankCode;
      this.io80002cdto.PbKind = "N";
      this.io80002cdto.TrxCcyu = "VND";
      this.io80002cdto.CashCardNo = "1111111111111111";
      this.io80002cdto.SecurityNo = "1111            ";
      this.io80002cdto.CashCardNo = "1111111111111111";
      this.io80002cdto.AtmSeqNo = in.cdto.atmSeqNo;

      ////////////////////////////////////////////////////////////////////////
      // ��������ŷ��� �ǽ��Ѵ�.
      ////////////////////////////////////////////////////////////////////////
      int wtxamt = 1000;
      this.io80002cdto.Amount = ComUtil.ZeroToStr(ComUtil.Int2Str(wtxamt) ,this.io80002cdto.Amount_LEN) ;
      this.io80002cdto.TransactionAmount = this.io80002cdto.Amount;
      this.io80002cdto.TrxStatus = "50";
      this.io80002cdto.FeeWaivFlag = "N";
      this.io80002cdto.ApproveStatus = "50";
      this.io80002cdto.SecurityNo = "1111            ";
      this.io80002cdto.ColleceedBalance = ComUtil.ZeroToStr("0000",this.io80002cdto.ColleceedBalance_LEN) ;

      this.in.iodata.sBoundData = this.io80002cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80002����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("DEP80002����["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-DEP80002 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-DEP80002 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  private IOBoundDep80003CDTO io80003cdto;
  public boolean DEP80003()
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80003");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80003cdto = new IOBoundDep80003CDTO();
      this.io80003cdto.AccountNumber = "23807040022";
      this.io80003cdto.BankCode = this.in.cdto.bankCode;
      this.io80003cdto.SecurityNo = "1111            ";

      this.io80003cdto.CashCardNo = "1111111111111111";

      this.in.iodata.sBoundData = this.io80003cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("DEP80003����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("DEP80003����["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-DEP80003 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-DEP80003 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  //�ڱ��μ��� ����ȸ
  private IOBoundTel80007CDTO io80007cdto;
  public boolean TEL80007(String tellerno)
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80007");
      this.in.iohead.sDTimer = "99000";
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;

      //��������Ÿ�� �����Ѵ�.
      this.io80007cdto = new IOBoundTel80007CDTO();
      this.io80007cdto.TellerNo = ComUtil.PSpaceToStr(tellerno,io80007cdto.TellerNo_LEN );

      this.in.iodata.sBoundData = this.io80007cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("TEL80007����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("TEL80007����["+recvdata+"]");
      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-TEL80007 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-TEL80007 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );

        IOBoundTel80007CDTO oo80007cdto = new IOBoundTel80007CDTO();
        oo80007cdto.setIOBoundTel80007CDTOParsing(this.out.iodata.sBoundData );

        System.out.println("oo80007cdto.tellerNo : " + oo80007cdto.TellerNo );
        System.out.println("oo80007cdto.currency balance amount : " + oo80007cdto.Currency01 + " " + oo80007cdto.Amount01  );
        System.out.println("oo80007cdto.BankCode : " + oo80007cdto.BankCode);
        System.out.println("oo80007cdto.BranchCode : " + oo80007cdto.BranchCode);
        System.out.println("oo80007cdto.TxDate : " + oo80007cdto.TxDate);

        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }

  private IOBoundDep80008CDTO io80008cdto;
  public boolean DEP80008(String txamount,String accountno,String txnumber)
  {
    try{
      //Build Head
      this.in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      this.in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      this.in.cdto.setEventNo("80008");
      this.in.iohead.sDTimer = "99000";
/*
      this.atmseqno++;
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(""+this.atmseqno , 20) ;
*/
      in.cdto.atmSeqNo = ComUtil.ZeroToStr(ComUtil.GetSysTime(), 20) ;


      //��������Ÿ�� �����Ѵ�.
      this.io80008cdto = new IOBoundDep80008CDTO();
      this.io80008cdto.AccountNumber = accountno;
      this.io80008cdto.BankCode = this.in.cdto.bankCode;
      this.io80008cdto.approveStatus = "50";
      this.io80008cdto.approveUserId = "ATM0238001";
      this.io80008cdto.txAmount = ComUtil.ZeroToStr(txamount,this.io80008cdto.txAmount_LEN);
      this.io80008cdto.transactionDate = this.in.cdto.bizDate;
      this.io80008cdto.atmTransactionNo = ComUtil.AtferSpaceToStr(txnumber,this.io80008cdto.atmTransactionNo_LEN);

      this.in.iodata.sBoundData = this.io80008cdto.toString();
      this.in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(this.in.iodata.sBoundData.length()),5);

      String senddata = in.toString();
      System.out.println("DEP80008����["+senddata+"]");

      //�����μ�������
      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      String recvdata = SOCKETapi.jni_read_data(this.cdis);

      System.out.println("DEP80008����["+recvdata+"]");

      this.out = new IOBoundArea(recvdata);
      if( this.out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-DEP80008 �ŷ�����----------::"+this.out.iohead.sBErrCode );
        return false;
      }
      else{
        System.out.println("-DEP80008 �ŷ�����----:: ������ �籸���Ѵ�."+this.out.iohead.sBErrCode );
        this.io80008cdto.setIOBoundDep80008CDTOParsing(this.out.iodata.sBoundData  );
        System.out.println("accound no:"+this.io80008cdto.AccountNumber );
        System.out.println("atmseqno  :"+this.io80008cdto.atmTransactionNo );
        System.out.println("tx amount:" + this.io80008cdto.txAmount );

        // 1.�ŷ����� :: ����ߴ� �ݾ׿��� 1�鸸���� ���Ѵ�.
        this.txamount = this.txamount + ComUtil.Str2Int(txamount);
        return true;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      return false;
    }
  }
}
