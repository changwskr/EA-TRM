package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;
import wsj.atm.common.*;
import wsj.atm.env.*;
import wsj.atm.log.*;
import wsj.atm.packet.*;

import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;

import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;


public class EX04_ATMEJB extends Thread {
  public static int gTxCnt=0;
  private Socket csocket;
  private OutputStream cdos;
  private InputStream cdis;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  private int txcnt;

  public static void main(String args[]) throws IOException {
    Hashtable tb = new Hashtable();
    System.out.println("Usage :: port thr#cnt tx#cnt");
    for(int i=1;i<=Integer.valueOf(args[1]).intValue();i++){
      new EX04_ATMEJB("21.101.3.49",Integer.valueOf(args[0]).intValue(),tb,ComUtil.Str2Int(args[2])).start();
    }
  }

  public EX04_ATMEJB (String IP,int port,Hashtable thrmanage,int txcnt) throws IOException {
    this.port = port;
    this.hostip = IP;
    this.thrmanage=thrmanage;
    this.txcnt = txcnt;
  }

  private int cnt =0;
  String srttime;  String recvdata;
  public void run(){
    srttime = ComUtil.GetSysTime();
    String recvdata = null;
    String senddata = null;
    try{
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }
    while(true){
      try{
        IOBoundArea in = new IOBoundArea();
        IOBoundArea out = new IOBoundArea();
        in.cdto.setUserId("WXX0000001");
        in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
        in.iohead.sDSysDate = ComUtil.GetSysDate() ;
        in.cdto.setEventNo("10000");
        in.iodata.sBoundData = "AAAAA";
        in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
        in.iohead.sDTimer = "10000";
        senddata = in.toString();
        csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
        JLO.getInstance().printf(1,senddata);
        SOCKETapi.write_data(this.cdos ,senddata);

		System.out.println("\n\n^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
		callEjb();
		System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n\n");

        cnt++;
        recvdata = SOCKETapi.read_data(this.cdis);
		System.out.println("Send["+senddata+"]");
		System.out.println("Recv["+recvdata+"]");
		System.out.println("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||");
		senddata="";
		recvdata="";

        if(cnt==txcnt) {
			System.out.println("||||||||||||||||||||||||||||||||||| end");
			break;
		}
      }
      catch(Exception ex){
        try{
          this.cdis.close();
          this.cdos.close();
          this.csocket.close();
          this.csocket = new Socket(this.hostip ,this.port);
          this.hostname = this.csocket.getInetAddress().getHostAddress();
          this.cdis = this.csocket.getInputStream();
          this.cdos = this.csocket.getOutputStream();
        }
        catch(Exception ex1){
          ex1.printStackTrace();
          System.exit(0);
        }
        continue;
      }
    }

    System.out.println(Thread.currentThread().getName()
    + " Ŭ���̾�Ʈ ���� ["+srttime+":"+ComUtil.GetSysTime()+"]["+cnt+"]"+ComUtil.ItvSec(srttime,ComUtil.GetSysTime()));

  }

  public void callEjb(){

    try{

      //=======================================================================
      //local application tunnelling call ejb ���
      TCPCallEJB cejb = new TCPCallEJB("21.101.7.60","10000");
      BoundArea inbound = new BoundArea(BoundArea.CMD_INITIAL) ;

      // �α��� �ŷ��� �ǽ��� CosesCommonDTO�� ���Ѵ�.
      inbound.tellerId = "test1";
      inbound.passwd = "test1";
      inbound.setBankCode("03");
      inbound=cejb.Login(inbound);


      int cnt=0;
      while(true){
        // STF
        cnt++;
        if( cnt == 11 ) break;
        System.out.println("----------------------------------�ŷ��� �����մϴ�["+cnt+"]");
        System.out.println("--�⺻������ ����");
        inbound.errcode = "IZZ000";

        // BIZ
        System.out.println("----------------------------------�����ŷ��� �����մϴ�");
        // ��������Ÿ����
        try{
          AccountQueryCDTO acdto = null;
          acdto = new AccountQueryCDTO();
          inbound.setCommand(BoundArea.CALL_BATCH_EJB);
          acdto.setAccountNumber("0001100100000048");
          acdto.setBankCode("03");
          inbound.setParameter(acdto);

          // ȣ�� ���񽺸��� ����
          System.out.println("--------EJB ȣ�����");
          BoundArea outbound=(BoundArea)cejb.callEJB("deposit-getAccountInfo",inbound);
          System.out.println("--------EJB ȣ������");

          if( outbound.errcode.equals ("IZZ000") ){
            System.out.println("�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
            AccountQueryCDTO result = (AccountQueryCDTO)outbound.getParameter();
            System.out.println("************************************************");
            System.out.println("***AccountQueryCDTO***"+result.toString());
            System.out.println("--txno:"+outbound.cdto.getTransactionNo());
            System.out.println("--amount:"+acdto.getCollectedBalance());
            System.out.println("************************************************");
          }
          else
            System.out.println("�ŷ�ȣ���� ������ �߻��߽��ϴ�.");

          System.out.println("--�⺻������ �������ϰ� ����/���������� �Ǵ�");
          System.out.println("----------------------------------�ŷ��� �����մϴ�");
        }
        catch(Exception ex){}

      }

      return ;
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }

}

