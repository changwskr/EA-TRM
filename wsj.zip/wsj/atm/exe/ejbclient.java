package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;

import wsj.atm.common.ComUtil;
import wsj.atm.log.JLO;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.packet.*;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.socket.CLTINFO;
import com.chb.coses.wPilot.transfer.ItfaoinfoCDTO;
import wsj.atm.bound.BoundArea;

import wsj.atm.socket.ATMserver;
import wsj.atm.tcf.*;
import wsj.atm.common.ComUtil;
import wsj.atm.log.JLO;
import wsj.atm.packet.*;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.socket.CLTINFO;



public class ejbclient {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundCOM10000CDTO iob10000cdto;
  public IOBoundCOM10000CDTO oob10000cdto;

  private CosesCommonDTO cdto;
  private TCPCallEJB cejb;
  private CLTINFO cltinfo;
  public LOGIN login;
  public BoundArea outbound;

  public ejbclient(IOBoundArea inarea,IOBoundArea outarea ) throws IOException,Exception {
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob10000cdto = new IOBoundCOM10000CDTO();
  }

  public void getTCPCallEJB() throws Exception {
    try {
      if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMIPORT")
            );
      }
      else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMIPORT")
            );
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
      throw ex;
    }
  }

  public void execute(){

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          ejbclient �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      // login �ŷ��� �ǽ��Ѵ�.
      this.login = new LOGIN(inarea,outarea);
      this.login.execute();
      this.cdto = login.outbound.cdto;

      // data ����
      this.iob10000cdto.bankcode = "03";
      this.iob10000cdto.bizdate = "20030630";

      ItfaoinfoCDTO icdto = new ItfaoinfoCDTO();
      icdto.setBankcode(this.login.outbound.cdto.getBankCode() );
      icdto.setBizdate(this.login.outbound.cdto.getBusinessDate() );
      icdto.setBranchcode(this.login.outbound.cdto.getBranchCode() );
      icdto.setBrnhostseq("1234567890");
      icdto.setErrcode("IZZ000");
      icdto.setEventno("80001");
      icdto.setIntime("101011");
      icdto.setOuttime("101011");
      icdto.setSystemdate(login.outbound.cdto.getSystemDate() );
      icdto.setUserid(login.outbound.cdto.getUserID());

      this.outbound=(BoundArea)this.cejb.callEJB2("wPilot-inquiry",this.cdto,icdto);
      switch( outbound.errcode.charAt(0) )
      {
        case 'E':
        case 'I':
          break;
      }
      icdto = (ItfaoinfoCDTO)outbound.getParameter();


    }
    catch(Exception ex){
      ex.printStackTrace();
      JLO.getInstance().eprintf(1,ex);
    }
  }

  public static void main(String args[]) throws Exception
  {
    try{
      IOBoundArea in = new IOBoundArea();
      IOBoundArea out = new IOBoundArea();
      in.cdto.setUserId("ATM0238003");
      in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      in.cdto.setTerminalId("ATM0238003");
      in.cdto.setEventNo("80000");
      in.iohead.sDTimer = "60000";
      in.iodata.sBoundData = "03ATM0238003ATM02380";
      in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
      ejbclient clt = new ejbclient(in,out);
      clt.execute();

    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
}




class LOGIN {
  private IOBoundArea inarea;
  private IOBoundArea outarea;
  public IOBoundLog80000CDTO iob80000cdto;
  public IOBoundLog80000CDTO oob80000cdto;
  private BoundArea inbound;
  public BoundArea outbound;
  private TCPCallEJB cejb;
  private CLTINFO cltinfo;

  public LOGIN(IOBoundArea inarea,IOBoundArea outarea) throws IOException,Exception {
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80000cdto = new IOBoundLog80000CDTO();
    this.oob80000cdto = new IOBoundLog80000CDTO();
    this.inbound = new BoundArea(BoundArea.CMD_INITIAL) ;

    /*
    this.cejb = new TCPCallEJB(
                             UbbConfig.getInstance().GetEnvValue("RMISERVER"),
                             UbbConfig.getInstance().GetEnvValue("RMIPORT")
                             );
    */
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);

  }

  public IOBoundArea execute(){

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          LOGIN �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMIPORT")
            );
      }
      else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMIPORT")
            );
      }

      this.iob80000cdto.setIOBoundLog80000CDTOParsing(this.inarea.iodata.sBoundData);
      this.inbound.tellerId = this.iob80000cdto.tellerid;
      this.inbound.passwd = this.iob80000cdto.password;
      this.inbound.setBankCode(this.iob80000cdto.bankcode );

      //////////////////////////////////////////////////////////////////////////
      // 1] 1 ��
      //////////////////////////////////////////////////////////////////////////
      this.outbound=this.cejb.Login(this.inbound);
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      //JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      //TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      //ATMserver.atmejbpool.printStates();
      //JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      //JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //this.outbound=(BoundArea)ejbinstance.Login(this.inbound);
      //ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      switch( outbound.errcode.charAt(0) )
      {
        case 'E':
          this.outarea.iohead.sBErrCode=this.inarea.iohead.sBErrCode="EL0001";
          this.inarea.iohead.setMsg("Application Exception[LOGIN.LOGIN ERROR]",this.outarea);
          JLO.getInstance().printf(1,"==�α��� �ŷ��� �����߽��ϴ�.["+this.outarea.iohead.sMsg+"]");
          this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          return this.outarea ;
        case 'I':
          break;
      }

      JLO.getInstance().printf(1,"==�α��� �ŷ��� �����߽��ϴ�.");

      IOBoundCDTO cdto = this.iob80000cdto.getIOBoundCDTO(this.outbound);
      String icn = this.inarea.cdto.cifNum;
      String irn = this.inarea.cdto.refNum;
      String atmseq = this.inarea.cdto.atmSeqNo;
      //STF���� �ð����� ����ϱ� ���� �־��� ����Ÿ�� �ٽ� �����Ѵ�.
      cdto.setRefNum(irn);
      cdto.setCifNum(icn);
      cdto.setAtmSeqNo(atmseq);

      this.outarea.cdto = this.inarea.cdto = cdto;
      this.outarea.cdto.eventNo = "80000";  // �α��� �ŷ��� ���ؼ� ������ cdto�� CosesCommonDTO �̹Ƿ�

      this.outarea.iohead.sDLoginOffSet = this.inarea.iohead.sDLoginOffSet = "1";
      this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
      this.outarea.iohead.setMsg("Application Info[LOGIN.LOGIN SUCCESS]");
      this.iob80000cdto.workingkey = "1234567890abcdef";
      this.outarea.iodata.sBoundData = this.iob80000cdto.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.iob80000cdto.toString().length()),5);
      this.outarea.iodata.sLength = ComUtil.Int2Str(this.iob80000cdto.toString().length());
    }
    catch(Exception ex){
      ex.printStackTrace();
      JLO.getInstance().eprintf(1,ex);
      this.outarea.iohead.sBErrCode = "EL0002";
      this.outarea.cdto.eventNo = "80000";  // �α��� �ŷ��� ���ؼ� ������ cdto�� CosesCommonDTO �̹Ƿ�
      this.outarea.iohead.setMsg("Application Exception[LOGIN.Not Login]");
      this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      return this.outarea ;
    }
    return this.outarea;
  }
}

