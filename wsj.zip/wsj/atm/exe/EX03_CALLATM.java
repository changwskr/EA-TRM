package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;

import wsj.atm.common.*;
import wsj.atm.env.*;
import wsj.atm.log.*;
import wsj.atm.packet.*;

public class EX03_CALLATM extends Thread {
  public static int gTxCnt=0;
  private Socket csocket;
  private OutputStream cdos;
  private InputStream cdis;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  private int txcnt;

  public static void main(String args[]) throws IOException {
    Hashtable tb = new Hashtable();
    System.out.println("Usage :: port thr#cnt tx#cnt");
    for(int i=1;i<=Integer.valueOf(args[1]).intValue();i++){
      new EX03_CALLATM("21.101.3.49",Integer.valueOf(args[0]).intValue(),tb,ComUtil.Str2Int(args[2])).start();
    }
  }

  public EX03_CALLATM (String IP,int port,Hashtable thrmanage,int txcnt) throws IOException {
    this.port = port;
    this.hostip = IP;
    this.thrmanage=thrmanage;
    this.txcnt = txcnt;
  }

  private int cnt =0;
  String srttime;
  String recvdata;
  public void run(){
    srttime = ComUtil.GetSysTime();
    String recvdata = null;
    String senddata = null;
    try{
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }

    ////////////////////////////////////////////////////////////////////////
    // �α��� �ŷ��� �ǽ��Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    try{
      IOBoundArea in = new IOBoundArea();

      //�������� �ۼ�
      in.cdto.setUserId("test1*****");
      in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      in.cdto.setTerminalId("Teminal***ID");
      in.cdto.setEventNo("30000");
      in.iohead.sDTimer = "60000"; //60��

      String logindata = "02test1     test1   ";
      in.iodata.sBoundData = logindata;
      in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;

      senddata = in.toString();

      System.out.println("["+senddata+"]");

      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      JLO.getInstance().printf(1,senddata);

      SOCKETapi.jni_write_data(this.cdos ,senddata);
      recvdata = SOCKETapi.jni_read_data(this.cdis);

      IOBoundArea outarea = new IOBoundArea(recvdata);

      if( outarea.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-----------------------------------::"+outarea.iohead.sBErrCode );
        return;
      }
      System.out.println("--����---------------------------------::"+outarea.iohead.sBErrCode );

    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println("loging ����");
      return;
    }


    while(true){
      try{
        IOBoundArea in = new IOBoundArea();
        IOBoundArea out = new IOBoundArea();

        in.cdto.setUserId("WXX0000001");
        in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
        in.iohead.sDSysDate = ComUtil.GetSysDate() ;
        in.cdto.setEventNo("10000");
        in.iodata.sBoundData = "AAAAA";
        in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
        in.iohead.sDTimer = "10000";
        senddata = in.toString();
        csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
        JLO.getInstance().printf(1,senddata);
        SOCKETapi.jni_write_data(this.cdos ,senddata);
        cnt++;
        recvdata = SOCKETapi.jni_read_data(this.cdis);
        if(cnt==txcnt) break;
      }
      catch(Exception ex){
        try{
          this.cdis.close();
          this.cdos.close();
          this.csocket.close();
          this.csocket = new Socket(this.hostip ,this.port);
          this.hostname = this.csocket.getInetAddress().getHostAddress();
          this.cdis = this.csocket.getInputStream();
          this.cdos = this.csocket.getOutputStream();
        }
        catch(Exception ex1){
          ex1.printStackTrace();
          System.exit(0);
        }
        continue;
      }
    }

    System.out.println(Thread.currentThread().getName()
    + " Ŭ���̾�Ʈ ���� ["+srttime+":"+ComUtil.GetSysTime()+"]["+cnt+"]"+ComUtil.ItvSec(srttime,ComUtil.GetSysTime()));

    try{
      this.cdis.close();
      this.cdos.close();
      this.csocket.close();
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex1){
      ex1.printStackTrace();
      System.exit(0);
    }

  }
}
