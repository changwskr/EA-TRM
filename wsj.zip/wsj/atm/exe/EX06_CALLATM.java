package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.io.*;

import wsj.atm.common.*;
import wsj.atm.env.*;
import wsj.atm.log.*;
import wsj.atm.packet.*;

public class EX06_CALLATM extends Thread {
  public static int gTxCnt=0;
  private Socket csocket;
  private OutputStream cdos;
  private InputStream cdis;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  private int txcnt;


  public static void main(String args[]) throws IOException {

    Hashtable tb = new Hashtable();
    System.out.println("Usage :: port thr#cnt tx#cnt");
    System.out.println("      :: ������ü�� ���õ� ������ �����Ѵ�");

    for(int i=1;i<=Integer.valueOf(args[1]).intValue();i++){
      new EX06_CALLATM("21.101.3.49",Integer.valueOf(args[0]).intValue(),tb,ComUtil.Str2Int(args[2])).start();
    }
  }

  public EX06_CALLATM (String IP,int port,Hashtable thrmanage,int txcnt) throws IOException {
    this.port = port;
    this.hostip = IP;
    this.thrmanage=thrmanage;
    this.txcnt = txcnt;
  }

  private int cnt =0;
  String srttime;
  String recvdata;

  public void run(){
    srttime = ComUtil.GetSysTime();
    String recvdata = null;
    String senddata = null;
    try{
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }

    ////////////////////////////////////////////////////////////////////////
    // �α��� �ŷ��� �ǽ��Ѵ�.
    ////////////////////////////////////////////////////////////////////////
    IOBoundArea in = null;
    IOBoundArea out = null;

    try{
      in = new IOBoundArea();
      out = null;
      ///////////////////////////////////////////////////////////////////////
      // �α��ΰŷ��� �ǽ��Ѵ�
      ///////////////////////////////////////////////////////////////////////
      //�������� �ۼ�
      in.cdto.setUserId("test1     ");
      in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
      in.iohead.sDSysDate = ComUtil.GetSysDate() ;
      in.cdto.setTerminalId("Teminal***ID");
      in.cdto.setEventNo("80000");
      in.iohead.sDTimer = "99000"; //60��
      in.cdto.setBankCode("03");
      String logindata = "03test1     test1   ";
      in.iodata.sBoundData = logindata;
      in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str( in.iodata.sBoundData.length() ),5) ;
      senddata = in.toString();

      csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
      SOCKETapi.jni_write_data(this.cdos ,senddata);
      recvdata = SOCKETapi.jni_read_data(this.cdis);

      out = new IOBoundArea(recvdata);

      if( out.iohead.sBErrCode.charAt(0) == 'E' ){
        System.out.println("-�α��� �ŷ�����----------::"+out.iohead.sBErrCode );
        return;
      }
      else{
        System.out.println("-�α��� �ŷ�����----------::"+out.iohead.sBErrCode );
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println("login �ŷ��� �����߽��ϴ�.");
      return;
    }

    while(true){
      try{

        System.out.println("-------------------------------------------------------------------------------["+cnt+"]");

        //in.cdto.setUserId("WXX0000001");
        in.iohead.sDInTime = ComUtil.GetSysTime().substring(0,8);
        in.iohead.sDSysDate = ComUtil.GetSysDate() ;
        in.cdto.setEventNo("80002");
        in.iodata.sBoundData = "AAAAA";
        in.iohead.sDTimer = "99000";
        //��������Ÿ�� �����Ѵ�.
        IOBoundDep80002CDTO depo = new IOBoundDep80002CDTO();
        depo.AccountNumber = "0238100200000271";
        // ������ü�� ���ؼ� �ִ´�.
        depo.TargetAccountNo  = "0001100100000048";
        depo.BankCode = in.cdto.bankCode;
        depo.PbKind = "N";
        depo.TrxCcyu = "USD";
        depo.Amount = ComUtil.BigZeroToStr("50.00",depo.Amount_LEN) ;
        depo.TransactionAmount = depo.Amount;
        depo.TrxStatus = "50";
        depo.FeeWaivFlag = "N";
        depo.ApproveStatus = "50";
        depo.ColleceedBalance = ComUtil.BigZeroToStr("00.00",depo.ColleceedBalance_LEN) ;

        in.iodata.sBoundData = depo.toString();
        in.sLength = ComUtil.ZeroToStr( ComUtil.Int2Str(depo.toString().length()),5);

        senddata = in.toString();
        System.out.println("EJB����["+senddata+"]");
        csocket.setSoTimeout(ComUtil.Str2Int(in.iohead.sDTimer));
        SOCKETapi.jni_write_data(this.cdos ,senddata);
        recvdata = SOCKETapi.jni_read_data(this.cdis);
        System.out.println("EJB����["+recvdata);

        cnt++;
        if(cnt==txcnt) break;

      }
      catch(Exception ex){
        try{
          this.cdis.close();
          this.cdos.close();
          this.csocket.close();
          this.csocket = new Socket(this.hostip ,this.port);
          this.hostname = this.csocket.getInetAddress().getHostAddress();
          this.cdis = this.csocket.getInputStream();
          this.cdos = this.csocket.getOutputStream();
        }
        catch(Exception ex1){
          ex1.printStackTrace();
          System.exit(0);
        }
        cnt++;
        if(cnt==txcnt) break;
        continue;
      }
    }

    System.out.println(Thread.currentThread().getName()
    + " Ŭ���̾�Ʈ ���� ["+srttime+":"+ComUtil.GetSysTime()+"]["+cnt+"]"+ComUtil.ItvSec(srttime,ComUtil.GetSysTime()));

    try{
      this.cdis.close();
      this.cdos.close();
      this.csocket.close();
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex1){
      ex1.printStackTrace();
      System.exit(0);
    }

  }
}
