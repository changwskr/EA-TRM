package wsj.atm.exe;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.util.*;
import java.text.*;
import java.io.*;

public class DJClient extends Thread {
  public static int gTxCnt=0;
  private Socket csocket;
  private OutputStream cdos;
  private InputStream cdis;

  private int port;
  private String hostip;
  private String hostname;
  private Hashtable thrmanage;

  private int txcnt;

  public static void main(String args[]) throws IOException {
    Hashtable tb = new Hashtable();
    System.out.println("Usage :: port thr#cnt tx#cnt ip");
    for(int i=1 ; i<=Integer.valueOf(args[1]).intValue() ; i++)
    {
      new DJClient(args[3],Integer.valueOf(args[0]).intValue(),tb,Str2Int(args[2])).start();
    }
  }

  public DJClient (String IP,int port,Hashtable thrmanage,int txcnt) throws IOException {
    this.port = port;
    this.hostip = IP;
    this.thrmanage=thrmanage;
    this.txcnt = txcnt;
  }

  public static final int Str2Int(String str)
  {
    int i=Integer.valueOf(str).intValue();
    return(i);
  }

  public static final void jni_write_data (OutputStream out,String senddata) throws IOException
  {
    byte[] bytebuff = senddata.getBytes();
    try{
      //�����ٵ���Ÿ�� ���̸� ���� �����Ѵ�.
      int size = bytebuff.length;
      String sendlen_buff = ZeroPlusToString(new Integer(size).toString(),5);
      byte[] bytebuff2 = sendlen_buff.getBytes();
      out.write(bytebuff2,0,bytebuff2.length);
      System.out.println(":::>> send_len : "+ sendlen_buff);

      //������Ÿ�� �����Ѵ�.
      out.write(bytebuff,0,bytebuff.length);
    }
    catch(IOException ioe){
      ioe.printStackTrace();
      System.out.println(ioe);
      System.out.println(ioe);
      throw new IOException("write_data ex::"+ioe.getMessage());
    }
    return ;
  }
  public static String ZeroPlusToString(String str,int size)
  {
    StringBuffer tt = new StringBuffer();
    for ( int i = 1; i <= size ; i ++ )
      tt.append('0');
    DecimalFormat fmt = new DecimalFormat(tt.toString());
    fmt = new DecimalFormat(tt.toString());
    return(fmt.format(Integer.valueOf(str).intValue()));
  }
  public static final String read_data (InputStream in) throws IOException {
    byte[] bytebuff;
    try{
      DataInputStream dis = new DataInputStream(in);
      int size=dis.readInt();
      bytebuff = read_data(in,size);
    }
    catch(Exception ioe){
      ioe.printStackTrace();
      throw new IOException("read_data ex::"+ioe.getMessage());
    }
    return new String(bytebuff);
  }
  // ���������ϴ� ����Ʈ�� ���̸� ���� write�ϰ� ���� byte�� write�Ѵ�.
  public static final void write_data (OutputStream out,String senddata) throws IOException {
    byte[] bytebuff = senddata.getBytes();
    try{
      DataOutputStream dos = new DataOutputStream(out);
      int size = bytebuff.length;
      dos.writeInt(size);
      out.write(bytebuff,0,bytebuff.length);
    }
    catch(IOException ioe){
      ioe.printStackTrace();
      throw new IOException("write_data ex::"+ioe.getMessage());
    }
    return ;
  }

  private static final byte[] read_data(InputStream in, int len) throws Exception
  {
    java.io.ByteArrayOutputStream bout = new java.io.ByteArrayOutputStream();
    int bcount = 0;
    byte[] buf = new byte[2048];
    while( bcount < len ) {
      int n = in.read(buf,0, len-bcount < 2048 ? len-bcount : 2048 );
      if (n == -1) break;
      bcount += n;
      bout.write(buf,0,n);
    }
    bout.flush();
    return bout.toByteArray();
  }
  public static final String jni_read_data (InputStream in) throws IOException
  {
    byte[] bytebuff;
    try{
      byte[] bytebuff2= null;
      bytebuff2 = read_data(in,5);
      int size = Integer.valueOf(new String(bytebuff2)).intValue();
      bytebuff = read_data(in,size);
    }
    catch(Exception ioe){
      ioe.printStackTrace();
      System.out.println(ioe);
      System.out.println(ioe);
      throw new IOException("read_data ex::"+ioe.getMessage());
    }
    return new String(bytebuff);
  }

  private int cnt =0;
  String srttime;
  String recvdata;
  public void run(){
    String recvdata = null;
    String senddata = null;
    try{
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.csocket.setSoTimeout(30000);
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();

    }
    catch(Exception ex){
      ex.printStackTrace();
      System.exit(0);
    }

    while(true){
      try{

        senddata="1111111111111111111111111111111111111";
        System.out.println("send["+senddata+"]");

        jni_write_data(this.cdos ,senddata);
        cnt++;
        recvdata = jni_read_data(this.cdis);
        System.out.println("send["+recvdata+"]");

        if(cnt==txcnt) break;
      }
      catch(Exception ex){
        try{
          this.cdis.close();
          this.cdos.close();
          this.csocket.close();
          this.csocket = new Socket(this.hostip ,this.port);
          this.csocket.setSoTimeout(30000);
          this.hostname = this.csocket.getInetAddress().getHostAddress();
          this.cdis = this.csocket.getInputStream();
          this.cdos = this.csocket.getOutputStream();
        }
        catch(Exception ex1){
          ex1.printStackTrace();
          System.exit(0);
        }
        continue;
      }
    }

    try{
      this.cdis.close();
      this.cdos.close();
      this.csocket.close();
      this.csocket = new Socket(this.hostip ,this.port);
      this.hostname = this.csocket.getInetAddress().getHostAddress();
      this.cdis = this.csocket.getInputStream();
      this.cdos = this.csocket.getOutputStream();
    }
    catch(Exception ex1){
      ex1.printStackTrace();
      System.exit(0);
    }

  }
}