package wsj.atm.bound;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.Serializable;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.packet.IOBoundProtoType;
import wsj.atm.common.ComUtil;
/**
 *	BatchTunnelingServlet�� ����ϱ� ���� �ְ� �޴� Command object�̴�.<p>
 *	BatchUtil.getCommand(context) �޼��带 ���� BatchCommand ��ü�� �����Ѵ�.
 *
 * @version		BFA 1.1		7 Nov 2002
 * @author		Jeon HongSeong[hsjeon70@dreamwiz.com]
 */
public class BoundArea implements Serializable,Cloneable
{
  /**
   */
  public static final int CALL_LOGIN = 100;
  public static final int RTN_TO_CLIENT = 1000;
  public static final int CMD_INITIAL = 1;

  /**
   *	Batch EJB ������Ʈ �޼��带 ȣ���ϱ����� command
   */
  public static final int CALL_BATCH_EJB		=10;
  /**
   *	business date�� ������� command
   */
  public static final int GET_BUSINESS_DATE	=20;
  /**
   *	system date�� ������� command
   */
  public static final int GET_SYSTEM_DATE		=30;
  /**
   *	system time�� ������� command
   */
  public static final int GET_SYSTEM_TIME		=40;

  /**
   *	command
   */
  private int command;

  //batch id
  private String batchId;
  // bank code
  private String bankCode;
  // branch code
  private String branchCode;
  // nation
  private String nation;
  // region code
  private String regionCode;
  // batch id
  private String terminalId;
  // batch type
  private String terminalType;
  // time zone
  private String timeZone;
  // user id
  private String register;

  ////////////////////////////////////////////////////////////////////////
  // CosesCommonDTO �� �߰��Ѵ�.
  ////////////////////////////////////////////////////////////////////////
  public CosesCommonDTO cdto;
  public String passwd;
  public String tellerId;
  public String errcode;
  public String errmsg;
  /**
   * EJB business action name
   */
  private String bizAction;
  /**
   *	business method�� parameter�� ������ CDTO
   */
  private Object parameter;

  //////////////////////////////////////////////////////////////////////////
  /**
   *	Constructor
   *
   *	@param	command	BoundArea�� ����
   */
  public BoundArea(int command)
  {
    this.command = command;
    this.cdto = new CosesCommonDTO();
    this.passwd = "********";
    this.tellerId = "**********";
    this.errcode = "IZZ000";
  }

  /**
   *	command�� ���� getter method
   *
   *	@return Batch command
   */
  public int getCommand()
  {
    return this.command;
  }

  /**
   *	command�� ���� setter method
   *
   *	@param	command	 Batch command
   */
  public void setCommand(int command)
  {
    this.command = command;
  }

  /**
   *	bizAction�� ���� getter method
   *
   *	@return EJB business action name
   */
  public String getBizAction()
  {
    return this.bizAction;
  }

  /**
   *	bizAction�� ���� setter method
   *
   *	@param	bizAction	EJB business action name
   */
  public void setBizAction(String bizAction)
  {
    this.bizAction = bizAction;
  }

  /**
   *	parameter�� ���� getter method
   *
   *	@return EJB business method parameter�� ������ CDTO
   */
  public Object getParameter()
  {
    return this.parameter;
  }

  /**
   *	parameter�� ���� setter method
   *
   *	@param	parameter	EJB business method parameter�� ������ CDTO
   */
  public void setParameter(Object parameter)
  {
    this.parameter = parameter;
  }

  /**
   *	batchId ���� getter method
   *
   *	@return	batchId
   */
  public String getBatchId()
  {
    return this.batchId;
  }

  /**
   *	batchId ���� setter method
   *
   *	@param	batchId	batchId
   */
  public void setBatchId(String batchId)
  {
    this.batchId = batchId;
  }

  /**
   *	bankCode�� ���� getter method
   *
   *	@return	bank code
   */
  public String getBankCode()
  {
    return this.bankCode;

  }

  /**
   *	bankCode�� ���� setter method
   *
   *	@param	bankCode	bank code
   */
  public void setBankCode(String bankCode)
  {
    this.bankCode = bankCode;
    this.cdto.setBankCode(this.bankCode);
  }

  /**
   *	branchCode�� ���� getter method
   *
   *	@return branch code
   */
  public String getBranchCode()
  {
    return this.branchCode;
  }

  /**
   *	branchCode�� ���� setter method
   *
   *	@param	branchCode	branch code
   */
  public void setBranchCode(String branchCode)
  {
    this.branchCode = branchCode;
    this.cdto.setBranchCode(this.branchCode);
  }

  /**
   *	nation�� ���� setter method
   *
   *	@param	nation	���� �ڵ�
   */
  public void setNation(String nation)
  {
    this.nation = nation;
    this.cdto.setNation(this.nation);
  }

  /**
   *	nation�� ���� getter method
   *
   *	@return  ���� �ڵ�
   */
  public String getNation()
  {
    return this.nation;
  }

  /**
   *	regionCode�� ���� setter method
   *
   *	@param	regionCode	���� �ڵ�
   */
  public void setRegionCode(String regionCode)
  {
    this.regionCode = regionCode;
    this.cdto.setRegionCode(this.regionCode);
  }

  /**
   *	regionCode�� ���� getter method
   *
   *	@return region code
   */
  public String getRegionCode()
  {
    return this.regionCode;
  }

  /**
   *	timeZone�� ���� setter method
   *
   *	@param timeZone	time zone
   */
  public void setTimeZone(String timeZone)
  {
    this.timeZone = timeZone;
    this.cdto.setTimeZone(this.timeZone );
  }

  /**
   *	timeZone�� ���� getter method
   *
   *	@return time zone
   */
  public String getTimeZone()
  {
    return this.timeZone;
  }

  /**
   *	termianlId�� ���� setter method
   *
   *	@param	terminalId	batch Id
   */
  public void setTerminalId(String terminalId)
  {
    this.terminalId = terminalId;
    this.cdto.setTerminalID(this.terminalId);
  }

  /**
   *	terminalId�� ���� getter method
   *
   *	@return	termianlId(batch id)
   */
  public String getTerminalId()
  {
    return this.terminalId;
  }

  /**
   *	termianlType�� ���� setter method
   *
   *	@param	terminalType	batch type
   */
  public void setTerminalType(String terminalType)
  {
    this.terminalType = terminalType;
    this.cdto.setTerminalType(this.terminalType);
  }

  /**
   *	terminalType�� ���� getter method
   *
   *	@return terminalType(batch type)
   */
  public String getTerminalType()
  {
    return this.terminalType;
  }

  /**
   *	register�� ���� getter method
   *
   *	@return batch �����
   */
  public String getRegister()
  {
    return this.register;
  }

  /**
   *	register�� ���� setter method
   *
   *	@param	batch �����
   */
  public void setRegister(String register)
  {
    this.register = register;
  }

  /**
   *	BoundArea attribute list�� ��ȯ�ϴ� toString() method
   *
   *	@return attribute list
   */
  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    sb.append("BoundArea [ command=").append(command);
    sb.append(", bizAction=").append(bizAction);
    sb.append(", bankCode=").append(bankCode);
    sb.append(", branchCode=").append(branchCode);
    sb.append(", nation=").append(nation);
    sb.append(", regionCode=").append(regionCode);
    sb.append(", timeZone=").append(timeZone);
    sb.append(", terminalId=").append(terminalId);
    sb.append(", terminalType=").append(terminalType);
    sb.append(", register=").append(register);
    sb.append(", parameter=").append(parameter);
    sb.append(" ]");

    return sb.toString();
  }

  public Object clone() {
    Object o = null;
    try{
      o = super.clone();
    }
    catch(Exception e){
      e.printStackTrace();
    }
    return o;
  }

  public void setFormat(){

    cdto.setTerminalID(ComUtil.FillSpaceToStr(cdto.getTerminalID(),IOBoundProtoType.terminalId_LEN));
    cdto.setTerminalType(ComUtil.FillSpaceToStr(cdto.getTerminalType(),IOBoundProtoType.terminalType_LEN));
    cdto.setXmlSeq(ComUtil.FillSpaceToStr(cdto.getXmlSeq(),IOBoundProtoType.xmlSeq_LEN));
    cdto.setBankCode(ComUtil.FillSpaceToStr(cdto.getBankCode(),IOBoundProtoType.bankCode_LEN));
    cdto.setBranchCode(ComUtil.FillSpaceToStr(cdto.getBranchCode(),IOBoundProtoType.branchCode_LEN));
    cdto.setGlPostBranchCode(ComUtil.FillSpaceToStr(cdto.getGlPostBranchCode(),IOBoundProtoType.gIPostBrCode_LEN));
    cdto.setChannelType(ComUtil.FillSpaceToStr(cdto.getChannelType(),IOBoundProtoType.channelType_LEN));
    cdto.setUserID(ComUtil.FillSpaceToStr(cdto.getUserID(),IOBoundProtoType.userId_LEN));
    cdto.setEventNo(ComUtil.FillSpaceToStr(cdto.getEventNo(),IOBoundProtoType.eventNo_LEN ));
    cdto.setNation(ComUtil.FillSpaceToStr(cdto.getNation(),IOBoundProtoType.nationCode_LEN));
    cdto.setRegionCode(ComUtil.FillSpaceToStr(cdto.getRegionCode(),IOBoundProtoType.regionCode_LEN));
    cdto.setTimeZone(ComUtil.FillSpaceToStr(cdto.getTimeZone(),IOBoundProtoType.timeZone_LEN));
    cdto.setReqName(ComUtil.FillSpaceToStr(cdto.getReqName(),IOBoundProtoType.reqName_LEN));
    cdto.setSystemDate(ComUtil.FillSpaceToStr(cdto.getSystemDate(),IOBoundProtoType.trxDate_LEN ));
    cdto.setBusinessDate(ComUtil.FillSpaceToStr(cdto.getBusinessDate(),IOBoundProtoType.bizDate_LEN));
    cdto.setSystemInTime(ComUtil.FillSpaceToStr(cdto.getSystemInTime(),IOBoundProtoType.trxInTime_LEN));
    cdto.setSystemOutTime(ComUtil.FillSpaceToStr(cdto.getSystemOutTime(),IOBoundProtoType.trxOutTime_LEN));
    cdto.setTransactionNo(ComUtil.FillSpaceToStr(cdto.getTransactionNo(),IOBoundProtoType.trxNumber_LEN));
    cdto.setBaseCurrency(ComUtil.FillSpaceToStr(cdto.getBaseCurrency(),IOBoundProtoType.baseCurrency_LEN));

    return;
  }

}