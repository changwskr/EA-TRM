package wsj.atm.env;

import java.io.*;
import java.util.*;
import wsj.atm.env.JEN;

public class UbbConfig {
  private static JEN jen;
  private static UbbConfig instance;
  private static boolean verbose = false;
  private static String ubb_fname = jen.JBB_CONF_FILE;

  public static synchronized UbbConfig getInstance() {
    if (instance == null) {
      instance = new UbbConfig();
    }
    return instance;
  }

  public static synchronized UbbConfig getInstance(String fname) {
    if (instance == null) {
      instance = new UbbConfig();
      instance.setFname(fname);
    }
    return instance;
  }

  public void setFname(String fname) {
    this.ubb_fname = fname;
  }


  public UbbConfig() {

  }

  public UbbConfig(String fname) {
    setFname(fname);
  }

  public synchronized String GetEnvValue(String tmp) throws IOException
  {
    String ConfigPath=null;

    Properties p = new Properties();
    String tmpv = null;
    FileInputStream fis = new FileInputStream(ubb_fname);
    try {
      p.load(fis);
      tmpv=p.getProperty(tmp);
      fis.close();
    }
    catch (IOException e) {
      System.out.println("GetEnvValue() ���� ȯ����ý� ���ܹ߻�" );
      e.printStackTrace();
      fis.close();
      throw new IOException("GetEnvValue() ���� ȯ����ý� ���ܹ߻�" );
    }
    return tmpv;
  }


}