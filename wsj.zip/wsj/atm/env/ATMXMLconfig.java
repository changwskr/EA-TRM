package wsj.atm.env;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.net.*;
import java.io.*;
import java.util.*;
import com.chb.coses.foundation.base.*;
import com.chb.coses.foundation.config.*;

public class ATMXMLconfig {
  private static ATMXMLconfig instance;
  //private static final String xmlfile = "/home/cosif/atmppp/env/ATMconfig.xml";
  private static String xmlfile = "atm.conf.file";

  public static synchronized ATMXMLconfig getInstance() {
    if (instance == null) {
      try{
        instance = new ATMXMLconfig();
        ATMXMLconfig.xmlfile = System.getProperty(ATMXMLconfig.xmlfile);
        if( ATMXMLconfig.xmlfile == null )
          ATMXMLconfig.xmlfile = JEN.JBB_CONF_FILE;
        }catch(Exception igex){}
    }
    return instance;
  }
  public String GetEnvValue(String ele1,String ele2){
    return XMLCache.getInstance().getXML(ATMXMLconfig.xmlfile).getRootElement().getChild(ele1).getChildTextTrim(ele2);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3){
    return XMLCache.getInstance().getXML(ATMXMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChildTextTrim(ele3);
  }
  public String GetEnvValue(String ele1,String ele2,String ele3,String ele4){
    return XMLCache.getInstance().getXML(ATMXMLconfig.xmlfile).getRootElement().getChild(ele1).getChild(ele2).getChild(ele3).getChildTextTrim(ele4);
  }
  public ATMXMLconfig() {
  }

}


