package wsj.atm.env;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import wsj.atm.common.ComUtil;

public class JEN implements Serializable {
  ///////////////////////////////////////////
  // Ʈ����� ��ȣ ä��
  ///////////////////////////////////////////
  public static int ex_txseq = 0;

  ///////////////////////////////////////////
  // ȯ�������̸�
  ///////////////////////////////////////////
  //public static String JBB_CONF_FILE="/home/cosif/atmppp/env/JBBCONF.ini";
  //public static String JBB_CONF_FILE="/home/cosif/atmppp/env/"+ComUtil.GetHostName()+".JBBCONF.INI";
  public static String JBB_CONF_FILE="/home/cosif/atmppp/env/ATMconfig.xml";
  public static String JTM_LOG_FILE="/home/cosif/atmppp/env/JTMLOGMODE.INI";
  ///////////////////////////////////////////
  // TIME ZONE INFOMATION
  ///////////////////////////////////////////
  public static String TIME_ZONE;
  ///////////////////////////////////////////
  // OS����
  ///////////////////////////////////////////
  public static String OS_TYPE="UNIX";
  ///////////////////////////////////////////
  // RMI ����
  ///////////////////////////////////////////
  public static String RMI_IP="21.101.7.60";
  public static String RMI_PORT="10000";
  public static String JNDI_NAME="JRD";
  public static String JNDI_NAME_LOG="JRDlog";
  public static String JNDI_NAME_SEQ="JRDseq";
  ///////////////////////////////////////////
  // ������������
  ///////////////////////////////////////////
  public static char JBL_PROCESS_PROTO = '1';
  public static char JSL_PROCESS_PROTO = '2';
  public static char JSH_PROCESS_PROTO = '3';
  public static char JSH_CLIENT_PROTO = '4';
  public static char JBL_MANPROC_PROTO = '5';
  public static String JSL_SEND_TYPE="1";
  public static String JSH_SEND_TYPE="2";
  public static String PROCESS_CHK_DATA="PROCESS";
  public static int POSITION_USERID=135;
  ///////////////////////////////////////////
  // ȯ������
  ///////////////////////////////////////////
  public static String JSL_IP;
  public static String JSL_NAME;
  public static String JSL_PORT;
  public static String JSL_BOOT;
  public static String JSL_MAX_THR_CNT;
  public static String JSH_MAX_THR_CNT;
  public static String JSH_BOOT;
  public static String JSH_SVC_NAME;
  public static String JSH_NUM;
  public static String TYPE;
  public static String LOG_FILE;
  public static String JPC_LOOP_TIME;
  public static String JSP_LOOP_TIME;
  public static String JPC_SOK_TIMEOUT;
  public static String JSR_SOK_PORT;
  public static String JSI_SOK_PORT="35530";
  public static String JSI_MAX_THR_CNT="3";
  ///////////////////////////////////////////
  // �α����
  ///////////////////////////////////////////
  public static String LOGFILENAME;
  public static String BIZLOGFILENAME;
  ///////////////////////////////////////////
  // JSH ���μ��� ���� ����
  ///////////////////////////////////////////
  public String JSH_CONN_CLT_NUM="JSH_CONN_CLT_NUM";
  ///////////////////////////////////////////
  // JSL ���μ��� ���� ����
  ///////////////////////////////////////////
  //////////////////////////////////////////
  public static JEN instance;

  public static synchronized JEN getInstance() throws IOException {
    if (instance == null) {
      instance = new JEN();
    }
    return instance;
  }

  public JEN() throws IOException {
    JSR_SOK_PORT=UbbConfig.getInstance().GetEnvValue("JSR_SOK_PORT");
    OS_TYPE=UbbConfig.getInstance().GetEnvValue("OS_TYPE");
    JSL_IP=UbbConfig.getInstance().GetEnvValue("JSL_IP");
    JSL_NAME=UbbConfig.getInstance().GetEnvValue("JSL_NAME");
    JSL_PORT=UbbConfig.getInstance().GetEnvValue("JSL_PORT");
    JSL_MAX_THR_CNT=UbbConfig.getInstance().GetEnvValue("JSL_MAX_THR_CNT");
    JSH_MAX_THR_CNT=UbbConfig.getInstance().GetEnvValue("JSH_MAX_THR_CNT");
    TYPE=UbbConfig.getInstance().GetEnvValue("TYPE");
    JSL_BOOT=UbbConfig.getInstance().GetEnvValue("JSL_BOOT");
    JSH_BOOT=UbbConfig.getInstance().GetEnvValue("JSH_BOOT");
    JSH_SVC_NAME="JSH_SVC_";
    JSH_NUM=UbbConfig.getInstance().GetEnvValue("JSH_NUM");
    LOG_FILE=UbbConfig.getInstance().GetEnvValue("LOG_FILE");
    JPC_LOOP_TIME=UbbConfig.getInstance().GetEnvValue("JPC_LOOP_TIME");
    JSP_LOOP_TIME=UbbConfig.getInstance().GetEnvValue("JSP_LOOP_TIME");
    JPC_SOK_TIMEOUT=UbbConfig.getInstance().GetEnvValue("JPC_SOK_TIMEOUT");
    /*
    LOGFILENAME=UbbConfig.getInstance().GetEnvValue("LOGFILENAME");
    BIZLOGFILENAME=UbbConfig.getInstance().GetEnvValue("BIZLOGFILENAME");
    TIME_ZONE=UbbConfig.getInstance().GetEnvValue("TIMEZONE");
    */
    if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
      LOGFILENAME=ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGFILENAME");
      BIZLOGFILENAME=ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","BIZLOGFILENAME");
      TIME_ZONE=ATMXMLconfig.getInstance().GetEnvValue("RESOURCE","TIMEZONE");
    }
    else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
      LOGFILENAME=ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","LOGFILENAME");
      BIZLOGFILENAME=ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","BIZLOGFILENAME");
      TIME_ZONE=ATMXMLconfig.getInstance().GetEnvValue("RESOURCE","TIMEZONE");
    }
  }
}
