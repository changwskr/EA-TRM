package wsj.atm.env;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ATMPPPDOC {
/*------------------------------------------------------------------------------
  FILENAME :JBBCONF.ini
  *-----------------------------------------------------------------------------
#REFERENCE [ConfigReference]
#Tue Feb 04 10:56:38 KST 2003

*-----------------------------------------------------------------------
*LOG MANAGEMENT
*-----------------------------------------------------------------------
LOGFILENAME=/home/cosif/atmppp/log/bizlog/atmppp
SYSLOGFILENAME=/home/cosif/atmppp/log/bizlog/system
BIZLOGFILENAME=/home/cosif/atmppp/log/packet/
JBB_CONF=/home/cosif/atmppp/env/JBBCONF.ini
LOGINATM=/home/cosif/atmppp/log/atminfo/

*-----------------------------------------------------------------------
*TIMEZONE
*-----------------------------------------------------------------------
TIMEZONE=GMT+09:00

*-----------------------------------------------------------------------
* ���� ����
*-----------------------------------------------------------------------
*ATMserverhandler
ATMserverhandler_NUM=2
ATMserverhandler_MAX_THR_CNT=10

ATMserverhandler_SVC_1=ATMserverhandler_1
ATMserverhandler_PORT_1=32231

ATMserverhandler_SVC_2=ATMserverhandler_2
ATMserverhandler_PORT_2=32232

*-----------------------------------------------------------------------
*WAS
*-----------------------------------------------------------------------
#RMISERVER=21.102.4.173
RMISERVER=21.102.1.227
#RMISERVER=21.101.7.60
#RMISERVER=21.102.4.162
#RMISERVER=21.101.3.49
#RMIPORT=7001
#RMISERVER=21.102.4.178
RMIPORT=10000

*-----------------------------------------------------------------------
*DBPOOL
*-----------------------------------------------------------------------
driver=oracle.jdbc.driver.OracleDriver
url=jdbc:oracle:thin:@21.101.3.49:1521:DEVMIS
#url=jdbc:oracle:thin:@21.101.7.60:1521:ACCT1
user=mis
#user=eplaton
password=mis
#password=eplaton
InitConnCnt=5
MaxConnCnt=5
MaxConnTimeout=60

*-----------------------------------------------------------------------
*EJBPOOL
*-----------------------------------------------------------------------
eInitConnCnt=5
eMaxConnCnt=5
eMaxConnTimeout=60

*-----------------------------------------------------------------------
*Blocking Transaction
*-----------------------------------------------------------------------
[TELLER]
TMODE=OFF
TELLS=0238001
TELLE=0238001

[TXCODE]
EMODE=OFF
EVNTS1=80001
EVNTE1=80001
EVNTS2=*****
EVNTE2=*****
EVNTS3=*****
EVNTE3=*****
EVNTS4=*****
EVNTE4=*****
EVNTS5=*****
EVNTE5=*****

[BRANCH]
BMODE=OFF
BRCHS=0238
BRCHE=0238

  *-----------------------------------------------------------------------------
  FILENAME : JTMLOGMODE.INI
  *-----------------------------------------------------------------------------
  #######################################
  # NOLOG   : 4
  # INFO    : 1
  # DEBUG   : 2
  # FATAL   : 10
  #
  #######################################
JTMLOGGING_MODE=1
JTMDEBUGIN_MODE=3

--------------------------------------------------------------------------------*/
}
