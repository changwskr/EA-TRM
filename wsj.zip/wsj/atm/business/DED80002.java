package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80002CDTO;
import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.AccountDetailCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.tcf.*;
import wsj.atm.socket.*;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;

public class DED80002 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundDep80002CDTO iobounddeposit = null;
  public AccountDetailCDTO acdto = null;

  public DED80002(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80002 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iobounddeposit = new IOBoundDep80002CDTO();
      iobounddeposit.setIOBoundDep80002CDTOParsing(this.inarea.iodata.sBoundData);
      iobounddeposit.FeeWaivFlag="N";

      acdto = new AccountDetailCDTO();
      acdto.setAccountNumber(iobounddeposit.AccountNumber);
      acdto.setBankCode(iobounddeposit.BankCode);
      acdto.setPbKind(iobounddeposit.PbKind);

      /*
      acdto.setAmount(new BigDecimal(iobounddeposit.Amount));
      acdto.setTransactionAmount(new BigDecimal(iobounddeposit.TransactionAmount));
      */

      acdto.setTrxStatus(iobounddeposit.TrxStatus );
      acdto.setCalculationFee(iobounddeposit.FeeWaivFlag);
      acdto.setCalculationFee(iobounddeposit.FeeWaivFlag);
      acdto.setInclusionFee("N");
      acdto.setTransactionCode("550");
      acdto.setSecurityNo(ComUtil.CutSpaceToStr(iobounddeposit.SecurityNo,iobounddeposit.SecurityNo_LEN));
      acdto.setAtmSeqNo(this.inarea.cdto.atmSeqNo);
      acdto.setCardNumber(this.iobounddeposit.CashCardNo );
      acdto.setRateType("N");

      /*
      AccountQueryCDTO aqcdto = TCPCallEJB.getAccountQueryCDTO(this.iobounddeposit.AccountNumber,
                          this.iobounddeposit.BankCode,
                          STF.getCosesCDTOfromInBoundArea(this.inarea));
      */
      ///////////////////////////////////////////////////////////////////////////
      BoundArea outbound1 = TCPCallEJB.getAccountQueryCDTO(this.iobounddeposit.AccountNumber,
                          this.iobounddeposit.BankCode,
                          STF.getCosesCDTOfromInBoundArea(this.inarea));
      AccountQueryCDTO aqcdto = (AccountQueryCDTO)outbound1.getParameter();

      BoundArea bab = TCPCallEJB.getAccountQueryCDTO(ComUtil.CutSpaceToStr(iobounddeposit.TargetAccountNo,iobounddeposit.TargetAccountNo_LEN),
                          this.iobounddeposit.BankCode,STF.getCosesCDTOfromInBoundArea(this.inarea));
      AccountQueryCDTO aqcdtt = (AccountQueryCDTO)bab.getParameter();

      if( aqcdtt == null ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "ED0033" ;
        this.outarea.iohead.setMsg("App Ex[DED80002.TCPCallEJB Processing Error]");
        this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }

      if( aqcdto == null ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "ED0017" ;
        this.outarea.iohead.setMsg("App Ex[DED80002.TCPCallEJB Processing Error]");
        this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      else{
        if( !outbound1.errcode.equals("IZZ000")){
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound1.errcode;
          this.outarea.iohead.setMsg("App Ex[DED80002.TCPCallEJB Processing Error]");
          this.outarea.iohead.setMsg(outbound1.errmsg);
          this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(
              ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }
      }
      //////////////////////////////////////////////////////////////////////////

      if( aqcdto.getCurrency().equals("USD") && aqcdtt.getCurrency().equals("VND") ){
        iobounddeposit.TrxCcyu = "VND";
        acdto.setTrxCcy(iobounddeposit.TrxCcyu);
      }
      else if( aqcdto.getCurrency().equals("VND") && aqcdtt.getCurrency().equals("USD") ){
        /* ��Ʈ������ ���� ���� : VND->USD�� �ŷ��� ���´�.
        iobounddeposit.TrxCcyu = "USD";
        acdto.setTrxCcy(iobounddeposit.TrxCcyu);
        */
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "ED0055" ;
        this.outarea.iohead.setMsg("Not Accept Tranaction between VND account and USD account");
        this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      else if( aqcdto.getCurrency().equals("VND") && aqcdtt.getCurrency().equals("VND") ){
        iobounddeposit.TrxCcyu = "VND";
        acdto.setTrxCcy(iobounddeposit.TrxCcyu);
      }
      else if( aqcdto.getCurrency().equals("USD") && aqcdtt.getCurrency().equals("USD") ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "ED0055" ;
        this.outarea.iohead.setMsg("Not Accept Tranaction between USD account and USD account");
        this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }

      if( aqcdto.getCurrency().equals("USD") ){
        acdto.setTransactionAmount(new BigDecimal(iobounddeposit.TransactionAmount));
      }
      else if( aqcdto.getCurrency().equals("VND") ){
        acdto.setAmount(new BigDecimal(iobounddeposit.Amount));
        acdto.setTransactionAmount(new BigDecimal(iobounddeposit.TransactionAmount));
      }

      acdto.setAccountGroup(aqcdto.getAccountGroup());
      acdto.setAccountGroupKind(aqcdto.getAccountGroupKind());
      acdto.setCIFNo(aqcdto.getCIFNo());
      JLO.getInstance().printf(1,"### AccountGrp:" + aqcdto.getAccountGroup() + "CifNo:"+aqcdto.getCIFNo()
                   +"  Passwd:["+ComUtil.CutSpaceToStr(iobounddeposit.SecurityNo,iobounddeposit.SecurityNo_LEN)+"]");
      JLO.getInstance().printf(1, aqcdto.getCurrency() + " : transaction amount - " + acdto.getTransactionAmount()
                         + " amount - " + acdto.getAmount() + " trxccy : " + acdto.getTrxCcy()
                         );

      acdto.setApproveStatus(iobounddeposit.ApproveStatus);
      // ���� ��ü ���� ��ȣ
      acdto.setTransferAcctNo( ComUtil.CutSpaceToStr(iobounddeposit.TargetAccountNo,iobounddeposit.TargetAccountNo_LEN));
      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      ///////////////////////////////////////////////////////////////////////////
      // 1]  object model
      ///////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-withdrawAccount",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("deposit-withdrawAccount",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");
      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        AccountDetailCDTO result = (AccountDetailCDTO)outbound.getParameter();
        outbound.cdto.setTransactionNo(result.getTrxNo());
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"--trxnumber:"+result.getTrxNo());
        JLO.getInstance().printf(1,"--colamount:"+result.getCollectedBalance().toString());
        //JLO.getInstance().printf(1,"--feeamount:"+result.getFeeAmount().toString());
        JLO.getInstance().printf(1,"--feeamount:"+result.getFeeAmount().toBigInteger().longValue());
        JLO.getInstance().printf(1,"************************************************");
        //��¾�������Ÿ�ۼ�
        //this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toString(),IOBoundDep80002CDTO.FeeAmount_LEN );
        this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toBigInteger().longValue()+"",IOBoundDep80002CDTO.FeeAmount_LEN );

        /**********************************************************************
         * VND USD �� ���Ͽ� �޸� �۾��� �Ѵ�.
         * ********************************************************************/
         this.iobounddeposit.TrxCcyu=result.getCurrency();
         if( result.getCurrency().equals("USD") ){
            this.iobounddeposit.ColleceedBalance = ComUtil.BigZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80002CDTO.ColleceedBalance_LEN );
            //this.iobounddeposit.TD5="USD";
         }
         else if( result.getCurrency().equals("VND") ){
            this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80002CDTO.ColleceedBalance_LEN );
            //this.iobounddeposit.TD5="VND";
         }
        //this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80002CDTO.ColleceedBalance_LEN );


        this.iobounddeposit.setTransactionNo(result.getTrxNo());
        if( aqcdtt.getCIFName().length() >= 20 ){
          this.iobounddeposit.TD10 = aqcdtt.getCIFName().substring(0,20);
        }
        else{
          this.iobounddeposit.TD10 = ComUtil.PSpaceToStr(aqcdtt.getCIFName(),this.iobounddeposit.TD10_LEN) ;
        }
        this.outarea.cdto.setTrxNumber( this.iobounddeposit.TransactionNo );
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Infomation[DED80002.Tx is success]");
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        iobounddeposit.toPrint();
      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0005";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80002.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0006";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80002.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0007";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80002.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0008";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80002.Other Exception]");
      }
      this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(
          ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }



}