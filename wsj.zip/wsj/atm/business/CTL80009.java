package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundCtl80009CDTO;
import wsj.atm.packet.IOBoundProtoType;

public class CTL80009
{
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public String OrgEventNo;
  public IOBoundCtl80009CDTO iobound = null;

  public CTL80009(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
  }

  public IOBoundArea execute() throws Exception
  {

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          CTL80009 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      iobound = new IOBoundCtl80009CDTO();
      iobound.setIOBoundCtl80009CDTOParsing(this.inarea.iodata.sBoundData);
      JLO.getInstance().printf(1,"Bank Code :"+iobound.BankCode );
      JLO.getInstance().printf(1,"Biz  Date :"+iobound.bizDate );
      JLO.getInstance().printf(1,"Trx Stats :"+iobound.CloseOffset);

      if( iobound.CloseOffset.equals("10") )
        JLO.getInstance().printf(1,"�ش翵�����ڷ� �ŷ����Դϴ� " + iobound.bizDate );

      if( iobound.CloseOffset.equals("20") )
        JLO.getInstance().printf(1,"�ش翵�����ڷ� �����۾����Դϴ� " + iobound.bizDate );

      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      JLO.getInstance().eprintf(10,e);
    }
    return outarea;

  }

}
