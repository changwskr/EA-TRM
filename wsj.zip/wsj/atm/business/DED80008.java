package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80008CDTO;
import wsj.atm.packet.IOBoundTxHistoryCDTO;
import wsj.atm.packet.IOBoundProtoType;
import com.chb.coses.deposit.transfer.AccountPageCDTO;
import com.chb.coses.deposit.transfer.TransactionHistoryPageItemsCDTO;
import com.chb.coses.deposit.transfer.CancelAccountCDTO;
import com.chb.coses.deposit.transfer.InquiryConditionCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;

import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class DED80008 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public String OrgEventNo;
  public IOBoundDep80008CDTO iobounddeposit = null;
  public CancelAccountCDTO acdto = null;

  public DED80008(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.OrgEventNo = this.inarea.cdto.eventNo;
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80008 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      JLO.getInstance().printf(1,"--�⺻������ ����");
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iobounddeposit = new IOBoundDep80008CDTO();
      iobounddeposit.setIOBoundDep80008CDTOParsing(this.inarea.iodata.sBoundData);

      acdto = new CancelAccountCDTO();
      acdto.setAccountNumber(iobounddeposit.AccountNumber);
      acdto.setBankCode(iobounddeposit.BankCode);
      /* --------------------------------------------------------------------*
      String txNo =
          TCPCallEJB.getTransactionNo( this.iobounddeposit.AccountNumber,
                                       this.iobounddeposit.BankCode,
                                       this.iobounddeposit.transactionDate,
                                       this.iobounddeposit.txAmount,
                                       STF.getCosesCDTOfromInBoundArea(this.inarea) );
      if( txNo.equals("0000000000000000") ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "EI0034" ;
        this.outarea.iohead.setMsg("DED8008 GetTxNo Exception");
        this.outarea.iodata.sBoundData = "DED8008 GetTxNo Exception";
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      acdto.setTransactionNo(txNo);
      * --------------------------------------------------------------------*/

      /*
      acdto.setTransactionNo(ComUtil.CutSpaceToStr(this.iobounddeposit.atmTransactionNo,
                               IOBoundProtoType.trxNumber_LEN));
      */
      String txNo = this.iobounddeposit.getTransactionNo(STF.getCosesCDTOfromInBoundArea(this.inarea));
      if( txNo.equals("0000000000000000") ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "EI0034" ;
        this.outarea.iohead.setMsg("DED8008 GetTxNo Exception");
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      acdto.setTransactionNo(txNo);
      acdto.setEventNumber("13120");
      acdto.setTransactionDate(this.iobounddeposit.transactionDate);

      //////////////////////////////////////////////////////////////////////////
      IOBoundTxHistoryCDTO iotxhistory = IOBoundTxHistoryCDTO.GetIOBoundTxHistoryCDTO(iobounddeposit.atmTransactionNo,iobounddeposit.transactionDate);
      if( iotxhistory == null ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "EI0034" ;
        this.outarea.iohead.setMsg("No History Transaction ");
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1," 1) txno    : " + txNo);
      JLO.getInstance().printf(1," 2) atmseq  : " + iobounddeposit.atmTransactionNo);
      JLO.getInstance().printf(1," 3) cardno  : " + iotxhistory.getcard_no() );
      JLO.getInstance().printf(1," 4) acctno  : " + iobounddeposit.AccountNumber );
      JLO.getInstance().printf(1," 5) atmount : " + iobounddeposit.txAmount );
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //////////////////////////////////////////////////////////////////////////
      acdto.setCashCardNumber(iotxhistory.getcard_no());
      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////

      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-cancel",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      /////////////////////////////////////////////////////////////////////////
      // ��Ұŷ��ϰ�쿡�� �̺�Ʈ��ȣ�� 13120���� �����.
      /////////////////////////////////////////////////////////////////////////
      this.inarea.cdto.eventNo = acdto.getEventNumber();

      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("deposit-cancel",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");
      this.inarea.cdto.eventNo= this.OrgEventNo;

      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        CancelAccountCDTO result = (CancelAccountCDTO)outbound.getParameter();
        outbound.cdto.setTransactionNo(result.getTransactionNo());
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***CancelAccountCDTO***::"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--txaccount:"+result.getAccountNumber());
        JLO.getInstance().printf(1,"--txno:"+result.getTransactionNo());
        JLO.getInstance().printf(1,"************************************************");
        //���outarea�ۼ�
        this.outarea.cdto.setTrxNumber(result.getTransactionNo());
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
        this.outarea.iohead.setMsg("Application Info[DED80008.Tx is success]");
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = iobounddeposit.toString();

        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0013";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80008.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0014";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80008.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0015";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80008.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0016";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80008.Other Exception]");
      }
      this.outarea.iodata.sBoundData = iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }

}
