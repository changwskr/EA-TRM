package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.socket.ATMserver;
import wsj.atm.ejb.EJBPool;
import wsj.atm.packet.IOBoundArea;

public class COM10000 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;

  public COM10000(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
  }


  public IOBoundArea execute() throws Exception{

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          COM10000 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
      ATMserver.tpsvcinfo.prntCLTINFO();
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
    return outarea;
  }
}

