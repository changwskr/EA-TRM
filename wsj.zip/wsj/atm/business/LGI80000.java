package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import wsj.atm.socket.ATMserver;
import wsj.atm.tcf.*;
import wsj.atm.common.ComUtil;
import wsj.atm.log.JLO;
import wsj.atm.packet.*;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;
import wsj.atm.socket.CLTINFO;

public class LGI80000 {
  private IOBoundArea inarea;
  private IOBoundArea outarea;
  public IOBoundLog80000CDTO iob80000cdto;
  public IOBoundLog80000CDTO oob80000cdto;
  private BoundArea inbound;
  public BoundArea outbound;
  private TCPCallEJB cejb;
  private CLTINFO cltinfo;

  public LGI80000(IOBoundArea inarea,IOBoundArea outarea) throws IOException,Exception {
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80000cdto = new IOBoundLog80000CDTO();
    this.oob80000cdto = new IOBoundLog80000CDTO();
    this.inbound = new BoundArea(BoundArea.CMD_INITIAL) ;

    /*
    this.cejb = new TCPCallEJB(
                             UbbConfig.getInstance().GetEnvValue("RMISERVER"),
                             UbbConfig.getInstance().GetEnvValue("RMIPORT")
                             );
    */
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);

  }

  public IOBoundArea execute(){

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          LGI80000 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","MASTER","RMIPORT")
            );
      }
      else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
        this.cejb = new TCPCallEJB(
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMISERVER"),
            ATMXMLconfig.getInstance().GetEnvValue("NETWORK","SLAVE","RMIPORT")
            );
      }

      this.iob80000cdto.setIOBoundLog80000CDTOParsing(this.inarea.iodata.sBoundData);
      this.inbound.tellerId = this.iob80000cdto.tellerid;
      this.inbound.passwd = this.iob80000cdto.password;
      this.inbound.setBankCode(this.iob80000cdto.bankcode );

      //////////////////////////////////////////////////////////////////////////
      // 1] 1 ��
      //////////////////////////////////////////////////////////////////////////
      this.outbound=this.cejb.Login(this.inbound);
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      //JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      //TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      //ATMserver.atmejbpool.printStates();
      //JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      //JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //this.outbound=(BoundArea)ejbinstance.Login(this.inbound);
      //ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      switch( outbound.errcode.charAt(0) )
      {
        case 'E':
          this.outarea.iohead.sBErrCode=this.inarea.iohead.sBErrCode="EL0001";
          this.inarea.iohead.setMsg("Application Exception[LGI80000.LOGIN ERROR]",this.outarea);
          JLO.getInstance().printf(1,"==�α��� �ŷ��� �����߽��ϴ�.["+this.outarea.iohead.sMsg+"]");
          this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          return this.outarea ;
        case 'I':
          break;
      }

      JLO.getInstance().printf(1,"==�α��� �ŷ��� �����߽��ϴ�.");

      IOBoundCDTO cdto = this.iob80000cdto.getIOBoundCDTO(this.outbound);
      String icn = this.inarea.cdto.cifNum;
      String irn = this.inarea.cdto.refNum;
      String atmseq = this.inarea.cdto.atmSeqNo;
      //STF���� �ð����� ����ϱ� ���� �־��� ����Ÿ�� �ٽ� �����Ѵ�.
      cdto.setRefNum(irn);
      cdto.setCifNum(icn);
      cdto.setAtmSeqNo(atmseq);

      this.outarea.cdto = this.inarea.cdto = cdto;
      this.outarea.cdto.eventNo = "80000";  // �α��� �ŷ��� ���ؼ� ������ cdto�� CosesCommonDTO �̹Ƿ�

      this.outarea.iohead.sDLoginOffSet = this.inarea.iohead.sDLoginOffSet = "1";
      this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
      this.outarea.iohead.setMsg("Application Info[LGI80000.LOGIN SUCCESS]");
      this.iob80000cdto.workingkey = "1234567890abcdef";
      this.outarea.iodata.sBoundData = this.iob80000cdto.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.iob80000cdto.toString().length()),5);
      this.outarea.iodata.sLength = ComUtil.Int2Str(this.iob80000cdto.toString().length());
    }
    catch(Exception ex){
      ex.printStackTrace();
      JLO.getInstance().eprintf(1,ex);
      this.outarea.iohead.sBErrCode = "EL0002";
      this.outarea.cdto.eventNo = "80000";  // �α��� �ŷ��� ���ؼ� ������ cdto�� CosesCommonDTO �̹Ƿ�
      this.outarea.iohead.setMsg("Application Exception[LGI80000.Not Login]");
      this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      return this.outarea ;
    }
    return this.outarea;
  }
}
