package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.socket.ATMserver;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import wsj.atm.packet.IOBoundTel80006CDTO;
import com.chb.coses.teller.transfer.*;
import wsj.atm.common.EnvPropertySaving;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.transfer.ListDTO;
import wsj.atm.socket.CLTINFO;

//////////////////////////////////////////////////////////////////////////////
// ���� OPEN �ŷ��� �ǽ��Ѵ�.
//////////////////////////////////////////////////////////////////////////////
public class TEL80006 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundTel80006CDTO iob80006cdto = null;
  public IOBoundTel80006CDTO oob80006cdto = null;
  public CloseTellerInfoCDTO closetellercdto = null;
  public EnvPropertySaving envp;
  private CLTINFO cltinfo;

  public TEL80006(IOBoundArea inarea,IOBoundArea outarea) throws IOException{
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80006cdto = new IOBoundTel80006CDTO();
    this.oob80006cdto = new IOBoundTel80006CDTO();
    this.envp = new EnvPropertySaving(this.inarea.cdto.userId);
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"###########################################################");
    JLO.getInstance().printf(1,"#          TEL80006 �� ȣ��Ǿ����ϴ�  [ ���� CLOSE ]         #");
    JLO.getInstance().printf(1,"###########################################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      JLO.getInstance().printf(1,"--�⺻������ ����");
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iob80006cdto.setIOBoundTel80006CDTOParsing(this.inarea.iodata.sBoundData);

      //���������� �����Ѵ�
      //WOO 20030323 ���´�.
      /*
      if( this.inarea.iohead.sDSijaeClosOffset.equals("1") ){
        this.outarea.iohead.sDSijaeClosOffset = this.inarea.iohead.sDSijaeClosOffset = "1";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ET0010";
        this.outarea.iohead.setMsg("Application Exception[TEL80006.Already is Closed]");
        this.outarea.iodata.sBoundData = this.iob80006cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      */

      closetellercdto = new CloseTellerInfoCDTO();
      closetellercdto.setTellerNo(this.iob80006cdto.TellerNo);
      closetellercdto.setTellerStatus(this.iob80006cdto.TellerStatus); // ����open�ÿ� ������ ��
      closetellercdto.setTxDate(this.iob80006cdto.TxDate);
      closetellercdto.setBankCode(this.iob80006cdto.BankCode);
      closetellercdto.setBranchCode(this.iob80006cdto.BranchCode);

      CloseTellerListCDTO closeTellerList=null;
      ArrayList list = new ArrayList();
      for(int i=0;i<=2;i++) {
        CloseTellerCurrencyCDTO ccyCDTO = new com.chb.coses.teller.transfer.CloseTellerCurrencyCDTO();
        if( ccyCDTO.getCurrency() == null ) continue;
        switch( i ){
          case 0:
            if( !(iob80006cdto.Currency01.equals("VND") ||  iob80006cdto.Currency01.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(iob80006cdto.Currency01);
            ccyCDTO.setLastBalanceAmount(new BigDecimal(iob80006cdto.Amount01));
            break;
          case 1:
            if( !(iob80006cdto.Currency02.equals("VND") ||  iob80006cdto.Currency02.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(iob80006cdto.Currency02);
            ccyCDTO.setLastBalanceAmount(new BigDecimal(iob80006cdto.Amount02));
            break;
          case 3:
            if( !(iob80006cdto.Currency03.equals("VND") ||  iob80006cdto.Currency03.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(iob80006cdto.Currency03);
            ccyCDTO.setLastBalanceAmount(new BigDecimal(iob80006cdto.Amount03));
            break;
        }
        list.add(ccyCDTO);
      }
      closeTellerList = new CloseTellerListCDTO(list);
      closetellercdto.setCloseTellerListCDTO(closeTellerList);

      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("teller-closeTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),closetellercdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("teller-closeTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),closetellercdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      JLO.getInstance().printf(1,"--------EJB ȣ������");

      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        CloseTellerInfoCDTO result = (CloseTellerInfoCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***CloseTellerInfoCDTO***"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--bankcode:"+result.getBankCode());

        this.oob80006cdto = (IOBoundTel80006CDTO)this.iob80006cdto.clone();
        this.oob80006cdto.TellerNo = result.getTellerNo();
        this.oob80006cdto.TellerStatus = result.getTellerStatus();
        this.oob80006cdto.BankCode = result.getBankCode();
        this.oob80006cdto.BranchCode = result.getBranchCode();
        this.oob80006cdto.TxDate = result.getTxDate();

        for( int i = 0 ; i<result.getCloseTellerListCDTO().size() ; i++){
          CloseTellerCurrencyCDTO ccyCDTO = (CloseTellerCurrencyCDTO)result.getCloseTellerListCDTO().get(i);
          OpenCurrencyInfoCDTO openItemCDTO = new OpenCurrencyInfoCDTO();
          if( ccyCDTO.getCurrency() == null ) continue;
          switch( i ){
            case 0:
              oob80006cdto.Currency01= ccyCDTO.getCurrency();
              oob80006cdto.Amount01 = ComUtil.LZeroToStr( ccyCDTO.getLastBalanceAmount().toString(),oob80006cdto.Amount_LEN ) ;
              break;
            case 1:
              oob80006cdto.Currency02= ccyCDTO.getCurrency();
              oob80006cdto.Amount02 = ComUtil.LZeroToStr( ccyCDTO.getLastBalanceAmount().toString(),oob80006cdto.Amount_LEN ) ;
              break;
            case 3:
              oob80006cdto.Currency03= ccyCDTO.getCurrency();
              oob80006cdto.Amount03 = ComUtil.LZeroToStr( ccyCDTO.getLastBalanceAmount().toString(),oob80006cdto.Amount_LEN ) ;
              break;
          }
        }

        JLO.getInstance().printf(1,"************************************************");
        this.outarea.iohead.sDSijaeClosOffset = this.inarea.iohead.sDSijaeClosOffset = "1";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Info[TEL80006.Transaction is success]");
        this.outarea.iodata.sBoundData = this.oob80006cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        //this.outarea.iodata.sBoundData = this.oob80006cdto.toString();
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0011";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80006.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0012";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80006.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0013";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80006.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ET0014";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80006.Other Exception]");
      }
      this.outarea.iodata.sBoundData = this.oob80006cdto.toString();



      this.outarea.sLength = ComUtil.ZeroToStr(
          ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }

    if( this.outarea.iohead.sBErrCode.equals("IZZ000") )
    {
      //�ش翵�����ڷ��ؼ� �̹� ���ڷ��� SignOn�ŷ��� �ߴ����� Ȯ���Ѵ�.
      //�ش翵�����ڷ��ؼ� �̹� ���ڷ��� SignOn�ŷ��� �ߴ����� Ȯ���Ѵ�.
      this.envp.loadingINI();
      this.envp.setSijaeOpenFlag("20");
      this.envp.savingINI();
    }

    return outarea;
  }
}