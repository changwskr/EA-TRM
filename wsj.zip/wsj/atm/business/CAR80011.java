package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundCardInqry01CDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import com.chb.coses.cashCard.transfer.CashCardCDTO;

import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class CAR80011 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public String OrgEventNo;
  public IOBoundCardInqry01CDTO ioboundcard = null;
  public CashCardCDTO icdto = null;

  public CAR80011(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.OrgEventNo = this.inarea.cdto.eventNo;
  }

  public IOBoundArea execute() throws Exception {

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          CAR80011 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");
    String eventNo=null;
    String cardNo=null;
    String atmseqNo=null;

    try{
      ioboundcard = new IOBoundCardInqry01CDTO();
      ioboundcard.setIOBoundCardInqry01CDTOParsing(this.inarea.iodata.sBoundData);

      icdto = new CashCardCDTO();
      icdto.setCardNumber(ComUtil.CutSpaceToStr(ioboundcard.cardNumber,ioboundcard.cardNumber_LEN) );
      icdto.setPasswordNo(ComUtil.CutSpaceToStr(ioboundcard.passwordNo,ioboundcard.passwordNo_LEN));

      JLO.getInstance().printf(1,"-card number : " + icdto.getCardNumber() );
      JLO.getInstance().printf(1,"-card passwd : " + icdto.getPasswordNo() );

      JLO.getInstance().printf(1,"-EJB call start");
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("cashCard-inquiryCashCard",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),icdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"-EJB call end");

      if( outbound.errcode.equals ("IZZ000") )
      {
        JLO.getInstance().printf(1,"ejb call tx success :"+outbound.errcode);
        CashCardCDTO result = (CashCardCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"* CashCardCDTO : "+result.toString());
        JLO.getInstance().printf(1,"************************************************");
        ioboundcard.primaryAccountNo = result.getPrimaryAccountNo();
        /*
        if( (ioboundcard.primaryCurrency=result.getPrimaryCurrency()).equals("USD") ){
          ioboundcard.primaryColleceedBalance = ComUtil.BigZeroToStr(result.getPrimaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.primaryColleceedBalance_LEN );
        }
        else if( (ioboundcard.primaryCurrency=result.getPrimaryCurrency()).equals("VND") ){
          ioboundcard.primaryColleceedBalance = ComUtil.LZeroToStr(result.getPrimaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.primaryColleceedBalance_LEN );
        }
        else{
          String exceptionCode = "ED0035";
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
          this.outarea.iohead.setMsg("There is not Primary Currency Info");
          this.outarea.iodata.sBoundData = ioboundcard.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }
        */

        ioboundcard.secondaryAccountNo = result.getSecondaryAccountNo();
        /*
        if( (ioboundcard.secondaryCurrency=result.getSecondaryCurrency()).equals("USD") ){
          ioboundcard.secondaryColleceedBalance = ComUtil.BigZeroToStr(result.getSecondaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.secondaryColleceedBalance_LEN );
        }
        else if( (ioboundcard.secondaryCurrency=result.getSecondaryCurrency()).equals("VND") ){
          ioboundcard.secondaryColleceedBalance = ComUtil.LZeroToStr(result.getSecondaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.secondaryColleceedBalance_LEN );
        }
        else{
          String exceptionCode = "ED0035";
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
          this.outarea.iohead.setMsg("There is not Secondary Currency Info");
          this.outarea.iodata.sBoundData = ioboundcard.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }
        */

        ioboundcard.ternaryAccountNo = result.getTernaryAccountNo();
        /*
        if( (ioboundcard.ternaryCurrency=result.getTernaryCurrency()).equals("USD") ){
          ioboundcard.ternaryColleceedBalance = ComUtil.BigZeroToStr(result.getTernaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.ternaryColleceedBalance_LEN );
        }
        else if( (ioboundcard.ternaryCurrency=result.getPrimaryCurrency()).equals("VND") ){
          ioboundcard.ternaryColleceedBalance = ComUtil.LZeroToStr(result.getTernaryColleceedBalance().toString(),IOBoundCardInqry01CDTO.ternaryColleceedBalance_LEN );
        }
        else
        {
          String exceptionCode = "ED0035";
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
          this.outarea.iohead.setMsg("There is not Ternary Currency Info");
          this.outarea.iodata.sBoundData = ioboundcard.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }
        */

        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
        this.outarea.iohead.setMsg("Application Info[CAR80011.Tx is success]");
        this.outarea.iodata.sBoundData = ioboundcard.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      else{
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = ioboundcard.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0013";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[CAR80011.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0014";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[CAR80011.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0015";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[CAR80011.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
      }
      else{
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0016";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[CAR80011.Other Exception]");
      }
      this.outarea.iodata.sBoundData = ioboundcard.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }

}
