package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import wsj.atm.tcf.STF;
import wsj.atm.socket.ATMserver;
import java.math.BigDecimal;
import wsj.atm.common.ComUtil;
import wsj.atm.common.EnvPropertySaving;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundTel80004CDTO;
import com.chb.coses.teller.transfer.*;

import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.transfer.ListDTO;
import wsj.atm.socket.ATMserverhandler;
import wsj.atm.socket.CLTINFO;

//////////////////////////////////////////////////////////////////////////////
// ���� OPEN �ŷ��� �ǽ��Ѵ�.
//////////////////////////////////////////////////////////////////////////////
public class TEL80004 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundTel80004CDTO iob80004cdto = null;
  public IOBoundTel80004CDTO oob80004cdto = null;
  public OpenInfoCDTO opencdto = null;
  public EnvPropertySaving envp;
  private CLTINFO cltinfo;

  public TEL80004(IOBoundArea inarea,IOBoundArea outarea) throws IOException{
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80004cdto = new IOBoundTel80004CDTO();
    this.oob80004cdto = new IOBoundTel80004CDTO();
    this.envp = new EnvPropertySaving(this.inarea.cdto.userId);
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"###########################################################");
    JLO.getInstance().printf(1,"#          TEL80004 �� ȣ��Ǿ����ϴ�  [ ���� OPEN ]         #");
    JLO.getInstance().printf(1,"###########################################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      JLO.getInstance().printf(1,"--�⺻������ ����");
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iob80004cdto.setIOBoundTel80004CDTOParsing(this.inarea.iodata.sBoundData);

      /*---- woo 2003.03.25
      // �ڷ��� ���� ������ ���� �ʴ´�.
      //�ش翵�����ڷ��ؼ� �̹� ���ڷ��� SignOn�ŷ��� �ߴ����� Ȯ���Ѵ�.
      if( this.inarea.iohead.sDSijaeOpenOffset.equals("1") ){
        this.oob80004cdto = (IOBoundTel80004CDTO)this.iob80004cdto.clone();
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IT0001";
        this.outarea.iohead.setMsg("Application Info[TEL80004.Already is Login]");
        this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      */

      this.envp.loadingINI();

      /*---- woo 2003.03.25
      // �ڷ��� ���� ������ ���� �ʴ´�.

      if( iob80004cdto.TxDate.equals((String)this.envp.envh.get("TxDate")) &&
                     this.envp.envh.get("SijaeOpenFlag").equals("10") )
      {
        this.oob80004cdto = (IOBoundTel80004CDTO)this.iob80004cdto.clone();
        this.oob80004cdto.TellerNo = (String)this.envp.envh.get("TellerNo");
        this.oob80004cdto.TxDate = (String)this.envp.envh.get("TxDate");
        this.oob80004cdto.TellerStatus = (String)this.envp.envh.get("TellerStatus");
        this.oob80004cdto.Currency01 = (String)this.envp.envh.get("Currency01");
        this.oob80004cdto.Amount01 = (String)this.envp.envh.get("Amount01");

        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Info[TEL80004.Transaction is success]");
        this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      else if( iob80004cdto.TxDate.equals((String)this.envp.envh.get("TxDate")) &&
                     this.envp.envh.get("SijaeOpenFlag").equals("20") ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ET0001";
        this.outarea.iohead.setMsg("Application Ex[TEL80004.Already to be closed]");
        this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      */

      opencdto = new OpenInfoCDTO();
      opencdto.setIntellerNo(this.iob80004cdto.TellerNo);
      opencdto.setIntxDate(this.iob80004cdto.TxDate);

      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("teller-openTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),opencdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("teller-openTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),opencdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");

      if( outbound.errcode.equals ("IZZ000") )
      {
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        OpenInfoCDTO result = (OpenInfoCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***OpenInfoCDTO***"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--tstatus:"+result.getOutTellerStatus());


        this.oob80004cdto = (IOBoundTel80004CDTO)this.iob80004cdto.clone();
        this.oob80004cdto.TellerStatus = result.getOutTellerStatus();
        for( int i = 0 ; i<result.getOpenListCDTO().size() ; i++){
          OpenCurrencyInfoCDTO opCDTO = (OpenCurrencyInfoCDTO)result.getOpenListCDTO().get(i);
          OpenCurrencyInfoCDTO openItemCDTO = new OpenCurrencyInfoCDTO();
          JLO.getInstance().printf(1,"********************************************1");
          if( opCDTO.getCurrency() == null ) {
            JLO.getInstance().printf(1,"-----111");
            continue;
          }
          String amount = "0";
          try{
            if( opCDTO.getStartingBalanceAmount() != null ){
              amount = opCDTO.getStartingBalanceAmount().toString();
            }
            else
              amount = "0";
          } catch(NullPointerException ex){
            amount="0";
          }
          JLO.getInstance().printf(1,"*["+amount+"]");
          switch( i ){
            case 0:
              oob80004cdto.Currency01= opCDTO.getCurrency();

              oob80004cdto.Amount01 = ComUtil.LZeroToStr(amount,this.oob80004cdto.Amount_LEN );
                      JLO.getInstance().printf(1,"***********************************************2");
              break;
            case 1:
              oob80004cdto.Currency02= opCDTO.getCurrency();
              oob80004cdto.Amount02 = ComUtil.LZeroToStr(amount,this.oob80004cdto.Amount_LEN );
                      JLO.getInstance().printf(1,"************************************************3");
              break;
            case 3:
              oob80004cdto.Currency03= opCDTO.getCurrency();
              oob80004cdto.Amount03 = ComUtil.LZeroToStr(amount,this.oob80004cdto.Amount_LEN );
              JLO.getInstance().printf(1,"************************************************4");
              break;
          }
        }
        JLO.getInstance().printf(1,"************************************************");
        this.outarea.iohead.sDSijaeOpenOffset = this.inarea.iohead.sDSijaeOpenOffset = "1";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Info[TEL80004.Transaction is success]");
        this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;

        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">���� open(80004)"+">"+oob80004cdto.TellerNo +"->");
        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">    TellerID:"+oob80004cdto.TellerNo);
        JLO.getInstance().printf(1,">      TxDate:"+oob80004cdto.TxDate );
        JLO.getInstance().printf(1,">TellerStatus:"+oob80004cdto.TellerStatus );
        JLO.getInstance().printf(1,">    TxAmount:"+oob80004cdto.Amount01 );
        JLO.getInstance().printf(1,"==========================================================================");


      }
      else
      {
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ET0002";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80004.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ET0003";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80004.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ET0004";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80004.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"******BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ET0005";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[TEL80004.Other Exception]");
      }
      this.outarea.iodata.sBoundData = this.oob80004cdto.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(
          ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }

    if( this.outarea.iohead.sBErrCode.equals("IZZ000") )
    {
      //�ش翵�����ڷ��ؼ� �̹� ���ڷ��� SignOn�ŷ��� �ߴ����� Ȯ���Ѵ�.
      this.envp.setCosesCommonDTO(this.inarea.cdto);
      this.envp.setIOBoundTel80004CDTO(this.oob80004cdto);
      this.envp.setSijaeOpenFlag("10");
      this.envp.savingINI();
    }
    return outarea;
  }
}