package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import wsj.atm.tcf.STF;
import wsj.atm.socket.ATMserver;
import java.math.BigDecimal;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundTel80007CDTO;
import com.chb.coses.teller.transfer.*;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.transfer.ListDTO;
import wsj.atm.socket.CLTINFO;

//////////////////////////////////////////////////////////////////////////////
// �ڱ��μ��� �ŷ� ����ȸ
//////////////////////////////////////////////////////////////////////////////
public class TEL80007 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundTel80007CDTO iob80007cdto = null;
  public IOBoundTel80007CDTO oob80007cdto = null;
  public TransferCDTO transfercdto = null;
  private CLTINFO cltinfo;

  public TEL80007(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80007cdto = new IOBoundTel80007CDTO();
    this.oob80007cdto = new IOBoundTel80007CDTO();
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"###########################################################");
    JLO.getInstance().printf(1,"#          TEL80007 �� ȣ��Ǿ����ϴ�  [ ���� OPEN ]         #");
    JLO.getInstance().printf(1,"###########################################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      JLO.getInstance().printf(1,"--�⺻������ ����");
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iob80007cdto.setIOBoundTel80007CDTOParsing(this.inarea.iodata.sBoundData);
      transfercdto = new TransferCDTO();
      transfercdto.setTellerNo( ComUtil.CutSpaceToStr( this.iob80007cdto.TellerNo, this.iob80007cdto.TellerNo_LEN ));

      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("teller-preQueryForTransferTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),transfercdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("teller-preQueryForTransferTellerCash",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),transfercdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");

      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        TransferCDTO result = (TransferCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***TransferCDTO***"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--bankcode:"+result.getOutBankCode());

        this.oob80007cdto = (IOBoundTel80007CDTO)this.iob80007cdto.clone();
        this.oob80007cdto.TellerNo = result.getTellerNo();
        this.oob80007cdto.BankCode = result.getOutBankCode();
        this.oob80007cdto.BranchCode = result.getOutBranchCode();
        this.oob80007cdto.TxDate = result.getOutTxDate();

        for( int i = 0 ; i<result.getTransferListCDTO().size() ; i++){
          TransferCashAmountCDTO  cashBalanceCDTO = (TransferCashAmountCDTO )result.getTransferListCDTO().get(i);
          if( cashBalanceCDTO.getCurrency() == null ) continue;
          switch( i ){
            case 0:
              this.oob80007cdto.Currency01= cashBalanceCDTO.getCurrency();
              this.oob80007cdto.Amount01 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80007cdto.Amount_LEN );
              break;
            case 1:
              this.oob80007cdto.Currency02= cashBalanceCDTO.getCurrency();
              this.oob80007cdto.Amount02 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80007cdto.Amount_LEN );
             break;
            case 3:
              this.oob80007cdto.Currency03= cashBalanceCDTO.getCurrency();
              this.oob80007cdto.Amount03 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80007cdto.Amount_LEN );
              break;
          }
        }

        JLO.getInstance().printf(1,"************************************************");
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Info[TEL80007.Transaction is success]");
        this.outarea.iodata.sBoundData = this.oob80007cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;

        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">�ڱ��μ��� ����ȸ(80007)"+">"+oob80007cdto.TellerNo +"->");
        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">    TellerID:"+oob80007cdto.TellerNo);
        JLO.getInstance().printf(1,">      TxDate:"+oob80007cdto.TxDate );
        JLO.getInstance().printf(1,">    BankCode:"+oob80007cdto.BankCode );
        JLO.getInstance().printf(1,">    Currency:"+oob80007cdto.Currency01 );
        JLO.getInstance().printf(1,">      Amount:"+oob80007cdto.Amount01 );
        JLO.getInstance().printf(1,"==========================================================================");

      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        //this.outarea.iodata.sBoundData = this.oob80007cdto.toString();
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
   {
     String errmsg = null;
     if(e instanceof BizActionException)
     {
       //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0015";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80007.BizActionException]");
     }
     else if(e instanceof RemoteException)
     {
       //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0016";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80007.RemoteException]");
     }
     else if(e instanceof CosesAppException)
     {
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0017";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80007.RemoteException]");
     }
     else if(e instanceof BizDelegateException)
     {
       //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
       JLO.getInstance().eprintf(10,e);
       e.printStackTrace();
       BizDelegateException bdex = (BizDelegateException)e;
       Map map = bdex.getExceptions();
       Set set = map.keySet();
       Iterator iter = set.iterator();
       String exceptionCode = null;
       String exceptionMsg = null;
       while(iter.hasNext()){
         exceptionCode = (String)iter.next();
         exceptionMsg = (String)map.get(exceptionCode);
       }
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
       this.outarea.iohead.setMsg(exceptionMsg);
       //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
     }
     else{
       JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0018";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80007.Other Exception]");
     }
     this.outarea.iodata.sBoundData = this.oob80007cdto.toString();
     this.outarea.sLength = ComUtil.ZeroToStr(
         ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
     this.outarea.iodata.sLength = this.outarea.sLength;
   }
   return outarea;
  }
}