package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80008CDTO;
import wsj.atm.packet.IOBoundTxHistoryCDTO;
import wsj.atm.packet.IOBoundProtoType;
import com.chb.coses.deposit.transfer.AccountPageCDTO;
import com.chb.coses.deposit.transfer.TransactionHistoryPageItemsCDTO;
import com.chb.coses.deposit.transfer.CancelAccountCDTO;
import com.chb.coses.deposit.transfer.InquiryConditionCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;

import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class DED80009 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public String OrgEventNo;
  public IOBoundDep80008CDTO iobounddeposit = null;
  public CancelAccountCDTO acdto = null;

  public DED80009(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.OrgEventNo = this.inarea.cdto.eventNo;
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80009 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");
    String eventNo=null;
    String cardNo=null;
    String atmseqNo=null;

    try{
      iobounddeposit = new IOBoundDep80008CDTO();
      iobounddeposit.setIOBoundDep80008CDTOParsing(this.inarea.iodata.sBoundData);

      acdto = new CancelAccountCDTO();
      acdto.setAccountNumber(iobounddeposit.AccountNumber);
      acdto.setBankCode(iobounddeposit.BankCode);
      acdto.setEventNumber("13120");
      acdto.setTransactionDate(this.iobounddeposit.transactionDate);
      String txNo = this.iobounddeposit.getTransactionNo(STF.getCosesCDTOfromInBoundArea(this.inarea));
      if( txNo.equals("0000000000000000") ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "EI0034" ;
        this.outarea.iohead.setMsg("DED8008 GetTxNo Exception");
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      acdto.setTransactionNo(txNo);

      //////////////////////////////////////////////////////////////////////////
      IOBoundTxHistoryCDTO iotxhistory = IOBoundTxHistoryCDTO.GetIOBoundTxHistoryCDTO(iobounddeposit.atmTransactionNo,iobounddeposit.transactionDate);
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1," 1) txno : " + txNo);
      JLO.getInstance().printf(1," 2) atmseq : " + iobounddeposit.atmTransactionNo);
      JLO.getInstance().printf(1," 3) cardno : " + iotxhistory.getcard_no() );
      JLO.getInstance().printf(1," 4) acctno : " + iobounddeposit.AccountNumber );
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      //////////////////////////////////////////////////////////////////////////

      JLO.getInstance().printf(1,"-EJB ȣ�����");
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");

      this.inarea.cdto.eventNo = acdto.getEventNumber();
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("deposit-cancel",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"-EJB ȣ������");

      this.inarea.cdto.eventNo= this.OrgEventNo;
      if( outbound.errcode.equals ("IZZ000") )
      {
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        CancelAccountCDTO result = (CancelAccountCDTO)outbound.getParameter();
        outbound.cdto.setTransactionNo(result.getTransactionNo());
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***CancelAccountCDTO***::"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--txaccount:"+result.getAccountNumber());
        JLO.getInstance().printf(1,"--txno:"+result.getTransactionNo());
        JLO.getInstance().printf(1,"************************************************");

        this.outarea.cdto.setTrxNumber(result.getTransactionNo());
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
        this.outarea.iohead.setMsg("Application Info[DED80009.Tx is success]");
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      else{
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0013";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80009.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0014";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80009.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0015";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80009.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
      }
      else{
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0016";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80009.Other Exception]");
      }
      this.outarea.iodata.sBoundData = iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }

}
