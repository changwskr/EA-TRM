package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80011CDTO;
import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.AccountDetailCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class DED80011 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundDep80011CDTO iobounddeposit = null;
  public AccountQueryCDTO acdto = null;

  public DED80011(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80011 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      iobounddeposit = new IOBoundDep80011CDTO();
      iobounddeposit.setIOBoundDep80011CDTOParsing(this.inarea.iodata.sBoundData);

      acdto = new AccountQueryCDTO();
      acdto.setAccountNumber(iobounddeposit.TargetAccountNo);
      acdto.setBankCode(this.inarea.cdto.bankCode);

      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      BoundArea outbound=(BoundArea)ejbinstance.callEJB2("deposit-getAccountInfo",STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      if( outbound.errcode.equals ("IZZ000") )
      {
        AccountQueryCDTO result = (AccountQueryCDTO)outbound.getParameter();
        this.iobounddeposit.TargetCustName = ComUtil.PSpaceToStr(result.getCIFName(),iobounddeposit.TargetCustName_LEN );
        JLO.getInstance().printf(1,result.getAccountNumber() + ":: iobounddeposit.TargetCustName ["+this.iobounddeposit.TargetCustName+"]");
      }
      else
      {
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"REQUEST CALL SERVICE ERROR.TargetAccountnumber");
        return outarea;
      }

      this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
      this.outarea.iohead.setMsg("Application Infomation[DED80011.Tx is success]");
      this.outarea.iodata.sBoundData = iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
      iobounddeposit.toPrint();

    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0009";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80011.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0010";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80011.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0011";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80011.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
      }
      else{
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0012";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80011.Other Exception]");
      }
      this.outarea.iodata.sBoundData = iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }
}