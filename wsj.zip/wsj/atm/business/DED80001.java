package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.tcf.STF;
import wsj.atm.tcf.ETF;
import wsj.atm.socket.ATMserver;
import wsj.atm.ejb.EJBPool;

import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80001CDTO;
import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.AccountDetailCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.CLTINFO;

public class DED80001 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundDep80001CDTO iobounddeposit = null;
  public AccountDetailCDTO acdto = null;
  private EJBPool atmejbpool;
  private TCPCallEJB ejbinstance;
  private CLTINFO cltinfo;

  public DED80001(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.atmejbpool = ATMserver.atmejbpool.getEJBPool();
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);
  }
  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80001 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");
    try{
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iobounddeposit = new IOBoundDep80001CDTO();
      iobounddeposit.setIOBoundDep80001CDTOParsing(this.inarea.iodata.sBoundData);
      iobounddeposit.FeeWaivFlag="N";

      acdto = new AccountDetailCDTO();
      acdto.setAccountNumber(iobounddeposit.AccountNumber);
      acdto.setBankCode(iobounddeposit.BankCode);
      acdto.setPbKind(iobounddeposit.PbKind);
      acdto.setTrxCcy(iobounddeposit.TrxCcyu);
      acdto.setTrxStatus(iobounddeposit.TrxStatus );
      acdto.setCalculationFee(iobounddeposit.FeeWaivFlag);
      acdto.setInclusionFee("N");
      acdto.setApproveStatus(iobounddeposit.ApproveStatus);
      acdto.setTransactionCode("500");
      acdto.setSecurityNo(ComUtil.CutSpaceToStr(iobounddeposit.SecurityNo,iobounddeposit.SecurityNo_LEN ));
      acdto.setAtmSeqNo(this.inarea.cdto.atmSeqNo);
      acdto.setCardNumber(this.iobounddeposit.CashCardNo );
      acdto.setCalculationFee("N");
      acdto.setInclusionFee("N");
      acdto.setRateType("N");

      /*
      AccountQueryCDTO aqcdto = TCPCallEJB.getAccountQueryCDTO(this.iobounddeposit.AccountNumber,
                          this.iobounddeposit.BankCode,
                          STF.getCosesCDTOfromInBoundArea(this.inarea));
      */
      BoundArea outbound1 = TCPCallEJB.getAccountQueryCDTO(this.iobounddeposit.AccountNumber,
                          this.iobounddeposit.BankCode,
                          STF.getCosesCDTOfromInBoundArea(this.inarea));
      AccountQueryCDTO aqcdto = (AccountQueryCDTO)outbound1.getParameter();
      if( aqcdto == null ){
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= "ED0017" ;
        this.outarea.iohead.setMsg("App Ex[DED80001.TCPCallEJB Processing Error]");
        this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        return this.outarea;
      }
      else
      {
        if( !outbound1.errcode.equals("IZZ000"))
        {
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound1.errcode;
          this.outarea.iohead.setMsg("App Ex[DED80001.TCPCallEJB Processing Error]");
          this.outarea.iohead.setMsg(outbound1.errmsg);
          this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(
              ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }
      }

      if( aqcdto.getCurrency().equals("USD") ){
        acdto.setTransactionAmount(new BigDecimal(iobounddeposit.TransactionAmount));

        JLO.getInstance().printf(1,"USD ACCOUNT : " + acdto.getTransactionAmount());
      }

      else if( aqcdto.getCurrency().equals("VND") ){
        acdto.setAmount(new BigDecimal(iobounddeposit.Amount));
        acdto.setTransactionAmount(new BigDecimal(iobounddeposit.TransactionAmount));
        JLO.getInstance().printf(1,"VND ACCOUNT : " + acdto.getTransactionAmount());
      }

      acdto.setAccountGroup(aqcdto.getAccountGroup());
      acdto.setAccountGroupKind(aqcdto.getAccountGroupKind());
      acdto.setCIFNo(aqcdto.getCIFNo());

      JLO.getInstance().printf(1,"### AccountGrp:" + aqcdto.getAccountGroup() + "CifNo:"+aqcdto.getCIFNo()
                   +"  Passwd:["+this.acdto.getSecurityNo()+"|" +ComUtil.CutSpaceToStr(iobounddeposit.SecurityNo,iobounddeposit.SecurityNo_LEN)+"]");
      JLO.getInstance().printf(1, aqcdto.getCurrency() + " : transaction amount - " + acdto.getTransactionAmount()
                               + " amount - " + acdto.getAmount()
                               );


      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-withdrawAccount",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      this.ejbinstance = this.atmejbpool.getTCPCallEJB();
      this.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +this.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");

      BoundArea outbound=(BoundArea)
                         this.ejbinstance.callEJB2("deposit-withdrawAccount",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      this.atmejbpool.freeTCPCallEJB(this.ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");

      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        AccountDetailCDTO result = (AccountDetailCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"--trxnumber:"+result.getTrxNo());
        JLO.getInstance().printf(1,"--colamount:"+result.getCollectedBalance().toString());
        JLO.getInstance().printf(1,"--feeamount:"+result.getFeeAmount().toBigInteger().longValue());
        JLO.getInstance().printf(1,"-currency:" + result.getCurrency() );
        JLO.getInstance().printf(1,"************************************************");


        //��¾�������Ÿ�ۼ�
        //this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toString(),IOBoundDep80001CDTO.FeeAmount_LEN );

        /**********************************************************************
         * VND USD �� ���Ͽ� �޸� �۾��� �Ѵ�.
         **********************************************************************/
        this.iobounddeposit.TrxCcyu=result.getCurrency();
        if( result.getCurrency().equals("USD") ){
          this.iobounddeposit.ColleceedBalance = ComUtil.BigZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80001CDTO.ColleceedBalance_LEN );
        }
        else if( result.getCurrency().equals("VND") ){
          this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80001CDTO.ColleceedBalance_LEN );
        }

        this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toBigInteger().longValue()+"",IOBoundDep80001CDTO.FeeAmount_LEN );
        this.iobounddeposit.setTransactionNo(result.getTrxNo());

        this.outarea.cdto.setTrxNumber( this.iobounddeposit.TransactionNo );
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Infomation[DED80001.Tx is success]");
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        iobounddeposit.toPrint();
      }
      else{
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);

        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0001";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Except[DED80001.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0002";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Except[DED80001.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0003";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Except[DED80001.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0004";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Except[DED80001.other Exception]");
      }
      this.outarea.iodata.sBoundData = this.iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(
          ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }
}