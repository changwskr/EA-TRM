package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;

import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80003CDTO;
import com.chb.coses.collateral.transfer.CollateralCategoryCDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.deposit.transfer.AccountDetailCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class DED80003 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundDep80003CDTO iobounddeposit = null;
  //public AccountQueryCDTO acdto = null;
  public AccountDetailCDTO acdto = null;

  public DED80003(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80003 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");

    try{
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iobounddeposit = new IOBoundDep80003CDTO();
      iobounddeposit.setIOBoundDep80003CDTOParsing(this.inarea.iodata.sBoundData);

      //acdto = new AccountQueryCDTO();
      acdto = new AccountDetailCDTO();
      acdto.setAccountNumber(iobounddeposit.AccountNumber);
      acdto.setBankCode(iobounddeposit.BankCode);
      acdto.setSecurityNo(ComUtil.CutSpaceToStr(iobounddeposit.SecurityNo,iobounddeposit.SecurityNo_LEN));
      acdto.setCardNumber(this.iobounddeposit.CashCardNo );

      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("deposit-getAccountInfo",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      */

      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("deposit-getAccountInfo",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),acdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"--------EJB ȣ������");
      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        AccountQueryCDTO result = (AccountQueryCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"--trxnumber:"+result.getTrxNo());
        JLO.getInstance().printf(1,"--col amount:"+result.getCollectedBalance().toString());
        //JLO.getInstance().printf(1,"--feeamount:"+result.getFeeAmount().toString());
        JLO.getInstance().printf(1,"--feeamount:"+result.getFeeAmount().toBigInteger().longValue());
        JLO.getInstance().printf(1,"************************************************");
        //��¾�������Ÿ�ۼ�
        // ��µ���Ÿ ���� �������� �����Ǿ�� �� ���
        /*
        this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toString(),IOBoundDep80003CDTO.FeeAmount_LEN );
        this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80003CDTO.ColleceedBalance_LEN );
        this.iobounddeposit.setTransactionNo(result.getTrxNo());
        */
        //this.iobounddeposit.FeeAmount = ComUtil.BigZeroToStr(result.getFeeAmount().toString(),IOBoundDep80003CDTO.FeeAmount_LEN );
        this.iobounddeposit.FeeAmount = ComUtil.LZeroToStr(result.getFeeAmount().toBigInteger().longValue()+"",IOBoundDep80003CDTO.FeeAmount_LEN );
        //this.iobounddeposit.ColleceedBalance = ComUtil.BigZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80003CDTO.ColleceedBalance_LEN );

        /**********************************************************************
         * VND USD �� ���Ͽ� �޸� �۾��� �Ѵ�.
         * ********************************************************************/
        this.iobounddeposit.TrxCcyu=result.getCurrency();
        JLO.getInstance().printf(1,"this.iobounddeposit.TrxCcyu ["+this.iobounddeposit.TrxCcyu+"]");

        if( result.getCurrency().equals("USD") ){
           this.iobounddeposit.ColleceedBalance = ComUtil.BigZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80003CDTO.ColleceedBalance_LEN );
           //this.iobounddeposit.TD5="USD";
         }
         else if( result.getCurrency().equals("VND") ){
           this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toString(),IOBoundDep80003CDTO.ColleceedBalance_LEN );
           //this.iobounddeposit.TD5="VND";
         }

        //this.iobounddeposit.ColleceedBalance = ComUtil.LZeroToStr(result.getCollectedBalance().toBigInteger().longValue()+"",IOBoundDep80003CDTO.ColleceedBalance_LEN );
        this.iobounddeposit.setTransactionNo(result.getTrxNo());

        //���outarea�ۼ�
        this.outarea.cdto.setTrxNumber( this.iobounddeposit.TransactionNo );
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application Infomation[DED80003.Tx is success]");
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        iobounddeposit.toPrint();
      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = iobounddeposit.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0009";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80003.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0010";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80003.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0011";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80003.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
        //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
      }
      else{
        JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0012";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80003.Other Exception]");
      }
      this.outarea.iodata.sBoundData = iobounddeposit.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }
}