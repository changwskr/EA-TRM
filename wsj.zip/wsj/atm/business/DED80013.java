package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import java.math.BigDecimal;
import wsj.atm.tcf.STF;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;
import wsj.atm.packet.IOBoundDep80013CDTO;
import com.chb.coses.deposit.transfer.AccountQueryCDTO;
import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import com.chb.coses.cashCard.transfer.CashCardCDTO;

import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import wsj.atm.socket.ATMserver;

public class DED80013 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public String OrgEventNo;
  public IOBoundDep80013CDTO ioboundcard = null;
  public CashCardCDTO icdto = null;

  public DED80013(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.OrgEventNo = this.inarea.cdto.eventNo;
  }

  public IOBoundArea execute() throws Exception {

    JLO.getInstance().printf(1,"############################################");
    JLO.getInstance().printf(1,"#          DED80013 �� ȣ��Ǿ����ϴ�        #");
    JLO.getInstance().printf(1,"############################################");
    String eventNo=null;
    String cardNo=null;
    String atmseqNo=null;

    try{
      ioboundcard = new IOBoundDep80013CDTO();
      ioboundcard.setIOBoundDep80013CDTOParsing(this.inarea.iodata.sBoundData);

      icdto = new CashCardCDTO();
      icdto.setCardNumber(ComUtil.CutSpaceToStr(ioboundcard.cardNumber,ioboundcard.cardNumber_LEN) );
      icdto.setPasswordNo(ComUtil.CutSpaceToStr(ioboundcard.passwordNo ,ioboundcard.passwordNo_LEN));

      JLO.getInstance().printf(1,"-card number : " + icdto.getCardNumber() );
      JLO.getInstance().printf(1,"-card passwd : " + icdto.getPasswordNo() );

      JLO.getInstance().printf(1,"-EJB call start");
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("cashCard-inquiryCashCard",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),icdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);
      JLO.getInstance().printf(1,"-EJB call end");

      if( outbound.errcode.equals ("IZZ000") )
      {
        JLO.getInstance().printf(1,"ejb call tx success :"+outbound.errcode);
        CashCardCDTO result = (CashCardCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"* CashCardCDTO : "+result.toString());
        JLO.getInstance().printf(1,"************************************************");

        ioboundcard.primaryAccountNo = result.getPrimaryAccountNo();
        if( (ioboundcard.primaryCurrency=result.getPrimaryCurrency()).equals("USD") ){
          ioboundcard.primaryColleceedBalance =
              ComUtil.BigZeroToStr(result.getPrimaryBalance().toString(),IOBoundDep80013CDTO.primaryColleceedBalance_LEN );
        }
        else if( (ioboundcard.primaryCurrency=result.getPrimaryCurrency()).equals("VND") ){
          ioboundcard.primaryColleceedBalance =
              ComUtil.LZeroToStr(result.getPrimaryBalance().toString(),IOBoundDep80013CDTO.primaryColleceedBalance_LEN );
        }
        else{
          String exceptionCode = "ED0035";
          this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
          this.outarea.iohead.setMsg("There is not Primary Currency Info");
          this.outarea.iodata.sBoundData = ioboundcard.toString();
          this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
          this.outarea.iodata.sLength = this.outarea.sLength;
          return this.outarea;
        }

        if( (result.getSecondaryCurrency()).equals("USD") ){
          ioboundcard.secondaryAccountNo = result.getSecondaryAccountNo();
          ioboundcard.secondaryCurrency=result.getSecondaryCurrency();
          ioboundcard.secondaryColleceedBalance =
              ComUtil.BigZeroToStr(result.getSecondaryBalance().toString(),IOBoundDep80013CDTO.secondaryColleceedBalance_LEN );
        }
        else if( (result.getSecondaryCurrency()).equals("VND") ){
          ioboundcard.secondaryAccountNo = result.getSecondaryAccountNo();
          ioboundcard.secondaryCurrency=result.getSecondaryCurrency();;
          ioboundcard.secondaryColleceedBalance =
              ComUtil.LZeroToStr(result.getSecondaryBalance().toString(),IOBoundDep80013CDTO.secondaryColleceedBalance_LEN );
        }
        else{
          ioboundcard.secondaryAccountNo = " ";
          ioboundcard.secondaryCurrency = " ";
          ioboundcard.secondaryAccountNo = ComUtil.SpaceToStr(ioboundcard.secondaryAccountNo,ioboundcard.secondaryAccountNo_LEN);
          ioboundcard.secondaryCurrency  = ComUtil.SpaceToStr(ioboundcard.secondaryCurrency,ioboundcard.secondaryCurrency_LEN);
        }

        if( (result.getTenaryCurrency()).equals("USD") ){
          ioboundcard.ternaryAccountNo = result.getTernaryAccountNo();
          ioboundcard.ternaryCurrency=result.getTenaryCurrency();;
          ioboundcard.ternaryColleceedBalance = ComUtil.BigZeroToStr(result.getTenaryBalance().toString(),IOBoundDep80013CDTO.ternaryColleceedBalance_LEN );
        }
        else if( (result.getTenaryCurrency()).equals("VND") ){
          ioboundcard.ternaryAccountNo = result.getTernaryAccountNo();
          ioboundcard.ternaryCurrency=result.getTenaryCurrency();
          ioboundcard.ternaryColleceedBalance = ComUtil.LZeroToStr(result.getTenaryBalance().toString(),IOBoundDep80013CDTO.ternaryColleceedBalance_LEN );
        }
        else{
          ioboundcard.ternaryAccountNo = " ";
          ioboundcard.ternaryCurrency = " ";
          ioboundcard.ternaryAccountNo = ComUtil.SpaceToStr(ioboundcard.ternaryAccountNo,ioboundcard.ternaryAccountNo_LEN);
          ioboundcard.ternaryCurrency  = ComUtil.SpaceToStr(ioboundcard.ternaryCurrency,ioboundcard.ternaryCurrency_LEN);
        }

        ioboundcard.RecordCount = ComUtil.Int2Str(result.getRecordCount());

        JLO.getInstance().printf(1,"cardNumber         [" + this.ioboundcard.cardNumber  +"]");
        JLO.getInstance().printf(1,"passwordNo         [" + this.ioboundcard.passwordNo  +"]");
        JLO.getInstance().printf(1,"primaryAccountNo   [" + this.ioboundcard.primaryAccountNo +"]");
        JLO.getInstance().printf(1,"primaryAccountCurrency  [" + this.ioboundcard.primaryCurrency  +"]");
        JLO.getInstance().printf(1,"primaryColle  [" + this.ioboundcard.primaryColleceedBalance   +"]");

        JLO.getInstance().printf(1,"secondaryAccountNo [" + this.ioboundcard.secondaryAccountNo +"]");
        JLO.getInstance().printf(1,"secondAccountCurrency  [" + this.ioboundcard.secondaryCurrency   +"]");
        JLO.getInstance().printf(1,"secondColle  [" + this.ioboundcard.secondaryColleceedBalance    +"]");

        JLO.getInstance().printf(1,"ternaryAccountNo   [" + this.ioboundcard.ternaryAccountNo +"]");
        JLO.getInstance().printf(1,"ternaryAccountCurrency  [" + this.ioboundcard.ternaryCurrency  +"]");
        JLO.getInstance().printf(1,"ternaryColle  [" + this.ioboundcard.ternaryColleceedBalance   +"]");

        JLO.getInstance().printf(1,"----------------------------------------------------");


        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode = "IZZ000";
        this.outarea.iohead.setMsg("Application Info[DED80013.Tx is success]");
        this.outarea.iodata.sBoundData = ioboundcard.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
      else{
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        this.outarea.iodata.sBoundData = ioboundcard.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
      }
    }
    catch(Exception e)
    {
      String errmsg = null;
      if(e instanceof BizActionException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0013";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80013.BizActionException]");
      }
      else if(e instanceof RemoteException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0014";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80013.RemoteException]");
      }
      else if(e instanceof CosesAppException)
      {
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0015";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80013.CosesAppException]");
      }
      else if(e instanceof BizDelegateException)
      {
        JLO.getInstance().eprintf(10,e);
        e.printStackTrace();
        BizDelegateException bdex = (BizDelegateException)e;
        Map map = bdex.getExceptions();
        Set set = map.keySet();
        Iterator iter = set.iterator();
        String exceptionCode = null;
        String exceptionMsg = null;
        while(iter.hasNext()){
          exceptionCode = (String)iter.next();
          exceptionMsg = (String)map.get(exceptionCode);
        }
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
        this.outarea.iohead.setMsg(exceptionMsg);
      }
      else{
        JLO.getInstance().eprintf(10,e);
        String exceptionCode = "ED0016";
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
        this.outarea.iohead.setMsg("Application Exception[DED80013.Other Exception]");
      }
      this.outarea.iodata.sBoundData = ioboundcard.toString();
      this.outarea.sLength = ComUtil.ZeroToStr(ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
      this.outarea.iodata.sLength = this.outarea.sLength;
    }
    return outarea;
  }

}
