package wsj.atm.business;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.net.*;
import java.rmi.*;
import javax.naming.*;
import javax.ejb.*;
import wsj.atm.tcf.STF;
import wsj.atm.socket.ATMserver;
import java.math.BigDecimal;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.log.JLO;
import wsj.atm.packet.IOBoundArea;

import wsj.atm.packet.IOBoundTel80005CDTO;
import com.chb.coses.teller.transfer.*;

import com.chb.coses.cosesFramework.transfer.CosesCommonDTO;
import wsj.atm.bound.BoundArea;
import wsj.atm.ejb.TCPCallEJB;
import wsj.atm.env.UbbConfig;
import wsj.atm.bound.BoundArea;
import com.chb.coses.cosesFramework.exception.*;
import com.chb.coses.framework.exception.*;
import com.chb.coses.framework.transfer.ListDTO;
import wsj.atm.socket.CLTINFO;

//////////////////////////////////////////////////////////////////////////////
// ���� OPEN �ŷ��� �ǽ��Ѵ�.
//////////////////////////////////////////////////////////////////////////////
public class TEL80005 {
  public IOBoundArea inarea;
  public IOBoundArea outarea;
  public IOBoundTel80005CDTO iob80005cdto = null;
  public IOBoundTel80005CDTO oob80005cdto = null;
  public TransferCDTO transfercdto = null;
  private CLTINFO cltinfo;

  public TEL80005(IOBoundArea inarea,IOBoundArea outarea) {
    this.inarea = inarea;
    this.outarea = outarea;
    this.iob80005cdto = new IOBoundTel80005CDTO();
    this.oob80005cdto = new IOBoundTel80005CDTO();
    this.cltinfo = (CLTINFO)ATMserver.tpsvcinfo.getClient(this.inarea.cdto.userId);

  }

  public IOBoundArea execute() throws Exception{
    JLO.getInstance().printf(1,"###########################################################");
    JLO.getInstance().printf(1,"#          TEL80005 �� ȣ��Ǿ����ϴ�  [ ���� OPEN ]         #");
    JLO.getInstance().printf(1,"###########################################################");

    try{
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�["+"]");
      JLO.getInstance().printf(1,"--�⺻������ ����");
      //�ŷ����������� ��ũ�Ѵ�.
      JLO.getInstance().printf(1,"----------------------------------�����ŷ��� �����մϴ�");
      //�Էµ���Ÿ�� �����´�.
      iob80005cdto.setIOBoundTel80005CDTOParsing(this.inarea.iodata.sBoundData);

      transfercdto = new TransferCDTO();
      transfercdto.setTellerNo( ComUtil.CutSpaceToStr( this.iob80005cdto.TellerNo, this.iob80005cdto.TellerNo_LEN ));
      transfercdto.setCurrency(this.iob80005cdto.Currency);
      transfercdto.setTxAmount( new BigDecimal(this.iob80005cdto.TxAmount ));
      transfercdto.setTargetTellerNo( ComUtil.CutSpaceToStr( this.iob80005cdto.TargetTellerNo, this.iob80005cdto.TargetTellerNo_LEN ));

      //////////////////////////////////////////////////////////////////////////
      // 1 ���
      //////////////////////////////////////////////////////////////////////////

      TransferListCDTO transList=null;
      ArrayList list = new ArrayList();
      TransferCashAmountCDTO ccyCDTO = new TransferCashAmountCDTO();
      ccyCDTO.setCurrency(this.iob80005cdto.Currency);
      ccyCDTO.setCurrentCashBalance(new BigDecimal(this.iob80005cdto.TxAmount ));
      list.add(ccyCDTO);
      transList = new TransferListCDTO(list);
      transfercdto.setTransferListCDTO(transList);


      //////////////////////////////////////////////////////////////////////////
      // 2 ���
      //////////////////////////////////////////////////////////////////////////
      /*
      TransferListCDTO transList=null;
      ArrayList list = new ArrayList();
      for(int i=0;i<=2;i++) {
        TransferCashAmountCDTO ccyCDTO = new TransferCashAmountCDTO();
        if( opCDTO.getCurrency() == null ) continue;
        switch( i ){
          case 0:
            if( !(iob80005cdto.Currency01.equals("VND") ||  iob80005cdto.Currency01.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(this.iob80005cdto.Currency01);
            ccyCDTO.setCurrentCashBalance(new BigDecimal(this.iob80005cdto.Amount01 ));
            break;
          case 1:
            if( !(iob80005cdto.Currency02.equals("VND") ||  iob80005cdto.Currency02.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(this.iob80005cdto.Currency02);
            ccyCDTO.setCurrentCashBalance(new BigDecimal(this.iob80005cdto.Amount02 ));
            break;
          case 3:
            if( !(iob80005cdto.Currency03.equals("VND") ||  iob80005cdto.Currency03.equals("USD")) )
              continue;
            ccyCDTO.setCurrency(this.iob80005cdto.Currency03);
            ccyCDTO.setCurrentCashBalance(new BigDecimal(this.iob80005cdto.Amount03 ));
            break;
        }
        list.add(ccyCDTO);
      }
      transList = new TransferListCDTO(list);
      transfercdto.setTransferListCDTO(transList);

      *************************/

      JLO.getInstance().printf(1,"--------EJB ȣ�����");
      /////////////////////////////////////////////////////////////////////////
      // 1] Object �̿��
      /////////////////////////////////////////////////////////////////////////
      /*
      BoundArea outbound=(BoundArea)
                         TCPCallEJB.getInstance().callEJB2("teller-transferTellerCashInfo",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),transfercdto);
      */
      /////////////////////////////////////////////////////////////////////////
      // 2] ObjectPool �̿��pool.printVector();
      /////////////////////////////////////////////////////////////////////////
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      JLO.getInstance().printf(1,"�ϳ��� connection ��ü�� Ǯ���� ��ȯ�ް��� �մϴ� -- 1");
      TCPCallEJB ejbinstance = ATMserver.atmejbpool.getTCPCallEJB();
      ATMserver.atmejbpool.printStates();
      JLO.getInstance().printf(1,"vector.size() : " +ATMserver.atmejbpool.getVector().size());
      JLO.getInstance().printf(1,"----------------------------------------------------------------------");
      BoundArea outbound=(BoundArea)
                         ejbinstance.callEJB2("teller-transferTellerCashInfo",
                         STF.getCosesCDTOfromInBoundArea(this.inarea),transfercdto);
      ATMserver.atmejbpool.freeTCPCallEJB(ejbinstance);

      JLO.getInstance().printf(1,"--------EJB ȣ������");

      if( outbound.errcode.equals ("IZZ000") ){
        JLO.getInstance().printf(1,"�ŷ��� ���������� ȣ��Ǿ����ϴ�:"+outbound.errcode);
        TransferCDTO result = (TransferCDTO)outbound.getParameter();
        JLO.getInstance().printf(1,"************************************************");
        JLO.getInstance().printf(1,"***TransferCDTO***"+result.toString());
        JLO.getInstance().printf(1,"--txno:"+outbound.cdto.getTransactionNo());
        JLO.getInstance().printf(1,"--bankcode:"+result.getOutBankCode());

        this.oob80005cdto = (IOBoundTel80005CDTO)this.iob80005cdto.clone();
        this.oob80005cdto.TellerNo = result.getTellerNo();
        this.oob80005cdto.BankCode = result.getOutBankCode();
        this.oob80005cdto.BranchCode = result.getOutBranchCode();
        this.oob80005cdto.TargetTellerNo = result.getTargetTellerNo();
        this.oob80005cdto.Currency = result.getCurrency();

        for( int i = 0 ; i<result.getTransferListCDTO().size() ; i++){
          TransferCashAmountCDTO  cashBalanceCDTO = (TransferCashAmountCDTO )result.getTransferListCDTO().get(i);
          if( cashBalanceCDTO.getCurrency() == null ) continue;
          switch( i ){
            case 0:
              oob80005cdto.Currency01= cashBalanceCDTO.getCurrency();
              oob80005cdto.Amount01 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80005cdto.Amount_LEN );
              JLO.getInstance().printf(1,"oob80005cdto.Amount01:"+oob80005cdto.Amount01);
              break;
            case 1:
              oob80005cdto.Currency02= cashBalanceCDTO.getCurrency();
              oob80005cdto.Amount02 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80005cdto.Amount_LEN );
             JLO.getInstance().printf(1,"oob80005cdto.Amount02:"+oob80005cdto.Amount02);
              break;
            case 3:
              oob80005cdto.Currency03= cashBalanceCDTO.getCurrency();
              oob80005cdto.Amount03 = ComUtil.LZeroToStr(cashBalanceCDTO.getCurrentCashBalance().toString(),this.oob80005cdto.Amount_LEN );
              JLO.getInstance().printf(1,"oob80005cdto.Amount03:"+oob80005cdto.Amount03);
              break;
          }
        }

        JLO.getInstance().printf(1,"************************************************");
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="IZZ000";
        this.outarea.iohead.setMsg("Application info[TEL80005.Tx is success]");
        this.outarea.iodata.sBoundData = this.oob80005cdto.toString();
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;

        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">�ڱ��μ���(80005)"+">"+oob80005cdto.TellerNo+"->"+oob80005cdto.TargetTellerNo);
        JLO.getInstance().printf(1,"==========================================================================");
        JLO.getInstance().printf(1,">TellerID:"+oob80005cdto.TellerNo);
        JLO.getInstance().printf(1,">TargetTellID:"+oob80005cdto.TargetTellerNo);
        JLO.getInstance().printf(1,">"+oob80005cdto.TellerNo+"->"+oob80005cdto.TargetTellerNo+":"+oob80005cdto.TxAmount);
        JLO.getInstance().printf(1,">"+oob80005cdto.TellerNo+" Current cashBalance->"+":"+oob80005cdto.Amount01 );
        JLO.getInstance().printf(1,"==========================================================================");

      }
      else{
        // �����ܿ��� �߻��� �����ڵ带 �޴´�
        this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode= outbound.errcode ;
        this.outarea.iohead.setMsg(outbound.errmsg);
        //this.outarea.iodata.sBoundData = this.oob80005cdto.toString();
        this.outarea.iodata.sBoundData = this.inarea.iodata.sBoundData;
        this.outarea.sLength = ComUtil.ZeroToStr(
            ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
        this.outarea.iodata.sLength = this.outarea.sLength;
        JLO.getInstance().printf(1,"�ŷ�ȣ���� wo woo wo owoo  ������ �߻��߽��ϴ�.");
      }
      JLO.getInstance().printf(1,"--�⺻������ �������ϰ� ����/���������� �Ǵ�");
      JLO.getInstance().printf(1,"----------------------------------�ŷ��� �����մϴ�");
    }
    catch(Exception e)
   {
     String errmsg = null;
     if(e instanceof BizActionException)
     {
       //JLO.getInstance().printf(10,"BizActionException �߻� !!!!!!!!!!!!!!!!!!! ");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0006";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80005.BizActionException]");
     }
     else if(e instanceof RemoteException)
     {
       //JLO.getInstance().printf(10,"RemoteException �߻� !!!!!!!!!!!!!!!!!!! ");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0007";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80005.RemoteException]");
     }
     else if(e instanceof CosesAppException)
     {
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0008";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80005.CosesAppException]");
     }
     else if(e instanceof BizDelegateException)
     {
       //JLO.getInstance().printf(10,"-----------8888888888----------BizDelegaeException");
       JLO.getInstance().eprintf(10,e);
       e.printStackTrace();
       BizDelegateException bdex = (BizDelegateException)e;
       Map map = bdex.getExceptions();
       Set set = map.keySet();
       Iterator iter = set.iterator();
       String exceptionCode = null;
       String exceptionMsg = null;
       while(iter.hasNext()){
         exceptionCode = (String)iter.next();
         exceptionMsg = (String)map.get(exceptionCode);
       }
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode="ED"+exceptionCode;
       this.outarea.iohead.setMsg(exceptionMsg);
       //JLO.getInstance().printf(10,"---------------------BizDelegaeException:["+exceptionCode+"]");
     }
     else{
       JLO.getInstance().printf(1,"�ŷ�ȣ���� ������ �߻��߽��ϴ�.qqqqqqqqqqqqqqqq----------");
       JLO.getInstance().eprintf(10,e);
       String exceptionCode = "ET0009";
       this.outarea.iohead.sBErrCode = this.inarea.iohead.sBErrCode=exceptionCode;
       this.outarea.iohead.setMsg("Application Exception[TEL80005.Other Exception]");
     }
     this.outarea.iodata.sBoundData = this.oob80005cdto.toString();
     this.outarea.sLength = ComUtil.ZeroToStr(
         ComUtil.Int2Str(this.outarea.iodata.sBoundData.length()),5);
     this.outarea.iodata.sLength = this.outarea.sLength;
   }
   return outarea;
  }
}