package wsj.atm.log;


import java.io.*;
import java.rmi.*;
import java.util.*;
import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.util.Date;

/**
 * <PRE>
 * Class    : Debugging
 * Function :
 * Comment  : Log File Writing <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */

public class Debugging {
  private static Debugging instance;
  public String logging_file_name;
  public String ip;
  public long omode;
  public int pint;

  public Debugging() throws IOException,NotBoundException {
  }
  public static synchronized Debugging getInstance(String logging_file_name,String ip) {
    if (instance == null) {
      try{
        instance = new Debugging();
        instance.logging_file_name = logging_file_name;
        instance.ip = ip;
      }
      catch(Exception igex){
        igex.printStackTrace();
      }
    }
    return instance;
  }

  public synchronized void printf(String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try{
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = GetSysTime().substring(0,8) + "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex){}
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
    return;
  }

  public synchronized void eprintf(Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      LOGFILENAME = this.logging_file_name  + GetHostName() + "." + GetSysDate();
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      e.printStackTrace();
      try{
        fos.close();
        ps.close();
      }
      catch(Exception ex)
      {}
    }
    return;
  }

  public static String GetHostName()
  {
    InetAddress Address=null ;
    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }
  public static String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }
  public static String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }
  public static void main(String args[]) {
    Debugging.getInstance("./kk.log","172.21.119.110").printf("-----------------------");
    IOException ex = new IOException();
    Debugging.getInstance("./kk.log","172.21.119.110").eprintf(ex);
  }
}
