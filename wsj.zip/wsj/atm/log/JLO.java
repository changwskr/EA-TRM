package wsj.atm.log;

import java.io.*;
import java.rmi.*;
import java.util.*;
import java.net.*;
import wsj.atm.common.ComUtil;
import wsj.atm.env.JEN;
import wsj.atm.env.UbbConfig;
import wsj.atm.env.*;

import wsj.atm.common.FILEapi;

/**
 * <PRE>
 * Class    : JLO
 * Function :
 * Comment  : Log File Writing <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */


public class JLO {
  private static JLO instance;
  public static String HOSTNAME=ComUtil.GetHostName();
  public static JEN jen ;
  public static long omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE );;
  public static int pint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMLOGGING_MODE"));
  public static int dint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMDEBUGIN_MODE"));
  public JLO() throws IOException,NotBoundException {
    this.jen = new JEN();
  }

  public static synchronized JLO getInstance() {
    if (instance == null) {
      try{
        instance = new JLO();
        }catch(Exception igex){}
    }
    return instance;
  }

/*
  public void println() {
    String LOGFILENAME = jen.LOGFILENAME + "777" + ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      ps.print(ComUtil.PSpaceToStr(HostName,9));
      ps.print(ComUtil.PSpaceToStr(HostSeq,9));
      ps.print(ComUtil.PSpaceToStr(StartTime.substring(0,8),9));
      ps.print(ComUtil.PSpaceToStr(EndTime.substring(0,8),9));
      ps.print(ComUtil.PSpaceToStr(SysDate,9));
      ps.print(ComUtil.PSpaceToStr(FileName,25));
      ps.print(ComUtil.PSpaceToStr(FileTransferStat,5));
      ps.print(ComUtil.PSpaceToStr(DBUpdateStat,6));
      ps.print(ComUtil.PSpaceToStr(ErrCode,7));
      ps.print(ComUtil.PSpaceToStr(ErrMsg,30));
      ps.println();
      ps.close();
    }catch(Exception e){
        ps.println();
        ps.close();
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
  }
*/

  public synchronized static String GetEnvValue(String tmp)
  {
    String ConfigPath=null;

    Properties p = new Properties();
    String tmpv = null;
    try {
      p.load(new FileInputStream(JEN.JTM_LOG_FILE));
      tmpv=p.getProperty(tmp);
    }
    catch (IOException e) {
      System.out.println("GetEnvValue() ���� ȯ����ý�12 ���ܹ߻�" );
      e.printStackTrace();
      //throw new IOException("GetEnvValue() ���� ȯ����ý� ���ܹ߻�" );
    }
    return tmpv;
  }

  public synchronized static void printf(int mode,String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;



    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    //System.out.println(mode+":"+nmode+":------------:"+JLO.getInstance().pint+":"+JLO.getInstance().omode);
    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().pint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMLOGGING_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
      //System.out.println(mode+":------------:"+JLO.getInstance().pint+":"+JLO.getInstance().omode);
    }

    if( mode >= JLO.getInstance().pint ){
    }
    else
      return;

    try{
      if( thrname.substring(0,3).equals("JSH")) {
        /*
        LOGFILENAME = UbbConfig.getInstance().GetEnvValue("LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      thrname.substring(0,3) +"."+
                      ComUtil.GetSysDate();
        */
        if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
          LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGFILENAME") + "." +
                        ComUtil.GetHostName() + "." +
                        thrname.substring(0,3) +"."+
                        ComUtil.GetSysDate();

        }
        else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
          LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","LOGFILENAME") + "." +
                        ComUtil.GetHostName() + "." +
                        thrname.substring(0,3) +"."+
                        ComUtil.GetSysDate();

        }


      }
      else{
        /*
        LOGFILENAME = UbbConfig.getInstance().GetEnvValue("LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      //thrname.substring(0,3)  +"."+
                      thrname  +"."+
                      ComUtil.GetSysDate();
        */
        if( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","KEY")) ){
          LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGFILENAME") + "." +
                        ComUtil.GetHostName() + "." +
                        //thrname.substring(0,3)  +"."+
                        thrname  +"."+
                        ComUtil.GetSysDate();

        }
        else if ( ComUtil.GetHostName().equals(ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","KEY")) ){
          LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","SLAVE","LOGFILENAME") + "." +
                        ComUtil.GetHostName() + "." +
                        //thrname.substring(0,3)  +"."+
                        thrname  +"."+
                        ComUtil.GetSysDate();

        }


      }
    }
    catch(Exception ex){
    }

    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = //ComUtil.getCurrentDate() +
          ComUtil.GetSysTime().substring(0,8)  +
          "-" +
          //ComUtil.PSpaceToStr(Thread.currentThread().getName(),25) +
      thrname +
          "|" +
          contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }

    return;
  }

  public synchronized static void debuging(int mode,String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;

    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().dint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMDEBUGIN_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    }

    if( mode >= JLO.getInstance().dint ){
    }
    else
      return;

    try{
      /*
      LOGFILENAME = UbbConfig.getInstance().GetEnvValue("SYSLOGFILENAME") + "." +
                    ComUtil.GetHostName() + "." +
                    thrname.substring(0,3)  +"."+
                    ComUtil.GetSysDate();
      */
      LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","SYSLOGFILENAME") + "." +
                    ComUtil.GetHostName() + "." +
                    thrname.substring(0,3)  +"."+
                    ComUtil.GetSysDate();

    }
    catch(Exception ex){
    }

    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = ComUtil.GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }
    return;
  }


  public synchronized static void print(int mode,String contentToWrite) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;

    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().pint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMLOGGING_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    }

    if( mode >= JLO.getInstance().pint ){
    }
    else
      return;

    try{

      if( thrname.substring(0,3).equals("JSH")) {
      /*
        LOGFILENAME = UbbConfig.getInstance().GetEnvValue("LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      thrname.substring(0,3) +"."+
                      ComUtil.GetSysDate();
      */
        LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      thrname.substring(0,3) +"."+
                      ComUtil.GetSysDate();

      }
      else{
        /*
        LOGFILENAME = UbbConfig.getInstance().GetEnvValue("LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      //thrname.substring(0,3)  +"."+
                      thrname  +"."+
                      ComUtil.GetSysDate();
        */
        LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","LOGFILENAME") + "." +
                      ComUtil.GetHostName() + "." +
                      //thrname.substring(0,3)  +"."+
                      thrname  +"."+
                      ComUtil.GetSysDate();

      }
    }
    catch(Exception ex){
    }

    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      ps.print(contentToWrite+",");
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }

    return;
  }

  public synchronized static void printf2(int mode,String contentToWrite) throws IOException{
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    JEN jen = new JEN();

    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().pint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMLOGGING_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    }

    if( mode >= JLO.getInstance().pint ){
    }
    else
      return;

    LOGFILENAME = jen.LOGFILENAME + "." +
                  ComUtil.GetHostName() + "." +
                  thrname.substring(0,3)  +"."+
                  ComUtil.GetSysDate();

    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      contentToWrite = //ComUtil.getCurrentDate() +
          ComUtil.GetSysTime().substring(0,8)  +
          "-" +
          //ComUtil.PSpaceToStr(Thread.currentThread().getName(),25) +
      thrname +
          "|" +
          contentToWrite;
      ps.println(contentToWrite);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }

    return;
  }

  public synchronized static void eprintf(int mode,Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().pint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMLOGGING_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    }
    if( mode >= JLO.getInstance().pint ){
    }
    else
      return;

    LOGFILENAME = JEN.LOGFILENAME + "." +
                  ComUtil.GetHostName() + "." +
                  //thrname.substring(0,3)  +"."+
                  thrname  +"."+
                  ComUtil.GetSysDate();

    FileOutputStream fos = null;
    PrintStream ps = null;

    try {
      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = ComUtil.GetSysTime().substring(0,8)  +
                       "-" +
                     //ComUtil.PSpaceToStr(Thread.currentThread().getName(),25) +
      thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }

    return;
  }

  public synchronized static void debuging(int mode,Exception pex) {
    String thrname = Thread.currentThread().getName();
    String LOGFILENAME = null;
    FileOutputStream fos = null;
    PrintStream ps = null;
    long nmode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);

    if( nmode != JLO.getInstance().omode ){
      JLO.getInstance().dint = ComUtil.Str2Int(JLO.getInstance().GetEnvValue("JTMDEBUGIN_MODE"));
      JLO.getInstance().omode = FILEapi.FILElastmodified(JEN.JTM_LOG_FILE);
    }
    if( mode < JLO.getInstance().dint ){
      return;
    }

    try {
      /*
      LOGFILENAME = UbbConfig.getInstance().GetEnvValue("SYSLOGFILENAME") + "." +
                    ComUtil.GetHostName() + "." +
                    thrname.substring(0,3)  +"."+
                    ComUtil.GetSysDate();
      */
      LOGFILENAME = ATMXMLconfig.getInstance().GetEnvValue("MACHINE","MASTER","SYSLOGFILENAME") + "." +
                    ComUtil.GetHostName() + "." +
                    thrname.substring(0,3)  +"."+
                    ComUtil.GetSysDate();

      fos = new FileOutputStream(LOGFILENAME, true);
      ps = new PrintStream(fos);
      String contentToWrite = "";
      contentToWrite = ComUtil.GetSysTime().substring(0,8)  +
                       "-" +
                       thrname +
                       "|" +
                       contentToWrite;
      ps.println(contentToWrite);
      pex.printStackTrace(ps);
      ps.flush();
      ps.close();
      fos.close();
    }catch(Exception e){
      try{
        fos.close();
        ps.close();
        }catch(Exception ex){}
        e.printStackTrace();
        System.out.println("appendFileWrite Exception");
    }
    return;
  }




  public void println(String contentToWrite) {
    String LOGFILENAME = jen.LOGFILENAME + "." +
                         ComUtil.GetHostName() + "." +
                         Thread.currentThread().getName() +"."+
                         ComUtil.GetSysDate();
    try {
      contentToWrite = ComUtil.getCurrentDate() +
                       "-" +
                       ComUtil.PSpaceToStr(Thread.currentThread().getName(),10) +
                       "|" +
                       contentToWrite;
      System.out.println(contentToWrite );
      System.out.println(ComUtil.getCurrentDate() +
                         "-" +
                         ComUtil.PSpaceToStr(Thread.currentThread().getName(),10) +
                         "|" + "-----------------------------------------------------------");
    }catch(Exception e){
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
    }
  }

  /**
   * �� �޼ҵ�� ������ ��Ʈ���� �α����Ͽ� ����Ѵ�.
   * The file is created, if it does not exist.
   * @param contentToWrite java.lang.String
   * @return boolean - true, if the append is successful. false, otherwise.
   */

  public static boolean log(String contentToWrite) {
    boolean result=true;
    String LOGFILENAME = jen.LOGFILENAME +"."+ ComUtil.GetHostName() + "." + ComUtil.GetSysDate();
    try {
      contentToWrite = ComUtil.getCurrentDate() + "-" + HOSTNAME+ "|" + contentToWrite + "\n";
      FileOutputStream fos = new FileOutputStream(LOGFILENAME, true);
      PrintStream ps = new PrintStream(fos);
      ps.print(contentToWrite);
      ps.close();
    }catch(Exception e){
      e.printStackTrace();
      System.out.println("appendFileWrite Exception");
      return false;
    }
    return true;
  }

  public static void main(String args[]) throws IOException {
    JLO.getInstance().printf(1,"-��������������������");
  }
}
