package wsj.jndi;

import java.util.Hashtable;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.naming.NamingEnumeration;

public class ListRMIObject {
  public ListRMIObject() {
  }
  public static void main(String[] args) {
    // ȯ�� ������ �Ѵ�.
    Hashtable hash = new Hashtable();
    hash.put("java.naming.factory.initial", "com.sun.jndi.rmi.registry.RegistryContextFactory");
    hash.put("java.naming.provider.url", "rmi://localhost:1099");

    try {
      // hash ������ Context �ʱ�ȭ �Ѵ�.
      Context context = new InitialContext(hash);

      // context���� ��� ���� �����´�.
      NamingEnumeration ne = context.list("");

      while(ne.hasMoreElements()){
        System.out.println ( ne.next() );
      }

    }
    catch (Exception e){
      e.printStackTrace();
    }
  }

}