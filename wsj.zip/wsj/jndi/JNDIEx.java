package wsj.jndi;

import javax.naming.*;
import weblogic.jndi.*;
import java.util.*;

class JNDIEx {

  public static Context getInitialContext()
  {
    Context ctx = null;
    Hashtable env = new Hashtable();

    env.put(Context.INITIAL_CONTEXT_FACTORY,"weblogic.jndi.WLInitialContextFactory");
    env.put(Context.PROVIDER_URL,"t3://localhost:7001");
    env.put(Context.SECURITY_PRINCIPAL,"system");
    env.put(Context.SECURITY_CREDENTIALS,"password");

    try {
      ctx = new InitialContext(env);
    }
    catch (NamingException e) {
    }
    finally {
      try {
        ctx.close();
      }
      catch(Exception e){
        e.printStackTrace();
      }
    }
    return ctx;
  }

  public static void getInitialContextFromEnv()
  {
    Context ctx = null;
    Environment env = new Environment();

    env.setSecurityPrincipal("system");
    env.setSecurityCredentials("weblogic");

    try {
      ctx = env.getInitialContext();
    }
    catch (NamingException e) {
    }
    finally {
      try {
        ctx.close();
      }
      catch(Exception e){
        e.printStackTrace();
      }
    }
  }

  public static void Bind()
  {
    Context ctx = null;
    Environment env = new Environment();
    env.setSecurityPrincipal("system");
    env.setSecurityCredentials("weblogic");

    try {
      ctx = getInitialContext();


      Person myPerson = new Person();
      ctx.bind ("Person Object",myPerson);

    }
    catch( NamingException e) {
    }

    try {


      Person myPerson = new Person();
      ctx.rebind ("Person Object",myPerson);

    }
    catch( NamingException e) {
    }
  }

  public static void subContextBind()
  {
    Context ctx = null;
    Environment env = new Environment();

    env.setSecurityPrincipal("system");
    env.setSecurityCredentials("weblogic");

    try {
      ctx=JNDIEx.getInitialContext();


      Context subctx = ctx.createSubcontext("JNDI Chapter");

      Person myperson = new Person();
      subctx.bind("Person Object",myperson);

    }
    catch(NamingException e) {
    }
  }

  public static void Lookup()
  {
    Context ctx = null;
    Environment env = new Environment();

    env.setSecurityPrincipal("system");
    env.setSecurityCredentials("weblogic");

    try {
      ctx = env.getInitialContext();
      Person myPerson = (Person)ctx.lookup("JNDI Chapter/Person Object");
    }
    catch(NamingException e){
    }
  }

}

class Person {

  public Person(){

  }

}




