package wsj.ofac;
import java.io.*;
import java.net.*;

public class MultiSocket extends Socket
{
  public MultiSocket(String ip, int port)
      throws UnknownHostException, IOException
  {
    super(ip,port);
  }
}
