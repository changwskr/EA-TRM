package wsj.ofac;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.rmi.*;

public class OFACrmicall
{
  private static OFACrmicall instance;

  public static synchronized OFACrmicall getInstance() {
    if (instance == null) {
      try{
        instance = new OFACrmicall();
      }
      catch(Exception igex)
      {
        igex.printStackTrace();
        return null;
      }
    }
    return instance;
  }

  public OFACrmicall() throws Exception
  {
  }

  public synchronized String execute(String ip,String port,String message)
  {
    String result = null;
    try{
      String rmiURL="rmi://"+ip+":"+port+"/OFAC";
      System.out.println("OFACrmicall lookup start"+"--------------------------------------");
      System.out.println("url : " + rmiURL);

      OFACmethod e = (OFACmethod)Naming.lookup(rmiURL);
      result = e.say(message);
      System.out.println("OFACexecute.main() "+"result - "+result);
      System.out.println("----------------------------------------------------");
    }
    catch(Exception ex){
      ex.printStackTrace();
      return null;
    }
    return result;
  }
}