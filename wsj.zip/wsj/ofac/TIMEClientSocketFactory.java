package wsj.ofac;

import java.io.*;
import java.net.*;
import java.util.*;
import java.rmi.server.*;

public class TIMEClientSocketFactory
    implements RMIClientSocketFactory, Serializable {

  private int timeout = 30000;
  private InetAddress[] svrAddrs;

  public void init() throws UnknownHostException,IOException
  {
    String hostname = InetAddress.getLocalHost().getHostName();
    svrAddrs = InetAddress.getAllByName(hostname);
  }

  public void init(int timeout) throws UnknownHostException,IOException
  {
    String hostname = InetAddress.getLocalHost().getHostName();
    svrAddrs = InetAddress.getAllByName(hostname);
    this.timeout = timeout;
  }

  public Socket createSocket(String ip, int port) throws IOException
  {
    System.out.println("TIMEClientSocketFactory.createSocket()]"+"connect - "+ip+":"+port);
    Socket sck = null;
    try {
      sck = new Socket(ip,port);
    } catch(IOException e) {
      e.printStackTrace();
      System.out.println("---kkkTIMEClientSocketFactory.createSocket()]"+e.toString());
      for(int i=0;i<svrAddrs.length;i++) {
        if(!svrAddrs[i].getHostAddress().equals(ip)) {
          try {
            System.out.println(
            "TIMEClientSocketFactory.createSocket()]"+
            "connect aaa- "+svrAddrs[i].getHostAddress()+":"+port
            );
            sck = new Socket(svrAddrs[i],port);
          } catch(Exception ex) {	}
        }
      }
    }
    if(sck==null) throw new IOException("Unkwon Host...");
    sck.setSoTimeout(timeout); //����Ʈ 30���̴�.
    System.out.println("TIMEClientSocketFactory.createSocket()]"+"create a Socket - "+sck);
    return sck;
  }


}


