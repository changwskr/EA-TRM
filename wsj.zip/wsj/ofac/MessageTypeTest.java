package wsj.ofac;

public class MessageTypeTest {

   static {

     System.loadLibrary("messagetype");

   }

   public native String printMessage(String str);

   public static void main(String[] args)  throws Exception {

       MessageType h = new MessageType();

       System.out.println("-------------------------------------------------");
       System.out.println("pass arg message : " + "[" + "ppppppp" + "]");
       System.out.println("retn val message : " + "[" + h.printMessage("ppppppp") + "]");

   }

}


