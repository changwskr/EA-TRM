package wsj.hwarang;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import sun.net.ftp.FtpClient;

public class FTPdownload {

  public static int execute(String hostname,
                            String path_filename,
                            String username,
                            String password )
  {
    FtpClient fc=null;
    InputStream theFile = null;
    FileOutputStream fos = null;
    String filename ="";
    String directory = "";
    int rtn = 0;

    try {
      int lastSlash = path_filename.lastIndexOf('/');
      filename = path_filename.substring(lastSlash+1);
      directory = path_filename.substring(0, lastSlash);

      HwaRang.ertrace("================================================");
      HwaRang.ertrace(">FTPdownload start>");
      HwaRang.ertrace("================================================");
      HwaRang.ertrace(">"+HwaRang.GetHostName()+":"+HwaRang.GetSysDate()+":"+HwaRang.GetSysTime() );
      HwaRang.ertrace(">Target hostname:"+hostname);
      HwaRang.ertrace(">Target path    :"+directory);
      HwaRang.ertrace(">Target filename:"+path_filename);
      HwaRang.ertrace(">username:"+username);
      HwaRang.ertrace(">password:"+password);
    }
    catch (ArrayIndexOutOfBoundsException e) {
      e.printStackTrace();
      return -1;
    }

    try {

      fc = new FtpClient(hostname);
      fc.login(username, password);
      fc.binary();
      fc.cd(directory);
      theFile = fc.get(filename);
      int i = 0;
      fos = new FileOutputStream(filename);
      while((i = theFile.read()) != -1) {
        fos.write((byte)i);
      }
      fc.closeServer();
      fos.close();
    }
    catch (IOException e) {
      e.printStackTrace();
      rtn =-1;
    }

    try
    {
      if( fos != null )
        fos.close();
      if( theFile != null )
        theFile.close();
      if( fc != null )
        fc.closeServer();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    switch( rtn )
    {
      case 0:
        HwaRang.ertrace("-- SUCCESS --");
        break;
      case -1:
        HwaRang.ertrace("-- ERROR --");
        break;
    }
    HwaRang.ertrace(">"+HwaRang.GetHostName()+":"+HwaRang.GetSysDate()+":"+HwaRang.GetSysTime() );
      HwaRang.ertrace("================================================");

    return rtn;
  }

  public static void main(String argv[] ) {

    FTPdownload.execute("188.238.50.52",
                        "/home/cosif/samgokgy/log/org/STATEMENT_IMAGE.003.20031230",
                        "cosif",
                        "cosif");

  }
}