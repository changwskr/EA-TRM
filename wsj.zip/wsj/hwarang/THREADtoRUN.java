package wsj.hwarang;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class THREADtoRUN
{
  public static void execute(Runnable obj,String thread_name)
  {
    try{
      Thread thr = new Thread(obj,thread_name);
      thr.start();
    }
    catch(Exception ex){
      ex.printStackTrace();
    }
  }
}

