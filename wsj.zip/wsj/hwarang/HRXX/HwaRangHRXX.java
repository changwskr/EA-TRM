package wsj.hwarang.HRXX;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;
import wsj.hwarang.*;

public class HwaRangHRXX extends HwaRang
{
  private Connection conn;
  private HRecordInfo info;
  private HRecordInfo Sinfo;
  public static String ROC_MAX_DATE = "20000101";
  public static String HRXX_MODE="X";

  public HwaRangHRXX()
  {
    try {
    }
    catch(Exception ex) {
      ex.printStackTrace();
      System.exit(1);
    }
  }

  int sleepFlag=0;
  public void HRXXEXE ()
  {
    while( true )
    {
      info  = null;
      Sinfo = null;

      if ( sleepFlag == 0 )
      {
        try{
          Thread.currentThread().sleep(10000);
        } catch(Exception ignore) {}
      }

      try {
        conn = dbConn(ROCDBIP,ROCSID,ROCDBUSER,ROCDBPAWD);
        if( conn == null ){
          HwaRang.ertrace("> DB Connection ERROR -- continue");
          sleepFlag = 0;
          continue;
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
        HwaRang.ertrace(ex.toString());
        HwaRang.ertrace("> DB Connection ERROR -- continue");
        sleepFlag = 0;
        continue;
      }

      if ( ROC_MAX_DATE == null ) {
        ertrace("*************** ROC_MAX_DATE not get ****************");
        break;
      }

      trace("");
      trace("==========================================================================================");
      trace(">"+HwaRang.GetHostName()+":"+HwaRang.GetSysDate()+":"+HwaRang.GetSysTime() );

      if( (info=STEP_02_GETrecorefile_INhq(conn)) != null )
      {
        trace(">FILENAME:"+info.hostname );
        trace(">FILESIZE:"+info.fsize );

        try {
          //:~ ���������� ���� �����Ƿ� ������ �ٷ� ������ ���� ����
          sleepFlag = 1;
          Sinfo = new HRecordInfo(info.hostseq,info.fname,
                                  info.fsize,"X","X",info.curdate,
                                  info.systime,info.hostname,"0" );
          //:~ 1. ROC�κ��� �ϳ��� ������ �ٿ�ε� �Ѵ�.
          trace(">STEP_04_FTPdownload_FROMroc:-- ST");

          switch( STEP_04_FTPdownload_FROMroc(Sinfo,MODE.charAt(0) ) )
          {
            case -1:
              ertrace(">STEP_04_FTPdownload_FROMroc:-- FAIL -- info.fname:" + info.fname);
              break;
            case 0:
              trace(">STEP_04_FTPdownload_FROMroc:-- SUCCESS -- info.fname:" + info.fname);

              if( STEP_05_INSERTrecord_INhq(Sinfo) )
              {

                if( LUpdateZHRecordInfo(Sinfo,"Z",conn) && UpdateZHRecordInfo(Sinfo,"Z") ){
                  trace(">LUpdateZHRecordInfo,UpdateZHRecordInfo -- SUCCESS -- Sinfo.fname:" + info.fname);
                  //=====================================================================
                  if( HRXX_MODE.charAt(0)=='B' )
                    STEP_06_CALLbusiness_INhq(Sinfo);
                  //=====================================================================
                }
                else{
                  DeleteHRecordInfo(Sinfo);
                  LUpdateZHRecordInfo(Sinfo,"X","0",conn);
                  HwaRang.ertrace(">HQ ::" + info.fname + "DELETE - Network fail");
                  HwaRang.ertrace(">HQ :: -- FAIL -- info.fname:" + info.fname);
                }
              }
              else{
                LUpdateZHRecordInfo(Sinfo,"X","0",conn);
              }
              break;
          }
        }
        catch(Exception e){
          HwaRang.ertrace(e.toString());
          e.printStackTrace();
          HwaRang.ertrace(">HwaRangHRXX "+"Client teminate: "+info.fname);
        }
      }
      else {
        HwaRang.ertrace(">### HwaRangHRXX ### "+"There is no Data in Lfileinfo");
        break;
      }

      try {
        conn.close();
      }
      catch(Exception ex) {
        HwaRang.ertrace(ex.toString());
        HwaRang.ertrace("STEP_03_GETrecord_INroc conn.close() ���ܹ߻�");
      }

      //=====================================================================
      String hostname=null;
      if( HRXX_MODE.charAt(0)=='F' ){
        System.out.println("USAGE : HwaRangZX hostname base_date dbuser dbpasswd dburl");
        if( "188.238.50.52".equals(ROCIP) )
          hostname="CVBU002";
        else if( "21.111.50.52".equals(ROCIP) )
          hostname="CHBNY02";
        else{
          System.out.println("##########NOT MATCH HOSTNAME############");
          return;
        }
        try{
          new HwaRangZX (hostname,ROC_MAX_DATE,ROCDBUSER,ROCDBPAWD,
                       "jdbc:oracle:thin:@"+HQIP+":1521:"+HQSID).execute();
        }
        catch(Exception ex){
          ex.printStackTrace();
        }
      }
      //=====================================================================

    }
  }

  public static void main(String args[])
      throws Exception
  {

    if (args.length != 2 ){
      System.out.println("-After FTP transfer,  Business");
      System.out.println("java wsj.samgokgy.download.HwaRangHRXX basedate F");
      System.out.println("-FTP transfer, at once Business");
      System.out.println("java wsj.samgokgy.download.HwaRangHRXX basedate B");
      return;
    }
    ROC_MAX_DATE = args[0];
    HRXX_MODE = args[1];

    System.out.println("================================================");
    System.out.println(" [VN]");
    System.out.println("================================================");
    System.out.println("java -Dhqip=21.101.3.47 -Dhqdbuser=mis -Dhqdbpawd=mis -Dhqsid=DEVMIS ");
    System.out.println("     -Drocip=188.238.50.52 -Drocosuser=cosif -Drocospawd=cosif -Drocdbuser=mis -Drocdbpawd=mis -Drocsid=DEVMIS ");
    System.out.println("     -Dmode=c||n -Drocdbip=188.238.50.50 -Dlogmode=on||off");
    System.out.println("     -Dorg_path=/home/cosif/samgokgy/log/org/");
    System.out.println("     -Dtar_path=/home/cosif/samgokgy/log/tar/");
    System.out.println(" wsj.samgokgy.download.HwaRangHRXX base_date F||B");
    System.out.println("");

    System.out.println("================================================");
    System.out.println(" [US]");
    System.out.println("================================================");
    System.out.println("java -Dhqip=21.101.3.47 -Dhquser=mis -Dhqpawd=mis -Dhqsid=DEVMIS ");
    System.out.println("     -Drocip=21.111.50.52 -Drocosuser=cosif -Drocospawd=cosif -Drocdbuser=usny -Drocdbpawd=usny -Drocsid=USMIS ");
    System.out.println("     -Dmode=c||n -Drocdbip=21.111.50.52 -Dlogmode=on||off");
    System.out.println("     -Dorg_path=/home/cosif/samgokgy/log/org/");
    System.out.println("     -Dtar_path=/home/cosif/samgokgy/log/tar/");
    System.out.println(" wsj.samgokgy.download.HwaRangHRXX base_date F||B");
    System.out.println("");

    HwaRangHRXX hwr = new HwaRangHRXX();
    hwr.HRXXEXE();
  }

}


