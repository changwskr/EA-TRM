package wsj.hwarang;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


import java.io.*;
import java.util.*;
import java.sql.*;

public class HwaRangZX
{
  Connection 	conn;
  public String roc_name;
  public String base_date;
  public String dbuser;
  public String dbpasswd;
  public String dburl;
  public static String BASEDATE = "20000101";

  public HwaRangZX (String roc_name,String base_date,
                     String dbuser,String dbpasswd,String dburl)
      throws IOException,Exception
  {
    this.roc_name = roc_name;
    this.base_date = BASEDATE = base_date ;
    this.dbuser= dbuser;
    this.dbpasswd = dbpasswd;
    this.dburl = dburl;

    System.out.println("|||||==============================="+"=====================================|||||");

    conn = dbConn(dbuser,dbpasswd,dburl);
    if ( conn == null ){
      System.out.println(" ++ HwaRangZX() connection is null ++ ");
      System.exit(1);
    }
    System.out.println(" ++ HwaRangZX() DB connection success ++ ");
  }

  public static Connection dbConn(String user,String passwd,String dburl)
  {
    Connection conn = null;

    try {
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      conn = DriverManager.getConnection (dburl, user, passwd);
    } catch ( Exception e ) {
      System.out.println("DriverManager.getConnection Exception ");
      return null;
    }
    return conn;
  }

  public static void dbClose(Connection connection)
  {
    try {
      connection.close();
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new RuntimeException(exception.toString());
    }
  }


  public void execute ()
  {
    while (true)
    {
      System.out.println("\n\n");

      try{
        System.out.println(">================================================================");
        System.out.println(">BASEDATE:"+BASEDATE);
        BASEDATE = base_date;

        HRecordInfo info = STEP_01_GETrecord_INFILEINFO( conn );
        if ( info == null )
        {
          System.out.println(">BREAK");
          break;
        }
        if( HwaRang.checkPrevious(info,conn,BASEDATE).equals("SUCCESS") ){
          STEP_02_CALLbusiness(info,conn);
        }
      }
      catch(Exception e){
        e.printStackTrace();
      }
    }
    dbClose(conn);
    System.out.println(">END");
  }


  public HRecordInfo STEP_01_GETrecord_INFILEINFO(  Connection connection)
  {
    HRecordInfo info=null;
    String tablename=null;
    Statement stmt = null;
    ResultSet rs = null;

    System.out.println(">STEP_01_GETrecord_INFILEINFO:--ST--");

    try {
      connection.setAutoCommit(false);
    }
    catch (Exception exception) {
      System.out.println(exception);
      exception.printStackTrace();
      System.out.println(">STEP_01_GETrecord_INFILEINFO:--FAIL--");
      return null;
    }

    try {
      stmt = connection.createStatement();
      String sql = "SELECT hostseq,fname,fsize,statFile,commit,curdate,"+
                   "systime,hostname,filetransfercnt "+
                   "FROM fileinfo " +
                   "WHERE commit='X' AND statFile='Z' AND rownum=1 " +
                   "AND hostname='" + roc_name +"' "+
                   "AND curdate='" + BASEDATE +"' "+
                   "AND filetransfercnt BETWEEN 0 AND 2 ORDER BY hostname,hostseq" ;

      System.out.println(">STEP_01_GETrecord_INFILEINFO:SQL[" + sql + "]");

      rs = stmt.executeQuery(sql);
      if (rs.next())
      {
        info = new HRecordInfo( rs.getString(1),
                                rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),
                                rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9) );
      }
    }
    catch (Exception exception)
    {
      System.out.println(exception);
      exception.printStackTrace();
      try{
        rs.close();
        stmt.close();
      }
      catch(Exception ex){
      }
      System.out.println(">STEP_01_GETrecord_INFILEINFO:--FAIL--");
      return null;
    }

    try{
      rs.close();
      stmt.close();
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println(">STEP_01_GETrecord_INFILEINFO:--FAIL--");
      return null;
    }

    System.out.println(">STEP_01_GETrecord_INFILEINFO:--SUCCESS--");

    return info;
  }


  public int STEP_02_CALLbusiness(HRecordInfo info,Connection conn) {

    HQBatchEng hb = null;
    System.out.println(">STEP_02_CALLbusiness:--ST--");

    try {
      hb = new HQBatchEng();
      if( hb.execute(info.fname) )
      {
        STEP_03_COMMIT_INFILEINFO( info, "Z", conn );
        System.out.println(">STEP_02_CALLbusiness:--SUCCESS--");
        return 0;
      }
      else{
        STEP_03_COMMIT_INFILEINFO( info, "B", conn );
        System.out.println(">STEP_02_CALLbusiness:--FAIL--");
        return -1;
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
      System.out.println(">STEP_02_CALLbusiness:--FAIL--");
      return -1;
    }
  }

  public static void STEP_03_COMMIT_INFILEINFO( HRecordInfo info, String commit_stat,Connection connection ) {
    System.out.println(">STEP_03_COMMIT_INFILEINFO:--ST--");

    try {
      connection.setAutoCommit(false);
    } catch (Exception exception) {
      exception.printStackTrace();
      System.out.println(">STEP_03_COMMIT_INFILEINFO:--FAIL--");
      return;
    }

    try {
      String sql = "UPDATE FILEINFO SET COMMIT = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      PreparedStatement  pstmt = connection.prepareStatement(sql);

      pstmt.setString(1, commit_stat);
      pstmt.setString(2, info.fname);
      pstmt.setString(3, info.hostname);
      pstmt.setString(4, info.hostseq);

      if( pstmt.executeUpdate() == 1 ) ;
      pstmt.close();

    } catch (Exception exception) {
      exception.printStackTrace();
      try {
        connection.rollback();
        connection.setAutoCommit(true);
      } catch (Exception failure) {
        exception.printStackTrace();
      }
      System.out.println(">STEP_03_COMMIT_INFILEINFO:--FAIL--");
      return;
    }
    try {
      connection.commit();
      connection.setAutoCommit(true);
    } catch (Exception exception) {
      exception.printStackTrace();
      System.out.println(">STEP_03_COMMIT_INFILEINFO:--FAIL--");
      return;
    }
  }


  public static void main (String args[]) throws IOException,Exception {


    try {
      if( args.length  < 5 ){
        System.out.println("CASE 01:.");
        System.out.println("  -���� ROC�� ������ü�� �̻��� �Ŵ���� �������� �� ���:");
        System.out.println("  -S.1, ���� �ش������� rcp�Ѵ�.");
        System.out.println("  -S.2, HQ�� �ϳ��� ���ڵ带 �����Ѵ�(insert)");
        System.out.println("  -S.3, HQ�� insert�� ������ �����ʵ带 Z���� �ʱ�ȭ �Ѵ�");
        System.out.println("  -S.4, HwaRangZX�� �⵿�Ѵ�.");
        System.out.println("CASE 02:.");
        System.out.println("  -���� ROC�� ������ü�� ������ ���µ� MIS DB ����� ������ �� ��⵿��:");
        System.out.println("  -S.1,  HwaRangZB�� �⵿�Ѵ�.");
        System.out.println("CASE 03:.");
        System.out.println("  -���� �������� ���̺��� MIS DB�� �ݿ��� �ȵǾ��� ���:");
        System.out.println("  -S.1,  HwaRangZX�� �⵿�Ѵ�.");

        System.out.println("USAGE : HwaRangZX hostname base_date dbuser dbpasswd dburl");
      }
      else{
        new HwaRangZX (args[0],args[1],args[2],args[3],args[4]).execute();
      }
    }
    catch(Exception ex){
      ex.printStackTrace();
    }

  }

}
