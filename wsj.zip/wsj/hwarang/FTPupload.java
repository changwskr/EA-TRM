package wsj.hwarang;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.StringTokenizer;
import java.io.*;
import java.net.*;
import sun.net.TelnetInputStream;
import sun.net.TelnetOutputStream;
import sun.net.ftp.FtpClient;

public class FTPupload {



  public static int execute(String hostip,
                            String userid,
                            String passwd,
                            String tarpath,
                            String orgpath,
                            String onlyfilename)
  {
    FtpClient fc = null;
    FileInputStream from = null;
    TelnetOutputStream to = null;
    int LOCAL_SIZE = 4096;
    int rtn = 0;
    try
    {
      System.out.println("");
      System.out.println("===========================================================");
      System.out.println("FTPupload start>");
      System.out.println("===========================================================");
      System.out.println("Target hostname:"+hostip);
      System.out.println("Target path    :"+tarpath);
      System.out.println("Orginl filename:"+orgpath+"/"+onlyfilename);

      fc = new FtpClient(hostip);
      fc.login(userid, passwd);
      fc.binary();
      fc.cd(tarpath);
      from = new FileInputStream(orgpath+"/"+onlyfilename);
      to = fc.put(onlyfilename);
      byte[] buffer = new byte[LOCAL_SIZE];
      int bytes_read;
      while ((bytes_read = from.read(buffer)) != -1)
        to.write(buffer, 0, bytes_read);
      from.close();
      to.close();
    }
    catch (IOException e) {
      e.printStackTrace();
      rtn = -1;
    }
    try
    {
      if( from != null )
        from.close();
      if( to != null )
        to.close();
      if( fc != null )
        fc.closeServer();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    switch( rtn )
    {
      case 0:
        System.out.println("-- SUCCESS --");
        break;
      case -1:
        System.out.println("-- ERROR --");
        break;
    }
    System.out.println("FTP server connection close");
    System.out.println("===========================================================");

    return rtn;
  }

  public static void main(String argv[]) {
    /*
    execute(String hostip,
                            String userid,
                            String passwd,
                            String tarpath,
                            String orgpath,
                            String onlyfilename)
    */
    FTPupload.execute("21.101.3.49",
                      "cosif",
                      "cosif",
                      "/home/cosif/samgokgy/src",
                      "/home/cosif/samgokgy/src",
                      "FTPupload.java");

  }
}