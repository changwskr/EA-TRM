package wsj.hwarang;

import java.net.*;
import java.io.*;
import java.util.*;
import java.sql.*;


/*
 drop table tableinfo;
 CREATE TABLE TABLEINFO (
   FNAME                     VARCHAR2(30) NOT NULL,
   CURDATE                   VARCHAR2(8) NOT NULL,
   PRIMARY KEY ( FNAME )
  );


 drop table fileinfo;
 drop table lfileinfo;

 CREATE TABLE FILEINFO (
   HOSTSEQ                   VARCHAR2(10) NOT NULL,
   FNAME                     VARCHAR2(30) NOT NULL,
   FSIZE                     VARCHAR2(10) NOT NULL,
   STATFILE					VARCHAR2(2) NOT NULL,
   COMMIT					VARCHAR2(2) NOT NULL,
   CURDATE                   VARCHAR2(8) NOT NULL,
   SYSTIME                   VARCHAR2(10) NOT NULL,
   HOSTNAME                  VARCHAR2(20) NOT NULL,
   FILETRANSFERCNT					VARCHAR2(8) NOT NULL,
   PRIMARY KEY ( HOSTSEQ )
  );


 CREATE TABLE LFILEINFO (
   HOSTSEQ                   VARCHAR2(10) NOT NULL,
   FNAME                     VARCHAR2(30) NOT NULL,
   FSIZE                     VARCHAR2(10) NOT NULL,
   STATFILE					VARCHAR2(2) NOT NULL,
   COMMIT					VARCHAR2(2) NOT NULL,
   CURDATE                   VARCHAR2(8) NOT NULL,
   SYSTIME                   VARCHAR2(10) NOT NULL,
   HOSTNAME                  VARCHAR2(20) NOT NULL,
   FILETRANSFERCNT					VARCHAR2(8) NOT NULL,
   PRIMARY KEY ( HOSTSEQ )
  );


  */



public class HRecordInfo implements Serializable{

  public String  mKey;
  public String  hostseq;
  public String  fname;
  public String  fsize;
  // DB ���̺��κ��� ���ڵ带 �������� �о��ٴ� ���� CHECKING
  // X : ���� ����  Z : ���������� ����
  public String  statFile;
  // ���Ͼ��ε尡 ���������� ������ üŷ
  // X : ���� ����  Y: ������  Z : ���������� ���ε�
  public String  commit;
  public String  curdate;
  public String  systime;
  public String  hostname;
  public String  filetransfercnt;

  //////////////////////////////////////////////////////////////////////
  //  ������
  /////////////////////////////////////////////////////////////////////
  public HRecordInfo(String hostseq, String fname,    String fsize,
                    String statFile,String commit,   String curdate,
                    String systime, String hostname, String filetransfercnt ) {
    this.hostseq = hostseq;
    this.fname = fname;
    this.fsize = fsize;
    this.statFile = statFile;
    this.commit = commit;
    this.curdate = curdate;
    this.systime = systime;
    this.filetransfercnt = filetransfercnt;
    this.hostname = hostname;
    this.mKey = fname;
  }



}
