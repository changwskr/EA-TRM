package wsj.hwarang;

import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.sql.*;
import java.util.Date;
//import com.chb.coses.mis.HQ.batch.HQBatchEng;


/**
 * <PRE>
 * Class    : HwaRang
 * Function :
 * Comment  : <BR>
 *            <BR>
 *            <BR>
 * </PRE>
 * @version : 1.0
 * @author  : ��  ��  ��
 */


public class HwaRang implements Runnable
{
  private Connection conn;
  private HRecordInfo info;
  private HRecordInfo Sinfo;
  private String ROC_MAX_DATE = "20000101";

  public String HQIP = System.getProperty("hqip");
  public String HQDBUSER = System.getProperty("hqdbuser");
  public String HQDBPAWD = System.getProperty("hqdbpawd");
  public String HQSID = System.getProperty("hqsid");

  public static String ROCIP = System.getProperty("rocip");
  public String ROCDBIP = System.getProperty("rocdbip");
  public String ROCOSUSER = System.getProperty("rocosuser");
  public String ROCDBUSER = System.getProperty("rocdbuser");
  public String ROCOSPAWD = System.getProperty("rocospawd");
  public String ROCDBPAWD = System.getProperty("rocdbpawd");
  public String ROCSID = System.getProperty("rocsid");
  public String MODE = System.getProperty("mode");
  public String LOGMODE = System.getProperty("logmode");

  public static final String BEFORE_FILE_ERR_NEXT_PROC_STATFILE_Z = "N";
  public String message_exception_flag_GetTheRecordInfo="I";
  public String ORG_PATH="/home/cosif/samgokgy/log/org/";
  public String TAR_PATH="/home/cosif/samgokgy/log/tar/";
  public String rsh_cmd_compress="rsh" + " " + ROCIP + " " + "compress" + " " + ORG_PATH;

  public HwaRang()
  {
    try {
      if(System.getProperty("org_path")!=null) {
        ORG_PATH=System.getProperty("org_path");
      }
      if(System.getProperty("tar_path")!=null) {
        TAR_PATH=System.getProperty("tar_path");
      }
    }
    catch(Exception ex) {
      ex.printStackTrace();
      System.exit(1);
    }
  }

  public void run()
  {
    try {
      this.execute();
    }
    catch ( Exception ex ) {
      ex.printStackTrace();
    }
    return;
  }

  int sleepFlag = 0;
  public int execute ()
  {
    while( true )
    {
      info  = null;
      Sinfo = null;


      //:~ ���������� ROC���� ���̻� ����Ÿ ������ ���� ���� ��쿡 1�ʿ� �ѹ���
      //   ������ �������ؼ� ���� ����
      if ( sleepFlag == 0 )
      {
        try{
          Thread.currentThread().sleep(10000);
        } catch(Exception ignore) {}
      }

      //:~ ��Ʈ���̳� ����Ÿ���̽��� ������ ��츦 ����� OPEN/CLOSE�� �ݺ��ϵ��� �Ѵ�.
      try {
        conn = dbConn(ROCDBIP,ROCSID,ROCDBUSER,ROCDBPAWD);
        if( conn == null ){
          ertrace("> DB Connection ERROR -- continue");
          sleepFlag = 0;
          continue;
        }
      }
      catch(Exception ex) {
        ex.printStackTrace();
        ertrace(ex.toString());
        ertrace("> DB Connection ERROR -- continue");
        sleepFlag = 0;
        continue;
      }

      //:~  �������������� �����ֱ��� ������ �����Ѵ�.
      ROC_MAX_DATE = STEP_01_GETmaxdate_INroc(conn,"LFILEINFO");
      if ( ROC_MAX_DATE == null ) {
        ertrace("*************** ROC_MAX_DATE not get ****************");
        sleepFlag = 0;
        try {
          conn.close();
        }
        catch(Exception ex) {
          ertrace(ex.toString());
          ertrace("STEP_01_GETmaxdate_INroc conn.close() ���ܹ߻�");
        }
        continue;
      }

      trace("");
      trace("==========================================================================================");
      trace(">"+GetHostName()+":"+GetSysDate()+":"+GetSysTime() );

      if( (info=STEP_02_GETrecorefile_INhq(conn)) != null )
      {
        trace(">FILENAME:"+info.hostname );
        trace(">FILESIZE:"+info.fsize );

        try {
          //:~ ���������� ���� �����Ƿ� ������ �ٷ� ������ ���� ����
          sleepFlag = 1;
          Sinfo = new HRecordInfo(info.hostseq,info.fname,
                                  info.fsize,"X","X",info.curdate,
                                  info.systime,info.hostname,"0" );
          //:~ 1. ROC�κ��� �ϳ��� ������ �ٿ�ε� �Ѵ�.
          trace(">STEP_04_FTPdownload_FROMroc:-- ST");

          switch( STEP_04_FTPdownload_FROMroc(Sinfo,MODE.charAt(0) ) )
          {
            case -1:
              ertrace(">STEP_04_FTPdownload_FROMroc:-- FAIL -- info.fname:" + info.fname);
              /*
              //:~ ������ ������ ���Ƽ� ����ȣ��Ʈ���� ó���ɶ����� ��õ��Ѵ�.
                if( LUpdateZHRecordInfo(info,"B",conn) ){
                }
                else{
                }
              */
              break;
            case 0:
              trace(">STEP_04_FTPdownload_FROMroc:-- SUCCESS -- info.fname:" + info.fname);

              if( STEP_05_INSERTrecord_INhq(Sinfo) ){

                if( LUpdateZHRecordInfo(Sinfo,"Z",conn) && UpdateZHRecordInfo(Sinfo,"Z") ){
                  trace(">LUpdateZHRecordInfo,UpdateZHRecordInfo -- SUCCESS -- Sinfo.fname:" + info.fname);
                  //=====================================================================

                  STEP_06_CALLbusiness_INhq(Sinfo);
                  //=====================================================================
                }
                else{
                  DeleteHRecordInfo(Sinfo);
                  //���ο��� �ϳ��� ���ڵ带 �μ�Ʈ�ÿ� ������ �߻��� ��쿡��
                  //�̹� ROC�� FILETRANSFERCNT=1�̹Ƿ� �̰��� 0���� �����.
                  LUpdateZHRecordInfo(Sinfo,"X","0",conn);
                  ertrace(">HQ ::" + info.fname + "DELETE - Network fail");
                  ertrace(">HQ :: -- FAIL -- info.fname:" + info.fname);
                }
              }
              else{
                //���ο��� �ϳ��� ���ڵ带 �μ�Ʈ�ÿ� ������ �߻��� ��쿡��
                //�̹� ROC�� FILETRANSFERCNT=1�̹Ƿ� �̰��� 0���� �����.
                LUpdateZHRecordInfo(Sinfo,"X","0",conn);
              }

              break;
          }
        }
        catch(Exception e){
          ertrace(e.toString());
          e.printStackTrace();
          ertrace(">HwaRang "+"Client teminate: "+info.fname);
        }
      }
      else {
        sleepFlag = 0;
      }

      try {
        conn.close();
      }
      catch(Exception ex) {
        ertrace(ex.toString());
        ertrace("STEP_03_GETrecord_INroc conn.close() ���ܹ߻�");
      }

    }
  }

  /////////////////////////////////////////////////////////////////////////
  //   �����ܿ��� �ϳ��� ���Ͽ� ���� ���ڵ带 ���Խ� �̸� �а� FTP ����
  /////////////////////////////////////////////////////////////////////////
  int sleepFlag2=0;

  public HRecordInfo STEP_02_GETrecorefile_INhq(Connection conn)
  {
    int sametablecnt=0;
    String otable="";
    String ntable="";

    while(true)
    {
      try {
        trace(">STEP_02_GETrecorefile_INhq :: ST ===============>");
        trace(">"+GetHostName()+":"+GetSysDate()+":"+GetSysTime() );
        if( sleepFlag2 == 0 ){
          try{
            Thread.currentThread().sleep(10000);
          }catch(Exception ignore) {
          }
        }

        trace(">STEP_03_GETrecord_INroc ST ");

        //if ( (info=STEP_03_GETrecord_INroc(conn)) !=  null )
        if ( (info=STEP_03_GETrecord_INroc_UP(conn)) !=  null )
        {
          trace(">Get record success");
          sleepFlag2 = 1 ;
          return info;
        }
        else
        {
          ertrace(">NO -- RECORD -- ["+message_exception_flag_GetTheRecordInfo+"]");
          sleepFlag2=0;
          //���� �ϳ��� ���ڵ带 ������ ���µ� ������ ���� ��쿡�� ����Ÿ���̽���
          //���� ������ ���� �α����� �����Ѵ�.
          switch( message_exception_flag_GetTheRecordInfo.charAt(0) )
          {
            case 'I':
              break;
            case 'E':
              return null;
            case 'N':
              break;
            default:
              break;
          }
        }
      }
      catch( Exception ex ) {
        ex.printStackTrace();
        ertrace(ex.toString());
        ertrace(">STEP_02_GETrecorefile_INhq -- ERROR --");
        sleepFlag2=0;
        return null;
      }
    }
  }

  public static void main(String args[])
      throws Exception
  {

    System.out.println("================================================");
    System.out.println(" [VN]");
    System.out.println("================================================");
    System.out.println("java -Dhqip=21.101.3.47 -Dhqdbuser=mis -Dhqdbpawd=mis -Dhqsid=DEVMIS ");
    System.out.println("     -Drocip=188.238.50.52 -Drocosuser=cosif -Drocospawd=cosif -Drocdbuser=mis -Drocdbpawd=mis -Drocsid=DEVMIS ");
    System.out.println("     -Dmode=c||n||z -Drocdbip=188.238.50.50 -Dlogmode=on||off");
    System.out.println("     -Dorg_path=/home/cosif/samgokgy/log/org/");
    System.out.println("     -Dtar_path=/home/cosif/samgokgy/log/tar/");
    System.out.println(" com.chb.coses.itf.samgokgy.download.HwaRang ");
    System.out.println("");

    System.out.println("================================================");
    System.out.println(" [US]");
    System.out.println("================================================");
    System.out.println("java -Dhqip=21.101.3.47 -Dhquser=mis -Dhqpawd=mis -Dhqsid=DEVMIS ");
    System.out.println("     -Drocip=21.111.50.52 -Drocosuser=cosif -Drocospawd=cosif -Drocdbuser=usny -Drocdbpawd=usny -Drocsid=USMIS ");
    System.out.println("     -Dmode=c||n||z -Drocdbip=21.111.50.52 -Dlogmode=on||off");
    System.out.println("     -Dorg_path=/home/cosif/samgokgy/log/org/");
    System.out.println("     -Dtar_path=/home/cosif/samgokgy/log/tar/");
    System.out.println(" com.chb.coses.itf.samgokgy.download.HwaRang ");
    System.out.println("");

    /*
    HwaRang hwr = new HwaRang();
    hwr.execute();
    */

    THREADtoRUN.execute(new HwaRang(),"HwaRang_1ho");
    try{
      Thread.currentThread().sleep(5000);
    }
    catch(Exception ex){}

    THREADtoRUN.execute(new HwaRang(),"HwaRang_2ho");

  }

  public HRecordInfo STEP_03_GETrecord_INroc(Connection conn)
  {
    HRecordInfo info = null;

    message_exception_flag_GetTheRecordInfo="I";
    try {
      Statement  stmt = conn.createStatement();
      String sql = "select hostseq,fname,fsize,statFile,commit,curdate,systime,hostname,filetransfercnt from lfileinfo WHERE hostseq||curdate IN (SELECT MIN(hostseq||curdate) FROM lfileinfo WHERE statFile='X' AND commit='X' )";
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next()) {
        info = new HRecordInfo( rs.getString(1),rs.getString(2),rs.getString(3),
                                rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
                                rs.getString(8),rs.getString(9) );
      }
      rs.close();
      stmt.close();
    } catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      message_exception_flag_GetTheRecordInfo="E";
      return null;
    }
    message_exception_flag_GetTheRecordInfo="N";

    return info;
  }

  public synchronized HRecordInfo STEP_03_GETrecord_INroc_UP(Connection conn)
  {
    HRecordInfo info = null;

    message_exception_flag_GetTheRecordInfo="I";
    try {
      Statement  stmt = conn.createStatement();
      String sql = "select hostseq,fname,fsize,statFile,commit,curdate,systime,hostname,filetransfercnt from lfileinfo WHERE hostseq||curdate IN (SELECT MIN(hostseq||curdate) FROM lfileinfo WHERE statFile='X' AND commit='X' AND FILETRANSFERCNT='0')";
      ResultSet rs = stmt.executeQuery(sql);

      if (rs.next()) {
        info = new HRecordInfo( rs.getString(1),rs.getString(2),rs.getString(3),
                                rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),
                                rs.getString(8),rs.getString(9) );
      }
      rs.close();
      stmt.close();
    } catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      message_exception_flag_GetTheRecordInfo="E";
      return null;
    }
    message_exception_flag_GetTheRecordInfo="N";

    ////////////////////////////////////////////////////////////////////////////
    if( info == null){
      return info;
    }
    if( !LUpdateZHRecordInfo_FileTransferCnt(info,"1",conn) ){
      message_exception_flag_GetTheRecordInfo="E";
      return null;
    }
    else
      return info;
    ////////////////////////////////////////////////////////////////////////////
  }

  public static synchronized boolean LUpdateZHRecordInfo_FileTransferCnt(HRecordInfo info,String cnt ,
                                     Connection connection)
  {

    try {
      connection.setAutoCommit(false);
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">LUpdateZHRecordInfo:Connection auto -- FAIL -- ");
      return false;
    }

    ertrace(">LUpdateZHRecordInfo_FileTransferCnt: -- ST");
    try {
      String sql = "UPDATE LFILEINFO SET FILETRANSFERCNT = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      PreparedStatement  pstmt = connection.prepareStatement(sql);
      pstmt.setString(1, cnt);
      pstmt.setString(2, info.fname);
      pstmt.setString(3, info.hostname);
      pstmt.setString(4, info.hostseq);
      pstmt.executeUpdate();
      pstmt.close();
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      try {
        connection.rollback();
        connection.setAutoCommit(true);
      } catch (Exception failure) {
        ertrace(exception.toString());
        exception.printStackTrace();
      }
      ertrace(">LUpdateZHRecordInfo_FileTransferCnt: -- FAIL");
      return false;
    }

    try {
      connection.commit();
      connection.setAutoCommit(true);
    } catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">LUpdateZHRecordInfo_FileTransferCnt: -- FAIL");
      return false;
    }
    ertrace(">LUpdateZHRecordInfo_FileTransferCnt: -- SUCCESS");
    return true;
  }

  public String STEP_01_GETmaxdate_INroc(Connection conn,String tblname)
  {
    String ROC_MAX_DATE = null;
    try {
      Statement  stmt = conn.createStatement();
      String sql = "SELECT max(curdate) FROM " + tblname ;
      ResultSet rs = stmt.executeQuery(sql);
      if (rs.next()) {
        ROC_MAX_DATE = rs.getString(1);
      }
      rs.close();
      stmt.close();
    }
    catch (Exception exception){
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">STEP_01_GETmaxdate_INroc ERROR -- ");
      return null;
    }
    trace(">STEP_01_GETmaxdate_INroc SUCCESS -- ROC_MAX_DATE : " + ROC_MAX_DATE);
    return ROC_MAX_DATE;
  }

  public int STEP_04_FTPdownload_FROMroc(HRecordInfo info,char mode) throws Exception
  {
    String roc_filename = null;
    String tar_filename = null;

    switch( mode )
    {
      //ROC���� �����尡 �ƴҶ� �߾ӿ��� ������� ���ϼ���
      case 'c':
        roc_filename = ORG_PATH+info.fname+".Z";
        tar_filename = TAR_PATH+info.fname+".Z";
        if( !SCompress.exec_sys_command("rsh" + " " + ROCIP + " " + "compress -f" + " " + ORG_PATH+info.fname)) {
          ertrace("SCompress.exec_sys_command::-FAIL-["+"rsh" + " " + ROCIP + " " + "compress -f" + " " + ORG_PATH+info.fname);
          return -1;
        }
        else
          trace("SCompress.exec_sys_command::-SUCCESS-["+"rsh" + " " + ROCIP + " " + "compress -f" + " " + ORG_PATH+info.fname);
        break;
        //ROC���� �������϶�
      case 'z':
        roc_filename = ORG_PATH+info.fname+".Z";
        tar_filename = TAR_PATH+info.fname+".Z";
        break;
        //ROC�� HQ��� ������Ҷ�
      case 'n':
        roc_filename = ORG_PATH+info.fname;
        tar_filename = TAR_PATH+info.fname;
        break;
    }

    if(info.fname == null){
      System.out.println("");
      return -1;
    }

    if( FTPdownload.execute(ROCIP,
                            roc_filename,
                            ROCOSUSER ,
                            ROCOSPAWD )==-1){
      return -1;
    }
    else{
      /////////////////////////////////////////////////////////////////////////
      // ���� ���丮�� Ʋ���ٸ�, CD DIR�ϰų�, FileMove�� �ʿ��ϴ�.
      /////////////////////////////////////////////////////////////////////////
      if( MODE.equals("c") ){
        SCompress.Compress('u',tar_filename);
        tar_filename = TAR_PATH+info.fname;
        trace(">STEP_04_COMPRESS MODE:" + tar_filename);
      }
      else if( MODE.equals("z") ){
        tar_filename = TAR_PATH+info.fname;
        trace(">STEP_04_COMPRESS MODE:" + tar_filename);
      }


      //:~ ���ϻ���� ���Ѵ�.
      long l = FILEsize(tar_filename);

      if( l == -1 ){
        ertrace(">FILEsize RTN:" + l);
        return -1;
      }
      else{
        if( info.fsize.equals(new Long(l).toString()) ){
          trace(">STEP_04_COMPARE EQ TFILESIZE:[" + new Long(l).toString() +"] OFILESIZE:[" +info.fsize +"]" );
          return 0;
        }
        else{
          ertrace(">STEP_04_COMPARE Not TFILESIZE:[" + new Long(l).toString() +"] OFILESIZE:[" +info.fsize +"]" );          return -1;
        }
      }
    }
  }

  public long FILEsize(String fname)
  {
    long strtmp=-1;

    try {
      File f = new File(fname);

      if(f.exists());
      else{
        return -1;
      }
      strtmp=f.length();
    }
    catch(Exception ex) {
      ex.printStackTrace();

      return -1;
    }
    return strtmp;
  }

  public final boolean FILEmove(String orgfname,String tarfname)
  {
    if( FILEcopy(orgfname,tarfname) ){
      if( FILEdel(orgfname) ){
        return true;
      }
      else
        return false;
    }
    else{
      return false;
    }

  }

  public final boolean FILEdel(String fname)
  {
    try {
      File f = new File(fname);

      if(f.exists());
      else
        return false;

      f.delete();
    }
    catch(Exception ex) {
      ex.printStackTrace();
      return false;
    }
    return true;
  }

  public final boolean FILEcopy(String oldfn,String newfn)
  {

    try {
      BufferedReader in = new BufferedReader(new FileReader(oldfn));
      PrintWriter out = new PrintWriter(
          new FileOutputStream(newfn));

      String strtmp;
      while( (strtmp=in.readLine()) != null ) {
        out.println(strtmp);
      }
      in.close();
      out.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
      return false;
    }
    return true;
  }

  public boolean LUpdateZHRecordInfo(HRecordInfo info,String statFile ,String filetransfercnt,
                                     Connection connection)
  {

    try {
      connection.setAutoCommit(false);
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">LUpdateZHRecordInfo:Connection auto -- FAIL -- ");
      return false;
    }

    trace(">LUpdateZHRecordInfo: -- ST");
    try {
      String sql = "UPDATE LFILEINFO SET STATFILE = ?,FILETRANSFERCNT=? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      PreparedStatement  pstmt = connection.prepareStatement(sql);
      pstmt.setString(1, statFile);
      pstmt.setString(2, filetransfercnt);
      pstmt.setString(3, info.fname);
      pstmt.setString(4, info.hostname);
      pstmt.setString(5, info.hostseq);
      pstmt.executeUpdate();
      pstmt.close();
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      try {
        connection.rollback();
        connection.setAutoCommit(true);
      } catch (Exception failure) {
        exception.printStackTrace();
        ertrace(exception.toString());
      }
      ertrace(">LUpdateZHRecordInfo: -- FAIL");
      return false;
    }

    try {
      connection.commit();
      connection.setAutoCommit(true);
    } catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">LUpdateZHRecordInfo: -- FAIL");
      return false;
    }
    info.statFile = statFile;
    trace(">LUpdateZHRecordInfo: -- SUCCESS");
    return true;
  }

  public boolean LUpdateZHRecordInfo(HRecordInfo info,String statFile ,
                                     Connection connection)
  {

    try {
      connection.setAutoCommit(false);
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">LUpdateZHRecordInfo:Connection auto -- FAIL -- ");
      return false;
    }

    trace(">LUpdateZHRecordInfo: -- ST");
    try {
      String sql = "UPDATE LFILEINFO SET STATFILE = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      PreparedStatement  pstmt = connection.prepareStatement(sql);
      pstmt.setString(1, statFile);
      pstmt.setString(2, info.fname);
      pstmt.setString(3, info.hostname);
      pstmt.setString(4, info.hostseq);
      pstmt.executeUpdate();
      pstmt.close();
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      try {
        connection.rollback();
        connection.setAutoCommit(true);
      } catch (Exception failure) {
        ertrace(exception.toString());
        exception.printStackTrace();
      }
      ertrace(">LUpdateZHRecordInfo: -- FAIL");
      return false;
    }

    try {
      connection.commit();
      connection.setAutoCommit(true);
    } catch (Exception exception) {
      ertrace(exception.toString());
      exception.printStackTrace();
      ertrace(">LUpdateZHRecordInfo: -- FAIL");
      return false;
    }
    info.statFile = statFile;
    trace(">LUpdateZHRecordInfo: -- SUCCESS");
    return true;
  }

  public boolean UpdateZHRecordInfo(HRecordInfo info,String statFile )
  {
    boolean ExtFlag = true;
    Connection connection = dbConn(HQIP,this.HQSID ,this.HQDBUSER ,this.HQDBPAWD );

    if (conn == null) {
      ertrace(">UpdateZHRecordInfo :-- Get Connection FAIL -- ");
      return false;
    }

    try {
      connection.setAutoCommit(false);
    }
    catch (Exception exception) {
      ertrace(exception.toString());
      exception.printStackTrace();
      ertrace(">UpdateZHRecordInfo : connection auto -- FAIL -- ");
      return false;
    }

    trace(">UpdateZHRecordInfo: -- ST");
    try {
      String sql = "UPDATE FILEINFO SET STATFILE = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      PreparedStatement  pstmt = connection.prepareStatement(sql);
      pstmt.setString(1, statFile);
      pstmt.setString(2, info.fname);
      pstmt.setString(3, info.hostname);
      pstmt.setString(4, info.hostseq);
      pstmt.executeUpdate();
      pstmt.close();
    }
    catch (Exception exception) {
      ertrace(exception.toString());
      exception.printStackTrace();
      try {
        connection.rollback();
        connection.setAutoCommit(true);
      } catch (Exception failure) {
        ertrace(failure.toString());
        failure.printStackTrace();
      }
      ertrace(">UpdateZHRecordInfo: -- FAIL");
      ExtFlag = false;
    }

    try {
      connection.commit();
      connection.setAutoCommit(true);
    } catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      ertrace(">UpdateZHRecordInfo: -- FAIL");
      ExtFlag = false;
    }

    try {
      conn.close();
    }
    catch(Exception ex) {
      ex.printStackTrace();
      ertrace(ex.toString());
      ertrace(">UpdateZHRecordInfo: -- FAIL");
    }
    return ExtFlag;

  }

  public boolean DeleteHRecordInfo(HRecordInfo info)
  {
    Connection connection = dbConn(HQIP,this.HQSID ,this.HQDBUSER ,this.HQDBPAWD );
    PreparedStatement  pstmt = null;
    boolean rtn = true;

    try {
      String sql = "DELETE FROM FILEINFO WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
      pstmt = connection.prepareStatement(sql);
      pstmt.setString(1, info.fname);
      pstmt.setString(2, info.hostname);
      pstmt.setString(3, info.hostseq);
      pstmt.executeUpdate();
      pstmt.close();
    }
    catch (Exception exception) {
      exception.printStackTrace();
      ertrace(exception.toString());
      rtn = false;
    }

    try {
      if( pstmt != null )
        pstmt.close();
      connection.close();
    } catch (Exception exception) {
      ertrace(exception.toString());
      exception.printStackTrace();
      rtn = false;
    }
    return rtn;
  }

  public int InsertHRecordInfo(String hostseq,String fname,String fsize,
                               String statFile,String commit,String curdate,
                               String systime,String hostname, String filetransfercnt)
  {
    int ExtFlag = 0;
    Connection conn = dbConn(HQIP,this.HQSID ,this.HQDBUSER ,this.HQDBPAWD );
    PreparedStatement  pstmt = null;

    if (conn != null) {
      try {
        String sql = "INSERT INTO FILEINFO VALUES(?,?,?,?,?,?,?,?,?)";
        pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, hostseq);
        pstmt.setString(2, fname);
        pstmt.setString(3, fsize);
        pstmt.setString(4, statFile);
        pstmt.setString(5, commit);
        pstmt.setString(6, curdate);
        pstmt.setString(7, systime);
        pstmt.setString(8, hostname);
        pstmt.setString(9, filetransfercnt);
        pstmt.executeUpdate();
        pstmt.close();
      } catch (Exception e) {
        e.printStackTrace();
        ertrace(e.toString());
        ertrace(""+"ERROR MSG : " + e.getMessage());
        ExtFlag = -1;
      }
      finally {
        try {
          if( pstmt != null )
            pstmt.close();
          conn.close();
        }
        catch(Exception ex) {
          ertrace(ex.toString());
          ertrace("InsertHRecordInfo conn.close() ���ܹ߻�");
          ExtFlag = -1;
        }
        return ExtFlag;
      }
    }
    else {
      System.out.println(""
                         +"================!!! InsertHRecordInfo() ���ܹ߻� !!!================");
      return -1;
    }
  }

  public Connection dbConn(String ip,String sid,String user,String passwd)
  {
    Connection conn = null;
    String DBURL="jdbc:oracle:thin:@"+ip+":1521:"+sid;
    String DBDIRVER="oracle.jdbc.driver.OracleDriver";
    String DBUSER=user;
    String DBPASSWORD=passwd;

    try {
      /*
      System.out.println("DBURL:"+DBURL);
      System.out.println("DBUSER:"+DBUSER);
      System.out.println("DBPASSWORD:"+DBPASSWORD);
      */
      DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
      conn = DriverManager.getConnection (DBURL, DBUSER, DBPASSWORD);
    } catch ( Exception e ) {
      ertrace(e.toString());
      e.printStackTrace();
      return null;
    }
    return conn;
  }

  public void dbClose(Connection conn){
    try {
      conn.close();
    } catch ( Exception e ) {
      e.printStackTrace();
      return;
    }
  }

  public boolean STEP_05_INSERTrecord_INhq(HRecordInfo Sinfo)
  {

    if ( InsertHRecordInfo(Sinfo.hostseq,Sinfo.fname,
                           Sinfo.fsize,Sinfo.statFile,
                           Sinfo.commit,Sinfo.curdate,
                           Sinfo.systime, Sinfo.hostname,
                           Sinfo.filetransfercnt ) == 0 )
    {
      trace(">STEP_05_INSERTrecord_INhq_HQ INSERT RECORD SUCCESS:"+info.fname);
      return true;
    }
    else{
      ertrace(">STEP_05_INSERTrecord_INhq_HQ INSERT RECORD FAIL:"+info.fname);
      return false;
    }
  }



  public int STEP_06_CALLbusiness_INhq(HRecordInfo pinfo)
  {
    HRecordInfo info = pinfo;
    HQBatchEng hb = null;
    Connection conn = dbConn(HQIP ,HQSID ,HQDBUSER,HQDBPAWD);

    int ExtFlag = 0;

    if (conn != null)
    {
      try {
        //:~ ������ ó������ ���� ���� �ִ��� �����Ѵ�.
        String rtnstr=checkPrevious(info,conn,ROC_MAX_DATE);
        if( ! rtnstr.equals("SUCCESS") )
        {
          UpdateZHRecordInfo(info,BEFORE_FILE_ERR_NEXT_PROC_STATFILE_Z);
          return -1;
        }

        hb = new HQBatchEng();
        if( hb.execute(info.fname) ){
          trace(">STEP_06_CALLbusiness_INhq_HQBatchEng:Call#Ok FILENAME:"+info.fname);
          //:~ ���� �������� ȣ���� �����ϰ� ������ FILEINFO ���̺� ���Ž� ������ �߻��ϸ�
          //   �״�� �д�. �׷��� ������ ó���ÿ� ��ó�� �ɼ� �ֵ��� �Ѵ�.
          //   �״�� �ξ ������� ���� �������� �̹� ���ŵ� ���� ��ó���ÿ��� SKIP�ϱ� �����̴�
          UpLoadOk( info, conn );
        }
        else{
          ertrace(">STEP_06_CALLbusiness_INhq_HQBatchEng:Call#FAIL FILENAME:"+info.fname);
          SetCommitSTAT( info, "B", conn );
          ExtFlag = -1;
        }
      }
      catch(Exception ex){
        ertrace(ex.toString());
        ertrace(">STEP_06_CALLbusiness_INhq_HQBatchEng:Call#FAIL FILENAME:"+info.fname);
        ExtFlag = -2;
      }
      finally {
        try {
          conn.close();
        }
        catch(Exception ex) {
          ertrace(ex.toString());
          ertrace("STEP_06_CALLbusiness_INhq conn.close() ���ܹ߻�");
          ExtFlag = -3;
        }
        return ExtFlag;
      }
    }
    else{
      ertrace("[error]STEP_06_CALLbusiness_INhq -- Connection GET ERROR -- :"+info.fname);
      return -1;
    }

  }

  public int SetCommitSTAT( HRecordInfo info, String commit,Connection connection ) {

    if (connection != null ) {
      try {
        connection.setAutoCommit(false);
      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        return -1;
      }

      try {
        String sql = "UPDATE FILEINFO SET COMMIT = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
        PreparedStatement  pstmt = connection.prepareStatement(sql);

        pstmt.setString(1, commit);
        pstmt.setString(2, info.fname);
        pstmt.setString(3, info.hostname);
        pstmt.setString(4, info.hostseq);

        if( pstmt.executeUpdate() == 1 ) ;
        pstmt.close();

      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        try {
          connection.rollback();
          connection.setAutoCommit(true);
        } catch (Exception failure) {
          ertrace(failure.toString());
          exception.printStackTrace();
        }
        return -1;
      }
      try {
        connection.commit();
        connection.setAutoCommit(true);
      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        return -1;
      }
      return 0;
    }
    else {
      ertrace("" +"db Connection error ");
      return -1;
    }
  }

  public int UpLoadOk( HRecordInfo info, Connection connection ) {

    if (connection != null ) {

      try {
        connection.setAutoCommit(false);
      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        return -1;
      }

      try {
        String sql = "UPDATE FILEINFO SET COMMIT = ? WHERE FNAME = ? AND HOSTNAME = ? AND HOSTSEQ = ?";
        PreparedStatement  pstmt = connection.prepareStatement(sql);

        pstmt.setString(1, "Z");
        pstmt.setString(2, info.fname);
        pstmt.setString(3, info.hostname);
        pstmt.setString(4, info.hostseq);

        if( pstmt.executeUpdate() == 1 ) ;

        pstmt.close();

      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        try {
          connection.rollback();
          connection.setAutoCommit(true);
        } catch (Exception failure) {
          ertrace(failure.toString());
          exception.printStackTrace();
        }
        return -1;
      }
      try {
        connection.commit();
        connection.setAutoCommit(true);
      } catch (Exception exception) {
        ertrace(exception.toString());
        exception.printStackTrace();
        return -1;
      }
      return 0;
    }
    else {
      ertrace(""+"db Connection error ");
      return -1;
    }
  }
  public static String memcpy(String org,int len)
  {
    String tar = null;
    try {
      String s1 = org.substring(0,len);
      tar	= s1;
    } catch (Exception e) {
      e.printStackTrace();
      System.out.println(e.getMessage());
      return null;
    }
    return(tar);
  }

  public static String checkPrevious(HRecordInfo info,Connection connection,String BASEDATE)
  {
    ////////////////////////////////////////////////////////////////
    //  ����ġ�� ����Ÿ�� ���� ó������ ���� ���� �ִٸ� ����
    ////////////////////////////////////////////////////////////////

    String mKey =null;
    String tablename=null;

    try {
      Statement  stmt = connection.createStatement();
      tablename = memcpy( info.fname, 15 );
      String sql = "SELECT fname FROM fileinfo WHERE fname like '"
                 +tablename+"%' AND curdate=( SELECT MAX(curdate) FROM fileinfo WHERE curdate < '"
                 +BASEDATE+"' ) AND (statfile !='Z' OR commit !='Z') ";
      tablename = null;
      ResultSet rs = stmt.executeQuery(sql);
      if (rs.next()) {
        tablename = rs.getString(1);
      }
      rs.close();
      stmt.close();
    }
    catch (Exception exception) {
      ertrace(exception.toString());
      exception.printStackTrace();
      return null;
    }
    if ( tablename != null )
    {
      // ����ġ�� ����Ÿ�� �������� �ʴ´�.
      // ���� ���ڵ������� N���� ó���Ѵ�.
      ertrace(">CHECK PREVIOUS TABLE:(No) Table Z-Z stat : " + info.fname );
      return "NO_PRVE_TABLE_DATA";
    }
    else{
      ertrace(">CHECK PREVIOUS TABLE:(OK) Table Z-Z stat : " + info.fname );
      return "SUCCESS";
    }
  }

  public static String GetHostName()
  {
    InetAddress Address=null ;

    try{
      Address = InetAddress.getLocalHost();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      return (null);
    }
    return( Address.getHostName() );
  }


  public static String GetSysTime()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("HHmmssSSS");
    return fmt.format(new java.util.Date()).toString();
  }

  public static String GetSysDate()
  {
    SimpleDateFormat fmt = new SimpleDateFormat("yyyyMMdd");
    return fmt.format(new Date()).toString();
  }

  public void trace(String message){
    if( LOGMODE.equals("on") )
      System.out.println(Thread.currentThread().getName()+"|"+ROCIP+"|"+GetSysDate()+"|"+GetSysTime().substring(0,6)+"|"+ message);
    return;
  }

  public static void ertrace(String message){
      System.out.println(Thread.currentThread().getName()+"|"+ROCIP+"|"+GetSysDate()+"|"+GetSysTime().substring(0,6)+"|"+ message);
    return;
  }

}

class HQBatchEng {

  public boolean execute(String fname){
    return true;
  }
}

/*
////////////////////////////////////////////////////////////////////////////////
 drop table fileinfo;
 drop table lfileinfo;

 CREATE TABLE FILEINFO (
   HOSTSEQ                   VARCHAR2(10) NOT NULL,
   FNAME                     VARCHAR2(30) NOT NULL,
   FSIZE                     VARCHAR2(10) NOT NULL,
   STATFILE					VARCHAR2(2) NOT NULL,
   COMMIT					VARCHAR2(2) NOT NULL,
   CURDATE                   VARCHAR2(8) NOT NULL,
   SYSTIME                   VARCHAR2(10) NOT NULL,
   HOSTNAME                  VARCHAR2(20) NOT NULL,
   FILETRANSFERCNT					VARCHAR2(8) NOT NULL,
   PRIMARY KEY ( HOSTSEQ )
  );

 CREATE TABLE LFILEINFO (
   HOSTSEQ                   VARCHAR2(10) NOT NULL,
   FNAME                     VARCHAR2(30) NOT NULL,
   FSIZE                     VARCHAR2(10) NOT NULL,
   STATFILE					VARCHAR2(2) NOT NULL,
   COMMIT					VARCHAR2(2) NOT NULL,
   CURDATE                   VARCHAR2(8) NOT NULL,
   SYSTIME                   VARCHAR2(10) NOT NULL,
   HOSTNAME                  VARCHAR2(20) NOT NULL,
   FILETRANSFERCNT					VARCHAR2(8) NOT NULL,
   PRIMARY KEY ( HOSTSEQ )
  );
////////////////////////////////////////////////////////////////////////////////
*/

