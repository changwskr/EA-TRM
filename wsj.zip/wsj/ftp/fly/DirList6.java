package wsj.ftp.fly;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

/************************************ 2001.02.01 *************************************************/
/************************************** Update ***************************************************/
/*********************************** Lee Sang Han ************************************************/


/********************************** MAIN *********************************************************/
import java.io.*;
import java.util.*;
import java.net.*;
import java.lang.*;
import java.awt.*;

/********************************* DirList6 Class ************************************************/
public class DirList6 extends Frame   {

   Panel p1,p2;
   Button input_button, output_button, start, stop, auto, exit;
   FileDialog dialog;
   static TextField input_source, output_source, url_source, scope, v_dir_source, skipfile;
   static TextArea textArea;
   static int state;
   static String temp2;
   static Vector seen = new Vector();
   static int input_dir_length;
   static int URL_filename_length;
   static String target_dir;
   static String URL_number;
   static String v_dir;
   static String year, month, day, hour, min, sec;
   static String logfilename, skipfilename;
   static int logstate;

/********************************* setdate() method *********************************************/
 public void setdate()
 {
   Date d = new Date();
   int i = d.getYear() + 1900;
   year = String.valueOf(i);
   int i2 = d.getMonth() + 1;
   month = String.valueOf(i2);
   day = String.valueOf( d.getDate() );
   hour = String.valueOf( d.getHours() );
   min = String.valueOf( d.getMinutes() );
   sec = String.valueOf( d.getSeconds() );
 }
/********************************* setdate() method End ******************************************/

/********************************* logset() method ***********************************************/
 public void logset()
 {
  logfilename = year + "��" + month + "��"+ day + "��"+ hour + "��"+ min + "��"+ sec + "��.txt";
 }
/********************************* logset() method End********************************************/

/************************************ log() method ***********************************************/
 public void log( String s )
 {
   try {
     FileOutputStream fos = new FileOutputStream( logfilename, true );
     PrintStream ps = new PrintStream( fos );
     if( logstate == 0 ){
               ps.print("************ SSI Conversion Program Log *************\n");
               ps.print("Make Log file -- " + logfilename + "\n");
               ps.print(" \n");
               Properties p = System.getProperties();
               p.list( ps );
     }
     else {
     ps.print( s + "\n" );
     ps.close();
     }
    }catch( Exception e ){
                         e.printStackTrace();
                         }
 }
/********************************* log() method End***********************************************/

/********************************* DirList6() method ***********************************************/
 public DirList6() {

   p1 = new Panel( new GridLayout( 5, 3 ) );
   input_source = new TextField( "�ҽ����丮�� �Է��ϼ���", 20 );
   output_source = new TextField( "���������丮�� �Է��ϼ���", 20 );
   url_source = new TextField( "http://localhost:80", 20 );
   v_dir_source = new TextField( "�������丮�� �Է��ϼ���", 20 );
   skipfile = new TextField(20);
   input_button = new Button( "Search1" );
   output_button = new Button( "Search2" );
   textArea = new TextArea( 10, 20 );
   textArea.append( "SSI CONVERSION PROGRAM START\n" );

   p1.add( new Label("  SOURCE DIRECTORY" ));
   p1.add( input_source );
   p1.add( input_button );
   p1.add( new Label( "  TARGET DIRECTORY" ));
   p1.add( output_source );
   p1.add( output_button );
   p1.add( new Label( "  URL ADDRESS" ));
   p1.add( url_source );
   p1.add( new Label( "" ));
   p1.add( new Label( "  VIRTUAL ADDRESS" ));
   p1.add( v_dir_source );
   p1.add( new Label( "" ));
   p1.add( new Label( "  SKIP FILE'S" ));
   p1.add( skipfile );
   p1.add( new Label( "" ));


   p2 = new Panel( new GridLayout( 1, 4 ));

   start = new Button( "Start" );
   stop = new Button( "Stop" );
   auto = new Button( "Auto" );
   scope = new TextField( 10 );
   exit = new Button("Exit");

   p2.add( start );
   p2.add( stop );
   p2.add( scope );
   p2.add( auto );
   p2.add( exit );

   add( "North", p1 );
   add( "Center", textArea );
   add( "South", p2 );
 }
/********************************* DirList6() method End *****************************************/

/************************************ add() method ***********************************************/
 public void add ( String text )
 {
   textArea.append( text +"\n" );
 }
/************************************ add() method End *******************************************/

/************************************ action() method ********************************************/
 public boolean action( Event e, Object arg )
 {
   if( arg.equals( "Exit" ))   {
      textArea.append( "Exit\n" );
      System.exit( 1 );
   }
   if( arg.equals( "Start" ))   {
      try{
      setdate();
      logset();
      log( "1" );
      logstate = 1;
      textArea.setText( "" );
      textArea.append( "Conversion Start.\n" );
      log( "********** Conversion Program Start " );
      log( " " );
      state = 1;
      /* DEBUG MODE
       * Setting parm
       */
      String tmp4 = input_source.getText();
      String tmp5 = output_source.getText();
      temp2 = tmp4.substring( 0, tmp4.length() - 1 );
      target_dir = tmp5.substring( 0, tmp5.length() -1 );
      URL_number = url_source.getText();
      skipfilename = skipfile.getText();
      v_dir = v_dir_source.getText();

      DirList10 dl = new DirList10( temp2 );
      dl.list();
      textArea.append( "Conversion Complete. \n" );
      log( " " );
      log( "********** Conversion Complete " );
      logstate = 0;
      }catch( java.lang.Throwable er ) { handleException( er ); }
   }
   if( arg.equals( "Stop" ))   {
      textArea.append( "Stop\n" );
      state = 2;
   }
   if( arg.equals( "Search1" ))   {
      textArea.append( "�ҽ� ���丮���� " );
      dialog = new FileDialog( this, "Source Directory Select", FileDialog.LOAD );
      dialog.show();
      String directory = dialog.getDirectory();
      String file = dialog.getFile();
      textArea.append( directory + "\n" );
      input_source.setText( directory );
   }
   if( arg.equals( "Search2" ))   {
      textArea.append( "������ ���丮���� " );
      dialog = new FileDialog( this, "Target Directory Select", FileDialog.LOAD );
      dialog.show();
      String directory = dialog.getDirectory();
      String file = dialog.getFile();
      textArea.append( directory + "\n" );
      output_source.setText( directory );
   }
   if( arg.equals( "Search3" ))   {
      textArea.append( "Search3\n" );
   }
   if( arg.equals( "Auto" ))   {
      textArea.append( "Auto\n" );
   }
   return true;
 }
/************************************ action() method End *******************************************/

/************************************ handleException() method **************************************/
 private void handleException( java.lang.Throwable et ) {
   et.printStackTrace();
   log( "handleException: " + et.getMessage() );
 }
/************************************ handleException() method End **********************************/

/************************************ main() method *************************************************/
 public static void main( String args[] ){
        DirList6 f = new DirList6();
        f.pack();
        f.setTitle( "SSI CONVERSION TEST" );
        f.setVisible( true );
   }
/************************************ main() method End**********************************************/

/************************************ DirList10() method ********************************************/
class DirList10 {
 File directory;
 int indent = 2;
 String dir_name = " ���丮 �� ";
 String file_name = " ���� �� ";
 String current_dir;
 String URL_dir;
 String input_dir;
 Thread readthread;

public void temp2( String temp2 ){}

public void target_dir( String target_dir ){}

public void URL_number( String URL_number ){}

public void v_dir( String v_dir ){}

public void run() {
 try{
    }catch( Exception ex) {}
}
/*************************************************************************************************/

 public DirList10 ( String s ) throws IOException {
    this ( new File(s), 2 );
 }
/*************************************************************************************************/

/*************************************************************************************************/
 public DirList10 ( File f ) throws IOException {
    this ( f, 2 );
 }
/*************************************************************************************************/

/*************************************** DirList3 ************************************************/
 public DirList10 ( File directory, int indent ) throws IOException {

    if( directory.isDirectory() ) {                                            /* Check directory */
        this.directory = new File ( directory.getCanonicalPath() );
    }
    else {
        throw new IOException( directory.toString() + " is not a directory" ); /* User input Error */
    }
    this.indent = indent;
    String spaces = "";
    for( int i=0; i<indent-2; i++ ) spaces += "";
    input_dir =  directory.toString();
    int temp = input_dir.length();
    current_dir = spaces + directory + File.separatorChar;                     /* Have Current directory's separatorChar */
    input_dir_length = temp2.length();
    URL_dir = current_dir.substring( input_dir_length );

    textArea.append( "DirList4 Creator--------------START\n" );
    textArea.append( "CURRENT_DIR : " + current_dir + "\n" );
    textArea.append( "URL_DIR : " + URL_dir + "\n" );
    textArea.append( "DirList4 Creator--------------END\n" );

    log( "---------- DirList6 Class Creator Start ----------" );
    log( "CURRENT_DIR : " + current_dir );
    log( "URL_DIR : " + URL_dir );
    log( "---------- DirList6 Class Creator End   ----------" );
  }
/*************************************** End-DirList3*********************************************/

/*************************************** list ****************************************************/
 public void list() throws IOException {

try{
    textArea.append( "list() start\n" );
    if( !seen.contains( this.directory ) ) {
        seen.addElement( this.directory );                                    /* Input directory to Vector */
        String[] files = directory.list();
        String spaces = "";
        String CurAbsDir = "";
        /*
         * DEBUG MODE
         * SHOW ALL LIST OF DIRECTORY
         */
        textArea.append( "Current Directory : " + (String)directory.toString()+ "\n" );
        textArea.append( "Start--------------------------------------\n" );
        log( "Current Directory :" + (String)directory.toString() );
        log( "---------- Start ----------" );

        for (int i=0; i<files.length ;i++ )
        {
                textArea.append( "Child name : " + files[i] + "\n" );
                log( "Child file's name :" + files[i] );
        }

        textArea.append( "End----------------------------------------\n" );
        log( "---------- End ----------" );

        for( int i =0; i < indent; i++ ) spaces +="";
        for( int i=0;  i< files.length; i++ ) {

        File f = new File( directory, files[i] );
            if( f.isFile() ) {                                               /* Check filename */
                String URL_filename_temp = spaces + URL_dir + f.getName();
                String URL_filename = URL_number +"/" +v_dir ;
                URL_filename_length = URL_filename.length();

                String temp4 ="\\";
                int temp3 = URL_filename_temp.length();

                for( int j=0; j < temp3; j++ ) {                              /* Change separator */
                    if( URL_filename_temp.substring( j, j+1 ).equals( temp4 ) )
                        URL_filename = URL_filename + "/";
                    else
                        URL_filename =  URL_filename + URL_filename_temp.substring( j, j+1 );
                }
                /* DEBUG MODE
                 * Change separator
                 */
                textArea.append( "---------------- " + target_dir + " START \n" );
                MakeDir2( target_dir );
                textArea.append( "---------------- " + target_dir + " END \n" );

                String temp14 = " ";
                String temp13 = "";
                int temp12 = URL_filename.length();
                for( int k=0; k < temp12; k++ ){
                     if( URL_filename.substring( k, k+1 ).equals( temp14 ) ){
                         temp13 = temp13 + "%20";
                     }
                     else
                         temp13 = temp13 + URL_filename.substring( k, k+1 );
                }
                URL_filename = temp13;

                textArea.append( " URL_filename : " + URL_filename + "\n" );
                String origin_filename = f.getName();
                MakeDir( URL_filename, URL_filename_length, target_dir );                  /* Make Directory */
                String tmp4 = "Thumbs.db";
                String tmp5 = ".exe";
                String tmp6 = ".asp";
                String tmp7 = ";";
                /* DEBUG MODE
                 * Skip file Search
                 */
                String[] skipfilename_2 = {"","","","","","","","","",""};
                int tmp8 = 0, par=0;
                for( par=0; par < skipfilename.length(); par++ ) {
                    String tmp9 = ( String )skipfilename.substring( par, par+1 );
                    if( tmp9.equals( tmp7) ) { tmp8++; }
                    else{
                        skipfilename_2[tmp8] += skipfilename.substring( par, par+1 );
                        }
                }
                String tmp10 = origin_filename.substring( origin_filename.lastIndexOf(".") );
                int tmp11 = 0;
                for( int par2 = 0; par2 < tmp8; par2++ )
                {
                     if( tmp10.equals(skipfilename_2[par2]) ){
                         tmp11 = 1;
                     }
                }
                /* DEBUG MODE
                 * Copy Skipfile by file System
                 */
                if( tmp11 == 1 ){
                  FileInputStream in = new FileInputStream( temp2 + URL_filename_temp );
                  FileOutputStream out = new FileOutputStream ( target_dir + URL_filename_temp );
                  byte[] buf = new byte[1024];
                  int tmp12=0;
                  while(( tmp12 = in.read( buf )) != -1 )
                   {
                           out.write( buf, 0, tmp12 );
                   }
                  in.close();
                  out.close();
                  log("System copy : " + temp2 + URL_filename_temp + " ---> " + target_dir+URL_filename_temp );
                }
                /* DEBUG MODE
                 * Check Skipfile
                 */
                if( ! origin_filename.equals( tmp4 ) && !origin_filename.substring(origin_filename.length()-4).equals( tmp5 )&& !origin_filename.substring(origin_filename.length()-4).equals( tmp6 ) && tmp11==0) {
                   URLDownload( URL_filename, URL_filename_length, target_dir, origin_filename ); /* Call URLDOWNLOAD method */
                   textArea.setText( "" );
                }

                textArea.append( "\n" );
                textArea.append ( "=======================================================================\n" );
                log( "==================================================================================" );
             }
             else {
                DirList10 dl = new DirList10( f, indent + 2 );
                File localFile = new File( target_dir + URL_dir + files[i] );
                localFile.mkdirs();
                /*
                 * DEBUG MODE
                 * CERTIFY DIRECTORY
                 */
                dl.list();
             }
          }
       }
    seen.removeAllElements();
} catch( Exception ex ) {
                        log("Exception: " + ex.getMessage());
                        }
}
/*************************************** End-list***************************************************/

/*************************************** URLDownload ***********************************************/
 public void URLDownload( String args, int URL_filename_length, String target_dir, String origin_filename ) throws IOException { // URL�� ���� ������ ����

                BufferedInputStream in = null;
                BufferedOutputStream out = null;

                try {
                        /* DEBUG MODE
                         * Open URL Stream
                         */
                        URL url  = new  URL( args );                             /* URL Object make */
                                                                                 /* Get filename from URL_filename */
                        String filename = url.getFile().substring( url.getFile().lastIndexOf('/') + 1 );

                        in = new BufferedInputStream( url.openStream(), 1024 );  /* Open InputStream */

                        String move =target_dir + "/"+args.substring( URL_filename_length +1 ).substring(0,args.substring( URL_filename_length +1 ).lastIndexOf('/')+1);
                        String temp6 = "";
                        int temp7 = move.length();
                        String temp8 ="\\";
                        for( int j=0; j < temp7; j++ ) {                         /* Change separator */
                            if( move.substring( j, j+1 ).equals( temp8 ) )
                                temp6 = temp6 + "/";
                            else
                                temp6 =  temp6 + move.substring( j, j+1 );
                        }
                        String temp10 = "asp";
                        String temp11 = "htm";

                        String temp6_6 = temp6;
                        String tmp2 = "";
                        int tmp = temp6_6.length();
                        String tmp1 = "%";
                        for( int k=0; k < tmp; k++ ){
                             if( temp6_6.substring( k, k+1 ).equals( tmp1 ) ){
                                 tmp2 = tmp2 + " "; k = k+2; }
                             else{
                                 tmp2 = tmp2 + temp6_6.substring( k, k+1 );}

                        }

                        textArea.append( "�̵��� ���丮" + tmp2 + filename + "\n");
                        log( "Source File : " + args + " ----> " + "Target File : " + tmp2 + filename );
                        out = new BufferedOutputStream(	new FileOutputStream( tmp2 +origin_filename )); /* Open OutStream */

                        byte[] buffer = new byte[1024];
                        int nRead=0, nWrote=0;

                        textArea.append( filename + " ������ �ٿ�ε��ϰ� �ֽ��ϴ�.\n" );
                        log( filename + " file downloading..." );
                                                                         /* Writing */
                        while (( nRead = in.read( buffer, 0, 1024 )) >= 0 ) {
                                out.write( buffer, 0, nRead );
                                nWrote += nRead;
                                textArea.append( "#" );
                                Thread.sleep( 10 );
                        }

                        textArea.append( "\n" );
                        textArea.append( filename+" ���Ͽ� "+nWrote+" ����Ʈ�� ����ϴ�.\n" );
                        log( filename+" file "+nWrote+" byte Download Complete" );

                } catch ( MalformedURLException mue ) {

                        textArea.append( "MalformedURLException: " + mue.getMessage()+ "\n" );
                        log( "MalformedURLException: " + mue.getMessage() );

                } catch ( IOException ie ) {

                        textArea.append( "IOException: " + ie.getMessage()+ "\n" );
                        log( "IOException: " + ie.getMessage() );

                } catch ( Exception ex ) {
                                          log( "Exception: " + ex.getMessage() );
                                         }
                finally {
                        try { in.close(); } catch ( IOException ie ) {
                                                   log( "IOException: " + ie.getMessage() );
                                                   }

                        try { out.close(); } catch ( IOException ie ) {
                                                   log( "IOException: " + ie.getMessage() );
                                                   }
     }
}
/*************************************** End-URLDownload *******************************************/

/*************************************** MakeDir ***************************************************/
 public void MakeDir( String args, int URL_filename_length, String target_dir ) {

    if( args.substring( URL_filename_length +1 ).indexOf('/') >= 0 ) {  /* Check New Directory */
        String move = target_dir + "/"+args.substring( URL_filename_length +1 ).substring( 0,args.substring( URL_filename_length +1 ).lastIndexOf('/')+1);
        String temp6 = "";
        int temp7 = move.length();
        String temp8 ="\\";
        for( int j=0; j < temp7; j++ ) {                        /* Change separator */
            if( move.substring( j, j+1 ).equals( temp8 ) )
                temp6 = temp6 + "/";
            else
                temp6 =  temp6 + move.substring( j, j+1 );
        }

       File f = new File( temp6 );
           f.mkdirs();                                           /* Make Directory */
     }
 }
/*************************************** End-MakeDir ***********************************************/

/*************************************** MakeDir2 ***************************************************/
 public void MakeDir2( String target_dir ) {

        String move =target_dir ;
        String temp6 = "";
        int temp7 = move.length();
        String temp8 ="\\";
        for( int j=0; j < temp7; j++ ) {                        /* Change separator */
            if( move.substring( j, j+1 ).equals( temp8 ) )
                temp6 = temp6 + "/";
            else
                temp6 =  temp6 + move.substring( j, j+1 );
        }
       File f = new File( temp6 );
       f.mkdirs();                                             /* Make Directory */
 }
/*************************************** End-MakeDir2 ***********************************************/

/*************************************** encoding ***************************************************/
 public String encoding( String s ) {
        if( s != null )
             return ( new String ( URLEncoder.encode( s )));
        else
             return "0";
 }
/*************************************** End-encoding ***********************************************/

}

}
/*************************************** DirList6 Class End *****************************************/






