package wsj.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class HQSUMfile {

  public HQSUMfile() {
  }
  public static void main(String[] args) {
    HQSUMfile HQSUMfile1 = new HQSUMfile();
  }
}