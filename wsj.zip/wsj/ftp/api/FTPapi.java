package wsj.ftp.api;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FTPapi {

  public FTPapi() {
  }
  public static void main(String[] args) {
    FTPapi FTPapi1 = new FTPapi();
  }
}