package wsj.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.util.StringTokenizer;
import java.io.*;
import java.net.*;
import sun.net.TelnetInputStream;
import sun.net.TelnetOutputStream;
import sun.net.ftp.FtpClient;

public class FtpClientApp {

    static FtpClient FtpClient = null;
    static final int LOCAL_SIZE = 4096;

    public static void main(String argv[]) {

        if (argv.length == 0) {
            System.out.println("usage : java FtpClientApp host");
            return;
        }
        try{
            FtpClient = new FtpClient (argv[0]);

            String user = "userid";
            String password = "password";

            System.out.println("Name ("+argv[0]+") : "+user);
            System.out.println("Password :"+password);
            FtpClient.login(user,password);

        } catch (Exception e) {
            System.out.print("login failed: "+e+"\n");
            return;
        }

        try{

            System.out.println("FTP server connection OK");

            System.out.println("ftp > list");
            listCommand();

            // (2) ascii()
            System.out.println("ftp > ascii");
            asciiCommand();

            // (3) put(fileName)
            System.out.println("ftp > put ftp.tst");
            String fileName  = "ftp.tst";
            putCommand(fileName);

            // (4) get(fileName)
            System.out.println("ftp > get ftp.tst");
            getCommand(fileName);

            // (5) binary()
            System.out.println("ftp > binary");
            binaryCommand();

            // (6) get(fileName)
            System.out.println("ftp > get ftp.tst");
            getCommand(fileName);

            // (7) put(fileName)
            System.out.println("ftp > put ftp.tst");
            putCommand(fileName);

            // (8) cd(directory)
            System.out.println("ftp > cd ..");
            String directory = "..";
            cdCommand(directory);

            // (9) put()
            System.out.println("ftp > list");
            listCommand();

            System.out.println("ftp > quit");

        } catch (Exception e) {
            System.out.println("FtpClient failed: "+e);
        }

        try{
            // closeServer()
            FtpClient.closeServer();
            System.out.println("FTP server connection close");
        } catch (Exception e) {
            System.out.println("logout failed: "+e);
        }
    }

    public static void getCommand(String fileName) throws Exception {

        if(fileName == null){
            System.out.println("usage: ftp> get fileName");
            return;
        }
        // copy a get file
        TelnetInputStream from = FtpClient.get(fileName);
        // Nxx target file is /flash/***
        FileOutputStream to = new FileOutputStream("/flash/"+fileName);
        byte[] buffer = new byte[LOCAL_SIZE];	// for stream buffer
        int bytes_read;				// byte count in stream buffer

        while ((bytes_read = from.read(buffer)) != -1)	// until EOF
            to.write(buffer, 0, bytes_read);		// write it

        to.close();
    }

    public static void putCommand(String fileName) throws Exception {

        if(fileName == null){
            System.out.println("usage: ftp> put fileName");
            return;
        }
        // copy a put file
        // Nxx target file is /flash/***
        FileInputStream from = new FileInputStream("/flash/"+fileName);
        TelnetOutputStream to = FtpClient.put(fileName);
        byte[] buffer = new byte[LOCAL_SIZE];	// for stream buffer
        int bytes_read;				// byte count in stream buffer

        while ((bytes_read = from.read(buffer)) != -1)	// until EOF
            to.write(buffer, 0, bytes_read);	// write it

        from.close();
        to.close();
    }

    public static void listCommand() throws Exception {

        TelnetInputStream getList = FtpClient.list();
        byte Buffer[] =new byte[LOCAL_SIZE];
        int numBytes = 0;

        // printout a file list
        for(;;){
            int b = getList.read();
            if(b == -1) break;
            Buffer[numBytes] = (byte)b;
            ++numBytes;
        }
        String strReadMessage = new String(Buffer,0,numBytes);
        System.out.println(strReadMessage);
    }

    public static void cdCommand(String directory) throws Exception {

        if(directory == null){
            System.out.println("usage: ftp> cd directory");
            return;
        }
        FtpClient.cd(directory);
    }

    public static void binaryCommand() throws Exception {
        FtpClient.binary();
    }

    public static void asciiCommand() throws Exception {
        FtpClient.ascii();
    }

}

