package wsj.ftp;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import sun.net.ftp.FtpClient;

public class FTPdownload {

  public static int execute(String hostname,
                            String path_filename,
                            String username,
                            String password )
  {
    FtpClient fc=null;
    InputStream theFile = null;
    FileOutputStream fos = null;
    String filename ="";
    String directory = "";
    int rtn = 0;

    try {
      int lastSlash = path_filename.lastIndexOf('/');
      filename = path_filename.substring(lastSlash+1);
      directory = path_filename.substring(0, lastSlash);

      System.out.println("");
      System.out.println("===========================================================");
      System.out.println("FTPdownload start>");
      System.out.println("===========================================================");
      System.out.println("Target hostname:"+hostname);
      System.out.println("Target path    :"+directory);
      System.out.println("Target filename:"+path_filename);
    }
    catch (ArrayIndexOutOfBoundsException e) {
      e.printStackTrace();
      return -1;
    }

    try {
      fc = new FtpClient(hostname);
      fc.login(username, password);
      fc.binary();
      fc.cd(directory);
      theFile = fc.get(filename);
      int i = 0;
      fos = new FileOutputStream(filename);
      while((i = theFile.read()) != -1) {
        fos.write((byte)i);
      }
      fc.closeServer();
      fos.close();
    }
    catch (IOException e) {
      e.printStackTrace();
      rtn =-1;
    }

    try
    {
      if( fos != null )
        fos.close();
      if( theFile != null )
        theFile.close();
      if( fc != null )
        fc.closeServer();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    switch( rtn )
    {
      case 0:
        System.out.println("-- SUCCESS --");
        break;
      case -1:
        System.out.println("-- ERROR --");
        break;
    }
    System.out.println("FTP server connection close");
    System.out.println("===========================================================");

    return rtn;
  }

  public static void main(String argv[] ) {
    /*
    execute(String hostname,
                            String path_filename,
                            String username,
                            String password )
    */
    FTPdownload.execute("21.101.3.49",
                        "/home/cosif/samgokgy/src/FTPupload.java.test",
                        "cosif",
                        "cosif");
  }
}